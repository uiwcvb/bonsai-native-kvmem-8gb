// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#pragma once

#include "core/tensor.h"

#include <cuda_runtime.h>

#include <cstdint>

namespace ninfer::ops::detail {

// Private launch entry; the wrapper has validated shape, layout, range and storage.
void attention_feature_sum_launch(const Tensor& input, std::int32_t first, std::int32_t count,
                                  Tensor& sum, cudaStream_t stream);

} // namespace ninfer::ops::detail
