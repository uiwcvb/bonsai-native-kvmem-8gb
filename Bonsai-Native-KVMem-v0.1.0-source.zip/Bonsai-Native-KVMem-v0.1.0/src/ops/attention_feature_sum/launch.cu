// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
// BF16 kernel adapted from KVMem's meank_add_bf16 in src/adapter/llama-kvmem-stagein.cu:
// https://github.com/kvmem/kvmem-llama.cpp/blob/95a2155b75f41eada1398c86b19dcf9703581b30/src/adapter/llama-kvmem-stagein.cu
// Preserves its per-feature lane, old FP32 accumulator, increasing-token addition loop,
// BF16 promotion, final store and 64-thread launch. The Tensor wrapper, contiguous-layout
// specialization and explicit caller stream/storage are NInfer adaptation, not upstream code.
// Upstream declares Apache-2.0 in its README License section; a copy is in /LICENSE.
#include "ops/attention_feature_sum/launch.h"

#include "core/device.h"

#include <cuda_bf16.h>

#include <cstddef>
#include <cstdint>

namespace ninfer::ops::detail {
namespace {

__global__ void attention_feature_sum_bf16_kernel(
    const std::uint8_t* input, float* acc, int tok0, int n_keep, int n_embd, int ne0,
    std::size_t nb0, std::size_t nb1, std::size_t nb2) {
    const int d = static_cast<int>(blockIdx.x) * static_cast<int>(blockDim.x) +
                  static_cast<int>(threadIdx.x);
    if (d >= n_embd || ne0 <= 0) { return; }
    const int head = d / ne0;
    const int dim  = d % ne0;
    float s        = acc[d];
    for (int t = 0; t < n_keep; ++t) {
        const std::size_t off = static_cast<std::size_t>(tok0 + t) * nb2 +
                                static_cast<std::size_t>(head) * nb1 +
                                static_cast<std::size_t>(dim) * nb0;
        s += __bfloat162float(*reinterpret_cast<const __nv_bfloat16*>(input + off));
    }
    acc[d] = s;
}

} // namespace

void attention_feature_sum_launch(const Tensor& input, std::int32_t first, std::int32_t count,
                                  Tensor& sum, cudaStream_t stream) {
    const int width       = static_cast<int>(sum.numel());
    constexpr int threads = 64;
    const int blocks      = (width - 1) / threads + 1;
    constexpr std::size_t nb0 = sizeof(__nv_bfloat16);
    const std::size_t nb1 = static_cast<std::size_t>(input.ne[0]) * nb0;
    const std::size_t nb2 = static_cast<std::size_t>(width) * nb0;
    attention_feature_sum_bf16_kernel<<<blocks, threads, 0, stream>>>(
        static_cast<const std::uint8_t*>(input.data), static_cast<float*>(sum.data), first,
        count, width, input.ne[0], nb0, nb1, nb2);
    CUDA_CHECK(cudaGetLastError());
}

} // namespace ninfer::ops::detail
