// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// NInfer Tensor contract/validation adapter; not the upstream KVMem host API.
#include "ninfer/ops/attention_feature_sum.h"

#include "ops/attention_feature_sum/launch.h"

#include <cstdint>
#include <limits>
#include <stdexcept>

namespace ninfer::ops {

void attention_feature_sum(const Tensor& input, std::int32_t first, std::int32_t count,
                           Tensor& sum, cudaStream_t stream) {
    if (input.dtype != DType::BF16 || sum.dtype != DType::FP32) {
        throw std::invalid_argument("attention_feature_sum: input must be BF16 and sum F32");
    }
    if (input.ne[0] <= 0 || input.ne[1] <= 0 || input.ne[2] <= 0 || input.ne[3] != 1 ||
        sum.ne[0] != input.ne[0] || sum.ne[1] != input.ne[1] || sum.ne[2] != 1 ||
        sum.ne[3] != 1) {
        throw std::invalid_argument("attention_feature_sum: expected input [D,H,T] and sum [D,H]");
    }
    const auto width = static_cast<std::int64_t>(input.ne[0]) * input.ne[1];
    if (width > std::numeric_limits<std::int32_t>::max()) {
        throw std::overflow_error("attention_feature_sum: D*H exceeds int32");
    }
    if (first < 0 || count < 0 || first > input.ne[2] || count > input.ne[2] - first) {
        throw std::invalid_argument("attention_feature_sum: token interval is out of bounds");
    }
    if (!input.is_contiguous() || !sum.is_contiguous()) {
        throw std::invalid_argument("attention_feature_sum: input and sum must be contiguous");
    }
    if (input.data == nullptr || sum.data == nullptr) {
        throw std::invalid_argument("attention_feature_sum: input and sum must be non-null");
    }
    const auto input_address = reinterpret_cast<std::uintptr_t>(input.data);
    const auto sum_address   = reinterpret_cast<std::uintptr_t>(sum.data);
    if (input_address % alignof(std::uint16_t) != 0 || sum_address % alignof(float) != 0) {
        throw std::invalid_argument("attention_feature_sum: storage is not element-aligned");
    }
    const auto input_bytes = input.bytes();
    const auto sum_bytes   = sum.bytes();
    // Subtract addresses instead of adding sizes, avoiding an address-end overflow.
    if (input_address <= sum_address ? sum_address - input_address < input_bytes
                                    : input_address - sum_address < sum_bytes) {
        throw std::invalid_argument("attention_feature_sum: input and sum storage must not overlap");
    }
    if (count == 0) { return; }
    detail::attention_feature_sum_launch(input, first, count, sum, stream);
}

} // namespace ninfer::ops
