# Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
target_sources(ninfer_ops PRIVATE
  "${CMAKE_CURRENT_LIST_DIR}/wrapper.cpp"
  "${CMAKE_CURRENT_LIST_DIR}/launch.cu"
)
