#pragma once

#include "core/weight.h"
#include "core/tensor.h"
#include "ops/common/rowsplit_a8_quantize.h"

#include <cuda_runtime.h>

namespace ninfer::ops::detail {

void q4_q5_attn_input_small_t_launch(const Tensor& x, const Weight& query_key_weight,
                                     const Weight& gate_value_weight, Tensor& q, Tensor& gate,
                                     Tensor& k, Tensor& v, cudaStream_t stream);

void q4_q5_attn_input_mixed_r32_c32_s2_launch(const Tensor& x, const Weight& w0, const Weight& w1,
                                              Tensor& q, Tensor& g, Tensor& k, Tensor& v,
                                              cudaStream_t stream);
void q4_q5_attn_input_mixed_r32_c64_s3_launch(const Tensor& x, const Weight& w0, const Weight& w1,
                                              Tensor& q, Tensor& g, Tensor& k, Tensor& v,
                                              cudaStream_t stream);
void q4_q5_attn_input_pair_r32_c64_s3_launch(const Tensor& x, const Weight& w0, const Weight& w1,
                                             Tensor& q, Tensor& g, Tensor& k, Tensor& v,
                                             cudaStream_t stream);
void q4_q5_attn_input_mixed_pipelined_r128_c128_launch(const Tensor& x, const Weight& w0,
                                                       const Weight& w1, Tensor& q, Tensor& g,
                                                       Tensor& k, Tensor& v, cudaStream_t stream);
// The pipelined tile over an A8 activation (quantized x of the same K and T).
void q4_q5_attn_input_a8_mixed_pipelined_r128_c128_launch(const A8G64Activation& x,
                                                          const Weight& w0, const Weight& w1,
                                                          Tensor& q, Tensor& g, Tensor& k,
                                                          Tensor& v, cudaStream_t stream);

void q4_q5_attn_input_grouped_mma_r32_c64_s4_launch(const Tensor& x, const Weight& query_key_weight,
                                                    const Weight& gate_value_weight, Tensor& q,
                                                    Tensor& gate, Tensor& k, Tensor& v,
                                                    cudaStream_t stream);

} // namespace ninfer::ops::detail
