// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#pragma once

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <span>

namespace ninfer {

class ReadOnlyMappedFile final {
public:
    explicit ReadOnlyMappedFile(const std::filesystem::path& path);
    ~ReadOnlyMappedFile();

    ReadOnlyMappedFile(const ReadOnlyMappedFile&)            = delete;
    ReadOnlyMappedFile& operator=(const ReadOnlyMappedFile&) = delete;
    ReadOnlyMappedFile(ReadOnlyMappedFile&&)                 = delete;
    ReadOnlyMappedFile& operator=(ReadOnlyMappedFile&&)      = delete;

    [[nodiscard]] std::span<const std::uint8_t> bytes() const noexcept;
    // Discard only this clean file view's resident pages, not its address or
    // lease. Borrowed spans remain valid and fault the same bytes back in.
    // This is advisory: callers must remeasure actual allocation headroom.
    void release_resident_pages() const noexcept;

private:
    const std::uint8_t* data_ = nullptr;
    std::size_t size_         = 0;
#ifdef _WIN32
    void* file_handle_    = nullptr;
    void* mapping_handle_ = nullptr;
#else
    int file_descriptor_ = -1;
#endif
};

} // namespace ninfer
