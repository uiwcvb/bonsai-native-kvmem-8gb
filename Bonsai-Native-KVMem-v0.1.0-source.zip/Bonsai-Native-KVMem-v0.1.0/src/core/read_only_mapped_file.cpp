// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#include "core/read_only_mapped_file.h"

#include <limits>
#include <stdexcept>
#include <string>
#include <system_error>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <cerrno>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

namespace ninfer {
namespace {

std::string path_text(const std::filesystem::path& path) {
    const auto encoded = path.u8string();
    return {reinterpret_cast<const char*>(encoded.data()), encoded.size()};
}

[[noreturn]] void throw_io_error(const std::filesystem::path& path, const char* operation,
                                 int error) {
    throw std::invalid_argument("failed to map read-only file '" + path_text(path) +
                                "' during " + operation + ": " +
                                std::system_category().message(error));
}

[[noreturn]] void throw_file_error(const std::filesystem::path& path, const char* operation,
                                   const char* detail) {
    throw std::invalid_argument("failed to map read-only file '" + path_text(path) +
                                "' during " + operation + ": " + detail);
}

} // namespace

ReadOnlyMappedFile::ReadOnlyMappedFile(const std::filesystem::path& path) {
    try {
#ifdef _WIN32
        HANDLE file = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_DELETE,
                                  nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (file == INVALID_HANDLE_VALUE) {
            const DWORD error = GetLastError();
            throw_io_error(path, "CreateFileW", static_cast<int>(error));
        }
        file_handle_ = file;

        SetLastError(NO_ERROR);
        const DWORD file_type = GetFileType(file);
        if (file_type == FILE_TYPE_UNKNOWN) {
            const DWORD error = GetLastError();
            if (error != NO_ERROR) {
                throw_io_error(path, "GetFileType", static_cast<int>(error));
            }
        }
        if (file_type != FILE_TYPE_DISK) {
            throw_file_error(path, "GetFileType", "not a regular disk file");
        }
        BY_HANDLE_FILE_INFORMATION information{};
        if (!GetFileInformationByHandle(file, &information)) {
            const DWORD error = GetLastError();
            throw_io_error(path, "GetFileInformationByHandle", static_cast<int>(error));
        }
        if ((information.dwFileAttributes & (FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_DEVICE)) !=
            0) {
            throw_file_error(path, "GetFileInformationByHandle", "not a regular file");
        }

        LARGE_INTEGER file_size{};
        if (!GetFileSizeEx(file, &file_size)) {
            const DWORD error = GetLastError();
            throw_io_error(path, "GetFileSizeEx", static_cast<int>(error));
        }
        if (file_size.QuadPart <= 0) {
            throw_file_error(path, "GetFileSizeEx", "file is empty or has a negative size");
        }
        const auto unsigned_size = static_cast<std::uint64_t>(file_size.QuadPart);
        if (unsigned_size > std::numeric_limits<std::size_t>::max()) {
            throw_file_error(path, "GetFileSizeEx", "file size exceeds size_t");
        }
        size_ = static_cast<std::size_t>(unsigned_size);

        HANDLE mapping = CreateFileMappingW(file, nullptr, PAGE_READONLY, 0, 0, nullptr);
        if (mapping == nullptr) {
            const DWORD error = GetLastError();
            throw_io_error(path, "CreateFileMappingW", static_cast<int>(error));
        }
        mapping_handle_ = mapping;

        void* view = MapViewOfFile(mapping, FILE_MAP_READ, 0, 0, 0);
        if (view == nullptr) {
            const DWORD error = GetLastError();
            throw_io_error(path, "MapViewOfFile", static_cast<int>(error));
        }
        data_ = static_cast<const std::uint8_t*>(view);
#else
        const int descriptor = open(path.c_str(), O_RDONLY | O_CLOEXEC);
        if (descriptor == -1) {
            const int error = errno;
            throw_io_error(path, "open", error);
        }
        file_descriptor_ = descriptor;

        struct stat information {};
        if (fstat(descriptor, &information) == -1) {
            const int error = errno;
            throw_io_error(path, "fstat", error);
        }
        if (!S_ISREG(information.st_mode)) {
            throw_file_error(path, "fstat", "not a regular file");
        }
        if (information.st_size <= 0) {
            throw_file_error(path, "fstat", "file is empty or has a negative size");
        }
        const auto unsigned_size = static_cast<std::uintmax_t>(information.st_size);
        if (unsigned_size > std::numeric_limits<std::size_t>::max()) {
            throw_file_error(path, "fstat", "file size exceeds size_t");
        }
        size_ = static_cast<std::size_t>(unsigned_size);

        void* view = mmap(nullptr, size_, PROT_READ, MAP_PRIVATE, descriptor, 0);
        if (view == MAP_FAILED) {
            const int error = errno;
            throw_io_error(path, "mmap", error);
        }
        data_ = static_cast<const std::uint8_t*>(view);
#endif
    } catch (...) {
#ifdef _WIN32
        if (data_ != nullptr) { (void)UnmapViewOfFile(const_cast<std::uint8_t*>(data_)); }
        if (mapping_handle_ != nullptr) { (void)CloseHandle(mapping_handle_); }
        if (file_handle_ != nullptr) { (void)CloseHandle(file_handle_); }
        data_          = nullptr;
        mapping_handle_ = nullptr;
        file_handle_    = nullptr;
#else
        if (data_ != nullptr) { (void)munmap(const_cast<std::uint8_t*>(data_), size_); }
        if (file_descriptor_ != -1) { (void)close(file_descriptor_); }
        data_           = nullptr;
        file_descriptor_ = -1;
#endif
        size_ = 0;
        throw;
    }
}

ReadOnlyMappedFile::~ReadOnlyMappedFile() {
#ifdef _WIN32
    if (data_ != nullptr) { (void)UnmapViewOfFile(const_cast<std::uint8_t*>(data_)); }
    if (mapping_handle_ != nullptr) { (void)CloseHandle(mapping_handle_); }
    if (file_handle_ != nullptr) { (void)CloseHandle(file_handle_); }
#else
    if (data_ != nullptr) { (void)munmap(const_cast<std::uint8_t*>(data_), size_); }
    if (file_descriptor_ != -1) { (void)close(file_descriptor_); }
#endif
}

std::span<const std::uint8_t> ReadOnlyMappedFile::bytes() const noexcept {
    return {data_, size_};
}

void ReadOnlyMappedFile::release_resident_pages() const noexcept {
    if (data_ == nullptr || size_ == 0) { return; }
#ifdef _WIN32
    // This view is never VirtualLock'ed. ERROR_NOT_LOCKED is expected:
    // VirtualUnlock still removes unlocked pages from this working-set range.
    (void)VirtualUnlock(const_cast<std::uint8_t*>(data_), size_);
#elif defined(MADV_DONTNEED)
    // The mapping is read-only and file-backed, so subsequent accesses fault
    // the file bytes back in; there are no anonymous or dirty pages to lose.
    (void)madvise(const_cast<std::uint8_t*>(data_), size_, MADV_DONTNEED);
#endif
}

} // namespace ninfer
