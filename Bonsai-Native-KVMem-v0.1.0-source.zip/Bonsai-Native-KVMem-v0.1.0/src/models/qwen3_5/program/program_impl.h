// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#pragma once
#include "models/qwen3_5/program/internal.h"

#include "core/arena.h"
#include "core/gdn_replay_records.h"
#include "core/host_kv_arena.h"
#include "ninfer/ops/gdn_replay.h"
#include "ninfer/ops/sampling.h"
#include "core/decode_graph.h"
#include "models/qwen3_5/frontend/prepared_prompt.h"

#include "models/qwen3_5/program/planning/startup.h"
#include "models/qwen3_5/program/storage/draft_context.h"
#include "models/qwen3_5/program/storage/host_kv_store.h"
#include "models/qwen3_5/program/storage/kv_store.h"
#include "models/qwen3_5/program/storage/state_store.h"
#if defined(NINFER_WITH_KVMEM)
#include "models/qwen3_5/program/storage/kvmem_conversation.h"
#include "models/qwen3_5/program/storage/kvmem_feature_workspace.h"
#include "models/qwen3_5/program/storage/kvmem_follower_execution_map.h"
#include "models/qwen3_5/program/storage/kvmem_follower_retained_pages.h"
#include "models/qwen3_5/program/storage/kvmem_mtp_accepted_keys.h"
#include "models/qwen3_5/program/storage/kvmem_query_checkpoint.h"
#endif
#include "models/qwen3_5/program/prefix_identity.h"
#include "models/qwen3_5/program/speculative/ngram_pool.h"
#include "models/qwen3_5/program/planning/resource_projection.h"
#include "models/qwen3_5/execution/text.h"
#include "models/qwen3_5/execution/vision.h"
#include "models/qwen3_5/program/vision_prefill.h"

#include <algorithm>
#include <cstdint>
#include <array>
#include <limits>
#include <memory>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

namespace ninfer::models::qwen3_5::detail {

class KVMemPageBackend;
class KVMemFollowerPageBackend;
class KVMemConversation;

using PreparedPromptData    = qwen3_5::PreparedPromptData;
using RewriteCheckpointKind = qwen3_5::RewriteCheckpointKind;
using RewriteCheckpointSpec = qwen3_5::RewriteCheckpointSpec;

using ReusePath = ninfer::PrefixReusePath;

[[nodiscard]] constexpr bool is_rewrite_checkpoint_restore(ReusePath path) noexcept {
    return path == ReusePath::PrivateTurnClosure || path == ReusePath::PrivateResponseReplay;
}

[[nodiscard]] constexpr ReusePath restore_path(RewriteCheckpointKind kind) noexcept {
    return kind == RewriteCheckpointKind::TurnClosure ? ReusePath::PrivateTurnClosure
                                                      : ReusePath::PrivateResponseReplay;
}

[[nodiscard]] constexpr runtime::CheckpointKind
checkpoint_kind(RewriteCheckpointKind kind) noexcept {
    return kind == RewriteCheckpointKind::TurnClosure ? runtime::CheckpointKind::TurnClosure
                                                      : runtime::CheckpointKind::ResponseReplay;
}

enum class RewriteCheckpointDisposition : std::uint8_t {
    RetainExisting,
    ReplaceAtCommittedFrontier,
    DropOptional,
};

struct PreparedCaptureBacking {
    std::vector<TokenId> ledger;
    qwen3_5::detail::ResidentPrefixIdentity prefix_identity;
};

struct PreparedCaptureIdentity {
    std::shared_ptr<const PreparedCaptureBacking> backing;
    qwen3_5::PrefixShortlistKey shortlist_key;
    runtime::PrefillWork rebuild_work;

    [[nodiscard]] std::span<const TokenId> ledger() const noexcept {
        if (!backing || shortlist_key.frontier > backing->ledger.size()) { return {}; }
        return std::span<const TokenId>(backing->ledger).first(shortlist_key.frontier);
    }

    [[nodiscard]] const qwen3_5::detail::ResidentPrefixIdentity* prefix_identity() const noexcept {
        return backing ? &backing->prefix_identity : nullptr;
    }

    [[nodiscard]] bool prefix_equals(const PreparedCaptureIdentity& other) const {
        const std::span<const TokenId> left  = ledger();
        const std::span<const TokenId> right = other.ledger();
        const auto* left_identity            = prefix_identity();
        const auto* right_identity           = other.prefix_identity();
        return left_identity != nullptr && right_identity != nullptr &&
               left.size() == right.size() && std::equal(left.begin(), left.end(), right.begin()) &&
               left_identity->prefix_equals(*right_identity, left.size());
    }
};

struct CaptureGroup {
    std::shared_ptr<const PreparedCaptureIdentity> identity;
    std::optional<RewriteCheckpointKind> rewrite;
    std::uint32_t frontier                  = 0;
    std::uint32_t input_order               = 0;
    bool shared                             = false;
    bool long_anchor                        = false;
    SharedCandidateEvidence shared_evidence = SharedCandidateEvidence::None;
};

enum class MtpBridgeMode : std::uint8_t {
    None,
    BeforeSuffix,
    AfterExactHit,
};

} // namespace ninfer::models::qwen3_5::detail

namespace ninfer::models::qwen3_5::detail {

enum class PressureStateDecision : std::uint8_t {
    None,
    DropEndpointDeviceDuplicate,
    DemoteEndpointToHost,
    DropEndpointHostDuplicate,
    DropRewriteDeviceDuplicate,
    DemoteRewriteToHost,
    DropRewriteHostDuplicate,
    DropSharedDeviceDuplicate,
    DemoteSharedToHost,
    DropSharedHostDuplicate,
};

enum class PressureKVDecisionKind : std::uint8_t {
    None,
    DropDeviceDuplicate,
    DemoteToHost,
    DropHostDuplicate,
};

struct PressureKVDecision {
    std::uint32_t begin_page    = 0;
    std::uint32_t page_count    = 0;
    PressureKVDecisionKind kind = PressureKVDecisionKind::None;

    [[nodiscard]] friend constexpr bool operator==(PressureKVDecision,
                                                   PressureKVDecision) noexcept = default;
};

// One Program-private complete outcome for one eligible owner. It may combine State, Main KV,
// Backend KV, and checkpoint changes; common scheduling never observes these physical decisions.
struct PressureDecision {
    std::uint64_t id = 0;
    std::vector<PressureStateDecision> state_changes;
    std::vector<PressureKVDecision> main_kv_changes;
    std::vector<PressureKVDecision> backend_kv_changes;
    std::vector<runtime::CheckpointRef> dropped_checkpoints;
    PhysicalDelta checkpoint_drop_effect;
    PhysicalDelta effect;
    std::vector<runtime::ContextTransferRequirement> transfer_requirements;
    std::uint32_t checkpoint_drops = 0;
    bool evicts_continuation       = false;
    bool shared_owner              = false;

    [[nodiscard]] friend bool operator==(const PressureDecision&,
                                         const PressureDecision&) noexcept = default;
};

struct PressureCheckpointRecoveryProjection {
    runtime::PlanningOwnerId owner;
    runtime::CheckpointRef checkpoint;
    std::uint32_t alternative_offset = 0;
    std::uint32_t alternative_count  = 0;
    bool survives                    = true;
};

struct CaptureAssessmentImpl {
    PhysicalDemand demand;
    PhysicalDelta active_entitlement_delta;
    PhysicalResources capacity_preparation_removed;
};

struct RequestBasePlanImpl {
    runtime::RequestPlanSummary summary;
    detail::PhysicalDemand root_demand;
    runtime::PrefillWork root_rebuild_work;
    std::uint32_t root_rebuild_tail_begin = 0;
    qwen3_5::PreparedContextCache context_cache;
    ops::SamplingConfig sampling;
    std::uint32_t text_kv_page_entitlement    = 0;
    std::uint32_t backend_kv_page_entitlement = 0;
    // The logical request fits the KVMem budget only through a compact sparse
    // view; the current dense prefill path must reject it before admission.
    bool sparse_kv_view_required = false;
    std::shared_ptr<const qwen3_5::VisionControlPlan> vision_control_plan;
    std::optional<qwen3_5::RewriteCheckpointSpec> rewrite_checkpoint;
    std::vector<CaptureGroup> capture_groups;
    std::vector<CaptureGroup> shared_candidates;
    qwen3_5::detail::PrefixShortlistDigests prefix_digests;
    std::uint32_t prefix_identity_tag = 0;
    bool allow_prefix_reuse           = false;
};

// Program-owned physical planning state shared by request materialization and active capture.
// Request scheduling fields never enter this record, and capture never becomes an admission type.
struct ResourceCandidateState {
    runtime::RequestPlanSummary summary;
    runtime::IdentityMaterializationAssessment identity_assessment;
    runtime::ProgramResourceRevision planning_revision;
    // Pressure outcomes are canonicalized against the candidate's identity peak.  Composition
    // rewrites demand to the selected post-pressure peak, so regenerating an outcome from that
    // rewritten demand would compare it against a different problem at seal time.
    detail::PhysicalResources identity_pressure_deficit;
    // A structurally valid pressure target can still be blocked by Host extent geometry even when
    // aggregate free bytes are sufficient. Keep the blocked allocation work explicit so a child
    // target can release Host replicas instead of being mistaken for a structurally invalid node.
    std::size_t blocked_host_allocation_bytes = 0;
    detail::PhysicalDemand demand;
    // Resources released by consuming this private owner alone. Shared aliases are intentionally
    // absent; complete pressure targets settle their joint reference graph separately.
    detail::PhysicalResources source_resources;
    ReusePath reuse                                  = ReusePath::Root;
    std::uint32_t reuse_base                         = 0;
    // Native KVMem keeps checkpoint identity at reuse_base (logical), while
    // the selected address resumes writing at this compact physical frontier.
    // Set only for an exact, consumed endpoint of the currently attached
    // native conversation; other cache paths need their own archive restore.
    std::optional<std::uint32_t> native_physical_reuse_base;
    RewriteCheckpointDisposition rewrite_disposition = RewriteCheckpointDisposition::DropOptional;
    bool has_source                                  = false;
    bool has_shared_source                           = false;
    std::optional<runtime::CheckpointRef> selected_checkpoint;
    std::uint32_t source_index             = 0;
    std::uint64_t source_generation        = 0;
    std::uint32_t shared_source_index      = 0;
    std::uint64_t shared_source_generation = 0;
    runtime::PrefillWork remaining_prefill_work;
    std::vector<runtime::ContextTransferRequirement> transfer_requirements;
    runtime::PrivateSourceMode source_mode = runtime::PrivateSourceMode::ConsumeToActive;
    detail::PhysicalResources active_optional_resources;
    bool state_fork_required          = false;
    bool text_prefix_fork_required    = false;
    bool backend_prefix_fork_required = false;
    bool needs_transfer               = false;
    std::vector<qwen3_5::detail::PressureDecision> pressure_options;
    std::vector<runtime::PlanningOwnerId> pressure_owner_ids;
    std::vector<std::uint32_t> pressure_indices;
    std::vector<std::uint64_t> pressure_generations;
    std::vector<qwen3_5::detail::PressureDecision> shared_pressure_options;
    std::vector<runtime::PlanningOwnerId> shared_pressure_owner_ids;
    std::vector<std::uint32_t> shared_pressure_indices;
    std::vector<std::uint64_t> shared_pressure_generations;
};

struct AdmissionCandidateImpl : ResourceCandidateState {
    MtpBridgeMode mtp_bridge = MtpBridgeMode::None;
    bool prepare_mtp         = false;
    std::optional<VisionPrefillPlan> vision;
    std::vector<CaptureGroup> capture_groups;
    std::vector<CaptureGroup> shared_candidates;
    ops::SamplingConfig sampling;
    std::uint32_t text_kv_page_entitlement    = 0;
    std::uint32_t backend_kv_page_entitlement = 0;
    runtime::LaneId destination{};
    std::uint64_t destination_epoch = 0;
    runtime::PrefillWork root_rebuild_work;
    std::uint32_t root_rebuild_tail_begin = 0;
    bool text_retained_tail_release       = false;
    bool backend_retained_tail_release    = false;
};

struct CapturePressureCandidateImpl : ResourceCandidateState {};

} // namespace ninfer::models::qwen3_5::detail

namespace ninfer::models::qwen3_5::detail {

using AdmissionCandidateImpl       = qwen3_5::detail::AdmissionCandidateImpl;
using CapturePressureCandidateImpl = qwen3_5::detail::CapturePressureCandidateImpl;
using ResourceCandidateState       = qwen3_5::detail::ResourceCandidateState;
using RequestBasePlanImpl          = qwen3_5::detail::RequestBasePlanImpl;
using CapturePressureCandidate     = qwen3_5::CapturePressureCandidate;

enum class PendingKind : std::uint8_t {
    None,
    Begin,
    Ordinary,
    Speculative,
};

struct PendingCandidate {
    PendingKind kind            = PendingKind::None;
    std::uint32_t base_E        = 0;
    std::uint32_t base_S        = 0;
    std::uint32_t prompt_tokens = 0;
    std::uint32_t produced      = 0;
};

enum class Lifecycle : std::uint8_t {
    Empty,
    Prefilling,
    Active,
    Pending,
    Finishable,
};

enum class ContinuationSlotRole : std::uint8_t {
    Free,
    ReservedMaterialization,
    Active,
    Catalogued,
};

struct ContinuationSlot {
    ContinuationSlotRole role = ContinuationSlotRole::Free;
    std::uint64_t generation  = 1;
};

struct RewriteCheckpoint {
    bool valid                 = false;
    RewriteCheckpointKind kind = RewriteCheckpointKind::TurnClosure;
    std::uint32_t frontier     = 0;
    runtime::PrefillWork rebuild_work;
};

struct LongAnchorCheckpoint {
    StateImageHandle state;
    std::uint32_t frontier = 0;
    std::uint32_t ordinal  = 0;
    runtime::PrefillWork rebuild_work;
};

struct SequenceKVBundle {
    KVAddressSpaceHandle text;
    std::optional<KVAddressSpaceHandle> backend;
};

#if defined(NINFER_WITH_KVMEM)
struct KVMemFollowerInstalledView {
    KVAddressSpaceHandle address;
    std::vector<KVMemFollowerExecutionRecord> execution;
    std::uint32_t visible_tokens = 0;
};
#endif

struct DecodeGraphProfile {
    std::uint32_t batch_size             = 1;
    std::uint32_t min_execution_frontier = 0;
    std::uint32_t max_execution_frontier = 0;
    std::uint32_t topology_class         = 0;
    DecodeGraphDefinition definition;
};

struct DecodeGraphTopology {
    std::uint32_t topology_class = 0;
    DecodeGraphExecutable executable;
    std::optional<std::size_t> installed_profile;
};

struct DecodeGraphFamily {
    std::vector<DecodeGraphProfile> profiles;
    std::vector<DecodeGraphTopology> topologies;
};

// Target model continuation for one logical sequence. This state remains meaningful after the
// request which produced it has finished, so it is deliberately separate from request lifecycle,
// output, sampling, and round-control state.
#if defined(NINFER_WITH_KVMEM)
struct NativeRecurrentCheckpoint {
    std::shared_ptr<const KVMemQueryBoundaryCheckpoint> payload;
    bool media_boundary = false;
    runtime::PrefillWork rebuild_work;
    std::uint32_t rebuild_tail_begin = 0;
};
#endif

struct SequenceState {
    std::optional<SequenceKVBundle> kv;
#if defined(NINFER_WITH_KVMEM)
    // A detached native archive follows the persistent continuation, not a
    // reusable execution lane. Only the current Program-active conversation
    // may instead live in ProgramImpl::native_kvmem_conversation.
    std::optional<KVMemConversation::Parked> native_kvmem_parked;
    // Number of accepted rows in the current native tail whose GPU slot pages
    // have already been adopted. Decode can keep a private writable tail until
    // a block closes, then hand those pages to the native slot once.
    std::uint32_t native_tail_materialized_tokens = 0;
    // Exact locations of committed MTP rows in this sequence's *actual*
    // backend writer. This is not inferred from target slots or original
    // positions; pressure can harvest only records still backed by this view.
    std::vector<KVMemFollowerExecutionRecord> native_follower_execution;
    // Pinned multimodal server's bounded conversation-owned checkpoints.
    // Query replay shares the immutable CPU payload, not a second copy.
    std::vector<NativeRecurrentCheckpoint> native_recurrent_checkpoints;
#endif
    ActiveStateBinding state;
    std::optional<StateImageHandle> rewrite_state;
    std::optional<StateImageHandle> reserved_state;
    Tensor tail_hidden;
    Tensor rewrite_checkpoint_hidden;
    std::uint32_t lane = 0;

    std::uint32_t execution_frontier = 0;
    // Set only for a KVMem-selected execution view. The logical frontier above
    // remains the model/RoPE position; this is the next compact KV write slot.
    // Dense continuations intentionally leave it unset so their old coordinate
    // and snapshot contracts remain unchanged.
    std::optional<std::uint32_t> compact_kv_frontier;
    std::uint32_t ledger_frontier    = 0;
    std::vector<TokenId> ledger;
    qwen3_5::detail::ResidentPrefixIdentity prefix_identity;
    qwen3_5::detail::PrefixShortlistDigests prefix_digests;
    std::int32_t rope_delta               = 0;
    std::uint32_t text_kv_valid           = 0;
    std::uint32_t mtp_kv_valid            = 0;
    std::uint32_t dflash_context_frontier = 0;
    std::array<TokenId, qwen3_5::kMtpDecodeMaximumDrafts> mtp_drafts{};
    std::uint32_t mtp_draft_count = 0;
    // Ledger prefix already reported to the n-gram pool; reset where a request rebinds the ledger.
    std::size_t ngram_observed    = 0;
    bool tail_hidden_valid        = false;
    bool endpoint_valid           = false;
    RewriteCheckpoint rewrite_checkpoint;
    std::vector<LongAnchorCheckpoint> long_anchors;
    std::vector<std::uint32_t> shared_prefix_references;
    runtime::PrefillWork rebuild_work;
    std::uint32_t rebuild_tail_begin = 0;
};
struct SharedPrefixState {
    std::optional<SequenceKVBundle> kv;
    StateImageHandle state;
    std::shared_ptr<const PreparedCaptureIdentity> identity;
    std::uint32_t frontier         = 0;
    std::uint32_t backend_frontier = 0;
    std::int32_t rope_delta        = 0;
    bool tail_hidden_valid         = false;
    runtime::PrefillWork rebuild_work;
    std::uint32_t active_references = 0;
};

enum class SharedPrefixSlotRole : std::uint8_t {
    Free,
    ReservedCapture,
    ReservedReplacement,
    Catalogued,
};

struct SharedPrefixSlot {
    SharedPrefixSlotRole role = SharedPrefixSlotRole::Free;
    std::uint64_t generation  = 1;
};

#if defined(NINFER_WITH_KVMEM)
// Request-scoped boundaries, not a second memory policy. The pinned server
// scores Q from an exact user range or a capped suffix, keeps [query,eval_end)
// mandatory, and replays from query only when the selected view changes.
struct KVMemTurnSpans {
    std::uint32_t query_begin = 0;
    std::uint32_t eval_end = 0;
    std::uint32_t capture_begin = 0;
    std::uint32_t capture_end = 0;
    std::uint32_t mandatory_begin = 0;
    std::uint32_t mandatory_end = 0;
    std::uint32_t replay_begin = 0;
    bool capture_exact_user = false;
    bool retrieve = false;
};
#endif

// Request/round control is not retained with a reusable SequenceState. A later concurrent Engine
// gives every occupied request slot its own instance of this state.
struct RequestControl {
    Lifecycle lifecycle = Lifecycle::Empty;
    PendingCandidate pending;
    ops::SamplingConfig sampling_host;
    GenerationTimings timings;
    SpeculativeStats speculative_stats;
    detail::PhysicalResources active_resources;
    detail::PhysicalResources optional_resources;
    bool publish_continuation = true;
#if defined(NINFER_WITH_KVMEM)
    // Set only after the final prompt/replay/MTP bridge checkpoint completes.
    // Normal generation commits advance E; cancelled/failed work cannot publish it.
    std::uint32_t native_evaluation_frontier = 0;
    // Speculative target execution overwrites the continuation hidden row
    // before licensing. Keep the small committed row for zero-column cancel.
    std::vector<std::byte> native_cancel_tail_hidden;
#endif

    struct Prefill {
        PreparedPromptData prompt;
#if defined(NINFER_WITH_KVMEM)
        std::optional<KVMemTurnSpans> native_turn_spans;
        KVMemFeatureWorkspace* native_features = nullptr; // Program-owned fixed capture arena.
        // Also owned by the continuation's bounded native checkpoint history.
        std::shared_ptr<const KVMemQueryBoundaryCheckpoint> native_query_checkpoint;
        std::optional<KVMemConversation::QuerySelectionPreview> native_query_selection;
        // A pressure transition after the query checkpoint invalidates the
        // unchanged-view shortcut even if the final resident IDs match.
        bool native_query_view_changed = false;
        bool native_query_replay_fits = false;
        // The pinned cached-Q selection was applied before this request's
        // suffix, including short turns. Subsequent segments stay on that
        // selected view and capture K only; retained query metadata is frozen.
        bool native_cached_preselected = false;
        // A cached Q could not preserve every mandatory observation or future
        // slot; capture a fresh suffix Q instead of reusing stale metadata.
        bool native_cached_query_fallback = false;
        // First pass has scored and selected history; the next prefill steps
        // overwrite only the current query suffix under the selected view.
        bool native_replaying = false;
        // A previously accepted partial tail is already owned by a native GPU
        // slot. Later chunks must replace its COW writer pages at a boundary.
        std::uint32_t native_materialized_tail_tokens = 0;
#endif
        std::optional<VisionPrefillPlan> vision_plan;
        std::unique_ptr<execution::VisionPrefillSession> vision;
        std::vector<CaptureGroup> capture_groups;
        std::size_t next_capture            = 0;
        std::uint64_t pending_capture_offer = 0;
        std::uint32_t base                  = 0;
        std::uint32_t cursor                = 0;
        std::uint32_t prompt_tokens         = 0;
        std::uint32_t initial_mtp_extent    = 0;
        double elapsed_seconds              = 0.0;
        bool prepare_mtp                    = false;
        ReusePath reuse                     = ReusePath::Root;
        MtpBridgeMode mtp_bridge            = MtpBridgeMode::None;
    };

    std::optional<Prefill> prefill;
};

class ProgramImpl {
public:
    struct PressureRecoveryScratch {
        struct StatePlacement {
            StateImageHandle state;
            bool device = false;
            bool host   = false;
        };

        struct OwnerProjection {
            const SequenceState* sequence                     = nullptr;
            const SharedPrefixState* shared                   = nullptr;
            const qwen3_5::detail::PressureDecision* decision = nullptr;
            runtime::PlanningOwnerId owner;
        };

        struct CheckpointProjection {
            qwen3_5::CheckpointSummary checkpoint;
            StateImageHandle state;
            bool survives = true;
        };

        std::vector<StatePlacement> state_placements;
        std::vector<OwnerProjection> owners;
        std::vector<CheckpointProjection> checkpoints;
        std::vector<std::optional<runtime::CheckpointRecoveryAlternativeWork>> direct_work;
        qwen3_5::ContinuationSummary continuation_summary;
    };

    ProgramImpl(const execution::Parameters& parameters, const SequencePlanImpl& plan,
                DeviceContext& device, const StartupObserver& startup_observer);
    ~ProgramImpl() noexcept;

    [[nodiscard]] RequestBasePlan plan_request(const PreparedPromptData& prompt,
                                               const runtime::ResolvedExecutionOptions& options);
    [[nodiscard]] std::vector<float> causal_score(PreparedPromptData&& prompt,
                                                  std::uint32_t first_target);
    [[nodiscard]] std::optional<AdmissionCandidate> inspect_admission(
        const PreparedPromptData& prompt, const RequestBasePlan& base, runtime::LaneId destination,
        const ContinuationHandle* source, const SharedPrefixHandle* shared_source,
        std::optional<runtime::CheckpointRef> checkpoint, bool must_retain_private_source);
    [[nodiscard]] std::optional<AdmissionCandidate> seal_materialization(
        const AdmissionCandidate& admission, const PreparedPromptData& prompt,
        std::span<const ContinuationHandle* const> pressure_owners,
        std::span<const runtime::PlanningOwnerId> pressure_owner_ids,
        std::span<const qwen3_5::detail::PressureDecision* const> pressure_options,
        std::span<const SharedPrefixHandle* const> shared_pressure_owners,
        std::span<const runtime::PlanningOwnerId> shared_pressure_owner_ids,
        std::span<const qwen3_5::detail::PressureDecision* const> shared_pressure_options);
    [[nodiscard]] std::unique_ptr<CapturePressureCandidateImpl>
    make_capture_physical_candidate(const CaptureAssessment& assessment) const;
    void select_shared_captures(AdmissionCandidate& candidate, const PreparedPromptData& prompt,
                                std::span<const std::uint32_t> frontiers);
    [[nodiscard]] runtime::PrefillWork
    shared_capture_split_prefill_work(const AdmissionCandidate& candidate,
                                      const PreparedPromptData& prompt,
                                      std::span<const std::uint32_t> frontiers);
    [[nodiscard]] runtime::PreflightStatus
    revalidate_materialization(const AdmissionCandidate& plan,
                               const PreparedPromptData& prompt) const;
    [[nodiscard]] runtime::ContextTransactionReserveStatus
    reserve_materialization(AdmissionCandidate&& plan, PreparedPromptData&& prompt,
                            runtime::CancellationFlagView cancellation);
    [[nodiscard]] bool
    persistent_backfill_safe(const RequestBasePlan& blocked_head,
                             const AdmissionCandidate& candidate,
                             std::span<const SequenceHandle> persistent_borrowers) const;
    [[nodiscard]] ContextTransactionProgress
    progress_context_transaction(runtime::CancellationFlagView cancellation);
    void finalize_context_transaction() noexcept;
    [[nodiscard]] bool has_context_transaction() const noexcept;
    [[nodiscard]] PrefillProgress advance_prefill(SequenceHandle sequence,
                                                  runtime::ExecutionTiming* failed_timing);
    [[nodiscard]] CaptureAssessment
    inspect_capture(const CaptureOffer& offer, const SharedPrefixHandle* exact_shared,
                    const SharedPrefixHandle* replacement,
                    std::optional<runtime::CheckpointRef> private_replacement,
                    bool permit_shared_publication) const;
    [[nodiscard]] std::vector<runtime::CheckpointRecoveryAlternativeWork>
    checkpoint_recovery_work(const ContinuationHandle& owner,
                             runtime::CheckpointRef checkpoint) const;
    [[nodiscard]] std::vector<runtime::CheckpointRecoveryAlternativeWork>
    checkpoint_recovery_work(const SharedPrefixHandle& owner,
                             runtime::CheckpointRef checkpoint) const;
    [[nodiscard]] bool shared_capture_matches(const CaptureOffer& offer,
                                              const SharedPrefixHandle& shared) const;
    void skip_capture(CaptureOffer&& offer);
    [[nodiscard]] runtime::ContextTransactionReserveStatus
    reserve_active_capture(CaptureOffer&& offer, const SharedPrefixHandle* exact_shared,
                           const SharedPrefixHandle* replacement,
                           std::optional<runtime::CheckpointRef> private_replacement,
                           bool permit_shared_publication,
                           runtime::CancellationFlagView cancellation);
    [[nodiscard]] runtime::ContextTransactionReserveStatus reserve_active_capture_with_pressure(
        CaptureOffer&& offer, const SharedPrefixHandle* exact_shared,
        const SharedPrefixHandle* replacement,
        std::optional<runtime::CheckpointRef> private_replacement, bool permit_shared_publication,
        CapturePressureCandidate&& pressure, runtime::CancellationFlagView cancellation);
    [[nodiscard]] PendingBatch decode(std::span<const SequenceHandle> sequences,
                                      std::span<const runtime::RoundBudget> budgets,
                                      runtime::ExecutionTiming* failed_timing);
    [[nodiscard]] runtime::ExecutionTiming
    append_forced_tokens(std::span<const SequenceHandle> sequences,
                         std::span<const TokenId> row_major_tokens, std::uint32_t row_stride,
                         std::span<const std::optional<std::uint32_t>> prefix_execution_splits,
                         runtime::ExecutionTiming* failed_timing);
    [[nodiscard]] CommitResult commit(PendingBatch&& pending,
                                      std::span<const runtime::CommitDecision> decisions,
                                      runtime::CommitObservation observation,
                                      runtime::ExecutionTiming* failed_timing);
    [[nodiscard]] DiscardResult abort_pending(PendingBatch&& pending) noexcept;
    [[nodiscard]] FinishResult finish(SequenceHandle sequence) noexcept;
    [[nodiscard]] FinishResult finish_cancelled(SequenceHandle sequence) noexcept;
    [[nodiscard]] AbortResult abort(SequenceHandle sequence) noexcept;
    [[nodiscard]] ReleaseResult release_continuation(ContinuationHandle&& continuation) noexcept;
    [[nodiscard]] ReleaseResult release_shared_prefix(SharedPrefixHandle&& shared) noexcept;
    void fail_all_cleanup() noexcept;
    [[nodiscard]] detail::PhysicalResources admission_capacity() const noexcept;
    [[nodiscard]] bool isolated_request_feasible(const RequestBasePlan& base) const noexcept;

    [[nodiscard]] runtime::ProgramResourceRevision resource_revision() const noexcept {
        return resource_revision_;
    }

    [[nodiscard]] qwen3_5::PhysicalUsageSnapshot physical_usage() const noexcept;

    [[nodiscard]] MemorySummary memory_summary() const noexcept;

    void reset_memory_peaks() noexcept;

    friend struct qwen3_5::detail::PressurePlanningSessionImpl;

    const execution::Parameters& parameters;
    DeviceContext& device;
    const std::uint32_t capacity;
    const std::uint32_t kv_capacity;
    const std::uint32_t max_concurrency;
    const ContextCacheOptions context_cache;
    const std::uint32_t continuation_capacity;
    const std::uint32_t shared_prefix_capacity;
    const std::uint32_t prefill_chunk;
    const std::uint32_t draft_window;
    // MTP: the widest verify window V, and the width of the round in flight (read at commit).
    const std::uint32_t verify_window;
    std::uint32_t mtp_round_width = 0;
    const NgramOptions ngram;
    // Shared by every lane of this Program; only the Engine worker mutates it.
    std::optional<NgramDraftPool> ngram_pool;
    const SpeculativeBackend speculative_backend;
    const KvCacheStorage kv_storage;
    const KVMemOptions kvmem;
    const ProposalHead proposal_head;
    const bool vision_enabled;
    const bool use_cuda_graph;
    const bool causal_scoring;
    const std::size_t kv_payload_bytes;
    const std::size_t text_kv_bytes;
    const std::size_t mtp_kv_bytes;
    const std::size_t gdn_state_bytes;
    const std::size_t dflash_kv_bytes;
    const std::size_t replay_records_bytes;
    const std::size_t graph_allowance_bytes;
    const WorkspacePlan workspace_plan;

    DeviceArena persistent;
    DeviceArena workspace_storage;
    WorkspaceArena work;
    execution::VisionFeatureCache vision_feature_cache;
    std::unique_ptr<qwen3_5::DecoderState> decoder;
    std::unique_ptr<HostKVArena> host_kv_arena;
    std::unique_ptr<LogicalKVPageStore> text_kv_pages;
    std::unique_ptr<KVAddressSpaceStore> text_kv_addresses;
    // The active native conversation owns its block table and CPU archive as
    // one payload, matching the pinned adapter's ConvStore ownership boundary.
    // It is destroyed before its Program-owned GPU backend and page stores.
#if defined(NINFER_WITH_KVMEM)
    std::unique_ptr<KVMemPageBackend> native_kvmem_backend;
    std::unique_ptr<KVMemFollowerPageBackend> native_kvmem_follower_backend;
    std::unique_ptr<KVMemConversation> native_kvmem_conversation;
    std::unique_ptr<KVMemParkedFileCache> native_kvmem_files;
    bool native_kvmem_budget_warned = false;
    // A stable device capture destination is needed by ordinary CUDA Graphs.
    // Its Raw target is rebound when the native conversation owner is reset.
    std::unique_ptr<KVMemFeatureWorkspace> native_prefill_features;
    std::unique_ptr<KVMemFeatureWorkspace> native_decode_features;
    std::optional<execution::AttentionFeatureCapture> native_decode_capture;
    std::unique_ptr<KVMemMtpAcceptedKeys> native_mtp_accepted_keys;
    std::optional<std::uint32_t> native_kvmem_owner;
    bool native_kvmem_poisoned = false;
    // Provisional bound-slot capture cannot exchange the protected GPU owner
    // or add an arena. Its files must also pass a fresh headroom proof before
    // the physical schedule releases any cached owner.
    bool native_kvmem_session_transfer_active = false;
#endif
    std::unique_ptr<LogicalKVPageStore> backend_kv_pages;
    std::unique_ptr<KVAddressSpaceStore> backend_kv_addresses;
    std::unique_ptr<HostKVExtentStore> host_kv_extents;
    std::size_t text_host_kv_page_stride    = 0;
    std::size_t backend_host_kv_page_stride = 0;
    std::unique_ptr<qwen3_5::StateImageDevicePool> state_images;
    std::unique_ptr<qwen3_5::HostStatePool> host_state_images;
    std::unique_ptr<StateImageStore> state_store;
    std::optional<GdnReplayRecords> replay_records;
    std::optional<ops::GdnReplayFoldPlan> replay_fold;
    // MTP with n-gram drafts: the same record planes at the MTP width K+1, for rounds that do not
    // widen to V+1. A round records and folds through the view of its own width.
    std::optional<GdnReplayRecords> narrow_replay_records;
    std::optional<ops::GdnReplayFoldPlan> narrow_replay_fold;

    [[nodiscard]] const GdnReplayRecords* round_replay_records(std::uint32_t width) const;
    [[nodiscard]] const ops::GdnReplayFoldPlan& round_replay_fold(std::uint32_t width) const;
    std::optional<DFlashPersistentState> dflash;
    qwen3_5::RoundState io;
    Tensor prefill_hidden;
    std::optional<Tensor> score_hidden;
    Tensor sampling_config;
    Tensor token_counts;

    std::vector<SequenceState> continuation_states;
    std::vector<ContinuationSlot> continuation_slots;
    std::vector<SharedPrefixState> shared_prefix_states;
    std::vector<SharedPrefixSlot> shared_prefix_slots;
    std::array<std::uint32_t, kMaximumConcurrency> active_continuations{};
    std::array<RequestControl, kMaximumConcurrency> requests;
    std::array<std::uint64_t, kMaximumConcurrency> lane_epochs{};

    DecodeGraphFamily ordinary_graphs;
    DecodeGraphFamily mtp_graphs;
    // MTP rounds at the n-gram verify window V+1; empty without n-gram drafts.
    DecodeGraphFamily mtp_wide_graphs;
    DecodeGraphFamily dflash_graphs;

    std::optional<PinnedHostBuffer> round_host;
    std::optional<PinnedHostBuffer> score_logprobs_host;
    TokenId* host_tokens = nullptr;
    std::optional<PinnedHostBuffer> ordinary_host;
    qwen3_5::OrdinaryDecodeIngress* ordinary_host_ingress = nullptr;
    qwen3_5::OrdinaryDecodeEgress* ordinary_host_egress   = nullptr;
    std::optional<PinnedHostBuffer> mtp_host;
    qwen3_5::MtpDecodeIngress* mtp_host_ingress = nullptr;
    qwen3_5::MtpDecodeEgress* mtp_host_egress   = nullptr;
    std::optional<PinnedHostBuffer> dflash_host;
    qwen3_5::DFlashDecodeIngress* dflash_host_ingress = nullptr;
    qwen3_5::DFlashDecodeEgress* dflash_host_egress   = nullptr;

    std::size_t workspace_logical_peak_bytes = 0;
    std::size_t vision_handoff_peak_bytes    = 0;

    // Fork-local session persistence (disk slots): serialize one catalogued continuation to a
    // host snapshot and rebuild one from a snapshot. Digest identity hashes the ledger prefix
    // (FNV-1a 64, session_snapshot.cpp). The v3 format persists the rewrite checkpoint and long
    // anchors beside the endpoint, so a restored continuation offers every surviving checkpoint
    // frontier that fit the server's state pools and anchor capacity, not just the endpoint.
    [[nodiscard]] std::uint32_t
    continuation_depth(const ContinuationHandle& continuation) const noexcept;
    [[nodiscard]] std::string continuation_digest(const ContinuationHandle& continuation) const;
    [[nodiscard]] std::vector<SlotCheckpoint>
    continuation_checkpoints(const ContinuationHandle& continuation) const;
    [[nodiscard]] qwen3_5::ContinuationSummary
    continuation_summary(const ContinuationHandle& continuation) const;
    [[nodiscard]] qwen3_5::SessionSnapshotInfo
    write_continuation(const ContinuationHandle& continuation, std::string_view model_binding,
                       const qwen3_5::SessionSnapshotSink& sink);
    [[nodiscard]] ContinuationHandle restore_continuation(std::span<const std::uint8_t> snapshot,
                                                          std::string_view model_binding,
                                                          const std::function<void()>& release_input_pages);
#if defined(NINFER_WITH_KVMEM)
    [[nodiscard]] qwen3_5::SessionSnapshotInfo
    write_native_continuation(const ContinuationHandle& continuation,
                              std::string_view model_binding,
                              const qwen3_5::SessionSnapshotSink& sink);
    [[nodiscard]] ContinuationHandle
    restore_native_continuation(std::span<const std::uint8_t> snapshot,
                                std::string_view model_binding,
                                const std::function<void()>& release_input_pages);
#endif
    [[nodiscard]] qwen3_5::SessionSnapshotTraffic session_snapshot_traffic() const noexcept {
        return snapshot_traffic_;
    }

    qwen3_5::SessionSnapshotTraffic snapshot_traffic_;

#if defined(NINFER_WITH_KVMEM)
    bool switch_native_session(const ContinuationHandle* target,
                               std::span<const ContinuationHandle* const> idle_lru,
                               const std::function<void(std::size_t)>& evict_idle,
                               const std::function<runtime::PreparedContextEvictionSave(std::size_t)>&
                                   prepare_eviction_save,
                               std::uint32_t target_frontier = 0,
                               // Explicit snapshot import supplies its own Runtime.
                               bool prepare_empty_owner = true);
    void prepare_empty_native_owner();
    void discard_corrupt_native_session(const ContinuationHandle& target);
    bool balance_native_session_archives(
        std::optional<std::uint32_t> target_index,
        std::span<const ContinuationHandle* const> idle_lru,
        const std::function<void(std::size_t)>& evict_idle,
        const std::function<runtime::PreparedContextEvictionSave(std::size_t)>& prepare_eviction_save,
        std::uint32_t query_width, bool prepare_empty_owner);
    [[nodiscard]] std::optional<PrefixShortlistKey>
    native_session_match(const ContinuationHandle& target,
                         const PreparedPromptData& prompt, const RequestBasePlan& base) const;
    [[nodiscard]] std::shared_ptr<const KVMemQueryBoundaryCheckpoint>
    capture_native_checkpoint(SequenceState& sequence, std::uint32_t frontier,
                              bool media_boundary = false);
    void remember_native_checkpoint(SequenceState& sequence,
                                    std::shared_ptr<const KVMemQueryBoundaryCheckpoint> payload,
                                    bool media_boundary);
    void rewind_native_session(std::uint32_t index, std::uint32_t frontier);
    [[nodiscard]] std::uint64_t native_checkpoint_ram_bytes(const SequenceState& sequence) const;
    [[nodiscard]] bool native_session_attached() const noexcept;
#endif

private:
    void advance_resource_revision() noexcept {
        if (++resource_revision_.value == 0) { ++resource_revision_.value; }
    }

    runtime::ProgramResourceRevision resource_revision_{.value = 1};
    std::uint32_t pressure_planning_generation_ = 0;
    bool pressure_planning_active_              = false;

    struct PressurePageScratchSlot {
        std::uint32_t generation     = 0;
        std::uint32_t selected_index = std::numeric_limits<std::uint32_t>::max();
        std::uint64_t host_group     = 0;
        bool projected               = false;
        bool device                  = false;
        bool host                    = false;
        bool pressure_targeted       = false;
    };

    struct PressureSelectedPage {
        LogicalKVPageHandle page;
        std::uint32_t references = 0;
    };

    struct PressureSelectedState {
        StateImageHandle state;
        bool device = false;
        bool host   = false;
    };

    mutable std::uint32_t pressure_page_scratch_generation_ = 0;
    mutable std::vector<PressurePageScratchSlot> pressure_text_page_scratch_;
    mutable std::vector<PressurePageScratchSlot> pressure_backend_page_scratch_;
    mutable std::vector<PressureSelectedPage> pressure_text_selected_pages_;
    mutable std::vector<PressureSelectedPage> pressure_backend_selected_pages_;
    mutable std::vector<std::uint8_t> pressure_private_owner_scratch_;
    mutable std::vector<std::uint8_t> pressure_shared_owner_scratch_;
    mutable std::vector<std::vector<runtime::CheckpointRef>> pressure_private_drop_scratch_;
    mutable std::vector<PressureSelectedState> pressure_state_scratch_;

    void begin_pressure_page_scratch() const noexcept;
    [[nodiscard]] PressurePageScratchSlot& pressure_page_scratch(const LogicalKVPageStore& store,
                                                                 LogicalKVPageHandle page) const;
    [[nodiscard]] const PressurePageScratchSlot*
    find_pressure_page_scratch(const LogicalKVPageStore& store, LogicalKVPageHandle page) const;

    struct MaterializationSourceProtection {
        struct StateOwnershipCandidate {
            StateImageHandle state;
            std::uint32_t source_checkpoint_references = 0;
        };

        std::optional<std::uint32_t> private_source_index;
        bool consumed_private_source = false;
        std::optional<StateImageHandle> state;
        std::uint32_t consumed_state_references = 0;
        bool state_fork_required                = false;
        std::vector<StateOwnershipCandidate> state_ownership_candidates;
        std::optional<KVAddressSpaceHandle> text;
        std::uint32_t text_pages          = 0;
        std::uint32_t text_transfer_pages = 0;
        bool text_prefix_fork_required    = false;
        std::optional<KVAddressSpaceHandle> backend;
        std::uint32_t backend_pages          = 0;
        std::uint32_t backend_transfer_pages = 0;
        bool backend_prefix_fork_required    = false;
    };

    struct PendingTransaction {
        std::uint64_t id = 0;
        std::array<std::uint32_t, kMaximumConcurrency> lanes{};
        std::array<std::uint64_t, kMaximumConcurrency> epochs{};
        std::size_t size = 0;
    };

    std::optional<PendingTransaction> pending_transaction_;
    std::uint64_t next_transaction_id_ = 1;

    enum class PressureTransitionPhase : std::uint8_t {
        HostReleases,
        CopyPreparation,
        CopiesInFlight,
        CopyPublication,
        Committed,
    };

    struct PressureTransition {
        PressureTransitionPhase phase = PressureTransitionPhase::HostReleases;
        std::array<TransferWork, 3> transfer_work{};
        std::array<std::uint32_t, 3> transfer_pages{};
        std::uint64_t state_images = 0;
        std::uint8_t timer_mask    = 0;
    };

    struct MaterializationTransaction {
        struct KVRestorePage {
            LogicalKVPageHandle logical;
            HostKVExtentCapability extent;
            std::uint32_t extent_page = 0;
        };

        struct PressureWork {
            struct StateChangeWork {
                std::optional<StateImageTransfer> transfer;
                bool host_released = false;
            };

            struct KVChangeWork {
                std::vector<LogicalKVPageHandle> pages;
                std::vector<DeviceKVPageHandle> sources;
                std::optional<HostKVExtentReservation> backup;
                bool host_released = false;
            };

            qwen3_5::detail::PressureDecision option;
            std::uint32_t continuation_index      = 0;
            std::uint64_t continuation_generation = 0;
            bool shared_owner                     = false;
            std::vector<StateChangeWork> state_changes;
            std::vector<KVChangeWork> main_kv_changes;
            std::vector<KVChangeWork> backend_kv_changes;
            detail::PhysicalDelta committed_delta;
            bool submitted                 = false;
            bool completed                 = false;
            bool checkpoint_drop_published = false;
            bool mutation_published        = false;
            std::uint64_t spill_pages      = 0;
        };

        std::uint64_t id = 0;
        runtime::LaneId destination;
        bool has_source                        = false;
        bool has_shared_source                 = false;
        runtime::PrivateSourceMode source_mode = runtime::PrivateSourceMode::ConsumeToActive;
        std::uint32_t source_index             = 0;
        std::uint64_t source_generation        = 0;
        std::uint32_t shared_source_index      = 0;
        std::uint64_t shared_source_generation = 0;
        std::optional<MaterializationSourceResult> source_result;
        std::optional<MaterializationSharedSourceResult> shared_source_result;
        std::vector<std::uint32_t> victim_indices;
        std::vector<std::uint64_t> victim_generations;
        std::vector<bool> victim_released;
        std::vector<PressureWork> pressure;
        std::vector<MaterializationVictimResult> pressure_results;
        std::size_t pressure_cursor = 0;
        std::size_t victim_count    = 0;
        std::vector<std::uint32_t> shared_victim_indices;
        std::vector<std::uint64_t> shared_victim_generations;
        std::vector<bool> shared_victim_released;
        std::vector<MaterializationSharedVictimResult> shared_pressure_results;
        std::vector<PressureWork> shared_pressure;
        std::size_t shared_pressure_cursor = 0;
        std::size_t shared_victim_count    = 0;
        PressureTransition pressure_transition;
        std::optional<AdmissionCandidate> plan;
        std::optional<std::uint32_t> root_continuation_index;
        bool root_waiting_for_victim = false;
        std::array<StateImageHandle, 2> reserved_states{};
        std::size_t reserved_state_count = 0;
        std::optional<StateImageHandle> state_fork_destination;
        std::optional<KVAddressSpaceHandle> root_text_address;
        std::optional<KVAddressSpaceHandle> root_backend_address;
        std::optional<KVActivationReservation> text_activation;
        std::optional<KVActivationReservation> backend_activation;
        std::optional<DeviceKVPageReservation> text_source_restore_reservation;
        std::optional<DeviceKVPageReservation> backend_source_restore_reservation;
        std::optional<KVPrefixForkReservation> text_prefix_fork;
        std::optional<KVPrefixForkReservation> backend_prefix_fork;
        std::optional<LogicalKVPageHandle> text_retained_tail;
        std::optional<LogicalKVPageHandle> backend_retained_tail;
        std::optional<HostKVExtentReservation> text_retained_tail_backup;
        std::optional<HostKVExtentReservation> backend_retained_tail_backup;
        std::optional<std::uint32_t> text_activation_frontier;
        std::optional<std::uint32_t> backend_activation_frontier;
        std::optional<StateImageTransfer> state_restore;
        bool split_state_identity = false;
        std::vector<KVRestorePage> text_restores;
        std::vector<DeviceKVPageHandle> text_restore_destinations;
        std::vector<KVRestorePage> backend_restores;
        std::vector<DeviceKVPageHandle> backend_restore_destinations;
        std::vector<runtime::ContextTransferObservation> transfer_observations;
        runtime::ContextOperationCounts operations;
        bool state_restored                 = false;
        bool transfer_submitted             = false;
        std::uint8_t transfer_timer_mask    = 0;
        bool prefix_tail_submitted          = false;
        bool retained_tail_backup_submitted = false;
        bool prefix_forks_ready             = false;
        bool source_prepared                = false;
        bool cancel_pending                 = false;
        bool prepared                       = false;
        bool terminal                       = false;
    };

    std::uint64_t next_materialization_id_ = 1;
    CudaCompletionEvent context_source_ready_;
    CudaCompletionEvent context_completion_;
    std::vector<TokenId> materialization_ledger_;
    qwen3_5::detail::ResidentPrefixIdentity materialization_identity_;
    qwen3_5::detail::PrefixShortlistDigests materialization_prefix_digests_;

    struct ActiveCaptureTransaction {
        std::uint64_t id         = 0;
        std::uint32_t lane       = 0;
        std::uint64_t lane_epoch = 0;
        CaptureGroup group;
        bool publish_private = false;
        bool publish_shared  = false;
        bool replaces_shared = false;
        std::optional<runtime::CheckpointRef> private_replacement;
        std::optional<std::uint32_t> shared_index;
        std::uint64_t replacement_generation = 0;
        StateImageHandle source_state;
        StateImageHandle destination_state;
        qwen3_5::CaptureStatePlacement state_placement = qwen3_5::CaptureStatePlacement::DeviceFork;
        std::optional<StateImageTransfer> state_snapshot;
        std::optional<KVAddressSpaceHandle> active_text_destination;
        std::optional<KVAddressSpaceHandle> active_backend_destination;
        std::optional<KVActiveSnapshotReservation> text_snapshot;
        std::optional<KVActiveSnapshotReservation> backend_snapshot;
        detail::PhysicalDelta resource_delta;
        detail::PhysicalDelta active_entitlement_delta;
        detail::PhysicalResources capacity_preparation_removed;
        ContinuationSummary active_summary;
        std::vector<runtime::ContextTransferRequirement> transfer_requirements;
        std::vector<runtime::ContextTransferObservation> transfer_observations;
        runtime::ContextOperationCounts operations;
        std::vector<std::uint32_t> victim_indices;
        std::vector<std::uint64_t> victim_generations;
        std::vector<MaterializationTransaction::PressureWork> pressure;
        std::vector<MaterializationVictimResult> pressure_results;
        std::vector<std::uint32_t> shared_victim_indices;
        std::vector<std::uint64_t> shared_victim_generations;
        std::vector<MaterializationTransaction::PressureWork> shared_pressure;
        std::vector<MaterializationSharedVictimResult> shared_pressure_results;
        PressureTransition pressure_transition;
        bool recycles_private_state        = false;
        bool replacement_removed           = false;
        bool prepared                      = false;
        std::uint64_t recycled_state_epoch = 0;
        bool transfer_enqueue_pending      = false;
        bool transfer_submitted            = false;
        std::uint8_t transfer_timer_mask   = 0;
        bool published                     = false;
    };

    std::uint64_t next_capture_offer_id_ = 1;

    using ContextTransaction =
        std::variant<std::monostate, MaterializationTransaction, ActiveCaptureTransaction>;
    ContextTransaction context_transaction_;

    [[nodiscard]] MaterializationResult
    progress_materialization_transaction(runtime::CancellationFlagView cancellation);
    [[nodiscard]] ActiveCaptureResult
    progress_active_capture_transaction(runtime::CancellationFlagView cancellation);
    [[nodiscard]] runtime::ContextTransactionReserveStatus
    reserve_active_capture_impl(CaptureOffer&& offer, const SharedPrefixHandle* exact_shared,
                                const SharedPrefixHandle* replacement,
                                std::optional<runtime::CheckpointRef> private_replacement,
                                bool permit_shared_publication,
                                std::optional<CapturePressureCandidate> pressure,
                                runtime::CancellationFlagView cancellation);

    std::array<CudaEventTimer, 3> context_transfer_timers_;

    [[nodiscard]] std::optional<AdmissionCandidate>
    inspect_lane(std::uint32_t lane, const PreparedPromptData& prompt, const RequestBasePlan& base,
                 const SequenceState* source, const SharedPrefixState* shared_source,
                 std::optional<runtime::CheckpointRef> checkpoint, bool must_retain_private_source);
    [[nodiscard]] StartResult start_request(MaterializationTransaction& transaction);
    // False when the plan went stale between planning and preparation. The caller aborts the
    // transaction instead of failing the Engine: nothing has been mutated at that point.
    [[nodiscard]] bool prepare_materialization(MaterializationTransaction& transaction);
    void enqueue_materialization_transfers(MaterializationTransaction& transaction);
    void record_materialization_transfer_observations(MaterializationTransaction& transaction);
    void publish_materialization_transfers(MaterializationTransaction& transaction);
    void prepare_prefix_forks(MaterializationTransaction& transaction);
    void prepare_consumed_source(MaterializationTransaction& transaction);
    void abort_materialization_transfers(MaterializationTransaction& transaction) noexcept;
    void prepare_pressure_bookkeeping(MaterializationTransaction::PressureWork& work);
    void prepare_pressure_work(MaterializationTransaction::PressureWork& work,
                               runtime::ContextResourceClass resource);
    void publish_pressure_host_releases(MaterializationTransaction::PressureWork& work);
    void publish_pressure_work(MaterializationTransaction::PressureWork& work) noexcept;
    void abort_pressure_work(MaterializationTransaction::PressureWork& work) noexcept;
    void start_context_transfer_timer(runtime::ContextResourceClass resource);
    void stop_context_transfer_timer(runtime::ContextResourceClass resource);
    [[nodiscard]] runtime::ContextTransferObservation context_transfer_observation(
        runtime::ContextResourceClass resource, runtime::ContextTransferDirection direction,
        TransferWork work, std::uint32_t page_count = 0, std::uint64_t state_images = 1) const;

    struct PhysicalReleaseResult {
        runtime::ConsumeStatus status = runtime::ConsumeStatus::InvariantMismatch;
        detail::PhysicalDelta delta;
    };

    [[nodiscard]] PhysicalReleaseResult
    release_materialization_victim(MaterializationTransaction& transaction, std::size_t position);
    void start_sequence(std::uint32_t lane, SequenceState& sequence,
                        MaterializationTransaction& transaction);
    void release_materialization_staging(MaterializationTransaction& transaction) noexcept;
    [[nodiscard]] runtime::PrefillStepResult
    advance_prefill_raw(std::uint32_t lane, runtime::ExecutionTiming* failed_timing);
    [[nodiscard]] runtime::BatchedGeneratedRound
    decode_raw(std::span<const std::uint32_t> lanes, std::span<const runtime::RoundBudget> budgets,
               runtime::ExecutionTiming* failed_timing);
    [[nodiscard]] runtime::ExecutionTiming
    resolve_prefill_raw(std::uint32_t lane, bool terminal, runtime::ExecutionTiming* failed_timing);
    [[nodiscard]] runtime::ExecutionTiming resolve_pending_raw(
        std::span<const std::uint32_t> lanes, std::span<const std::uint32_t> accepted_tokens,
        std::span<const std::uint8_t> terminal, std::span<const std::uint8_t> cancelled,
        std::span<const std::optional<std::uint32_t>> prefix_execution_splits,
        runtime::ExecutionTiming* failed_timing);
    [[nodiscard]] bool valid_sequence(SequenceHandle handle) const noexcept;
    [[nodiscard]] bool valid_continuation(const ContinuationHandle& handle) const noexcept;
    [[nodiscard]] bool valid_shared_prefix(const SharedPrefixHandle& handle) const noexcept;
    [[nodiscard]] bool valid_capture_offer(const CaptureOffer& offer) const noexcept;
    [[nodiscard]] bool materialization_pins(std::uint32_t index,
                                            std::uint64_t generation) const noexcept;
    [[nodiscard]] bool has_unsettled_state_fork() const noexcept;
    [[nodiscard]] bool valid_pending(const PendingBatch& pending) const noexcept;
    // Per-owner resources are intentionally distinct from global physical occupancy: an aliased
    // allocation contributes only when removing this owner would release it.
    [[nodiscard]] detail::PhysicalResources
    owner_exclusive_resources(const SequenceState& sequence) const;
    [[nodiscard]] detail::PhysicalResources
    owner_exclusive_resources(const SharedPrefixState& shared) const;
    [[nodiscard]] detail::PhysicalResources physical_occupancy() const noexcept;
    [[nodiscard]] bool physical_peak_fits(detail::PhysicalResources peak) const noexcept;
    [[nodiscard]] std::optional<StateImageHandle>
    try_selected_state(const SequenceState& sequence, ReusePath reuse,
                       std::optional<runtime::CheckpointRef> checkpoint) const;
    [[nodiscard]] StateImageHandle
    selected_state(const SequenceState& sequence, ReusePath reuse,
                   std::optional<runtime::CheckpointRef> checkpoint) const;
    [[nodiscard]] std::uint32_t
    selected_state_consumed_references(const SequenceState& sequence, ReusePath reuse,
                                       RewriteCheckpointDisposition rewrite_disposition,
                                       std::optional<runtime::CheckpointRef> checkpoint,
                                       std::uint32_t reuse_base) const;
    [[nodiscard]] bool
    selected_state_requires_fork(const SequenceState& sequence, ReusePath reuse,
                                 RewriteCheckpointDisposition rewrite_disposition,
                                 std::optional<runtime::CheckpointRef> checkpoint,
                                 std::uint32_t reuse_base) const;
    [[nodiscard]] bool can_retain_rewrite_checkpoint(const PreparedPromptData& prompt,
                                                     const RewriteCheckpointSpec& desired,
                                                     const SequenceState& sequence, ReusePath reuse,
                                                     std::uint32_t reuse_base) const;
    [[nodiscard]] std::uint32_t device_kv_prefix_pages(const KVAddressSpaceStore& addresses,
                                                       KVAddressSpaceHandle address,
                                                       std::uint32_t frontier) const;
    [[nodiscard]] std::uint32_t shared_kv_prefix_pages(const KVAddressSpaceStore& addresses,
                                                       KVAddressSpaceHandle address,
                                                       std::uint32_t frontier) const;
    [[nodiscard]] std::uint32_t shared_device_kv_prefix_pages(const KVAddressSpaceStore& addresses,
                                                              KVAddressSpaceHandle address,
                                                              std::uint32_t frontier) const;
    [[nodiscard]] bool partial_tail_cow_required(const KVAddressSpaceStore& addresses,
                                                 KVAddressSpaceHandle address,
                                                 std::uint32_t frontier) const;
    [[nodiscard]] std::uint32_t
    missing_shared_device_kv_prefix_pages(const KVAddressSpaceStore& addresses,
                                          KVAddressSpaceHandle address,
                                          std::uint32_t frontier) const;
    [[nodiscard]] std::size_t host_kv_prefix_bytes(const KVAddressSpaceStore& addresses,
                                                   KVAddressSpaceHandle address,
                                                   std::uint32_t frontier) const noexcept;
    [[nodiscard]] qwen3_5::CheckpointSummary
    checkpoint_summary(const SequenceState& sequence, runtime::CheckpointRef checkpoint,
                       StateImageHandle state, runtime::PrefillWork rebuild_work) const;
    [[nodiscard]] qwen3_5::ContinuationSummary
    continuation_summary(const SequenceState& sequence) const;
    void populate_continuation_summary(const SequenceState& sequence,
                                       qwen3_5::ContinuationSummary& summary) const;
    [[nodiscard]] qwen3_5::SharedPrefixSummary
    shared_prefix_summary(const SharedPrefixState& shared) const;
    [[nodiscard]] std::optional<MaterializationSourceProtection>
    materialization_source_protection(const ResourceCandidateState& candidate) const;
    [[nodiscard]] detail::PhysicalResources
    materialization_deficit(const ResourceCandidateState& candidate) const;
    [[nodiscard]] detail::PhysicalResources
    guided_materialization_deficit(const ResourceCandidateState& candidate,
                                   const detail::PhysicalDelta& pressure) const;
    [[nodiscard]] bool
    protected_materialization_page(const MaterializationSourceProtection* protection,
                                   const KVAddressSpaceStore& addresses, std::uint32_t page_offset,
                                   LogicalKVPageHandle page, bool backend) const;
    [[nodiscard]] std::optional<qwen3_5::detail::PressureDecision>
    inspect_pressure_option(const SequenceState& sequence, detail::PhysicalResources deficit,
                            const MaterializationSourceProtection* protection           = nullptr,
                            const qwen3_5::TargetKVRequirement* retained_requirement    = nullptr,
                            std::span<const runtime::CheckpointRef> dropped_checkpoints = {},
                            std::span<const StateImageHandle> released_states           = {},
                            const qwen3_5::detail::PressureDecision* current = nullptr) const;
    [[nodiscard]] std::vector<qwen3_5::detail::PressureDecision>
    inspect_pressure_successors(const SequenceState& sequence, detail::PhysicalResources residual,
                                const MaterializationSourceProtection* protection,
                                const qwen3_5::detail::PressureDecision* current = nullptr) const;
    [[nodiscard]] std::vector<qwen3_5::detail::PressureDecision> inspect_shared_pressure_successors(
        const SharedPrefixState& shared, detail::PhysicalResources residual,
        const MaterializationSourceProtection* protection,
        const qwen3_5::detail::PressureDecision* current = nullptr) const;
    [[nodiscard]] std::optional<qwen3_5::detail::PressureDecision> inspect_shared_pressure_option(
        const SharedPrefixState& shared, detail::PhysicalResources deficit,
        const MaterializationSourceProtection* protection = nullptr,
        const qwen3_5::detail::PressureDecision* current  = nullptr) const;
    [[nodiscard]] std::vector<qwen3_5::detail::PressureDecision> inspect_shared_pressure_options(
        const SharedPrefixState& shared, detail::PhysicalResources deficit,
        const MaterializationSourceProtection* protection = nullptr,
        const qwen3_5::detail::PressureDecision* current  = nullptr) const;
    [[nodiscard]] qwen3_5::detail::PressureDecision
    inspect_eviction_option(const SequenceState& sequence) const;
    [[nodiscard]] qwen3_5::detail::PressureDecision
    inspect_shared_eviction_option(const SharedPrefixState& shared) const;
    [[nodiscard]] std::optional<qwen3_5::detail::PressureDecision>
    inspect_checkpoint_drop_option(const SequenceState& sequence,
                                   std::span<const runtime::CheckpointRef> checkpoints) const;
    [[nodiscard]] bool
    pressure_decision_valid(const SequenceState& sequence,
                            const qwen3_5::detail::PressureDecision& decision,
                            const MaterializationSourceProtection* protection) const;
    [[nodiscard]] bool
    shared_pressure_decision_valid(const SharedPrefixState& shared,
                                   const qwen3_5::detail::PressureDecision& decision,
                                   const MaterializationSourceProtection* protection) const;
    [[nodiscard]] std::vector<runtime::ContextTransferRequirement>
    checkpoint_restore_requirements(const SequenceKVBundle& kv,
                                    const qwen3_5::TargetKVRequirement& requirement,
                                    StateImageHandle state) const;
    [[nodiscard]] bool pressure_checkpoint_recovery_impacts(
        const ResourceCandidateState& candidate,
        std::span<const ContinuationHandle* const> private_owners,
        std::span<const qwen3_5::detail::PressureDecision* const> private_decisions,
        std::span<const runtime::PlanningOwnerId> private_owner_ids,
        std::span<const SharedPrefixHandle* const> shared_owners,
        std::span<const qwen3_5::detail::PressureDecision* const> shared_decisions,
        std::span<const runtime::PlanningOwnerId> shared_owner_ids,
        std::vector<qwen3_5::detail::PressureCheckpointRecoveryProjection>& output,
        std::vector<runtime::CheckpointRecoveryAlternativeWork>& alternatives,
        PressureRecoveryScratch& scratch, std::uint64_t& projection_work) const;
    void publish_checkpoint_drop(SequenceState& sequence, runtime::CheckpointRef checkpoint);
    [[nodiscard]] PrefillProgress wrap_prefill(std::uint32_t lane, runtime::PrefillStepResult step);
    [[nodiscard]] PendingBatch wrap_pending(std::span<const std::uint32_t> lanes,
                                            const runtime::BatchedGeneratedRound& round);
    void invalidate_lane(std::uint32_t lane) noexcept;
    [[nodiscard]] SequenceState& active_sequence(std::uint32_t lane);
    [[nodiscard]] const SequenceState& active_sequence(std::uint32_t lane) const;
    [[nodiscard]] std::optional<std::uint32_t> allocate_continuation_slot() noexcept;
    [[nodiscard]] bool can_release_continuation_slot_strict(std::uint32_t index) const;
    void release_continuation_slot_strict(std::uint32_t index) noexcept;
    void release_continuation_slot_best_effort(std::uint32_t index) noexcept;
    void retire_continuation_slot(std::uint32_t index) noexcept;
    void clear_execution_failure_lanes(std::span<const std::uint32_t> lanes) noexcept;
#if defined(NINFER_WITH_KVMEM)
    void reset_native_kvmem_owner() noexcept;
    void park_current_native_owner_for_switch(bool prepare_empty_owner,
                                               bool allow_compaction = true);
    void restore_parked_native_owner_for_switch(std::uint32_t index,
                                               std::uint32_t target_frontier = 0);
#endif
    [[nodiscard]] bool can_clear_lane_strict(const SequenceState& sequence) const;
    [[nodiscard]] bool clear_lane_strict(SequenceState& sequence, RequestControl& request) noexcept;
    void clear_lane_best_effort(SequenceState& sequence, RequestControl& request) noexcept;
    void ordered_reset(SequenceState& sequence);
    [[nodiscard]] StateImageSelectors state_selectors(const SequenceState& sequence) const;
    [[nodiscard]] detail::PhysicalResources
    sequence_exclusive_state_resources(const SequenceState& sequence) const;
    [[nodiscard]] std::uint32_t owned_checkpoint_references(const SequenceState& sequence,
                                                            StateImageHandle state) const noexcept;
    [[nodiscard]] bool state_exclusive_to_sequence(const SequenceState& sequence,
                                                   StateImageHandle state) const noexcept;
    [[nodiscard]] bool compose_pressure_candidate(
        ResourceCandidateState& candidate,
        std::span<const ContinuationHandle* const> pressure_owners,
        std::span<const runtime::PlanningOwnerId> pressure_owner_ids,
        std::span<const qwen3_5::detail::PressureDecision* const> pressure_options,
        std::span<const SharedPrefixHandle* const> shared_pressure_owners,
        std::span<const runtime::PlanningOwnerId> shared_pressure_owner_ids,
        std::span<const qwen3_5::detail::PressureDecision* const> shared_pressure_options);
    [[nodiscard]] std::optional<detail::PressureTargetProjection> evaluate_pressure_target(
        const MaterializationSourceProtection* protection,
        std::span<const ContinuationHandle* const> pressure_owners,
        std::span<const qwen3_5::detail::PressureDecision> pressure_options,
        std::span<const SharedPrefixHandle* const> shared_pressure_owners,
        std::span<const qwen3_5::detail::PressureDecision> shared_pressure_options,
        std::vector<HostKVPageReplicaRelease>* released_host_pages) const;
    void refresh_state_views(SequenceState& sequence);
    void reserve_state_entitlement(SequenceState& sequence, std::uint32_t slots);
    void settle_state_fork(SequenceState& sequence);
    [[nodiscard]] detail::PhysicalResources
    release_checkpoint_reference(StateImageHandle checkpoint) noexcept;
    [[nodiscard]] bool can_release_shared_prefix_state(std::uint32_t index,
                                                       SharedPrefixSlotRole expected_role) const;
    [[nodiscard]] detail::PhysicalResources
    release_shared_prefix_state_strict(std::uint32_t index,
                                       SharedPrefixSlotRole expected_role) noexcept;
    [[nodiscard]] detail::PhysicalResources
    install_private_capture(SequenceState& sequence, const CaptureGroup& group,
                            StateImageHandle checkpoint,
                            std::optional<runtime::CheckpointRef> replacement);
    void prepare_active_capture(ActiveCaptureTransaction& transaction);
    void enqueue_active_capture_transfers(ActiveCaptureTransaction& transaction);
    void abort_active_capture(ActiveCaptureTransaction& transaction) noexcept;
    [[nodiscard]] ActiveCaptureResult publish_active_capture(ActiveCaptureTransaction& transaction);
    void release_active_shared_references_strict(SequenceState& sequence) noexcept;
    void release_active_shared_references(SequenceState& sequence) noexcept;
    void release_active_sequence_state_strict(SequenceState& sequence) noexcept;
    void release_sequence_state_strict(SequenceState& sequence) noexcept;
    void release_sequence_state(SequenceState& sequence) noexcept;
    void prepare_graphs();
    void install_sampling(SequenceState& sequence, RequestControl& request,
                          const ops::SamplingConfig& config);
    void set_device_i32(Tensor& tensor, std::int32_t value);
    void copy_tail(SequenceState& sequence, const Tensor& source);
    void copy_round_token();
    void
    commit_generated_prefix_identity(SequenceState& sequence, std::uint32_t base_ledger_frontier,
                                     std::span<const TokenId> accepted_tokens,
                                     std::optional<std::uint32_t> prefix_execution_split_after);
    [[nodiscard]] runtime::ExecutionTiming
    resolve_non_speculative_pending(SequenceState& sequence, RequestControl& request,
                                    std::uint32_t accepted_tokens, bool terminal,
                                    std::optional<std::uint32_t> prefix_execution_split_after,
                                    runtime::ExecutionTiming* failed_timing);
    [[nodiscard]] runtime::PrefillStepResult
    advance_prefill(SequenceState& sequence, RequestControl& request,
                    runtime::ExecutionTiming* failed_timing);
    void enqueue_dflash_context_append(std::span<const std::uint32_t> lanes,
                                       std::span<const std::uint32_t> starts,
                                       std::span<const std::uint32_t> counts);
    void validate_licensed_tokens(std::span<const TokenId> tokens) const;
    void mark_workspace_usage(std::size_t phase_bytes) noexcept;
    [[nodiscard]] runtime::BatchedGeneratedRound
    decode_ordinary_batch(std::span<const std::uint32_t> lanes,
                          std::span<const runtime::RoundBudget> budgets,
                          runtime::ExecutionTiming* failed_timing);
#if defined(NINFER_WITH_KVMEM)
    void ensure_native_decode_writable_tail(SequenceState& sequence);
    void adopt_native_decode_tail(SequenceState& sequence);
    [[nodiscard]] bool native_endpoint_tail_published(const SequenceState& sequence) const;
    void archive_native_follower_for_park(
        SequenceState& sequence, const kvmem::KvMemStore& store,
        kvmem::RawKvStore& follower_raw, std::span<const std::uint32_t> outgoing_ids);
    void restore_native_parked_execution(
        SequenceState& sequence, std::span<const std::uint32_t> selected_ids);
    void harvest_native_follower(SequenceState& sequence, const kvmem::KvMemStore& store,
                                 kvmem::RawKvStore& follower_raw,
                                 std::span<const std::uint32_t> outgoing_ids,
                                 std::uint32_t committed_original_frontier,
                                 KVMemFollowerRetainedPages& retained);
    void harvest_native_follower_for_query(
        SequenceState& sequence, const kvmem::KvMemStore& store,
        kvmem::RawKvStore& follower_raw,
        std::uint32_t committed_original_frontier,
        std::span<const std::uint32_t> selected_ids,
        std::uint32_t required_original_frontier,
        KVMemFollowerRetainedPages& retained);
    [[nodiscard]] KVMemFollowerInstalledView install_native_follower_selected(
        const kvmem::KvMemStore& store, std::span<const std::uint32_t> selected_ids,
        std::uint32_t append_reserve_tokens, std::uint32_t lane,
        const kvmem::RawKvStore& follower_raw,
        KVMemFollowerRetainedPages* retained = nullptr);
    void refresh_native_follower_execution(SequenceState& sequence);
#endif
    [[nodiscard]] runtime::BatchedGeneratedRound
    decode_mtp_batch(std::span<const std::uint32_t> lanes,
                     std::span<const runtime::RoundBudget> budgets,
                     runtime::ExecutionTiming* failed_timing);
    [[nodiscard]] runtime::BatchedGeneratedRound
    decode_dflash_batch(std::span<const std::uint32_t> lanes,
                        std::span<const runtime::RoundBudget> budgets,
                        runtime::ExecutionTiming* failed_timing);
    void resize_sequence_kv_entitlement(SequenceState& sequence, std::uint32_t text_pages,
                                        std::uint32_t backend_pages);
    void bind_sequence_kv(SequenceState& sequence);
    void unbind_sequence_kv(SequenceState& sequence) noexcept;
    void ensure_sequence_kv_mapped(SequenceState& sequence, std::uint32_t main_tokens,
                                   std::uint32_t backend_tokens = 0);
    void trim_sequence_kv(SequenceState& sequence, std::uint32_t main_tokens,
                          std::uint32_t backend_tokens = 0);
    void release_sequence_growth_entitlement(SequenceState& sequence) noexcept;
    void release_active_sequence_kv_strict(SequenceState& sequence) noexcept;
    void release_sequence_kv_strict(SequenceState& sequence) noexcept;
    void release_sequence_kv(SequenceState& sequence) noexcept;
    void commit_sequence_kv(SequenceState& sequence, std::uint32_t main_tokens,
                            std::uint32_t backend_tokens = 0);
    [[nodiscard]] qwen3_5::PagedKVCache* backend_kv_cache() noexcept;
    [[nodiscard]] const qwen3_5::PagedKVCache* backend_kv_cache() const noexcept;
    [[nodiscard]] std::uint32_t backend_kv_valid(const SequenceState& sequence) const noexcept;
    [[nodiscard]] qwen3_5::PagedKVCacheView text_kv_view(const SequenceState& sequence) const;
    [[nodiscard]] qwen3_5::PagedKVCacheView mtp_kv_view(const SequenceState& sequence) const;
};

} // namespace ninfer::models::qwen3_5::detail

namespace ninfer::models::qwen3_5::detail {

struct PressurePlanningSessionImpl {
    using Core                         = ProgramImpl;
    using AdmissionCandidate           = qwen3_5::AdmissionCandidate;
    using CapturePressureCandidate     = qwen3_5::CapturePressureCandidate;
    using AdmissionCandidateImpl       = qwen3_5::detail::AdmissionCandidateImpl;
    using CapturePressureCandidateImpl = qwen3_5::detail::CapturePressureCandidateImpl;
    using CandidateState               = qwen3_5::detail::ResourceCandidateState;
    using ContinuationHandle           = qwen3_5::ContinuationHandle;
    using SharedPrefixHandle           = qwen3_5::SharedPrefixHandle;

    struct Owner {
        const ContinuationHandle* private_handle = nullptr;
        const SharedPrefixHandle* shared_handle  = nullptr;
        runtime::PlanningOwnerId id;
        bool shared = false;
    };

    struct PhysicalCandidateBinding {
        const CandidateState* state                 = nullptr;
        const AdmissionCandidateImpl* admission     = nullptr;
        const CapturePressureCandidateImpl* capture = nullptr;
    };

    struct TargetNode {
        std::uint32_t candidate_index      = 0;
        std::uint32_t victim_choice_offset = 0;
        std::uint32_t victim_choice_count  = 0;
        std::optional<detail::PhysicalResources> assessed_residual;
        std::uint32_t next_expansion_owner = 0;
        std::uint32_t stable_ordinal       = 0;
        bool root_maximal                  = false;
    };

    struct CandidateVictimOptions {
        std::uint32_t owner_index = 0;
        std::vector<PressureDecision> decisions;
        std::uint16_t eviction_choice = 0;
    };

    struct CandidateOptions {
        std::vector<CandidateVictimOptions> victims;
        bool populated = false;
    };

    struct PreparedOwnerDecision {
        std::uint32_t candidate_index = 0;
        std::uint32_t victim_index    = 0;
        std::uint16_t choice          = 0;
        PressureDecision decision;
    };

    struct AssessmentSlot {
        std::vector<runtime::PressureOwnerOutcome> owner_outcomes;
        std::vector<runtime::PressureCheckpointRecoveryImpact> checkpoint_impacts;
        std::vector<runtime::CheckpointRecoveryAlternativeWork> recovery_alternatives;
        std::uint32_t generation = 1;
        bool leased              = false;
    };

    struct ConstructionOption {
        std::size_t victim = 0;
        PressureDecision decision;
        bool identity = false;
    };

    struct ConstructionSlot {
        std::vector<std::uint16_t> choices;
        std::vector<ConstructionOption> options;
        std::size_t next_owner        = 0;
        std::size_t next_option       = 0;
        std::uint32_t candidate_index = 0;
        std::uint32_t generation      = 0;
        std::uint32_t scan_generation = 1;
        detail::PhysicalResources residual;
        bool restore = false;
        bool leased  = false;
    };

    PressurePlanningSessionImpl(
        Core& owner, std::span<const PhysicalCandidateBinding> physical_candidates,
        std::span<const runtime::PlanningCandidateId> admission_candidate_ids,
        std::span<const ContinuationHandle* const> private_owners,
        std::span<const runtime::PlanningOwnerId> private_owner_ids,
        std::span<const SharedPrefixHandle* const> shared_owners,
        std::span<const runtime::PlanningOwnerId> shared_owner_ids);
    ~PressurePlanningSessionImpl() noexcept;

    [[nodiscard]] qwen3_5::PressureTargetHandle
    identity_target(runtime::PlanningCandidateId candidate) const;
    [[nodiscard]] qwen3_5::PressureTargetHandle
    root_maximal_target(runtime::PlanningCandidateId root_candidate);
    [[nodiscard]] qwen3_5::PressureTargetHandle
    maximal_target(runtime::PlanningCandidateId candidate);
    [[nodiscard]] qwen3_5::PressureConstructionCursor
    begin_construction(qwen3_5::PressureTargetHandle target, bool restore = false);
    [[nodiscard]] runtime::PressureConstructionStep
    next_construction_option(qwen3_5::PressureConstructionCursor& cursor);
    void choose_construction(qwen3_5::PressureConstructionCursor& cursor,
                             runtime::PressureConstructionOptionId option);
    [[nodiscard]] std::optional<qwen3_5::PressureTargetHandle>
    construction_target(const qwen3_5::PressureConstructionCursor& cursor);
    [[nodiscard]] ConstructionSlot&
    construction_slot(const qwen3_5::PressureConstructionCursor& cursor);
    static void release_construction(const void*, std::uint32_t, std::uint32_t) noexcept;
    [[nodiscard]] runtime::PressureTargetGuidance
    guidance_choices(std::uint32_t candidate_index, std::span<const std::uint16_t> choices,
                     std::uint32_t ordinal,
                     std::optional<std::size_t> override_owner = std::nullopt,
                     const PressureDecision* override_decision = nullptr);
    [[nodiscard]] detail::PhysicalResources
    construction_residual(std::uint32_t candidate_index,
                          std::span<const std::uint16_t> choices) const;
    [[nodiscard]] runtime::PressureTargetGuidance guidance(qwen3_5::PressureTargetHandle target);
    [[nodiscard]] qwen3_5::AssessedPressureTarget assess(qwen3_5::PressureTargetHandle target);
    [[nodiscard]] qwen3_5::PreparedPressureExpansion
    prepare_expansion(qwen3_5::PressureTargetHandle parent,
                      std::uint32_t maximum_owners = std::numeric_limits<std::uint32_t>::max());
    [[nodiscard]] qwen3_5::PressureExpansionView
    commit_expansion(qwen3_5::PreparedPressureExpansion&& prepared);
    void discard_expansion(qwen3_5::PreparedPressureExpansion&& prepared) noexcept;
    [[nodiscard]] runtime::PrefillWork
    shared_capture_split_prefill_work(const qwen3_5::AssessedPressureTarget& assessed,
                                      const PreparedPromptData& prompt,
                                      std::span<const std::uint32_t> frontiers) const;
    [[nodiscard]] std::optional<AdmissionCandidate> seal(qwen3_5::AssessedPressureTarget&& assessed,
                                                         const PreparedPromptData& prompt,
                                                         runtime::FinalScheduleIntent intent);
    [[nodiscard]] std::optional<CapturePressureCandidate>
    seal_capture(qwen3_5::AssessedPressureTarget&& assessed);

    [[nodiscard]] bool valid(qwen3_5::PressureTargetHandle target) const noexcept;
    [[nodiscard]] std::uint32_t candidate_index(runtime::PlanningCandidateId candidate) const;
    [[nodiscard]] std::span<const std::uint16_t> victim_choices(const TargetNode& target) const;
    [[nodiscard]] TargetNode* find_target(std::uint32_t candidate_index,
                                          std::span<const std::uint16_t> choices) noexcept;
    [[nodiscard]] const TargetNode*
    find_target(std::uint32_t candidate_index,
                std::span<const std::uint16_t> choices) const noexcept;
    [[nodiscard]] std::uint32_t intern_target(std::uint32_t candidate_index,
                                              std::span<const std::uint16_t> choices,
                                              bool root_maximal = false);
    void index_target(std::uint32_t target_index);
    void populate_options(std::uint32_t candidate_index);
    [[nodiscard]] std::vector<PressureDecision>
    pressure_successors(const CandidateVictimOptions& victim_options,
                        const detail::PhysicalResources& residual,
                        const Core::MaterializationSourceProtection& protection,
                        const PressureDecision* current) const;
    [[nodiscard]] std::uint32_t acquire_assessment_slot();
    static void release_assessment_slot(const void* owner, std::uint32_t slot,
                                        std::uint32_t generation) noexcept;

    Core* program = nullptr;
    runtime::ProgramResourceRevision resource_revision;
    std::uint32_t generation         = 1;
    std::uint32_t scratch_generation = 1;
    std::vector<PhysicalCandidateBinding> candidates;
    std::vector<runtime::PlanningCandidateId> candidate_ids;
    std::vector<Owner> owners;
    std::vector<CandidateOptions> candidate_options;
    std::vector<TargetNode> targets;
    std::vector<std::uint16_t> target_choice_arena;
    std::vector<std::uint16_t> choice_scratch;
    std::vector<std::uint32_t> target_hash_table;
    std::vector<TargetNode> expansion_scratch;
    std::vector<PreparedOwnerDecision> prepared_owner_decisions;
    std::vector<qwen3_5::PressureTargetHandle> committed_children;
    std::vector<const ContinuationHandle*> selected_private_owners;
    std::vector<runtime::PlanningOwnerId> selected_private_owner_ids;
    std::vector<const PressureDecision*> selected_private_decisions;
    std::vector<const SharedPrefixHandle*> selected_shared_owners;
    std::vector<runtime::PlanningOwnerId> selected_shared_owner_ids;
    std::vector<const PressureDecision*> selected_shared_decisions;
    std::vector<const ContinuationHandle*> recovery_private_owners;
    std::vector<const PressureDecision*> recovery_private_decisions;
    std::vector<runtime::PlanningOwnerId> recovery_private_owner_ids;
    std::vector<const SharedPrefixHandle*> recovery_shared_owners;
    std::vector<const PressureDecision*> recovery_shared_decisions;
    std::vector<runtime::PlanningOwnerId> recovery_shared_owner_ids;
    std::vector<const PressureDecision*> projected_owner_decisions;
    std::vector<runtime::PressureOwnerOutcome> assessment_outcomes;
    std::vector<PressureCheckpointRecoveryProjection> assessment_impact_projections;
    std::vector<runtime::CheckpointRecoveryAlternativeWork> assessment_recovery_alternatives;
    Core::PressureRecoveryScratch recovery_scratch;
    std::vector<runtime::PressureOwnerOutcome> guidance_outcomes;
    std::vector<runtime::PressureCheckpointOutcome> guidance_checkpoint_changes;
    std::vector<runtime::PressureOwnerRecoveryGuidance> guidance_recovery;
    std::array<ConstructionSlot, 4> construction_slots;
    std::uint32_t construction_generation = 0;
    std::array<AssessmentSlot, 2> assessment_slots;
    std::uint32_t prepared_new_count = 0;
    std::uint32_t prepared_owner_end = 0;
    std::size_t scratch_choice_mark  = 0;
    bool scratch_live                = false;
};



} // namespace ninfer::models::qwen3_5::detail
