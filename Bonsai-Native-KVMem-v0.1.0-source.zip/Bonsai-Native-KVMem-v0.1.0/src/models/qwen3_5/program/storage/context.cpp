// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#include "models/qwen3_5/program/program_impl.h"
#include "models/qwen3_5/program/context_work.h"
#include "core/device.h"
#if defined(NINFER_WITH_KVMEM)
#include "models/qwen3_5/program/storage/kvmem_follower_page_backend.h"
#include "models/qwen3_5/program/storage/kvmem_follower_prefill_pressure.h"
#include "models/qwen3_5/program/storage/kvmem_follower_replay_prefix.h"
#include "models/qwen3_5/program/storage/kvmem_page_backend.h"
#endif

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <span>
#include <stdexcept>
#include <utility>
#include <variant>

namespace ninfer::models::qwen3_5::detail {

bool ProgramImpl::valid_sequence(SequenceHandle handle) const noexcept {
    if (ContractAccess::owner(handle) != this) { return false; }
    const std::uint32_t lane = ContractAccess::lane(handle).value;
    if (lane >= max_concurrency || ContractAccess::epoch(handle) != lane_epochs[lane]) {
        return false;
    }
    if (active_continuations[lane] >= continuation_capacity ||
        continuation_slots[active_continuations[lane]].role != ContinuationSlotRole::Active) {
        return false;
    }
    const Lifecycle lifecycle = requests[lane].lifecycle;
    return lifecycle == Lifecycle::Prefilling || lifecycle == Lifecycle::Active ||
           lifecycle == Lifecycle::Pending || lifecycle == Lifecycle::Finishable;
}

bool ProgramImpl::valid_continuation(const ContinuationHandle& handle) const noexcept {
    if (ContractAccess::owner(handle) != this) { return false; }
    const std::uint32_t index = ContractAccess::index(handle);
    return index < continuation_capacity &&
           ContractAccess::epoch(handle) == continuation_slots[index].generation &&
           continuation_slots[index].role == ContinuationSlotRole::Catalogued;
}

bool ProgramImpl::valid_shared_prefix(const SharedPrefixHandle& handle) const noexcept {
    if (ContractAccess::owner(handle) != this) { return false; }
    const std::uint32_t index = ContractAccess::index(handle);
    return index < shared_prefix_capacity &&
           ContractAccess::epoch(handle) == shared_prefix_slots[index].generation &&
           shared_prefix_slots[index].role == SharedPrefixSlotRole::Catalogued;
}

bool ProgramImpl::valid_capture_offer(const CaptureOffer& offer) const noexcept {
    if (ContractAccess::owner(offer) != this) { return false; }
    const std::uint32_t lane = ContractAccess::lane(offer).value;
    if (lane >= max_concurrency || ContractAccess::epoch(offer) != lane_epochs[lane] ||
        (requests[lane].lifecycle != Lifecycle::Prefilling &&
         requests[lane].lifecycle != Lifecycle::Active) ||
        !requests[lane].prefill) {
        return false;
    }
    const RequestControl::Prefill& prefill = *requests[lane].prefill;
    return prefill.pending_capture_offer != 0 &&
           prefill.pending_capture_offer == ContractAccess::id(offer) &&
           prefill.next_capture < prefill.capture_groups.size() &&
           prefill.cursor == prefill.capture_groups[prefill.next_capture].frontier;
}

bool ProgramImpl::materialization_pins(std::uint32_t index,
                                       std::uint64_t generation) const noexcept {
    const MaterializationTransaction* transaction_ptr =
        std::get_if<MaterializationTransaction>(&context_transaction_);
    if (transaction_ptr == nullptr) { return false; }
    const MaterializationTransaction& transaction = *transaction_ptr;
    if (transaction.has_source && transaction.source_index == index &&
        transaction.source_generation == generation) {
        return true;
    }
    for (std::size_t victim = 0; victim < transaction.victim_count; ++victim) {
        if (!transaction.victim_released[victim] && transaction.victim_indices[victim] == index &&
            transaction.victim_generations[victim] == generation) {
            return true;
        }
    }
    return false;
}

bool ProgramImpl::valid_pending(const PendingBatch& pending) const noexcept {
    if (ContractAccess::owner(pending) != this || !pending_transaction_ ||
        ContractAccess::transaction(pending) != pending_transaction_->id) {
        return false;
    }
    const auto rows = ContractAccess::rows(pending);
    if (rows.size() != pending_transaction_->size) { return false; }
    for (std::size_t row = 0; row < rows.size(); ++row) {
        if (!valid_sequence(rows[row]) ||
            ContractAccess::lane(rows[row]).value != pending_transaction_->lanes[row] ||
            ContractAccess::epoch(rows[row]) != pending_transaction_->epochs[row] ||
            requests[pending_transaction_->lanes[row]].lifecycle != Lifecycle::Pending) {
            return false;
        }
    }
    return true;
}

void ProgramImpl::invalidate_lane(std::uint32_t lane) noexcept {
    if (lane >= max_concurrency) { return; }
    ++lane_epochs[lane];
    if (lane_epochs[lane] == 0) { ++lane_epochs[lane]; }
}

SequenceState& ProgramImpl::active_sequence(std::uint32_t lane) {
    if (lane >= max_concurrency) { throw std::out_of_range("active lane is out of range"); }
    const std::uint32_t index = active_continuations[lane];
    if (index >= continuation_capacity ||
        continuation_slots[index].role != ContinuationSlotRole::Active) {
        throw std::logic_error("active lane has no continuation binding");
    }
    return continuation_states[index];
}

const SequenceState& ProgramImpl::active_sequence(std::uint32_t lane) const {
    if (lane >= max_concurrency) { throw std::out_of_range("active lane is out of range"); }
    const std::uint32_t index = active_continuations[lane];
    if (index >= continuation_capacity ||
        continuation_slots[index].role != ContinuationSlotRole::Active) {
        throw std::logic_error("active lane has no continuation binding");
    }
    return continuation_states[index];
}

std::optional<std::uint32_t> ProgramImpl::allocate_continuation_slot() noexcept {
    for (std::uint32_t index = 0; index < continuation_capacity; ++index) {
        if (continuation_slots[index].role == ContinuationSlotRole::Free) {
            continuation_slots[index].role = ContinuationSlotRole::Active;
            return index;
        }
    }
    return std::nullopt;
}

bool ProgramImpl::can_release_continuation_slot_strict(std::uint32_t index) const {
    if (index >= continuation_capacity || !state_store || !text_kv_addresses || !text_kv_pages ||
        continuation_slots[index].role != ContinuationSlotRole::Catalogued) {
        return false;
    }
    const SequenceState& sequence = continuation_states[index];
    bool archive_only_endpoint = false;
#if defined(NINFER_WITH_KVMEM)
    const bool archive_has_no_follower =
        speculative_backend == SpeculativeBackend::None && sequence.mtp_kv_valid == 0 &&
        sequence.native_follower_execution.empty() && native_kvmem_conversation &&
        !native_kvmem_conversation->follower_config().has_value();
    const bool archive_follower_frontier_matches =
        speculative_backend == SpeculativeBackend::Mtp
            ? sequence.mtp_kv_valid <= sequence.text_kv_valid &&
                  sequence.text_kv_valid - sequence.mtp_kv_valid <= 1U
            : archive_has_no_follower;
    if (!sequence.kv && sequence.native_kvmem_parked && kvmem.enabled &&
        !sequence.native_kvmem_parked->empty() && sequence.endpoint_valid &&
        !sequence.rewrite_checkpoint.valid && !sequence.rewrite_state &&
        sequence.long_anchors.empty() && !sequence.reserved_state &&
        sequence.native_tail_materialized_tokens == 0 &&
        sequence.native_follower_execution.empty() && sequence.compact_kv_frontier &&
        sequence.text_kv_valid != 0 &&
        sequence.text_kv_valid == *sequence.compact_kv_frontier &&
        archive_follower_frontier_matches) {
        const KVMemConversation::SessionMetadata& metadata =
            sequence.native_kvmem_parked->metadata();
        archive_only_endpoint = !metadata.cold &&
                                metadata.row_positions.size() == sequence.execution_frontier &&
                                !metadata.prior_resident_block_ids.empty();
    }
#endif
    if (sequence.state.fork_pending || !sequence.shared_prefix_references.empty() ||
        (!sequence.kv && !archive_only_endpoint)) {
        return false;
    }
#if defined(NINFER_WITH_KVMEM)
    if (sequence.kv && sequence.native_kvmem_parked) { return false; }
#endif
    if (sequence.kv) {
        if (!text_kv_addresses->can_release(sequence.kv->text)) { return false; }
        if (sequence.kv->backend &&
            (!backend_kv_addresses || !backend_kv_pages ||
             !backend_kv_addresses->can_release(*sequence.kv->backend))) {
            return false;
        }
    }

    const auto validate_state = [&](StateImageHandle handle, bool release_object) {
        if (!state_store->valid(handle)) { return false; }
        const std::uint32_t owned = owned_checkpoint_references(sequence, handle);
        const std::uint32_t total = state_store->checkpoint_references(handle);
        if (owned > total ||
            (owned != 0 && state_store->role(handle) != StateImageRole::CheckpointImmutable)) {
            return false;
        }
        return !release_object || total != owned ||
               state_store->can_release_after_checkpoint_references(handle, owned);
    };
    const auto repeated_before_anchor = [&](std::size_t anchor_index, StateImageHandle handle) {
        if (handle == sequence.state.read || handle == sequence.state.write ||
            (sequence.rewrite_state && handle == *sequence.rewrite_state)) {
            return true;
        }
        for (std::size_t prior = 0; prior < anchor_index; ++prior) {
            if (sequence.long_anchors[prior].state == handle) { return true; }
        }
        return false;
    };

    if (sequence.endpoint_valid) {
        if (!validate_state(sequence.state.read, !sequence.state.read_has_external_owner() ||
                                                     sequence.state.read == sequence.state.write)) {
            return false;
        }
        if (sequence.state.write != sequence.state.read &&
            !validate_state(sequence.state.write, true)) {
            return false;
        }
    } else if (state_store->valid(sequence.state.read) ||
               state_store->valid(sequence.state.write) || sequence.state.borrows_read()) {
        return false;
    }
    if (sequence.rewrite_state && *sequence.rewrite_state != sequence.state.read &&
        *sequence.rewrite_state != sequence.state.write &&
        !validate_state(*sequence.rewrite_state, true)) {
        return false;
    }
    for (std::size_t anchor = 0; anchor < sequence.long_anchors.size(); ++anchor) {
        const StateImageHandle handle = sequence.long_anchors[anchor].state;
        if (!repeated_before_anchor(anchor, handle) && !validate_state(handle, true)) {
            return false;
        }
    }
    if (sequence.reserved_state) {
        const StateImageHandle handle = *sequence.reserved_state;
        bool repeated = handle == sequence.state.read || handle == sequence.state.write ||
                        (sequence.rewrite_state && handle == *sequence.rewrite_state);
        for (const LongAnchorCheckpoint& anchor : sequence.long_anchors) {
            repeated = repeated || anchor.state == handle;
        }
        if (!repeated && !validate_state(handle, true)) { return false; }
    }
    return true;
}

void ProgramImpl::release_continuation_slot_strict(std::uint32_t index) noexcept {
    try {
        if (!can_release_continuation_slot_strict(index)) { std::terminate(); }
    } catch (...) { std::terminate(); }
    SequenceState& sequence = continuation_states[index];
    if (sequence.kv) { release_sequence_kv_strict(sequence); }
    release_sequence_state_strict(sequence);
#if defined(NINFER_WITH_KVMEM)
    if (sequence.native_kvmem_parked) {
        try {
            sequence.native_kvmem_parked->retire();
            sequence.native_kvmem_parked.reset();
        } catch (...) { std::terminate(); }
    }
#endif
    retire_continuation_slot(index);
}

void ProgramImpl::release_continuation_slot_best_effort(std::uint32_t index) noexcept {
    if (index >= continuation_capacity ||
        continuation_slots[index].role == ContinuationSlotRole::Free) {
        return;
    }
    SequenceState& sequence = continuation_states[index];
    release_active_shared_references(sequence);
    release_sequence_kv(sequence);
    release_sequence_state(sequence);
#if defined(NINFER_WITH_KVMEM)
    if (sequence.native_kvmem_parked) {
        try {
            sequence.native_kvmem_parked->retire();
            sequence.native_kvmem_parked.reset();
        } catch (...) { std::terminate(); }
    }
#endif
    retire_continuation_slot(index);
}

void ProgramImpl::retire_continuation_slot(std::uint32_t index) noexcept {
    if (index >= continuation_capacity) { std::terminate(); }
#if defined(NINFER_WITH_KVMEM)
    if (kvmem.enabled && native_kvmem_owner && *native_kvmem_owner == index) {
        reset_native_kvmem_owner();
    }
#endif
    SequenceState& sequence     = continuation_states[index];
    sequence.execution_frontier = 0;
    sequence.compact_kv_frontier.reset();
#if defined(NINFER_WITH_KVMEM)
    sequence.native_tail_materialized_tokens = 0;
    sequence.native_follower_execution.clear();
    std::vector<NativeRecurrentCheckpoint>{}.swap(sequence.native_recurrent_checkpoints);
#endif
    sequence.ledger_frontier    = 0;
    sequence.ledger.clear();
    sequence.ngram_observed = 0;
    sequence.prefix_identity.clear();
    sequence.prefix_digests.clear();
    sequence.rope_delta              = 0;
    sequence.text_kv_valid           = 0;
    sequence.mtp_kv_valid            = 0;
    sequence.dflash_context_frontier = 0;
    sequence.mtp_draft_count         = 0;
    sequence.tail_hidden_valid       = false;
    sequence.endpoint_valid          = false;
    sequence.rewrite_checkpoint      = {};
    sequence.rebuild_work            = {};
    sequence.rebuild_tail_begin      = 0;
    for (std::uint32_t lane = 0; lane < max_concurrency; ++lane) {
        if (active_continuations[lane] == index) {
            active_continuations[lane] = continuation_capacity;
        }
    }
    ContinuationSlot& slot = continuation_slots[index];
    slot.role              = ContinuationSlotRole::Free;
    if (++slot.generation == 0) { ++slot.generation; }
}

detail::PhysicalResources
ProgramImpl::sequence_exclusive_state_resources(const SequenceState& sequence) const {
    if (!state_store) {
        throw std::logic_error("sequence StateImage resources have no physical store");
    }
    detail::PhysicalResources out;
    std::array<StateImageHandle, 4> states{};
    std::uint32_t state_count = 0;
    const auto add_state      = [&](StateImageHandle handle) {
        if (!state_store->valid(handle)) {
            throw std::logic_error("sequence owner has a stale StateImage");
        }
        if (!state_exclusive_to_sequence(sequence, handle)) { return; }
        for (std::uint32_t index = 0; index < state_count; ++index) {
            if (states[index] == handle) { return; }
        }
        states[state_count++]                 = handle;
        const StateReplicaResidency residency = state_store->residency(handle);
        if (residency == StateReplicaResidency::DeviceOnly ||
            residency == StateReplicaResidency::Both) {
            ++out.device.state_slots;
        }
        if (residency == StateReplicaResidency::HostOnly ||
            residency == StateReplicaResidency::Both) {
            ++out.host.state_slots;
        }
    };
    const bool has_read_state  = sequence.state.read.valid();
    const bool has_write_state = sequence.state.write.valid();
    if (has_read_state != has_write_state) {
        throw std::logic_error("sequence owner has a partial primary StateImage pair");
    }
    if (sequence.state.borrows_read() &&
        (!sequence.state.fork_pending || sequence.state.read == sequence.state.write)) {
        throw std::logic_error("sequence has an invalid borrowed StateImage source");
    }
    if (has_read_state) {
        if (!sequence.state.borrows_read() || sequence.state.read == sequence.state.write) {
            add_state(sequence.state.read);
        }
        add_state(sequence.state.write);
    }
    if (sequence.rewrite_state) { add_state(*sequence.rewrite_state); }
    if (sequence.reserved_state) { add_state(*sequence.reserved_state); }
    for (std::size_t anchor_index = 0; anchor_index < sequence.long_anchors.size();
         ++anchor_index) {
        const StateImageHandle handle = sequence.long_anchors[anchor_index].state;
        if (!state_store->valid(handle)) {
            throw std::logic_error("sequence owner has a stale long-anchor StateImage");
        }
        if (!state_exclusive_to_sequence(sequence, handle)) { continue; }
        bool seen = false;
        for (std::uint32_t index = 0; index < std::min<std::uint32_t>(state_count, states.size());
             ++index) {
            if (states[index] == handle) { seen = true; }
        }
        for (std::size_t prior = 0; !seen && prior < anchor_index; ++prior) {
            if (sequence.long_anchors[prior].state == handle) { seen = true; }
        }
        if (seen) { continue; }
        const StateReplicaResidency residency = state_store->residency(handle);
        if (residency == StateReplicaResidency::DeviceOnly ||
            residency == StateReplicaResidency::Both) {
            ++out.device.state_slots;
        }
        if (residency == StateReplicaResidency::HostOnly ||
            residency == StateReplicaResidency::Both) {
            ++out.host.state_slots;
        }
    }
    return out;
}

detail::PhysicalResources
ProgramImpl::owner_exclusive_resources(const SequenceState& sequence) const {
    if (!state_store || !text_kv_addresses || !text_kv_pages) {
        throw std::logic_error("sequence owner resources have no physical stores");
    }
    detail::PhysicalResources out = sequence_exclusive_state_resources(sequence);

    {
        bool archive_only_endpoint = false;
#if defined(NINFER_WITH_KVMEM)
        const bool archive_has_no_follower =
            speculative_backend == SpeculativeBackend::None && sequence.mtp_kv_valid == 0 &&
            sequence.native_follower_execution.empty() && native_kvmem_conversation &&
            !native_kvmem_conversation->follower_config().has_value();
        const bool archive_follower_frontier_matches =
            speculative_backend == SpeculativeBackend::Mtp
                ? sequence.mtp_kv_valid <= sequence.text_kv_valid &&
                      sequence.text_kv_valid - sequence.mtp_kv_valid <= 1U
                : archive_has_no_follower;
        if (!sequence.kv && sequence.native_kvmem_parked && kvmem.enabled &&
            !sequence.native_kvmem_parked->empty() && sequence.endpoint_valid &&
            !sequence.rewrite_checkpoint.valid && !sequence.rewrite_state &&
            sequence.long_anchors.empty() && !sequence.reserved_state &&
            sequence.native_tail_materialized_tokens == 0 &&
            sequence.native_follower_execution.empty() && sequence.compact_kv_frontier &&
            sequence.text_kv_valid != 0 &&
            sequence.text_kv_valid == *sequence.compact_kv_frontier &&
            archive_follower_frontier_matches) {
            const KVMemConversation::SessionMetadata& metadata =
                sequence.native_kvmem_parked->metadata();
            archive_only_endpoint = !metadata.cold &&
                                    metadata.row_positions.size() == sequence.execution_frontier &&
                                    !metadata.prior_resident_block_ids.empty();
        }
#endif
        if (!sequence.kv) {
            if (!archive_only_endpoint) {
                throw std::logic_error("sequence owner has no live or parked endpoint state");
            }
            return out;
        }
#if defined(NINFER_WITH_KVMEM)
        if (sequence.native_kvmem_parked) {
            throw std::logic_error("sequence owner has both live and parked KVMem state");
        }
#endif
        const auto add_kv = [&](const KVAddressSpaceStore& addresses,
                                const LogicalKVPageStore& pages, KVAddressSpaceHandle address,
                                std::uint32_t& device_pages) {
            if (!addresses.valid(address)) { throw std::logic_error("stale KV address space"); }
            for (std::uint32_t page = 0; page < addresses.mapped_pages(address); ++page) {
                const LogicalKVPageHandle logical = addresses.logical_page(address, page);
                // A shared logical page contributes to aggregate occupancy once. Releasing this
                // address cannot free either replica while another address still references it,
                // so it is not part of this owner's exact transition effect.
                if (pages.address_references(logical) > 1) { continue; }
                if (pages.device_resident(logical)) { ++device_pages; }
                if (pages.host_resident(logical)) {
                    if (!host_kv_extents) {
                        throw std::logic_error("missing Host KV extent store");
                    }
                    const HostKVPageReplica& replica = pages.host_replica(logical);
                    const std::size_t stride =
                        host_kv_extents->view(replica.extent).layout().page_stride;
                    if (stride > std::numeric_limits<std::size_t>::max() - out.host.kv_bytes) {
                        throw std::overflow_error("resident Host KV byte count overflow");
                    }
                    out.host.kv_bytes += stride;
                }
            }
            if (addresses.active(address)) {
                const std::uint32_t mapped      = addresses.mapped_pages(address);
                const std::uint32_t entitlement = addresses.entitlement(address);
                if (entitlement < mapped ||
                    entitlement - mapped >
                        std::numeric_limits<std::uint32_t>::max() - device_pages) {
                    throw std::logic_error("owner active KV entitlement is inconsistent");
                }
                device_pages += entitlement - mapped;
            }
        };
        add_kv(*text_kv_addresses, *text_kv_pages, sequence.kv->text, out.device.main_kv_pages);
        if (sequence.kv->backend) {
            if (!backend_kv_addresses || !backend_kv_pages) {
                throw std::logic_error("missing Backend KV stores");
            }
            add_kv(*backend_kv_addresses, *backend_kv_pages, *sequence.kv->backend,
                   out.device.backend_kv_pages);
        }
    }
    return out;
}

detail::PhysicalResources
ProgramImpl::owner_exclusive_resources(const SharedPrefixState& shared) const {
    if (!state_store || !text_kv_addresses || !text_kv_pages) {
        throw std::logic_error("shared owner resources have no physical stores");
    }
    detail::PhysicalResources out;
    {
        if (!shared.kv || !shared.identity || !state_store->valid(shared.state)) {
            throw std::logic_error("shared prefix has incomplete resident physical state");
        }
        if (state_store->checkpoint_references(shared.state) == 0) {
            throw std::logic_error("shared prefix StateImage has no checkpoint reference");
        }
        const StateReplicaResidency residency = state_store->residency(shared.state);
        if (state_store->checkpoint_references(shared.state) == 1) {
            if (residency == StateReplicaResidency::DeviceOnly ||
                residency == StateReplicaResidency::Both) {
                ++out.device.state_slots;
            }
            if (residency == StateReplicaResidency::HostOnly ||
                residency == StateReplicaResidency::Both) {
                ++out.host.state_slots;
            }
        }
        const auto add_kv = [&](const KVAddressSpaceStore& addresses,
                                const LogicalKVPageStore& pages, KVAddressSpaceHandle address,
                                std::uint32_t& device_pages) {
            if (!addresses.valid(address)) { throw std::logic_error("stale shared KV address"); }
            for (std::uint32_t page = 0; page < addresses.mapped_pages(address); ++page) {
                const LogicalKVPageHandle logical = addresses.logical_page(address, page);
                if (pages.address_references(logical) != 1) { continue; }
                if (pages.device_resident(logical)) { ++device_pages; }
                if (pages.host_resident(logical)) {
                    if (!host_kv_extents) {
                        throw std::logic_error("missing Host KV extent store");
                    }
                    const HostKVPageReplica& replica = pages.host_replica(logical);
                    const std::size_t stride =
                        host_kv_extents->view(replica.extent).layout().page_stride;
                    if (stride > std::numeric_limits<std::size_t>::max() - out.host.kv_bytes) {
                        throw std::overflow_error("shared Host KV byte count overflow");
                    }
                    out.host.kv_bytes += stride;
                }
            }
        };
        add_kv(*text_kv_addresses, *text_kv_pages, shared.kv->text, out.device.main_kv_pages);
        if (shared.kv->backend) {
            if (!backend_kv_addresses || !backend_kv_pages) {
                throw std::logic_error("missing shared Backend KV stores");
            }
            add_kv(*backend_kv_addresses, *backend_kv_pages, *shared.kv->backend,
                   out.device.backend_kv_pages);
        }
    }
    return out;
}

detail::PhysicalResources ProgramImpl::physical_occupancy() const noexcept {
    detail::PhysicalResources out;
    for (const RequestControl& request : requests) {
        if (request.lifecycle != Lifecycle::Empty) { ++out.device.active_lanes; }
    }
    if (state_store) {
        out.device.state_slots = state_store->device_occupied();
        out.host.state_slots   = state_store->host_occupied();
    }
    if (text_kv_pages) {
        const DeviceKVPagePool& pool = text_kv_pages->physical_pool();
        out.device.main_kv_pages     = pool.allocated_pages() + pool.reserved_pages();
    }
    if (backend_kv_pages) {
        const DeviceKVPagePool& pool = backend_kv_pages->physical_pool();
        out.device.backend_kv_pages  = pool.allocated_pages() + pool.reserved_pages();
    }
    if (host_kv_arena) { out.host.kv_bytes = host_kv_arena->occupied_bytes(); }
    return out;
}

detail::PhysicalResources
ProgramImpl::materialization_deficit(const ResourceCandidateState& admission) const {
    // Pressure is relative to this candidate's real peak. Treating every dimension as scarce
    // would forbid Device-to-Host demotion even when Host capacity is available.
    const detail::PhysicalResources required =
        checked_resource_sum(physical_occupancy(), admission.demand.physical_peak_additional);
    return positive_resource_difference(required, admission_capacity());
}

detail::PhysicalResources
ProgramImpl::guided_materialization_deficit(const ResourceCandidateState& admission,
                                            const detail::PhysicalDelta& pressure) const {
    // Pressure acts on the candidate's complete peak, not on its already-clamped deficit.  Applying
    // a demotion directly to a zero Host deficit would otherwise manufacture Host pressure even
    // when the arena has ample slack and steer the heuristic toward unnecessary destruction.
    const detail::PhysicalResources projected_peak = positive_resource_difference(
        checked_resource_sum(admission.demand.physical_peak_additional, pressure.added),
        pressure.removed);
    const detail::PhysicalResources required =
        checked_resource_sum(physical_occupancy(), projected_peak);
    return positive_resource_difference(required, admission_capacity());
}

bool ProgramImpl::physical_peak_fits(detail::PhysicalResources peak) const noexcept {
    const detail::PhysicalResources occupied = physical_occupancy();
    const detail::PhysicalResources limits   = admission_capacity();
    const auto fits_u32 = [](std::uint32_t used, std::uint32_t added, std::uint32_t capacity) {
        return added <= capacity && used <= capacity - added;
    };
    const auto fits_size = [](std::size_t used, std::size_t added, std::size_t capacity) {
        return added <= capacity && used <= capacity - added;
    };
    return fits_u32(occupied.device.active_lanes, peak.device.active_lanes,
                    limits.device.active_lanes) &&
           fits_u32(occupied.device.state_slots, peak.device.state_slots,
                    limits.device.state_slots) &&
           fits_u32(occupied.device.main_kv_pages, peak.device.main_kv_pages,
                    limits.device.main_kv_pages) &&
           fits_u32(occupied.device.backend_kv_pages, peak.device.backend_kv_pages,
                    limits.device.backend_kv_pages) &&
           fits_u32(occupied.host.state_slots, peak.host.state_slots, limits.host.state_slots) &&
           fits_size(occupied.host.kv_bytes, peak.host.kv_bytes, limits.host.kv_bytes);
}

// Every way this resolution fails is a stale plan rather than a broken Program, so preparation
// consults it directly and aborts its transaction. selected_state keeps throwing for the callers
// that have already established the path is live.
std::optional<StateImageHandle>
ProgramImpl::try_selected_state(const SequenceState& sequence, ReusePath reuse,
                                std::optional<runtime::CheckpointRef> checkpoint) const {
    if (reuse == ReusePath::PrivateEndpoint) {
        if (!sequence.endpoint_valid || !state_store->valid(sequence.state.read)) {
            return std::nullopt;
        }
        return sequence.state.read;
    }
    if (is_rewrite_checkpoint_restore(reuse) && sequence.rewrite_state &&
        state_store->valid(*sequence.rewrite_state)) {
        return *sequence.rewrite_state;
    }
    if (reuse == ReusePath::PrivateLongAnchor) {
        if (!checkpoint || checkpoint->kind != runtime::CheckpointKind::LongAnchor) {
            return std::nullopt;
        }
        const auto anchor = std::find_if(sequence.long_anchors.begin(), sequence.long_anchors.end(),
                                         [&](const LongAnchorCheckpoint& candidate) {
                                             return candidate.frontier == checkpoint->frontier &&
                                                    candidate.ordinal == checkpoint->ordinal;
                                         });
        if (anchor != sequence.long_anchors.end() && state_store->valid(anchor->state)) {
            return anchor->state;
        }
    }
    return std::nullopt;
}

StateImageHandle
ProgramImpl::selected_state(const SequenceState& sequence, ReusePath reuse,
                            std::optional<runtime::CheckpointRef> checkpoint) const {
    const std::optional<StateImageHandle> selected =
        try_selected_state(sequence, reuse, std::move(checkpoint));
    if (!selected) { throw std::logic_error("materialization path has no selected StateImage"); }
    return *selected;
}

std::uint32_t
ProgramImpl::selected_state_consumed_references(const SequenceState& sequence, ReusePath reuse,
                                                RewriteCheckpointDisposition rewrite_disposition,
                                                std::optional<runtime::CheckpointRef> checkpoint,
                                                std::uint32_t reuse_base) const {
    const StateImageHandle selected   = selected_state(sequence, reuse, checkpoint);
    std::uint32_t consumed_references = 0;
    if (is_rewrite_checkpoint_restore(reuse) &&
        rewrite_disposition != RewriteCheckpointDisposition::RetainExisting) {
        if (!sequence.rewrite_state || *sequence.rewrite_state != selected) {
            throw std::logic_error("selected rewrite StateImage is unavailable");
        }
        consumed_references = 1;
    } else if (reuse == ReusePath::PrivateEndpoint &&
               rewrite_disposition != RewriteCheckpointDisposition::RetainExisting &&
               sequence.rewrite_state && *sequence.rewrite_state == selected) {
        consumed_references = 1;
    }
    for (const LongAnchorCheckpoint& anchor : sequence.long_anchors) {
        if (anchor.frontier > reuse_base && anchor.state == selected) {
            if (consumed_references == std::numeric_limits<std::uint32_t>::max()) {
                throw std::overflow_error("consumed StateImage reference inventory overflow");
            }
            ++consumed_references;
        }
    }
    const std::uint32_t references = state_store->checkpoint_references(selected);
    if (consumed_references > references) {
        throw std::logic_error("selected StateImage reference inventory is inconsistent");
    }
    return consumed_references;
}

bool ProgramImpl::selected_state_requires_fork(const SequenceState& sequence, ReusePath reuse,
                                               RewriteCheckpointDisposition rewrite_disposition,
                                               std::optional<runtime::CheckpointRef> checkpoint,
                                               std::uint32_t reuse_base) const {
    const StateImageHandle selected = selected_state(sequence, reuse, checkpoint);
    return state_store->checkpoint_references(selected) !=
           selected_state_consumed_references(sequence, reuse, rewrite_disposition, checkpoint,
                                              reuse_base);
}

bool ProgramImpl::can_retain_rewrite_checkpoint(const PreparedPromptData& prompt,
                                                const RewriteCheckpointSpec& desired,
                                                const SequenceState& sequence, ReusePath reuse,
                                                std::uint32_t reuse_base) const {
    if (!sequence.rewrite_checkpoint.valid || !sequence.rewrite_state ||
        !state_store->valid(*sequence.rewrite_state) ||
        !qwen3_5::detail::prefix_matches(prompt, sequence.ledger, sequence.prefix_identity,
                                         sequence.rewrite_checkpoint.frontier)) {
        return false;
    }
    if (sequence.rewrite_checkpoint.frontier == desired.frontier) { return true; }
    return is_rewrite_checkpoint_restore(reuse) &&
           sequence.rewrite_checkpoint.frontier == reuse_base && desired.frontier <= reuse_base;
}

std::uint32_t ProgramImpl::device_kv_prefix_pages(const KVAddressSpaceStore& addresses,
                                                  KVAddressSpaceHandle address,
                                                  std::uint32_t frontier) const {
    const std::uint32_t required = kv_pages_for_frontier(frontier);
    if (required > addresses.mapped_pages(address)) {
        throw std::logic_error("checkpoint KV requirement exceeds address membership");
    }
    const LogicalKVPageStore& pages =
        (&addresses == text_kv_addresses.get()) ? *text_kv_pages : *backend_kv_pages;
    std::uint32_t resident = 0;
    for (std::uint32_t page = 0; page < required; ++page) {
        if (pages.device_resident(addresses.logical_page(address, page))) { ++resident; }
    }
    return resident;
}

std::uint32_t ProgramImpl::shared_kv_prefix_pages(const KVAddressSpaceStore& addresses,
                                                  KVAddressSpaceHandle address,
                                                  std::uint32_t frontier) const {
    const std::uint32_t required = kv_pages_for_frontier(frontier);
    if (required > addresses.mapped_pages(address)) {
        throw std::logic_error("checkpoint KV requirement exceeds address membership");
    }
    const LogicalKVPageStore& pages =
        (&addresses == text_kv_addresses.get()) ? *text_kv_pages : *backend_kv_pages;
    std::uint32_t shared = 0;
    for (std::uint32_t page = 0; page < required; ++page) {
        if (pages.address_references(addresses.logical_page(address, page)) <= 1) { continue; }
        if (page + 1U == required && frontier % static_cast<std::uint32_t>(kPagedKVPageSize) != 0) {
            continue;
        }
        ++shared;
    }
    return shared;
}

std::uint32_t ProgramImpl::shared_device_kv_prefix_pages(const KVAddressSpaceStore& addresses,
                                                         KVAddressSpaceHandle address,
                                                         std::uint32_t frontier) const {
    const std::uint32_t required = kv_pages_for_frontier(frontier);
    if (required > addresses.mapped_pages(address)) {
        throw std::logic_error("checkpoint KV requirement exceeds address membership");
    }
    const LogicalKVPageStore& pages =
        (&addresses == text_kv_addresses.get()) ? *text_kv_pages : *backend_kv_pages;
    std::uint32_t resident = 0;
    for (std::uint32_t page = 0; page < required; ++page) {
        const LogicalKVPageHandle logical = addresses.logical_page(address, page);
        if (pages.address_references(logical) > 1 && pages.device_resident(logical)) { ++resident; }
    }
    return resident;
}

bool ProgramImpl::partial_tail_cow_required(const KVAddressSpaceStore& addresses,
                                            KVAddressSpaceHandle address,
                                            std::uint32_t frontier) const {
    if (frontier == 0 || frontier % static_cast<std::uint32_t>(kPagedKVPageSize) == 0) {
        return false;
    }
    const std::uint32_t required = kv_pages_for_frontier(frontier);
    if (required > addresses.mapped_pages(address)) {
        throw std::logic_error("checkpoint KV requirement exceeds address membership");
    }
    const LogicalKVPageStore& pages =
        (&addresses == text_kv_addresses.get()) ? *text_kv_pages : *backend_kv_pages;
    const LogicalKVPageHandle tail = addresses.logical_page(address, required - 1U);
    return pages.address_references(tail) > 1 || !pages.device_resident(tail);
}

std::uint32_t
ProgramImpl::missing_shared_device_kv_prefix_pages(const KVAddressSpaceStore& addresses,
                                                   KVAddressSpaceHandle address,
                                                   std::uint32_t frontier) const {
    const std::uint32_t required = kv_pages_for_frontier(frontier);
    if (required > addresses.mapped_pages(address)) {
        throw std::logic_error("checkpoint KV requirement exceeds address membership");
    }
    const LogicalKVPageStore& pages =
        (&addresses == text_kv_addresses.get()) ? *text_kv_pages : *backend_kv_pages;
    std::uint32_t missing = 0;
    for (std::uint32_t page = 0; page < required; ++page) {
        const LogicalKVPageHandle logical = addresses.logical_page(address, page);
        if (pages.address_references(logical) > 1 && !pages.device_resident(logical)) { ++missing; }
    }
    return missing;
}

std::size_t ProgramImpl::host_kv_prefix_bytes(const KVAddressSpaceStore& addresses,
                                              KVAddressSpaceHandle address,
                                              std::uint32_t frontier) const noexcept {
    if (!host_kv_extents) { return 0; }
    try {
        const LogicalKVPageStore& pages =
            (&addresses == text_kv_addresses.get()) ? *text_kv_pages : *backend_kv_pages;
        const std::uint32_t required_pages = kv_pages_for_frontier(frontier);
        if (required_pages > addresses.mapped_pages(address)) { return 0; }
        std::size_t bytes = 0;
        for (std::uint32_t page = 0; page < required_pages; ++page) {
            const LogicalKVPageHandle logical = addresses.logical_page(address, page);
            if (pages.address_references(logical) > 1) { continue; }
            if (!pages.host_resident(logical)) { continue; }
            if (page + 1U == required_pages &&
                frontier % static_cast<std::uint32_t>(kPagedKVPageSize) != 0 &&
                partial_tail_cow_required(addresses, address, frontier)) {
                continue;
            }
            const std::uint32_t begin = page * static_cast<std::uint32_t>(kPagedKVPageSize);
            const std::uint32_t selected_columns =
                std::min(static_cast<std::uint32_t>(kPagedKVPageSize), frontier - begin);
            if (selected_columns != pages.committed_columns(logical)) {
                // A destructive private rewrite changes this tail page's content epoch, so its
                // old Host replica cannot remain part of the active entitlement.
                continue;
            }
            const std::size_t stride =
                host_kv_extents->view(pages.host_replica(logical).extent).layout().page_stride;
            if (stride > std::numeric_limits<std::size_t>::max() - bytes) { return 0; }
            bytes += stride;
        }
        return bytes;
    } catch (...) { return 0; }
}

qwen3_5::CheckpointSummary
ProgramImpl::checkpoint_summary(const SequenceState& sequence, runtime::CheckpointRef checkpoint,
                                StateImageHandle state, runtime::PrefillWork rebuild_work) const {
    bool archive_only_endpoint = false;
#if defined(NINFER_WITH_KVMEM)
    if (!sequence.kv && sequence.native_kvmem_parked && kvmem.enabled &&
        !sequence.native_kvmem_parked->empty()) {
        const bool archive_has_no_follower =
            speculative_backend == SpeculativeBackend::None && sequence.mtp_kv_valid == 0 &&
            sequence.native_follower_execution.empty() && native_kvmem_conversation &&
            !native_kvmem_conversation->follower_config().has_value();
        const bool archive_follower_frontier_matches =
            speculative_backend == SpeculativeBackend::Mtp
                ? sequence.mtp_kv_valid <= sequence.text_kv_valid &&
                      sequence.text_kv_valid - sequence.mtp_kv_valid <= 1U
                : archive_has_no_follower;
        if (checkpoint.kind != runtime::CheckpointKind::SessionEndpoint ||
            !sequence.endpoint_valid || checkpoint.frontier != sequence.execution_frontier ||
            sequence.rewrite_checkpoint.valid || sequence.rewrite_state ||
            !sequence.long_anchors.empty() || sequence.reserved_state ||
            sequence.native_tail_materialized_tokens != 0 ||
            !sequence.native_follower_execution.empty() || !sequence.compact_kv_frontier ||
            sequence.text_kv_valid == 0 ||
            sequence.text_kv_valid != *sequence.compact_kv_frontier ||
            !archive_follower_frontier_matches) {
            throw std::logic_error(
                "parked native continuation supports only its exact SessionEndpoint");
        }
        const KVMemConversation::SessionMetadata& metadata =
            sequence.native_kvmem_parked->metadata();
        if (metadata.cold || metadata.row_positions.size() != sequence.execution_frontier ||
            metadata.prior_resident_block_ids.empty()) {
            throw std::logic_error("parked native endpoint metadata differs from its logical frontier");
        }
        archive_only_endpoint = true;
    }
#endif
    if (!sequence.kv && !archive_only_endpoint) {
        throw std::logic_error("checkpoint summary has no live or parked endpoint state");
    }
#if defined(NINFER_WITH_KVMEM)
    if (sequence.kv && sequence.native_kvmem_parked) {
        throw std::logic_error("checkpoint summary has both live and parked KVMem state");
    }
#endif
    if (checkpoint.frontier == 0) {
        throw std::logic_error("checkpoint summary has an empty frontier");
    }
    if (!state_store->valid(state)) {
        throw std::logic_error("checkpoint summary has a stale StateImage");
    }
    const StateReplicaResidency state_location = state_store->residency(state);
    runtime::ReplicaResidency residency        = runtime::ReplicaResidency::DeviceOnly;
    if (state_location == StateReplicaResidency::HostOnly) {
        residency = runtime::ReplicaResidency::HostOnly;
    } else if (state_location == StateReplicaResidency::Both) {
        residency = runtime::ReplicaResidency::Both;
    } else if (state_location != StateReplicaResidency::DeviceOnly) {
        throw std::logic_error("checkpoint StateImage has no published replica");
    }
    std::uint32_t main_frontier = checkpoint.frontier;
    std::uint32_t backend_frontier =
        speculative_backend == SpeculativeBackend::Mtp      ? checkpoint.frontier - 1U
        : speculative_backend == SpeculativeBackend::DFlash ? checkpoint.frontier
                                                            : 0U;
#if defined(NINFER_WITH_KVMEM)
    if (kvmem.enabled && sequence.compact_kv_frontier) {
        // The checkpoint identity stays at its original logical position, but
        // its KV requirement uses the selected execution view. For an archived
        // endpoint these are future restore pages, not a claim of live addresses.
        // Earlier checkpoints need their own saved interval map; they may not
        // borrow this endpoint's compact frontier.
        if (checkpoint.frontier != sequence.execution_frontier ||
            sequence.text_kv_valid != *sequence.compact_kv_frontier ||
            sequence.text_kv_valid == 0 ||
            (speculative_backend == SpeculativeBackend::Mtp &&
             sequence.mtp_kv_valid > sequence.text_kv_valid)) {
            throw std::logic_error(
                "native checkpoint has no matching selected execution view");
        }
        main_frontier = sequence.text_kv_valid;
        // Preserve NInfer's checkpoint contract: the MTP row for the final
        // logical token is rebuilt by the next turn's bridge, even when that
        // row happens to remain physically committed in this endpoint view.
        backend_frontier = speculative_backend == SpeculativeBackend::Mtp
                               ? std::min(sequence.mtp_kv_valid, main_frontier - 1U)
                               : 0U;
    }
#endif
    const std::uint32_t identity_tag = static_cast<std::uint32_t>(speculative_backend) |
                                       (static_cast<std::uint32_t>(proposal_head) << 8U) |
                                       (static_cast<std::uint32_t>(kv_storage) << 16U);
#if defined(NINFER_WITH_KVMEM)
    const std::uint32_t main_pages = kv_pages_for_frontier(main_frontier);
    const std::uint32_t backend_pages = kv_pages_for_frontier(backend_frontier);
    if (archive_only_endpoint && main_pages == 0) {
        throw std::logic_error("parked native endpoint has no physical main-KV restore requirement");
    }
#else
    const std::uint32_t main_pages = kv_pages_for_frontier(main_frontier);
    const std::uint32_t backend_pages = kv_pages_for_frontier(backend_frontier);
#endif
    return qwen3_5::CheckpointSummary{
        .ref   = checkpoint,
        .scope = runtime::CheckpointScope::Private,
        .shortlist_key =
            {
                .digests      = sequence.prefix_digests.at(checkpoint.frontier),
                .frontier     = checkpoint.frontier,
                .identity_tag = identity_tag,
            },
        .state_residency = residency,
        .required_kv =
            {
                .main_frontier    = main_frontier,
                .backend_frontier = backend_frontier,
                .main_pages       = main_pages,
                .backend_pages    = backend_pages,
            },
        .rebuild_work = validated_rebuild_work(rebuild_work, checkpoint.frontier),
    };
}

qwen3_5::ContinuationSummary
ProgramImpl::continuation_summary(const SequenceState& sequence) const {
    qwen3_5::ContinuationSummary summary;
    summary.long_anchors.reserve(sequence.long_anchors.size());
    populate_continuation_summary(sequence, summary);
    return summary;
}

void ProgramImpl::populate_continuation_summary(const SequenceState& sequence,
                                                qwen3_5::ContinuationSummary& summary) const {
    validate_long_anchor_ordinals(sequence.long_anchors,
                                  context_cache.max_long_anchors_per_continuation.value_or(0));
    if (summary.long_anchors.capacity() < sequence.long_anchors.size()) {
        throw std::logic_error("continuation summary backing was not reserved");
    }
    summary.endpoint.reset();
    summary.rewrite.reset();
    summary.long_anchors.clear();
    summary.active_references = 0;
    if (sequence.endpoint_valid) {
        const runtime::CheckpointRef endpoint{
            .kind     = runtime::CheckpointKind::SessionEndpoint,
            .frontier = sequence.execution_frontier,
        };
        runtime::PrefillWork endpoint_work = sequence.rebuild_work;
        summary.endpoint =
            checkpoint_summary(sequence, endpoint, sequence.state.read, endpoint_work);
    }
    if (sequence.rewrite_checkpoint.valid) {
        if (!sequence.rewrite_state) {
            throw std::logic_error("rewrite checkpoint has no StateImage");
        }
        const runtime::CheckpointRef rewrite{
            .kind     = checkpoint_kind(sequence.rewrite_checkpoint.kind),
            .frontier = sequence.rewrite_checkpoint.frontier,
        };
        summary.rewrite = checkpoint_summary(sequence, rewrite, *sequence.rewrite_state,
                                             sequence.rewrite_checkpoint.rebuild_work);
    }
    for (const LongAnchorCheckpoint& anchor : sequence.long_anchors) {
        summary.long_anchors.push_back(
            checkpoint_summary(sequence,
                               runtime::CheckpointRef{.kind = runtime::CheckpointKind::LongAnchor,
                                                      .frontier = anchor.frontier,
                                                      .ordinal  = anchor.ordinal},
                               anchor.state, anchor.rebuild_work));
    }
    if (!summary.endpoint && !summary.rewrite && summary.long_anchors.empty()) {
        throw std::logic_error("private continuation has no checkpoint");
    }
    const auto* begin = continuation_states.data();
    const auto* end   = begin + continuation_capacity;
    if (&sequence >= begin && &sequence < end) {
        const std::size_t index = static_cast<std::size_t>(&sequence - begin);
        summary.active_references =
            continuation_slots[index].role == ContinuationSlotRole::Active ? 1U : 0U;
    }
}

qwen3_5::SharedPrefixSummary
ProgramImpl::shared_prefix_summary(const SharedPrefixState& shared) const {
    if (!shared.kv || !shared.identity || shared.frontier == 0 ||
        !state_store->valid(shared.state)) {
        throw std::logic_error("shared-prefix summary source is incomplete");
    }
    const StateReplicaResidency state_location = state_store->residency(shared.state);
    runtime::ReplicaResidency residency        = runtime::ReplicaResidency::DeviceOnly;
    if (state_location == StateReplicaResidency::HostOnly) {
        residency = runtime::ReplicaResidency::HostOnly;
    } else if (state_location == StateReplicaResidency::Both) {
        residency = runtime::ReplicaResidency::Both;
    } else if (state_location != StateReplicaResidency::DeviceOnly) {
        throw std::logic_error("shared-prefix StateImage has no published replica");
    }
    return qwen3_5::SharedPrefixSummary{
        .checkpoint =
            {
                .ref =
                    {
                        .kind     = runtime::CheckpointKind::SharedStablePrefix,
                        .frontier = shared.frontier,
                    },
                .scope           = runtime::CheckpointScope::Shared,
                .shortlist_key   = shared.identity->shortlist_key,
                .state_residency = residency,
                .required_kv =
                    {
                        .main_frontier    = shared.frontier,
                        .backend_frontier = shared.backend_frontier,
                        .main_pages       = kv_pages_for_frontier(shared.frontier),
                        .backend_pages    = kv_pages_for_frontier(shared.backend_frontier),
                    },
                .rebuild_work = validated_rebuild_work(shared.rebuild_work, shared.frontier),
            },
        .active_references = shared.active_references,
    };
}

PrefillProgress ProgramImpl::advance_prefill(SequenceHandle sequence,
                                             runtime::ExecutionTiming* failed_timing) {
    if (pending_transaction_ || !valid_sequence(sequence)) {
        throw std::logic_error("prefill sequence capability is invalid");
    }
    const std::uint32_t lane = ContractAccess::lane(sequence).value;
    if (requests[lane].lifecycle != Lifecycle::Prefilling) {
        throw std::logic_error("prefill advance requires a prefilling sequence");
    }
    try {
        runtime::PrefillStepResult step = advance_prefill_raw(lane, failed_timing);
        if (failed_timing != nullptr) { *failed_timing += step.timing; }
        return wrap_prefill(lane, std::move(step));
    } catch (...) {
        const Clock::time_point cleanup_started = Clock::now();
        clear_execution_failure_lanes(std::span<const std::uint32_t>(&lane, 1));
        if (failed_timing != nullptr) {
            failed_timing->post_host_ns += elapsed_ns(cleanup_started);
        }
        throw;
    }
}

bool ProgramImpl::can_clear_lane_strict(const SequenceState& sequence) const {
    const auto* begin = continuation_states.data();
    const auto* end   = begin + continuation_capacity;
    if (&sequence < begin || &sequence >= end || !state_store || !text_kv_addresses ||
        !text_kv_pages || !sequence.kv) {
        return false;
    }
    const std::uint32_t continuation = static_cast<std::uint32_t>(&sequence - begin);
    if (continuation_slots[continuation].role != ContinuationSlotRole::Active ||
        !text_kv_addresses->can_release_after_deactivate(sequence.kv->text) ||
        (sequence.kv->backend &&
         (!backend_kv_addresses || !backend_kv_pages ||
          !backend_kv_addresses->can_release_after_deactivate(*sequence.kv->backend)))) {
        return false;
    }

    for (std::size_t position = 0; position < sequence.shared_prefix_references.size();
         ++position) {
        const std::uint32_t index = sequence.shared_prefix_references[position];
        if (index >= shared_prefix_capacity ||
            shared_prefix_slots[index].role != SharedPrefixSlotRole::Catalogued) {
            return false;
        }
        const std::uint32_t required = static_cast<std::uint32_t>(std::count(
            sequence.shared_prefix_references.begin(),
            sequence.shared_prefix_references.begin() + static_cast<std::ptrdiff_t>(position + 1U),
            index));
        if (shared_prefix_states[index].active_references < required) { return false; }
    }

    if (!state_store->valid(sequence.state.read) || !state_store->valid(sequence.state.write) ||
        (sequence.state.fork_pending &&
         (!sequence.state.borrows_read() ||
          !state_store->can_abort_fork(sequence.state.read, sequence.state.write)))) {
        return false;
    }
    enum class ForkEndpoint : std::uint8_t { None, Source, Destination };
    const auto validate_state = [&](StateImageHandle handle, bool release_object,
                                    ForkEndpoint fork_endpoint = ForkEndpoint::None) {
        if (!state_store->valid(handle)) { return false; }
        const std::uint32_t owned = owned_checkpoint_references(sequence, handle);
        const std::uint32_t total = state_store->checkpoint_references(handle);
        if (owned > total ||
            (owned != 0 && state_store->role(handle) != StateImageRole::CheckpointImmutable &&
             fork_endpoint != ForkEndpoint::Destination)) {
            return false;
        }
        if (!release_object || total != owned) { return true; }
        if (fork_endpoint == ForkEndpoint::Source) {
            return state_store->can_release_source_after_fork_abort(sequence.state.read,
                                                                    sequence.state.write, owned);
        }
        if (fork_endpoint == ForkEndpoint::Destination) {
            return state_store->can_release_destination_after_fork_abort(
                sequence.state.read, sequence.state.write, owned);
        }
        return state_store->can_release_after_checkpoint_references(handle, owned);
    };
    const auto duplicates_binding = [&](StateImageHandle handle) {
        return handle == sequence.state.read || handle == sequence.state.write;
    };

    if (!validate_state(sequence.state.read,
                        !sequence.state.read_has_external_owner() ||
                            sequence.state.read == sequence.state.write,
                        sequence.state.fork_pending ? ForkEndpoint::Source : ForkEndpoint::None)) {
        return false;
    }
    if (sequence.state.write != sequence.state.read &&
        !validate_state(sequence.state.write, true,
                        sequence.state.fork_pending ? ForkEndpoint::Destination
                                                    : ForkEndpoint::None)) {
        return false;
    }
    if (sequence.rewrite_state && !duplicates_binding(*sequence.rewrite_state) &&
        !validate_state(*sequence.rewrite_state, true)) {
        return false;
    }
    for (std::size_t index = 0; index < sequence.long_anchors.size(); ++index) {
        const StateImageHandle handle = sequence.long_anchors[index].state;
        bool repeated                 = duplicates_binding(handle) ||
                        (sequence.rewrite_state && handle == *sequence.rewrite_state);
        for (std::size_t prior = 0; !repeated && prior < index; ++prior) {
            repeated = sequence.long_anchors[prior].state == handle;
        }
        if (!repeated && !validate_state(handle, true)) { return false; }
    }
    if (sequence.reserved_state) {
        const StateImageHandle handle = *sequence.reserved_state;
        bool repeated                 = duplicates_binding(handle) ||
                        (sequence.rewrite_state && handle == *sequence.rewrite_state);
        for (const LongAnchorCheckpoint& anchor : sequence.long_anchors) {
            repeated = repeated || anchor.state == handle;
        }
        if (!repeated && !validate_state(handle, true)) { return false; }
    }
    return true;
}

void ProgramImpl::release_active_shared_references_strict(SequenceState& sequence) noexcept {
    for (const std::uint32_t index : sequence.shared_prefix_references) {
        if (index >= shared_prefix_capacity ||
            shared_prefix_slots[index].role != SharedPrefixSlotRole::Catalogued ||
            shared_prefix_states[index].active_references == 0) {
            std::terminate();
        }
        --shared_prefix_states[index].active_references;
    }
    sequence.shared_prefix_references.clear();
}

bool ProgramImpl::clear_lane_strict(SequenceState& sequence, RequestControl& request) noexcept {
    try {
        if (!can_clear_lane_strict(sequence)) { return false; }
    } catch (...) { return false; }
    const auto* begin                = continuation_states.data();
    const std::uint32_t continuation = static_cast<std::uint32_t>(&sequence - begin);
    release_active_shared_references_strict(sequence);
    release_active_sequence_kv_strict(sequence);
    release_active_sequence_state_strict(sequence);
    request.prefill.reset();
    retire_continuation_slot(continuation);
    request.lifecycle            = Lifecycle::Empty;
    request.pending              = {};
    request.active_resources     = {};
    request.optional_resources   = {};
    request.publish_continuation = true;
    return true;
}

void ProgramImpl::clear_execution_failure_lanes(std::span<const std::uint32_t> lanes) noexcept {
    // A concurrent resource transaction may pin or inspect these active owners. Engine-wide
    // cleanup aborts that transaction before releasing lanes, preserving the only safe order.
    if (has_context_transaction()) { return; }
    for (const std::uint32_t lane : lanes) {
        if (lane >= max_concurrency || active_continuations[lane] >= continuation_capacity) {
            continue;
        }
        clear_lane_best_effort(active_sequence(lane), requests[lane]);
        invalidate_lane(lane);
    }
}

#if defined(NINFER_WITH_KVMEM)
void ProgramImpl::reset_native_kvmem_owner() noexcept {
    if (!native_kvmem_conversation || !native_kvmem_backend) {
        native_kvmem_poisoned = true;
        return;
    }
    try {
        device.synchronize();
        // abort_pending/fail_all can discard a licensed round without the
        // normal resolve_pending_raw cancellation path. Abandon its capture
        // before clearing/rebinding Raw; unaccepted columns must not publish K.
        if (native_mtp_accepted_keys && native_mtp_accepted_keys->verify_in_flight()) {
            native_mtp_accepted_keys->discard_verify();
        }
        if (!native_kvmem_poisoned && !native_kvmem_conversation->runtime().pending()) {
            // Normal release/abort follows pinned reset_policy: clear logical
            // history and mirrors without reallocating/zeroing the CPU arena.
            native_kvmem_conversation->clear_for_fresh_owner();
        } else {
            // A failed or unapplied physical transition is not a healthy empty
            // archive. Preserve the existing retire/reconstruct recovery path.
            auto runtime_config = native_kvmem_conversation->runtime().config();
            auto raw_config = native_kvmem_conversation->raw().config();
            std::optional<kvmem::RawKvStoreConfig> follower_config;
            if (auto* follower = native_kvmem_conversation->follower_raw()) {
                follower_config = follower->config();
                follower->wait_writes();
            }
            native_kvmem_conversation->raw().wait_writes();
            (void)native_kvmem_conversation->runtime().truncate_to(0);
            if (native_kvmem_backend->occupied_slots() != 0) {
                throw std::logic_error("native KVMem failure left GPU slots occupied");
            }
            native_kvmem_conversation.reset();
            native_kvmem_conversation = std::make_unique<KVMemConversation>(
                std::move(runtime_config), std::move(raw_config), *native_kvmem_backend,
                std::move(follower_config));
        }
        if (native_prefill_features) {
            native_prefill_features->bind_raw(native_kvmem_conversation->raw(), 0U, true);
        }
        if (native_decode_features) {
            native_decode_features->bind_raw(native_kvmem_conversation->raw(), 0U, true);
        }
        if (native_mtp_accepted_keys) {
            native_mtp_accepted_keys->rebind_raw(native_kvmem_conversation->raw(), 0U);
        }
        native_kvmem_owner.reset();
        native_kvmem_poisoned = false;
    } catch (...) {
        native_kvmem_poisoned = true;
    }
}
#endif

void ProgramImpl::clear_lane_best_effort(SequenceState& sequence,
                                         RequestControl& request) noexcept {
    request.prefill.reset();
    request.lifecycle            = Lifecycle::Empty;
    request.pending              = {};
    request.active_resources     = {};
    request.optional_resources   = {};
    request.publish_continuation = true;
    const auto* begin            = continuation_states.data();
    const auto* end              = begin + continuation_capacity;
    if (&sequence >= begin && &sequence < end) {
        release_continuation_slot_best_effort(static_cast<std::uint32_t>(&sequence - begin));
    }
}

StateImageSelectors ProgramImpl::state_selectors(const SequenceState& sequence) const {
    if (!state_store || !state_store->valid(sequence.state.read) ||
        !state_store->valid(sequence.state.write)) {
        throw std::logic_error("sequence has no active StateImage binding");
    }
    return state_store->selectors(sequence.state.read, sequence.state.write);
}

std::uint32_t ProgramImpl::owned_checkpoint_references(const SequenceState& sequence,
                                                       StateImageHandle state) const noexcept {
    std::uint32_t references = 0;
    if (sequence.rewrite_state && *sequence.rewrite_state == state) { ++references; }
    for (const LongAnchorCheckpoint& anchor : sequence.long_anchors) {
        if (anchor.state == state) { ++references; }
    }
    return references;
}

bool ProgramImpl::state_exclusive_to_sequence(const SequenceState& sequence,
                                              StateImageHandle state) const noexcept {
    if (!state_store || !state_store->valid(state)) { return false; }
    return state_store->checkpoint_references(state) ==
           owned_checkpoint_references(sequence, state);
}

void ProgramImpl::refresh_state_views(SequenceState& sequence) {
    sequence.tail_hidden               = {};
    sequence.rewrite_checkpoint_hidden = {};
    if (state_store->valid(sequence.state.read) && state_store->valid(sequence.state.write) &&
        state_store->residency(sequence.state.read) != StateReplicaResidency::HostOnly &&
        state_store->residency(sequence.state.write) != StateReplicaResidency::HostOnly) {
        const StateImageHandle committed =
            sequence.state.fork_pending ? sequence.state.read : sequence.state.write;
        sequence.tail_hidden =
            state_images->continuation_hidden_slot(state_store->physical_slot(committed));
    }
    if (sequence.rewrite_state && state_store->valid(*sequence.rewrite_state) &&
        state_store->residency(*sequence.rewrite_state) != StateReplicaResidency::HostOnly) {
        sequence.rewrite_checkpoint_hidden = state_images->continuation_hidden_slot(
            state_store->physical_slot(*sequence.rewrite_state));
    }
}

void ProgramImpl::reserve_state_entitlement(SequenceState& sequence, std::uint32_t slots) {
    const std::uint32_t owned = sequence_exclusive_state_resources(sequence).device.state_slots;
    if (slots == 0 || owned > slots) {
        throw std::logic_error("sequence StateImage entitlement is inconsistent");
    }
    if (owned == slots) { return; }
    if (slots - owned != 1 || sequence.reserved_state) {
        throw std::logic_error("sequence StateImage reservation is not a single destination");
    }
    std::optional<StateImageHandle> reserved = state_store->reserve_destination();
    if (!reserved) { throw std::bad_alloc(); }
    sequence.reserved_state = *reserved;
    if (sequence_exclusive_state_resources(sequence).device.state_slots != slots) {
        throw std::logic_error("sequence StateImage entitlement did not materialize exactly");
    }
}

void ProgramImpl::settle_state_fork(SequenceState& sequence) {
    if (!sequence.state.fork_pending) { return; }
    if (has_context_transaction()) {
        throw std::logic_error("StateImage Fork settlement overlaps a resource transaction");
    }
    const StateImageHandle source      = sequence.state.read;
    const StateImageHandle destination = sequence.state.write;
    const bool external_source         = sequence.state.read_has_external_owner();
    state_store->commit_fork(source, destination);
    sequence.state = ActiveStateBinding{.read = destination, .write = destination};
    if (!external_source && state_store->checkpoint_references(source) == 0 &&
        !state_store->release(source)) {
        throw std::logic_error("unreferenced StateImage fork source could not be released");
    }
    refresh_state_views(sequence);
}

bool ProgramImpl::has_unsettled_state_fork() const noexcept {
    for (std::uint32_t lane = 0; lane < max_concurrency; ++lane) {
        const std::uint32_t continuation = active_continuations[lane];
        if (continuation < continuation_capacity &&
            continuation_states[continuation].state.fork_pending) {
            return true;
        }
    }
    return false;
}

void ProgramImpl::release_active_sequence_state_strict(SequenceState& sequence) noexcept {
    const auto fail = []() noexcept { std::terminate(); };
    if (!state_store) { fail(); }
    try {
        if (sequence.state.fork_pending) {
            state_store->abort_fork(sequence.state.read, sequence.state.write);
        }
        if (sequence.rewrite_state) {
            state_store->release_checkpoint_reference(*sequence.rewrite_state);
        }
        for (const LongAnchorCheckpoint& anchor : sequence.long_anchors) {
            state_store->release_checkpoint_reference(anchor.state);
        }

        const auto release_if_unreferenced = [&](StateImageHandle handle, bool lifetime_owned) {
            if (!lifetime_owned || !state_store->valid(handle) ||
                state_store->checkpoint_references(handle) != 0) {
                return;
            }
            if (!state_store->release(handle)) { fail(); }
        };
        const auto duplicates_binding = [&](StateImageHandle handle) {
            return handle == sequence.state.read || handle == sequence.state.write;
        };

        release_if_unreferenced(sequence.state.write, true);
        if (sequence.state.read != sequence.state.write) {
            release_if_unreferenced(sequence.state.read, !sequence.state.read_has_external_owner());
        }
        if (sequence.rewrite_state) {
            release_if_unreferenced(*sequence.rewrite_state,
                                    !duplicates_binding(*sequence.rewrite_state));
        }
        for (std::size_t index = 0; index < sequence.long_anchors.size(); ++index) {
            const StateImageHandle handle = sequence.long_anchors[index].state;
            bool repeated                 = duplicates_binding(handle) ||
                            (sequence.rewrite_state && handle == *sequence.rewrite_state);
            for (std::size_t prior = 0; !repeated && prior < index; ++prior) {
                repeated = sequence.long_anchors[prior].state == handle;
            }
            release_if_unreferenced(handle, !repeated);
        }
        if (sequence.reserved_state) {
            const StateImageHandle handle = *sequence.reserved_state;
            bool repeated                 = duplicates_binding(handle) ||
                            (sequence.rewrite_state && handle == *sequence.rewrite_state);
            for (const LongAnchorCheckpoint& anchor : sequence.long_anchors) {
                repeated = repeated || anchor.state == handle;
            }
            release_if_unreferenced(handle, !repeated);
        }
    } catch (...) { fail(); }

    sequence.state          = {};
    sequence.rewrite_state  = std::nullopt;
    sequence.reserved_state = std::nullopt;
    sequence.endpoint_valid = false;
    sequence.long_anchors.clear();
    sequence.tail_hidden               = {};
    sequence.rewrite_checkpoint_hidden = {};
}

void ProgramImpl::release_sequence_state_strict(SequenceState& sequence) noexcept {
    const auto fail = []() noexcept { std::terminate(); };
    if (!state_store || sequence.state.fork_pending) { fail(); }

    try {
        if (sequence.rewrite_state) {
            state_store->release_checkpoint_reference(*sequence.rewrite_state);
        }
        for (const LongAnchorCheckpoint& anchor : sequence.long_anchors) {
            state_store->release_checkpoint_reference(anchor.state);
        }

        const auto release_if_unreferenced = [&](StateImageHandle handle, bool lifetime_owned) {
            if (!lifetime_owned || !state_store->valid(handle) ||
                state_store->checkpoint_references(handle) != 0) {
                return;
            }
            if (!state_store->release(handle)) { fail(); }
        };
        const auto repeated_before_anchor = [&](std::size_t anchor_index, StateImageHandle handle) {
            if ((sequence.endpoint_valid &&
                 (handle == sequence.state.read || handle == sequence.state.write)) ||
                (sequence.rewrite_state && handle == *sequence.rewrite_state)) {
                return true;
            }
            for (std::size_t prior = 0; prior < anchor_index; ++prior) {
                if (sequence.long_anchors[prior].state == handle) { return true; }
            }
            return false;
        };

        if (sequence.endpoint_valid) {
            release_if_unreferenced(sequence.state.write, true);
            if (sequence.state.read != sequence.state.write) {
                release_if_unreferenced(sequence.state.read,
                                        !sequence.state.read_has_external_owner());
            }
        }
        if (sequence.rewrite_state) {
            const StateImageHandle handle = *sequence.rewrite_state;
            const bool duplicates_endpoint =
                sequence.endpoint_valid &&
                (handle == sequence.state.read || handle == sequence.state.write);
            release_if_unreferenced(handle, !duplicates_endpoint);
        }
        for (std::size_t index = 0; index < sequence.long_anchors.size(); ++index) {
            const StateImageHandle handle = sequence.long_anchors[index].state;
            release_if_unreferenced(handle, !repeated_before_anchor(index, handle));
        }
        if (sequence.reserved_state) {
            const StateImageHandle handle = *sequence.reserved_state;
            bool repeated                 = sequence.endpoint_valid &&
                            (handle == sequence.state.read || handle == sequence.state.write);
            repeated = repeated || (sequence.rewrite_state && handle == *sequence.rewrite_state);
            for (const LongAnchorCheckpoint& anchor : sequence.long_anchors) {
                repeated = repeated || anchor.state == handle;
            }
            release_if_unreferenced(handle, !repeated);
        }
    } catch (...) { fail(); }

    sequence.state          = {};
    sequence.rewrite_state  = std::nullopt;
    sequence.reserved_state = std::nullopt;
    sequence.endpoint_valid = false;
    sequence.long_anchors.clear();
    sequence.tail_hidden               = {};
    sequence.rewrite_checkpoint_hidden = {};
}

void ProgramImpl::release_sequence_state(SequenceState& sequence) noexcept {
    if (!state_store) { return; }
    if (sequence.state.fork_pending && state_store->valid(sequence.state.read) &&
        state_store->valid(sequence.state.write)) {
        try {
            state_store->abort_fork(sequence.state.read, sequence.state.write);
        } catch (...) {}
    }

    try {
        if (sequence.rewrite_state && state_store->valid(*sequence.rewrite_state) &&
            state_store->checkpoint_references(*sequence.rewrite_state) != 0) {
            state_store->release_checkpoint_reference(*sequence.rewrite_state);
        }
        for (const LongAnchorCheckpoint& anchor : sequence.long_anchors) {
            if (state_store->valid(anchor.state) &&
                state_store->checkpoint_references(anchor.state) != 0) {
                state_store->release_checkpoint_reference(anchor.state);
            }
        }
    } catch (...) {}

    const auto releasable = [&](StateImageHandle handle) { return state_store->valid(handle); };
    if (releasable(sequence.state.write)) { (void)state_store->release(sequence.state.write); }
    if (!sequence.state.read_has_external_owner() && sequence.state.read != sequence.state.write &&
        releasable(sequence.state.read)) {
        (void)state_store->release(sequence.state.read);
    }
    if (sequence.rewrite_state) {
        const StateImageHandle handle = *sequence.rewrite_state;
        const bool duplicates_binding =
            handle == sequence.state.write ||
            (!sequence.state.read_has_external_owner() && handle == sequence.state.read);
        if (!duplicates_binding && releasable(handle)) { (void)state_store->release(handle); }
    }
    for (std::size_t index = 0; index < sequence.long_anchors.size(); ++index) {
        const StateImageHandle handle = sequence.long_anchors[index].state;
        bool duplicate =
            handle == sequence.state.write ||
            (!sequence.state.read_has_external_owner() && handle == sequence.state.read) ||
            (sequence.rewrite_state && handle == *sequence.rewrite_state);
        for (std::size_t previous = 0; !duplicate && previous < index; ++previous) {
            duplicate = sequence.long_anchors[previous].state == handle;
        }
        if (!duplicate && releasable(handle)) { (void)state_store->release(handle); }
    }
    if (sequence.reserved_state) {
        const StateImageHandle handle = *sequence.reserved_state;
        bool duplicate =
            handle == sequence.state.write ||
            (!sequence.state.read_has_external_owner() && handle == sequence.state.read) ||
            (sequence.rewrite_state && handle == *sequence.rewrite_state);
        for (const LongAnchorCheckpoint& anchor : sequence.long_anchors) {
            duplicate = duplicate || anchor.state == handle;
        }
        if (!duplicate && releasable(handle)) { (void)state_store->release(handle); }
    }
    sequence.state          = {};
    sequence.rewrite_state  = std::nullopt;
    sequence.reserved_state = std::nullopt;
    sequence.endpoint_valid = false;
    sequence.long_anchors.clear();
    sequence.tail_hidden               = {};
    sequence.rewrite_checkpoint_hidden = {};
}

void ProgramImpl::release_active_shared_references(SequenceState& sequence) noexcept {
    for (const std::uint32_t index : sequence.shared_prefix_references) {
        if (index >= shared_prefix_capacity ||
            shared_prefix_slots[index].role != SharedPrefixSlotRole::Catalogued ||
            shared_prefix_states[index].active_references == 0) {
            continue;
        }
        --shared_prefix_states[index].active_references;
    }
    sequence.shared_prefix_references.clear();
}

qwen3_5::PagedKVCache* ProgramImpl::backend_kv_cache() noexcept {
    if (speculative_backend == SpeculativeBackend::Mtp) { return decoder->mtp_cache(); }
    if (dflash && dflash->full) { return &*dflash->full; }
    return nullptr;
}

const qwen3_5::PagedKVCache* ProgramImpl::backend_kv_cache() const noexcept {
    if (speculative_backend == SpeculativeBackend::Mtp) { return decoder->mtp_cache(); }
    if (dflash && dflash->full) { return &*dflash->full; }
    return nullptr;
}

std::uint32_t ProgramImpl::backend_kv_valid(const SequenceState& sequence) const noexcept {
    if (speculative_backend == SpeculativeBackend::Mtp) { return sequence.mtp_kv_valid; }
    if (speculative_backend == SpeculativeBackend::DFlash) {
        return sequence.dflash_context_frontier;
    }
    return 0;
}

void ProgramImpl::resize_sequence_kv_entitlement(SequenceState& sequence, std::uint32_t text_pages,
                                                 std::uint32_t backend_pages) {
    if (!sequence.kv || text_pages == 0 ||
        (sequence.kv->backend.has_value() != (backend_pages != 0))) {
        throw std::invalid_argument("KV resize entitlement does not match the sequence bundle");
    }
    text_kv_addresses->resize_entitlement(sequence.kv->text, text_pages);
    if (sequence.kv->backend) {
        backend_kv_addresses->resize_entitlement(*sequence.kv->backend, backend_pages);
    }
}

void ProgramImpl::bind_sequence_kv(SequenceState& sequence) {
    if (!sequence.kv) { throw std::logic_error("KV allocation bundle is unavailable"); }
    const std::int32_t row = static_cast<std::int32_t>(sequence.lane);
    const bool text_active = text_kv_addresses->active(sequence.kv->text);
    const bool backend_active =
        sequence.kv->backend && backend_kv_addresses->active(*sequence.kv->backend);
    if (sequence.kv->backend && text_active != backend_active) {
        throw std::logic_error("KV address-space activation is not bundle-atomic");
    }
    try {
        if (!text_active) {
            text_kv_addresses->activate(sequence.kv->text,
                                        text_kv_addresses->mapped_pages(sequence.kv->text), row,
                                        device.stream);
            if (sequence.kv->backend) {
                backend_kv_addresses->activate(
                    *sequence.kv->backend,
                    backend_kv_addresses->mapped_pages(*sequence.kv->backend), row,
                    device.stream);
            }
        }
        set_device_i32(io.text_kv_table_row, text_kv_addresses->bound_row(sequence.kv->text));
        set_device_i32(io.backend_kv_table_row,
                       sequence.kv->backend ? backend_kv_addresses->bound_row(*sequence.kv->backend)
                                            : 0);
    } catch (...) {
        if (!text_active) {
            if (sequence.kv->backend && backend_kv_addresses->active(*sequence.kv->backend)) {
                backend_kv_addresses->deactivate(*sequence.kv->backend);
            }
            if (text_kv_addresses->active(sequence.kv->text)) {
                text_kv_addresses->deactivate(sequence.kv->text);
            }
        }
        throw;
    }
}

void ProgramImpl::unbind_sequence_kv(SequenceState& sequence) noexcept {
    if (!sequence.kv) { return; }
    try {
        if (sequence.kv->backend && backend_kv_addresses->active(*sequence.kv->backend)) {
            backend_kv_addresses->deactivate(*sequence.kv->backend);
        }
    } catch (...) {}
    try {
        if (text_kv_addresses->active(sequence.kv->text)) {
            text_kv_addresses->deactivate(sequence.kv->text);
        }
    } catch (...) {}
}

void ProgramImpl::ensure_sequence_kv_mapped(SequenceState& sequence, std::uint32_t main_tokens,
                                            std::uint32_t backend_tokens) {
    if (!sequence.kv || main_tokens > capacity || backend_tokens > capacity) {
        throw std::logic_error("KV materialization request is outside the sequence bundle");
    }
    if (backend_tokens != 0 && !sequence.kv->backend) {
        throw std::logic_error("backend KV materialization requested without an allocation");
    }
    if (kvmem.enabled) {
        // KVMem-on writers hold only their current growth extent, not the full
        // selected-history plus generation envelope. Decode and MTP can grow
        // after prefill, so expand the active entitlement at the single mapping
        // boundary instead of relying on a prefill-only reservation.
        const std::uint32_t main_pages = std::max(
            {1U, kv_pages_for_frontier(main_tokens),
             text_kv_addresses->mapped_pages(sequence.kv->text)});
        if (main_pages > text_kv_addresses->entitlement(sequence.kv->text)) {
            text_kv_addresses->resize_entitlement(sequence.kv->text, main_pages);
        }
        if (sequence.kv->backend) {
            const std::uint32_t backend_pages = std::max(
                {1U, kv_pages_for_frontier(backend_tokens),
                 backend_kv_addresses->mapped_pages(*sequence.kv->backend)});
            if (backend_pages > backend_kv_addresses->entitlement(*sequence.kv->backend)) {
                backend_kv_addresses->resize_entitlement(*sequence.kv->backend, backend_pages);
            }
        }
    }
    text_kv_addresses->ensure_mapped_to_tokens(sequence.kv->text, main_tokens, device.stream);
    if (backend_tokens != 0) {
        backend_kv_addresses->ensure_mapped_to_tokens(*sequence.kv->backend, backend_tokens,
                                                      device.stream);
    }
}

void ProgramImpl::commit_sequence_kv(SequenceState& sequence, std::uint32_t main_tokens,
                                     std::uint32_t backend_tokens) {
    if (!sequence.kv || main_tokens > capacity || backend_tokens > capacity ||
        (backend_tokens != 0 && !sequence.kv->backend)) {
        throw std::logic_error("KV commit request is outside the sequence bundle");
    }
    text_kv_addresses->commit_frontier(sequence.kv->text, main_tokens);
    if (sequence.kv->backend) {
        backend_kv_addresses->commit_frontier(*sequence.kv->backend, backend_tokens);
    }
}

void ProgramImpl::trim_sequence_kv(SequenceState& sequence, std::uint32_t main_tokens,
                                   std::uint32_t backend_tokens) {
    if (!sequence.kv || main_tokens > capacity || backend_tokens > main_tokens) {
        throw std::logic_error("KV trim request is outside the sequence bundle");
    }
    if (backend_tokens != 0 && !sequence.kv->backend) {
        throw std::logic_error("backend KV trim requested without an allocation");
    }
    text_kv_addresses->destructive_truncate(sequence.kv->text, main_tokens);
    if (sequence.kv->backend) {
        backend_kv_addresses->destructive_truncate(*sequence.kv->backend, backend_tokens);
    }
}

void ProgramImpl::release_sequence_growth_entitlement(SequenceState& sequence) noexcept {
    if (!sequence.kv) { return; }
    try {
        text_kv_addresses->release_growth_entitlement(sequence.kv->text);
        if (sequence.kv->backend) {
            backend_kv_addresses->release_growth_entitlement(*sequence.kv->backend);
        }
    } catch (...) {}
}

void ProgramImpl::release_active_sequence_kv_strict(SequenceState& sequence) noexcept {
    if (!sequence.kv || !text_kv_addresses ||
        !text_kv_addresses->can_release_after_deactivate(sequence.kv->text) ||
        (sequence.kv->backend &&
         (!backend_kv_addresses ||
          !backend_kv_addresses->can_release_after_deactivate(*sequence.kv->backend)))) {
        std::terminate();
    }
    if (sequence.kv->backend &&
        !backend_kv_addresses->release_after_deactivate(*sequence.kv->backend)) {
        std::terminate();
    }
    if (!text_kv_addresses->release_after_deactivate(sequence.kv->text)) { std::terminate(); }
    sequence.kv.reset();
    if (host_kv_extents) { (void)host_kv_extents->release_unreferenced(); }
}

void ProgramImpl::release_sequence_kv_strict(SequenceState& sequence) noexcept {
    if (!sequence.kv || !text_kv_addresses || !text_kv_addresses->can_release(sequence.kv->text)) {
        std::terminate();
    }
    if (sequence.kv->backend &&
        (!backend_kv_addresses || !backend_kv_addresses->can_release(*sequence.kv->backend))) {
        std::terminate();
    }
    if (sequence.kv->backend && !backend_kv_addresses->release(*sequence.kv->backend)) {
        std::terminate();
    }
    if (!text_kv_addresses->release(sequence.kv->text)) { std::terminate(); }
    sequence.kv.reset();
    if (host_kv_extents) { (void)host_kv_extents->release_unreferenced(); }
}

void ProgramImpl::release_sequence_kv(SequenceState& sequence) noexcept {
    if (!sequence.kv) { return; }
    unbind_sequence_kv(sequence);
    if (sequence.kv->backend && backend_kv_addresses) {
        (void)backend_kv_addresses->release(*sequence.kv->backend);
    }
    if (text_kv_addresses) { (void)text_kv_addresses->release(sequence.kv->text); }
    sequence.kv.reset();
    if (host_kv_extents) { (void)host_kv_extents->release_unreferenced(); }
}

qwen3_5::PagedKVCacheView ProgramImpl::text_kv_view(const SequenceState& sequence) const {
    if (!sequence.kv || !text_kv_addresses->active(sequence.kv->text)) {
        throw std::logic_error("sequence has no active KV execution mapping");
    }
    return decoder->text_kv.execution_view(text_kv_addresses->execution_row(sequence.kv->text));
}

qwen3_5::PagedKVCacheView ProgramImpl::mtp_kv_view(const SequenceState& sequence) const {
    if (speculative_backend != SpeculativeBackend::Mtp) { return {}; }
    if (decoder->mtp_cache() == nullptr || !sequence.kv || !sequence.kv->backend ||
        !backend_kv_addresses->active(*sequence.kv->backend)) {
        throw std::logic_error("sequence has no active MTP KV execution mapping");
    }
    return decoder->mtp_cache()->execution_view(
        backend_kv_addresses->execution_row(*sequence.kv->backend));
}

#if defined(NINFER_WITH_KVMEM)
bool ProgramImpl::native_endpoint_tail_published(const SequenceState& sequence) const {
    if (!native_kvmem_conversation || !native_kvmem_backend) { return false; }
    const auto& store = native_kvmem_conversation->runtime().store();
    if (store.total_tokens() == 0) {
        return sequence.execution_frontier == 0 && sequence.native_tail_materialized_tokens == 0;
    }
    if (store.blocks().empty()) { return false; }
    const auto& tail = store.blocks().back();
    if (tail.orig_pos_end() != sequence.execution_frontier || tail.n_tokens == 0 ||
        tail.n_tokens > kvmem.block_tokens || tail.gpu_slot < 0 || tail.in_flight ||
        tail.tier != kvmem::KvTier::GPU) {
        return false;
    }
    // This is published native coverage, not an uncommitted/pending tail.
    // Partial accepted tails retain their exact length until growth or park.
    const std::uint32_t published_tail =
        tail.n_tokens == kvmem.block_tokens ? 0U : tail.n_tokens;
    if (sequence.native_tail_materialized_tokens != published_tail) { return false; }
    (void)native_kvmem_backend->pages_for_slot(tail.block_id, tail.gpu_slot);
    return true;
}

void ProgramImpl::archive_native_follower_for_park(
    SequenceState& sequence, const kvmem::KvMemStore& store,
    kvmem::RawKvStore& follower_raw, std::span<const std::uint32_t> outgoing_ids) {
    // drain_resident_to_host has prepared the empty selection; its pending
    // spill plan must still be intact before follower bytes are archived.
    if (!kvmem.enabled || speculative_backend != SpeculativeBackend::Mtp ||
        !native_kvmem_backend || !native_kvmem_conversation || native_kvmem_poisoned ||
        !native_kvmem_owner || *native_kvmem_owner >= continuation_capacity ||
        &continuation_states[*native_kvmem_owner] != &sequence ||
        continuation_slots[*native_kvmem_owner].role != ContinuationSlotRole::Catalogued ||
        !native_kvmem_conversation->runtime().pending() ||
        !native_kvmem_conversation->runtime().last_plan().stage_in.empty() ||
        !std::equal(native_kvmem_conversation->runtime().last_plan().stage_out.begin(),
                    native_kvmem_conversation->runtime().last_plan().stage_out.end(),
                    outgoing_ids.begin(), outgoing_ids.end()) ||
        &native_kvmem_conversation->runtime().store() != &store ||
        native_kvmem_conversation->follower_raw() != &follower_raw ||
        !native_kvmem_follower_backend || !text_kv_addresses || !backend_kv_addresses ||
        !sequence.kv ||
        !sequence.kv->backend || !sequence.compact_kv_frontier ||
        !sequence.endpoint_valid || !native_endpoint_tail_published(sequence) ||
        store.config().block_tokens != kvmem.block_tokens ||
        kvmem.block_tokens != KVMemFollowerPageBackend::kBlockTokens ||
        store.total_tokens() != sequence.execution_frontier ||
        native_kvmem_conversation->metadata().row_positions.size() !=
            sequence.execution_frontier ||
        sequence.text_kv_valid != *sequence.compact_kv_frontier ||
        sequence.text_kv_valid == 0 ||
        text_kv_addresses->active(sequence.kv->text) ||
        text_kv_addresses->committed_frontier(sequence.kv->text) !=
            sequence.text_kv_valid ||
        backend_kv_addresses->active(*sequence.kv->backend) ||
        backend_kv_addresses->committed_frontier(*sequence.kv->backend) !=
            sequence.mtp_kv_valid) {
        throw std::logic_error("native park has no stable attached MTP execution view");
    }

    const std::uint32_t block_tokens = kvmem.block_tokens;
    const std::uint32_t total_tokens = store.total_tokens();
    const std::uint64_t expected_block_count =
        (static_cast<std::uint64_t>(total_tokens) + block_tokens - 1U) / block_tokens;
    if (expected_block_count != store.block_count()) {
        throw std::logic_error("native park Store block table does not cover its logical rows");
    }

    std::vector<std::uint8_t> outgoing(store.block_count(), 0);
    for (const std::uint32_t id : outgoing_ids) {
        if (id >= outgoing.size() || outgoing[id]) {
            throw std::logic_error("native park outgoing target IDs are invalid or repeated");
        }
        outgoing[id] = 1;
    }

    std::vector<std::uint32_t> resident_ids;
    resident_ids.reserve(store.block_count());
    std::uint64_t target_frontier = 0;
    for (std::uint32_t id = 0; id < store.block_count(); ++id) {
        const kvmem::KvMemBlock& block = store.blocks()[id];
        const std::uint64_t expected_begin = static_cast<std::uint64_t>(id) * block_tokens;
        const std::uint32_t expected_tokens = static_cast<std::uint32_t>(
            std::min<std::uint64_t>(block_tokens,
                                    static_cast<std::uint64_t>(total_tokens) - expected_begin));
        const bool gpu_tier = block.tier == kvmem::KvTier::GPU;
        const bool has_gpu_slot = block.gpu_slot >= 0;
        if (block.block_id != id || block.orig_pos_start != expected_begin ||
            block.n_tokens != expected_tokens || block.gpu_slot < -1 ||
            block.in_flight || gpu_tier != has_gpu_slot) {
            throw std::logic_error("native park Store block metadata is inconsistent");
        }
        if (has_gpu_slot) {
            if (!outgoing[id]) {
                throw std::logic_error("native park omitted a resident target block from spill");
            }
            resident_ids.push_back(id);
            target_frontier += block.n_tokens;
        } else if (outgoing[id]) {
            throw std::logic_error("native park marked a nonresident target block outgoing");
        }
    }
    if (resident_ids.empty() || outgoing_ids.size() != resident_ids.size() ||
        target_frontier != sequence.text_kv_valid ||
        target_frontier > std::numeric_limits<std::uint32_t>::max()) {
        throw std::logic_error("native park resident rows disagree with the target view");
    }

    const bool follower_lags_one =
        sequence.mtp_kv_valid < target_frontier &&
        target_frontier - sequence.mtp_kv_valid == 1U;
    if (sequence.mtp_kv_valid != target_frontier && !follower_lags_one) {
        throw std::logic_error("native park follower frontier differs by more than one row");
    }

    std::vector<KVMemFollowerExecutionRecord> expected_execution;
    expected_execution.reserve(resident_ids.size());
    std::uint64_t expected_frontier = 0;
    bool found_final_block = false;
    for (const std::uint32_t id : resident_ids) {
        const kvmem::KvMemBlock& block = store.blocks()[id];
        std::uint32_t rows = block.n_tokens;
        if (follower_lags_one && block.orig_pos_end() == total_tokens) {
            if (id != resident_ids.back()) {
                throw std::logic_error("native park final target block is out of order");
            }
            --rows;
            found_final_block = true;
        }
        if (rows == 0) { continue; }
        if (expected_frontier > std::numeric_limits<std::uint32_t>::max() ||
            expected_frontier % KVMemFollowerExecutionMap::kPageTokens != 0) {
            throw std::logic_error("native park follower compact map is not page aligned");
        }
        expected_execution.push_back(KVMemFollowerExecutionRecord{
            .native_block_id = id,
            .original_position = block.orig_pos_start,
            .execution_begin = static_cast<std::uint32_t>(expected_frontier),
            .committed_rows = rows,
        });
        expected_frontier += rows;
    }
    if ((follower_lags_one && !found_final_block) ||
        expected_frontier != sequence.mtp_kv_valid ||
        expected_execution.size() != sequence.native_follower_execution.size()) {
        throw std::logic_error("native park follower map does not cover its committed prefix");
    }
    for (std::size_t index = 0; index < expected_execution.size(); ++index) {
        const KVMemFollowerExecutionRecord& expected = expected_execution[index];
        const KVMemFollowerExecutionRecord& actual =
            sequence.native_follower_execution[index];
        if (actual.native_block_id != expected.native_block_id ||
            actual.original_position != expected.original_position ||
            actual.execution_begin != expected.execution_begin ||
            actual.committed_rows != expected.committed_rows) {
            throw std::logic_error("native park follower map is not a contiguous resident prefix");
        }
    }

    const std::uint32_t final_block_id = store.block_count() - 1U;
    if (outgoing[final_block_id]) {
        const kvmem::KvMemBlock& final_block = store.blocks()[final_block_id];
        std::uint32_t committed_final_rows = final_block.n_tokens;
        if (follower_lags_one && resident_ids.back() == final_block_id) {
            --committed_final_rows;
        }
        if (committed_final_rows < block_tokens) {
            // stage_out refuses to overwrite a packed suffix. Truncate only
            // this outgoing final block to the execution map's committed end.
            follower_raw.invalidate_packed_from(final_block.orig_pos_start +
                                                 committed_final_rows);
        }
    }

    const auto resolved = KVMemFollowerExecutionMap::resolve(
        sequence.native_follower_execution, *backend_kv_addresses, *sequence.kv->backend);
    for (const KVMemFollowerResolvedBlock& block : resolved) {
        if (!outgoing[block.record.native_block_id]) {
            throw std::logic_error("native park follower block is not being spilled");
        }
        native_kvmem_follower_backend->stage_out(
            block.record.original_position, block.mtp_pages,
            block.record.committed_rows, follower_raw);
        if (!follower_raw.has_k_gpu(block.record.native_block_id, 0,
                                    block.record.committed_rows) ||
            !follower_raw.has_v_gpu(block.record.native_block_id, 0,
                                    block.record.committed_rows)) {
            throw std::logic_error("native park did not preserve committed packed follower K/V");
        }
    }
}

void ProgramImpl::harvest_native_follower(
    SequenceState& sequence, const kvmem::KvMemStore& store,
    kvmem::RawKvStore& follower_raw, std::span<const std::uint32_t> outgoing_ids,
    std::uint32_t committed_original_frontier,
    KVMemFollowerRetainedPages& retained) {
    if (!kvmem.enabled || speculative_backend != SpeculativeBackend::Mtp ||
        !native_kvmem_follower_backend || !backend_kv_addresses ||
        !backend_kv_pages || &retained.owner() != backend_kv_pages.get() || !sequence.kv ||
        !sequence.kv->backend ||
        (sequence.native_follower_execution.empty() && sequence.mtp_kv_valid != 0) ||
        kvmem.block_tokens != 2U * static_cast<std::uint32_t>(kPagedKVPageSize) ||
        sequence.mtp_kv_valid !=
            backend_kv_addresses->committed_frontier(*sequence.kv->backend)) {
        throw std::logic_error("native follower has no committed source execution view");
    }
    preserve_kvmem_prefill_follower(
        store, sequence.native_follower_execution, *backend_kv_addresses,
        *sequence.kv->backend, *native_kvmem_follower_backend, follower_raw, outgoing_ids,
        committed_original_frontier, sequence.mtp_kv_valid, retained);
}

void ProgramImpl::harvest_native_follower_for_query(
    SequenceState& sequence, const kvmem::KvMemStore& store,
    kvmem::RawKvStore& follower_raw,
    std::uint32_t committed_original_frontier,
    std::span<const std::uint32_t> selected_ids,
    std::uint32_t required_original_frontier,
    KVMemFollowerRetainedPages& retained) {
    if (!kvmem.enabled || speculative_backend != SpeculativeBackend::Mtp ||
        !native_kvmem_follower_backend || !backend_kv_addresses || !backend_kv_pages ||
        &retained.owner() != backend_kv_pages.get() || selected_ids.empty() || !sequence.kv ||
        !sequence.kv->backend || committed_original_frontier == 0 ||
        required_original_frontier >= committed_original_frontier ||
        store.total_tokens() != committed_original_frontier ||
        sequence.text_kv_valid != sequence.mtp_kv_valid + 1U ||
        sequence.mtp_kv_valid !=
            backend_kv_addresses->committed_frontier(*sequence.kv->backend)) {
        throw std::logic_error("native query has no one-row-deferred follower view");
    }
    const auto& records = sequence.native_follower_execution;
    std::vector<std::uint8_t> covered(store.block_count(), 0);
    std::uint32_t execution = 0;
    for (const KVMemFollowerExecutionRecord& record : records) {
        if (record.native_block_id >= store.block_count() ||
            record.execution_begin != execution || covered[record.native_block_id]) {
            throw std::logic_error("native query follower map is not an ordered prefix");
        }
        const auto& block = store.blocks()[record.native_block_id];
        if (block.n_tokens == 0) {
            throw std::logic_error("native query follower record has an empty target block");
        }
        const std::uint32_t expected_rows =
            block.orig_pos_end() == committed_original_frontier
                ? block.n_tokens - 1U : block.n_tokens;
        if (block.block_id != record.native_block_id || block.gpu_slot < 0 ||
            block.orig_pos_start != record.original_position ||
            block.orig_pos_end() > committed_original_frontier ||
            expected_rows != record.committed_rows) {
            throw std::logic_error("native query follower map disagrees with resident history");
        }
        covered[record.native_block_id] = 1;
        execution += record.committed_rows;
    }
    if (execution != sequence.mtp_kv_valid) {
        throw std::logic_error("native query follower map misses accepted rows");
    }
    for (const auto& block : store.blocks()) {
        if (block.gpu_slot < 0 || block.n_tokens == 0 ||
            block.orig_pos_start >= committed_original_frontier) {
            continue;
        }
        if (block.orig_pos_end() > committed_original_frontier) {
            throw std::logic_error("native query contains a future follower block");
        }
        const std::uint32_t expected_rows =
            block.orig_pos_end() == committed_original_frontier
                ? block.n_tokens - 1U : block.n_tokens;
        if (expected_rows != 0 && !covered[block.block_id]) {
            throw std::logic_error("native query omitted a resident follower block");
        }
    }
    const auto resolved = KVMemFollowerExecutionMap::resolve(
        records, *backend_kv_addresses, *sequence.kv->backend);
    std::vector<std::uint8_t> selected(store.block_count(), 0);
    for (const std::uint32_t id : selected_ids) {
        if (id >= selected.size() || selected[id]) {
            throw std::logic_error("native query follower selection contains an invalid block");
        }
        selected[id] = 1;
    }
    for (const KVMemFollowerResolvedBlock& block : resolved) {
        const auto id = block.record.native_block_id;
        if (selected[id]) {
            // The query suffix will be evaluated again (or its final row is
            // deferred). Do not allocate/copy a Raw body only to invalidate it.
            if (block.record.original_position >= required_original_frontier) { continue; }
            // The pinned follower's slot_holds keep case does not require a
            // complete native block. Keep this exact committed prefix too;
            // the replay installer checks its row coverage and COWs a writable
            // tail. A deferred final target row is not part of this source.
            selected[id] = 2;
            continue;
        }
        // Only outgoing blocks need a packed mirror. A selected required
        // prefix remains resident, including its actual partial tail.
        native_kvmem_follower_backend->stage_out(
            block.record.original_position, block.mtp_pages,
            block.record.committed_rows, follower_raw);
        if (!follower_raw.has_k_gpu(block.record.native_block_id, 0,
                                    block.record.committed_rows) ||
            !follower_raw.has_v_gpu(block.record.native_block_id, 0,
                                    block.record.committed_rows)) {
            throw std::logic_error("native query did not preserve packed follower K/V");
        }
    }
    backend_kv_addresses->deactivate(*sequence.kv->backend);
    for (const KVMemFollowerResolvedBlock& block : resolved) {
        if (selected[block.record.native_block_id] != 2) { continue; }
        const auto first = block.record.execution_begin /
                           static_cast<std::uint32_t>(kPagedKVPageSize);
        KVMemFollowerRetainedPages::PagePair pair{};
        pair[0] = backend_kv_addresses->logical_page(*sequence.kv->backend, first);
        if (block.record.committed_rows > static_cast<std::uint32_t>(kPagedKVPageSize)) {
            pair[1] = backend_kv_addresses->logical_page(*sequence.kv->backend, first + 1U);
        }
        retained.retain_existing(block.record.native_block_id, pair,
                                 block.record.committed_rows);
    }
}

KVMemFollowerInstalledView ProgramImpl::install_native_follower_selected(
    const kvmem::KvMemStore& store, std::span<const std::uint32_t> selected_ids,
    std::uint32_t append_reserve_tokens, std::uint32_t lane,
    const kvmem::RawKvStore& follower_raw,
    KVMemFollowerRetainedPages* retained) {
    if (!kvmem.enabled || speculative_backend != SpeculativeBackend::Mtp ||
        !native_kvmem_follower_backend || !backend_kv_addresses ||
        lane >= max_concurrency) {
        throw std::logic_error("native follower selection has no backend owner");
    }
    KVMemFollowerInstalledView installed;
    installed.execution.reserve(selected_ids.size());
    std::uint64_t visible = 0;
    std::uint32_t prior_id = 0;
    std::uint32_t prior_original_end = 0;
    for (std::size_t index = 0; index < selected_ids.size(); ++index) {
        const std::uint32_t id = selected_ids[index];
        if (id >= store.block_count()) {
            throw std::logic_error("native follower selection contains an unknown block");
        }
        const auto& block = store.blocks()[id];
        if (block.block_id != id || block.gpu_slot < 0 || block.n_tokens == 0 ||
            block.n_tokens > kvmem.block_tokens ||
            (index != 0 && (id <= prior_id ||
                            block.orig_pos_start < prior_original_end)) ||
            visible > kv_capacity || block.n_tokens > kv_capacity - visible ||
            visible % static_cast<std::uint32_t>(kPagedKVPageSize) != 0) {
            throw std::logic_error("native follower selection is not an aligned resident view");
        }
        installed.execution.push_back(KVMemFollowerExecutionRecord{
            .native_block_id = id,
            .original_position = block.orig_pos_start,
            .execution_begin = static_cast<std::uint32_t>(visible),
            .committed_rows = block.n_tokens,
        });
        visible += block.n_tokens;
        prior_id = id;
        prior_original_end = block.orig_pos_end();
    }
    if (append_reserve_tokens > kv_capacity - visible) {
        throw std::logic_error("native follower selection exceeds its physical KV pool");
    }
    installed.visible_tokens = static_cast<std::uint32_t>(visible);
    const std::uint32_t entitlement =
        kv_pages_for_frontier(installed.visible_tokens + append_reserve_tokens);
    if (retained != nullptr) {
        if (!backend_kv_pages || &retained->owner() != backend_kv_pages.get()) {
            throw std::logic_error("native follower retained view has a different page owner");
        }
        if (kvmem.block_tokens != 2U * static_cast<std::uint32_t>(kPagedKVPageSize)) {
            throw std::logic_error("native follower retained view requires two complete pages per block");
        }
        std::vector<LogicalKVPageHandle> ordered_pages;
        ordered_pages.reserve(selected_ids.size() * 2U);
        for (const KVMemFollowerExecutionRecord& record : installed.execution) {
            if (record.committed_rows != kvmem.block_tokens ||
                record.execution_begin % kvmem.block_tokens != 0) {
                throw std::logic_error("native follower retained selection is not page-complete");
            }
            KVMemFollowerRetainedPages::PagePair pair{};
            if (retained->has(record.native_block_id)) {
                pair = retained->pages(record.native_block_id);
            } else {
                // Outgoing pages were released with the old address. Only a
                // truly cold selected block needs two new GPU pages and a
                // packed Raw K/V transfer.
                auto reservation = backend_kv_pages->physical_pool().make_empty_reservation();
                backend_kv_pages->physical_pool().resize_reservation(reservation, 2U);
                try {
                    pair[0] = backend_kv_pages->materialize(reservation);
                    pair[1] = backend_kv_pages->materialize(reservation);
                    const KVMemFollowerPageBackend::BlockPages physical{
                        backend_kv_pages->physical(pair[0]),
                        backend_kv_pages->physical(pair[1]),
                    };
                    native_kvmem_follower_backend->stage_in(
                        record.original_position, physical, record.committed_rows,
                        follower_raw);
                    for (const LogicalKVPageHandle page : pair) {
                        backend_kv_pages->commit_coverage(
                            page, static_cast<std::uint32_t>(kPagedKVPageSize));
                        backend_kv_pages->set_writer(page, false);
                    }
                    retained->adopt_new(record.native_block_id, pair);
                } catch (...) {
                    // stage_in uses the transfer stream; never free a page
                    // while an exceptional asynchronous copy might touch it.
                    if (cudaStreamSynchronize(device.transfer_stream) != cudaSuccess) {
                        std::terminate();
                    }
                    for (const LogicalKVPageHandle page : pair) {
                        if (page.valid() && backend_kv_pages->valid(page)) {
                            const bool writer =
                                backend_kv_pages->writer_references(page) != 0;
                            if (!backend_kv_pages->release_reference(page, writer)) {
                                std::terminate();
                            }
                        }
                    }
                    throw;
                }
            }
            ordered_pages.push_back(pair[0]);
            ordered_pages.push_back(pair[1]);
        }
        const auto address = backend_kv_addresses->create_inactive();
        if (!address) {
            throw std::runtime_error("native follower lacks a selected address descriptor");
        }
        try {
            backend_kv_addresses->install_inactive_execution_prefix(
                *address, ordered_pages, installed.visible_tokens);
            backend_kv_addresses->activate(
                *address, entitlement, static_cast<std::int32_t>(lane), device.stream);
            (void)KVMemFollowerExecutionMap::resolve(
                installed.execution, *backend_kv_addresses, *address);
            installed.address = *address;
            return installed;
        } catch (...) {
            (void)backend_kv_addresses->release_after_deactivate(*address);
            throw;
        }
    }
    const auto address = backend_kv_addresses->create_active(
        entitlement, static_cast<std::int32_t>(lane));
    if (!address) { throw std::runtime_error("native follower lacks an execution address"); }
    try {
        backend_kv_addresses->ensure_mapped_to_tokens(*address, installed.visible_tokens,
                                                      device.stream);
        backend_kv_addresses->commit_frontier(*address, installed.visible_tokens);
        const auto resolved = KVMemFollowerExecutionMap::resolve(
            installed.execution, *backend_kv_addresses, *address);
        for (const KVMemFollowerResolvedBlock& block : resolved) {
            native_kvmem_follower_backend->stage_in(
                block.record.original_position, block.mtp_pages,
                block.record.committed_rows, follower_raw);
        }
        installed.address = *address;
        return installed;
    } catch (...) {
        (void)backend_kv_addresses->release_after_deactivate(*address);
        throw;
    }
}

void ProgramImpl::refresh_native_follower_execution(SequenceState& sequence) {
    if (!kvmem.enabled || speculative_backend != SpeculativeBackend::Mtp ||
        !native_kvmem_conversation || !backend_kv_addresses || !sequence.kv ||
        !sequence.kv->backend ||
        backend_kv_addresses->committed_frontier(*sequence.kv->backend) !=
            sequence.mtp_kv_valid) {
        throw std::logic_error("native follower cannot publish an uncommitted execution view");
    }
    auto records = KVMemFollowerExecutionMap::from_native_resident(
        native_kvmem_conversation->runtime().store(), sequence.text_kv_valid,
        sequence.mtp_kv_valid);
    (void)KVMemFollowerExecutionMap::resolve(
        records, *backend_kv_addresses, *sequence.kv->backend);
    sequence.native_follower_execution = std::move(records);
}

void ProgramImpl::restore_native_parked_execution(
    SequenceState& sequence, std::span<const std::uint32_t> selected_ids) {
    const bool restore_mtp = speculative_backend == SpeculativeBackend::Mtp;
    const bool restore_target_only = speculative_backend == SpeculativeBackend::None;
    if (!kvmem.enabled || (!restore_mtp && !restore_target_only) ||
        !native_kvmem_backend || !native_kvmem_conversation || native_kvmem_poisoned ||
        native_kvmem_owner || !text_kv_addresses || !sequence.endpoint_valid || sequence.kv ||
        sequence.native_kvmem_parked || sequence.native_tail_materialized_tokens != 0 ||
        !sequence.native_follower_execution.empty() || !sequence.compact_kv_frontier ||
        sequence.text_kv_valid == 0 || sequence.text_kv_valid != *sequence.compact_kv_frontier ||
        (restore_mtp && (!native_kvmem_follower_backend || !backend_kv_addresses ||
                         !backend_kv_pages)) ||
        (restore_target_only &&
         (sequence.mtp_kv_valid != 0 || native_kvmem_conversation->follower_raw() != nullptr)) ||
        sequence.lane >= max_concurrency || native_kvmem_conversation->runtime().pending() ||
        native_kvmem_conversation->metadata().cold ||
        native_kvmem_conversation->runtime().store().total_tokens() !=
            sequence.execution_frontier ||
        native_kvmem_conversation->metadata().row_positions.size() !=
            sequence.execution_frontier) {
        throw std::logic_error("native restore has no matching parked continuation");
    }

    std::uint32_t continuation_index = continuation_capacity;
    for (std::uint32_t index = 0; index < continuation_capacity; ++index) {
        if (&continuation_states[index] == &sequence) {
            continuation_index = index;
            break;
        }
    }
    if (continuation_index == continuation_capacity ||
        continuation_slots[continuation_index].role != ContinuationSlotRole::Catalogued) {
        throw std::logic_error("native restore sequence is not a catalogued Program continuation");
    }

    const kvmem::KvMemStore& store = native_kvmem_conversation->runtime().store();
    const std::uint32_t block_tokens = kvmem.block_tokens;
    if (block_tokens != KVMemFollowerPageBackend::kBlockTokens ||
        store.config().block_tokens != block_tokens || store.total_tokens() == 0) {
        throw std::logic_error("native restore Store geometry does not match the Program backend");
    }
    const std::uint32_t total_tokens = store.total_tokens();
    const std::uint64_t expected_block_count =
        (static_cast<std::uint64_t>(total_tokens) + block_tokens - 1U) / block_tokens;
    if (expected_block_count != store.block_count()) {
        throw std::logic_error("native restore Store block table does not cover its logical rows");
    }

    std::vector<std::uint32_t> resident_ids;
    resident_ids.reserve(store.block_count());
    std::uint64_t target_frontier = 0;
    for (std::uint32_t id = 0; id < store.block_count(); ++id) {
        const kvmem::KvMemBlock& block = store.blocks()[id];
        const std::uint64_t expected_begin = static_cast<std::uint64_t>(id) * block_tokens;
        const std::uint32_t expected_tokens = static_cast<std::uint32_t>(
            std::min<std::uint64_t>(block_tokens,
                                    static_cast<std::uint64_t>(total_tokens) - expected_begin));
        const bool gpu_tier = block.tier == kvmem::KvTier::GPU;
        const bool has_gpu_slot = block.gpu_slot >= 0;
        if (block.block_id != id || block.orig_pos_start != expected_begin ||
            block.n_tokens != expected_tokens || block.gpu_slot < -1 || block.in_flight ||
            gpu_tier != has_gpu_slot) {
            throw std::logic_error("native restore Store block metadata is inconsistent");
        }
        if (has_gpu_slot) {
            if (!block.in_working_set) {
                throw std::logic_error("native restore selected a resident block outside its working set");
            }
            resident_ids.push_back(id);
            target_frontier += block.n_tokens;
        }
    }
    if (resident_ids.empty() || resident_ids.size() != selected_ids.size() ||
        !std::equal(resident_ids.begin(), resident_ids.end(), selected_ids.begin()) ||
        target_frontier == 0 || target_frontier > kv_capacity ||
        target_frontier != sequence.text_kv_valid) {
        throw std::logic_error("native restore selected IDs do not match its target execution view");
    }

    const bool follower_lags_one = restore_mtp && target_frontier > sequence.mtp_kv_valid &&
                                   target_frontier - sequence.mtp_kv_valid == 1U;
    if (restore_mtp && sequence.mtp_kv_valid != target_frontier && !follower_lags_one) {
        throw std::logic_error("native restore follower frontier differs by more than one row");
    }
    if (follower_lags_one &&
        (resident_ids.back() + 1U != store.block_count() ||
         store.blocks()[resident_ids.back()].orig_pos_end() != total_tokens)) {
        throw std::logic_error("native restore deferred follower row is not the logical final row");
    }

    kvmem::RawKvStore* follower_raw =
        restore_mtp ? native_kvmem_conversation->follower_raw() : nullptr;
    if (restore_mtp && follower_raw == nullptr) {
        throw std::logic_error("native restore has no packed MTP follower archive");
    }

    std::optional<KVAddressSpaceHandle> target_address;
    std::optional<KVMemFollowerInstalledView> follower_view;
    try {
        target_address = text_kv_addresses->create_inactive();
        if (!target_address) {
            throw std::runtime_error("native restore has no target KV address descriptor");
        }
        const std::vector<KVMemSelectedBlockOffset> target_execution =
            native_kvmem_backend->install_selected_blocks(
                store, selected_ids, *text_kv_addresses, *target_address);
        std::uint64_t installed_target_frontier = 0;
        if (target_execution.size() != selected_ids.size()) {
            throw std::logic_error("native restore target installer returned an incomplete map");
        }
        for (std::size_t index = 0; index < target_execution.size(); ++index) {
            const kvmem::KvMemBlock& block = store.blocks()[selected_ids[index]];
            const KVMemSelectedBlockOffset& offset = target_execution[index];
            if (offset.block_id != selected_ids[index] ||
                offset.original_begin != block.orig_pos_start ||
                offset.execution_begin != installed_target_frontier ||
                offset.tokens != block.n_tokens) {
                throw std::logic_error("native restore target execution offsets are inconsistent");
            }
            installed_target_frontier += offset.tokens;
        }
        if (installed_target_frontier != target_frontier ||
            text_kv_addresses->active(*target_address) ||
            text_kv_addresses->committed_frontier(*target_address) != target_frontier) {
            throw std::logic_error("native restore target view has the wrong compact frontier");
        }

        if (restore_mtp) {
            if (sequence.mtp_kv_valid == target_frontier) {
                follower_view.emplace(install_native_follower_selected(
                    store, selected_ids, 0, sequence.lane, *follower_raw));
            } else {
                KVMemFollowerReplayPrefix replay = install_kvmem_follower_replay_prefix(
                    store, selected_ids, total_tokens - 1U, device, *backend_kv_pages,
                    *backend_kv_addresses, *native_kvmem_follower_backend, *follower_raw,
                    std::max(1U, kv_pages_for_frontier(sequence.mtp_kv_valid)), sequence.lane);
                follower_view.emplace(KVMemFollowerInstalledView{
                    .address = replay.address,
                    .execution = std::move(replay.execution),
                    .visible_tokens = replay.compact_frontier,
                });
            }

            std::vector<KVMemFollowerExecutionRecord> expected_follower_execution;
            expected_follower_execution.reserve(selected_ids.size());
            std::uint64_t expected_follower_frontier = 0;
            for (std::size_t index = 0; index < selected_ids.size(); ++index) {
                const kvmem::KvMemBlock& block = store.blocks()[selected_ids[index]];
                std::uint32_t rows = block.n_tokens;
                if (follower_lags_one && index + 1U == selected_ids.size()) { --rows; }
                if (rows == 0) { continue; }
                expected_follower_execution.push_back(KVMemFollowerExecutionRecord{
                    .native_block_id = selected_ids[index],
                    .original_position = block.orig_pos_start,
                    .execution_begin = static_cast<std::uint32_t>(expected_follower_frontier),
                    .committed_rows = rows,
                });
                expected_follower_frontier += rows;
            }
            if (expected_follower_frontier != sequence.mtp_kv_valid ||
                follower_view->visible_tokens != sequence.mtp_kv_valid ||
                follower_view->execution.size() != expected_follower_execution.size() ||
                !backend_kv_addresses->active(follower_view->address)) {
                throw std::logic_error(
                    "native restore follower view has the wrong compact frontier");
            }
            for (std::size_t index = 0; index < expected_follower_execution.size(); ++index) {
                const KVMemFollowerExecutionRecord& expected =
                    expected_follower_execution[index];
                const KVMemFollowerExecutionRecord& actual = follower_view->execution[index];
                if (actual.native_block_id != expected.native_block_id ||
                    actual.original_position != expected.original_position ||
                    actual.execution_begin != expected.execution_begin ||
                    actual.committed_rows != expected.committed_rows) {
                    throw std::logic_error(
                        "native restore follower execution map is inconsistent");
                }
            }
            backend_kv_addresses->deactivate(follower_view->address);
            if (backend_kv_addresses->committed_frontier(follower_view->address) !=
                    sequence.mtp_kv_valid ||
                backend_kv_addresses->active(follower_view->address)) {
                throw std::logic_error("native restore follower view did not become inactive");
            }
            (void)KVMemFollowerExecutionMap::resolve(
                follower_view->execution, *backend_kv_addresses, follower_view->address);
        }

        text_kv_addresses->set_checkpoint_requirement(*target_address,
                                                      sequence.text_kv_valid);
        if (follower_view) {
            backend_kv_addresses->set_checkpoint_requirement(follower_view->address,
                                                              backend_kv_valid(sequence));
        }

        SequenceKVBundle restored_bundle{
            .text    = *target_address,
            .backend = follower_view
                           ? std::optional<KVAddressSpaceHandle>(follower_view->address)
                           : std::nullopt,
        };
        sequence.kv.emplace(std::move(restored_bundle));
        if (follower_view) {
            sequence.native_follower_execution = std::move(follower_view->execution);
        }
        // The restored native slot owns the accepted partial tail again.
        const auto& tail = store.blocks().back();
        sequence.native_tail_materialized_tokens =
            tail.n_tokens == kvmem.block_tokens ? 0U : tail.n_tokens;
        target_address.reset();
        follower_view.reset();
    } catch (...) {
        if (follower_view) {
            (void)backend_kv_addresses->release_after_deactivate(follower_view->address);
        }
        if (target_address) {
            (void)text_kv_addresses->release_after_deactivate(*target_address);
        }
        throw;
    }
}
#endif

void ProgramImpl::set_device_i32(Tensor& tensor, std::int32_t value) {
    CUDA_CHECK(
        cudaMemcpyAsync(tensor.data, &value, sizeof(value), cudaMemcpyHostToDevice, device.stream));
}

void ProgramImpl::ordered_reset(SequenceState& sequence) {
    if (!state_store->valid(sequence.state.write)) {
        throw std::logic_error("pre-reset StateImage reservation is missing");
    } else {
        if (sequence.state.fork_pending || sequence.state.read != sequence.state.write ||
            state_store->role(sequence.state.write) != StateImageRole::ActiveMutable) {
            throw std::logic_error("StateImage reset requires a private mutable destination");
        }
    }
    refresh_state_views(sequence);
    work.reset();
    set_device_i32(io.pos, 0);
    set_device_i32(io.rope_pos, 0);
    set_device_i32(io.rope_delta, 0);
    if (io.mtp) { set_device_i32(io.mtp->position, 0); }
    sequence.text_kv_valid           = 0;
    sequence.mtp_kv_valid            = 0;
#if defined(NINFER_WITH_KVMEM)
    sequence.native_follower_execution.clear();
#endif
    sequence.dflash_context_frontier = 0;
}


} // namespace ninfer::models::qwen3_5::detail
