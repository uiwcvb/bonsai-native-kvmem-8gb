// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#include "models/qwen3_5/program/storage/kvmem_page_backend.h"

#include <cuda_runtime.h>

#include <kvmem/kvmem_store.hpp>

#include <algorithm>
#include <cstring>
#include <exception>
#include <limits>
#include <stdexcept>
#include <utility>

namespace ninfer::models::qwen3_5::detail {

namespace {
void synchronize_host_transfer(cudaStream_t stream) {
    const cudaError_t error = cudaStreamSynchronize(stream);
    if (error != cudaSuccess) {
        throw std::runtime_error(std::string("KVMem Host transfer failed: ") +
                                 cudaGetErrorName(error) + ": " + cudaGetErrorString(error));
    }
}

class PinnedCpuSlots final : public kvmem::KvMemCpuStorage {
public:
    PinnedCpuSlots(std::uint32_t slots, std::size_t bytes)
        : slots_(slots), block_bytes_(bytes) {}

    std::size_t allocated_bytes() const noexcept override {
        return sizeof(*this) + slots_.capacity() * sizeof(slots_[0]) +
               (populated_ + (spare_ ? 1U : 0U)) * block_bytes_;
    }
    void prepare_slot() override {
        if (!spare_) spare_ = std::make_unique<PinnedHostBuffer>(block_bytes_);
    }
    std::uint8_t* slot_ptr(std::int32_t slot) override {
        auto& buffer = slots_.at(static_cast<std::size_t>(slot));
        if (!buffer) {
            if (!spare_) throw std::logic_error("native CPU slot was not prepared");
            buffer = std::move(spare_);
            ++populated_;
        }
        return static_cast<std::uint8_t*>(buffer->data());
    }
    const std::uint8_t* slot_ptr(std::int32_t slot) const override {
        const auto& buffer = slots_.at(static_cast<std::size_t>(slot));
        if (!buffer) throw std::logic_error("native CPU slot has no retained payload");
        return static_cast<const std::uint8_t*>(buffer->data());
    }
    void release_slot(std::int32_t slot) noexcept override {
        if (slot >= 0 && static_cast<std::size_t>(slot) < slots_.size() && slots_[slot]) {
            slots_[slot].reset();
            --populated_;
        }
    }
private:
    std::vector<std::unique_ptr<PinnedHostBuffer>> slots_;
    std::unique_ptr<PinnedHostBuffer> spare_;
    std::size_t block_bytes_;
    std::size_t populated_ = 0;
};
} // namespace

std::unique_ptr<kvmem::KvMemCpuStorage> KVMemPageBackend::make_cpu_storage(
    std::uint32_t slots, std::uint64_t bytes) {
    if (bytes != block_bytes_ || bytes > std::numeric_limits<std::size_t>::max()) {
        throw std::invalid_argument("native CPU storage geometry differs from GPU blocks");
    }
    return std::make_unique<PinnedCpuSlots>(slots, static_cast<std::size_t>(bytes));
}

KVMemPageBackend::KVMemPageBackend(DeviceContext& device, LogicalKVPageStore& pages)
    : device_(&device), pages_(&pages),
      layout_(plan_host_kv_page_layout(pages.physical_pool().geometry())) {
    if (pages.physical_pool().geometry().page_tokens != kPagedKVPageSize ||
        pages.physical_pool().capacity_pages() < 2 ||
        pages.physical_pool().capacity_pages() / 2 >
            static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max()) ||
        layout_.page_stride > std::numeric_limits<std::size_t>::max() / 2) {
        throw std::invalid_argument("KVMem requires pairs of NInfer 64-token KV pages");
    }
    const std::size_t bytes = layout_.page_stride * 2;
    block_bytes_ = bytes;
    bounce_.emplace(bytes);
    slots_.resize(pages.physical_pool().capacity_pages() / 2);
    free_slots_.reserve(slots_.size());
    for (std::size_t index = slots_.size(); index > 0; --index) {
        free_slots_.push_back(static_cast<std::int32_t>(index - 1));
    }
}

KVMemPageBackend::HostArchiveScope::HostArchiveScope(KVMemPageBackend& backend)
    : backend_(&backend) {
    if (backend.host_archive_active_ || backend.admission_active_ ||
        backend.occupied_slots_ != 0 || backend.host_archive_slot_ >= 0) {
        throw std::logic_error("KVMem Host archive traversal requires an exclusive idle backend");
    }
    backend.host_archive_active_ = true;
}

KVMemPageBackend::HostArchiveScope::~HostArchiveScope() noexcept {
    // Do not discard a sole copy on an interrupted Native transition. Its
    // owner is already fail-stop; the reserved slot also prevents GPU reuse.
    backend_->host_archive_active_ = false;
}

KVMemPageBackend::Slot& KVMemPageBackend::require_slot(std::int32_t slot) {
    if (slot < 0 || static_cast<std::size_t>(slot) >= slots_.size() ||
        !slots_[static_cast<std::size_t>(slot)].occupied) {
        throw std::invalid_argument("KVMem GPU slot is not owned by this backend");
    }
    return slots_[static_cast<std::size_t>(slot)];
}

const KVMemPageBackend::Slot& KVMemPageBackend::require_slot(std::int32_t slot) const {
    if (slot < 0 || static_cast<std::size_t>(slot) >= slots_.size() ||
        !slots_[static_cast<std::size_t>(slot)].occupied) {
        throw std::invalid_argument("KVMem GPU slot is not owned by this backend");
    }
    return slots_[static_cast<std::size_t>(slot)];
}

std::array<DeviceKVPageHandle, 2> KVMemPageBackend::physical_pages(const Slot& slot) const {
    if (!slot.pages_materialized) {
        throw std::logic_error("KVMem slot has no materialized GPU pages");
    }
    return {pages_->physical(slot.pages[0]), pages_->physical(slot.pages[1])};
}

std::int32_t KVMemPageBackend::reserve_gpu_slot_for_append() {
    if (host_archive_active_ || host_archive_slot_ >= 0) {
        throw std::logic_error("KVMem cannot append during an unfinished Host archive traversal");
    }
    return reserve_empty_slot();
}

std::int32_t KVMemPageBackend::reserve_empty_slot() {
    if (free_slots_.empty()) {
        throw std::runtime_error("KVMem has no free GPU block slot");
    }
    const std::int32_t slot_id = free_slots_.back();
    free_slots_.pop_back();
    slots_[static_cast<std::size_t>(slot_id)] = Slot{.occupied = true};
    ++occupied_slots_;
    return slot_id;
}

void KVMemPageBackend::begin_prefill_admission(
    const kvmem::KvMemStore& store, std::span<const std::uint32_t> stage_in,
    std::uint32_t pre_append_frontier) {
    if (admission_active_ || host_archive_active_ || host_archive_slot_ >= 0 ||
        pre_append_frontier > store.total_tokens()) {
        throw std::logic_error("KVMem prefill admission is already active or has an invalid frontier");
    }
    std::vector<bool> reserve_only;
    reserve_only.reserve(stage_in.size());
    for (std::size_t index = 0; index < stage_in.size(); ++index) {
        const std::uint32_t id = stage_in[index];
        if (id >= store.block_count() ||
            std::find(stage_in.begin(), stage_in.begin() + static_cast<std::ptrdiff_t>(index),
                      id) != stage_in.begin() + static_cast<std::ptrdiff_t>(index)) {
            throw std::invalid_argument("KVMem prefill admission contains an invalid stage-in block");
        }
        const kvmem::KvMemBlock& block = store.blocks()[id];
        // Runtime::stage_in skips blocks which were already resident.
        if (block.tier == kvmem::KvTier::GPU && block.gpu_slot >= 0) { continue; }
        const bool fresh = block.orig_pos_start >= pre_append_frontier;
        if ((fresh && (block.cpu_slot >= 0 || block.nvme_slot >= 0)) ||
            (!fresh && block.cpu_slot < 0 && block.nvme_slot < 0)) {
            // Unlike the llama adapter, this backend cannot regenerate full V
            // from a mean-only RawKvStore. Never treat a missing historical
            // payload as an empty page or discard a fresh block's backing.
            throw std::logic_error("KVMem stage-in has no source-faithful block payload");
        }
        reserve_only.push_back(fresh);
    }
    admission_reserve_only_.swap(reserve_only);
    admission_cursor_ = 0;
    admission_active_ = true;
}

void KVMemPageBackend::finish_prefill_admission() {
    if (!admission_active_) {
        throw std::logic_error("KVMem prefill admission is not active");
    }
    const bool complete = admission_cursor_ == admission_reserve_only_.size();
    abort_prefill_admission();
    if (!complete) {
        throw std::logic_error("KVMem prefill admission did not stage every planned block");
    }
}

void KVMemPageBackend::abort_prefill_admission() noexcept {
    admission_reserve_only_.clear();
    admission_cursor_ = 0;
    admission_active_ = false;
}

bool KVMemPageBackend::can_normalize_partial_page(LogicalKVPageHandle page,
                                                   std::uint32_t valid_columns) const noexcept {
    return valid_columns <= static_cast<std::uint32_t>(kPagedKVPageSize) &&
           pages_->valid(page) && pages_->device_resident(page) &&
           pages_->committed_columns(page) == valid_columns &&
           pages_->address_references(page) == 1 &&
           pages_->active_address_references(page) == 0 &&
           (pages_->writer_references(page) == 1 ||
            (pages_->writer_references(page) == 0 && pages_->can_set_writer(page, true))) &&
           pages_->source_pins(page) == 0 &&
           pages_->protected_columns(page) <= valid_columns &&
           pages_->can_attach_host_replica(page, pages_->content_epoch(page), valid_columns) &&
           pages_->can_retain_reference(page, false);
}

void KVMemPageBackend::normalize_partial_pages(
    std::span<const LogicalKVPageHandle> logical_pages,
    std::span<const std::uint32_t> valid_columns) {
    if (logical_pages.empty() || logical_pages.size() != valid_columns.size() ||
        logical_pages.size() > 2) {
        throw std::invalid_argument("KVMem partial-tail page normalization has invalid geometry");
    }

    for (std::size_t index = 0; index < logical_pages.size(); ++index) {
        if (!can_normalize_partial_page(logical_pages[index], valid_columns[index]) ||
            std::find(logical_pages.begin(), logical_pages.begin() + index,
                      logical_pages[index]) != logical_pages.begin() + index) {
            throw std::logic_error("KVMem partial-tail source page is not exclusively writable");
        }
    }
    for (std::size_t page_index = 0; page_index < logical_pages.size(); ++page_index) {
        pages_->physical_pool().zero_page_suffix(pages_->physical(logical_pages[page_index]),
                                                 valid_columns[page_index],
                                                 device_->stream);
    }
    CUDA_CHECK(cudaStreamSynchronize(device_->stream));
    for (const LogicalKVPageHandle page : logical_pages) {
        // An ordinary NInfer writer is deactivated before handing its exclusive
        // pages to the native slot. Temporarily acquire the page writer only
        // for the metadata coverage transition; no active address may observe
        // the zeroed suffix or the updated frontier.
        if (pages_->writer_references(page) == 0) { pages_->set_writer(page, true); }
        pages_->commit_coverage(page, static_cast<std::uint32_t>(kPagedKVPageSize));
        pages_->set_writer(page, false);
    }
}

void KVMemPageBackend::adopt_prefilled_block(
    std::uint32_t block_id, std::int32_t slot,
    std::array<LogicalKVPageHandle, 2> logical_pages, std::uint32_t valid_tokens) {
    constexpr std::uint32_t block_tokens =
        2U * static_cast<std::uint32_t>(kPagedKVPageSize);
    Slot& owned = require_slot(slot);
    const bool replay_slot = owned.reserved_for_replay && !owned.pages_materialized &&
                             owned.block_id == block_id && owned.valid_tokens == valid_tokens;
    if (valid_tokens == 0 || valid_tokens > block_tokens ||
        ((owned.block_id || owned.valid_tokens) && !replay_slot) ||
        logical_pages[0] == logical_pages[1]) {
        throw std::invalid_argument("KVMem prefilled-block adoption does not match an unbound slot");
    }
    for (const Slot& other : slots_) {
        if (&other == &owned || !other.occupied || !other.pages_materialized) { continue; }
        if (other.block_id == block_id ||
            std::find(other.pages.begin(), other.pages.end(), logical_pages[0]) !=
                other.pages.end() ||
            std::find(other.pages.begin(), other.pages.end(), logical_pages[1]) !=
                other.pages.end()) {
            throw std::logic_error("KVMem prefilled block or page is already slot-owned");
        }
    }

    const std::array<std::uint32_t, 2> columns{
        std::min(valid_tokens, static_cast<std::uint32_t>(kPagedKVPageSize)),
        valid_tokens > static_cast<std::uint32_t>(kPagedKVPageSize)
            ? valid_tokens - static_cast<std::uint32_t>(kPagedKVPageSize)
            : 0U};
    for (std::size_t index = 0; index < logical_pages.size(); ++index) {
        if (!can_normalize_partial_page(logical_pages[index], columns[index])) {
            throw std::logic_error("KVMem prefilled source page coverage or ownership is invalid");
        }
    }
    if (owned.pages_materialized) {
        for (const LogicalKVPageHandle placeholder : owned.pages) {
            if (pages_->active_address_references(placeholder) != 0 ||
                !pages_->can_release_reference(placeholder, false)) {
                throw std::logic_error("KVMem cannot replace a reserved slot with live page views");
            }
        }
    }

    normalize_partial_pages(logical_pages, columns);
    pages_->retain_reference(logical_pages[0], false);
    pages_->retain_reference(logical_pages[1], false);
    if (owned.pages_materialized) {
        const auto placeholders = owned.pages;
        for (const LogicalKVPageHandle placeholder : placeholders) {
            if (!pages_->release_reference(placeholder, false)) { std::terminate(); }
        }
    }
    owned.pages = logical_pages;
    owned.block_id = block_id;
    owned.valid_tokens = valid_tokens;
    owned.pages_materialized = true;
    owned.reserved_for_replay = false;
}

void KVMemPageBackend::adopt_inactive_prefill_address(
    std::uint32_t block_id, std::int32_t slot, KVAddressSpaceStore& addresses,
    KVAddressSpaceHandle source, std::uint32_t execution_begin,
    std::uint32_t valid_tokens) {
    constexpr std::uint32_t page_tokens = static_cast<std::uint32_t>(kPagedKVPageSize);
    constexpr std::uint32_t block_tokens = 2U * page_tokens;
    if (valid_tokens == 0 || valid_tokens > block_tokens ||
        execution_begin % block_tokens != 0 ||
        execution_begin > std::numeric_limits<std::uint32_t>::max() - valid_tokens ||
        addresses.active(source)) {
        throw std::invalid_argument("KVMem prefill address is not an inactive accepted block");
    }

    const std::uint32_t block_end = execution_begin + valid_tokens;
    const std::uint32_t source_frontier = addresses.committed_frontier(source);
    if ((valid_tokens == block_tokens ? source_frontier < block_end
                                      : source_frontier != block_end) ||
        addresses.mapped_pages(source) <
            execution_begin / page_tokens + 1U + (valid_tokens - 1U) / page_tokens) {
        throw std::invalid_argument("KVMem prefill address is not an inactive accepted block");
    }

    std::array<LogicalKVPageHandle, 2> logical_pages{};
    const std::uint32_t first_page = execution_begin / page_tokens;
    logical_pages[0] = addresses.logical_page(source, first_page);
    std::optional<LogicalKVPageHandle> filler;
    if (addresses.mapped_pages(source) > first_page + 1U) {
        logical_pages[1] = addresses.logical_page(source, first_page + 1U);
    } else {
        auto reservation = pages_->physical_pool().reserve(1);
        if (!reservation) {
            throw std::runtime_error("KVMem partial block has no GPU page for its empty tail");
        }
        filler = pages_->materialize(*reservation);
        logical_pages[1] = *filler;
    }
    try {
        adopt_prefilled_block(block_id, slot, logical_pages, valid_tokens);
    } catch (...) {
        if (filler && pages_->valid(*filler) &&
            !pages_->release_reference(*filler, pages_->writer_references(*filler) != 0)) {
            std::terminate();
        }
        throw;
    }
    if (filler && !pages_->release_reference(*filler, false)) { std::terminate(); }
}

void KVMemPageBackend::replace_partial_tail_block(
    std::uint32_t block_id, std::int32_t slot,
    std::array<LogicalKVPageHandle, 2> expected_pages, std::uint32_t expected_tokens,
    std::array<LogicalKVPageHandle, 2> replacement_pages, std::uint32_t new_tokens) {
    constexpr std::uint32_t page_tokens = static_cast<std::uint32_t>(kPagedKVPageSize);
    constexpr std::uint32_t block_tokens = 2U * page_tokens;
    Slot& owned = require_slot(slot);
    if (!owned.pages_materialized || owned.block_id != block_id || !owned.valid_tokens ||
        *owned.valid_tokens != expected_tokens || expected_tokens == 0 ||
        expected_tokens >= block_tokens || new_tokens <= expected_tokens ||
        new_tokens > block_tokens ||
        expected_pages != owned.pages || replacement_pages[0] == replacement_pages[1]) {
        throw std::invalid_argument("KVMem partial-tail replacement has a stale block or page set");
    }

    std::array<std::uint32_t, 2> new_columns{
        std::min(new_tokens, page_tokens), new_tokens > page_tokens ? new_tokens - page_tokens : 0U};
    std::vector<LogicalKVPageHandle> changed_pages;
    std::vector<std::uint32_t> changed_columns;
    changed_pages.reserve(2);
    changed_columns.reserve(2);
    bool changed = false;
    for (std::size_t index = 0; index < replacement_pages.size(); ++index) {
        if (replacement_pages[index] == owned.pages[index]) {
            if (pages_->committed_columns(owned.pages[index]) != page_tokens ||
                new_columns[index] >
                    std::min(expected_tokens > index * page_tokens
                                 ? expected_tokens - static_cast<std::uint32_t>(index * page_tokens)
                                 : 0U,
                             page_tokens)) {
                throw std::logic_error("KVMem partial-tail growth must replace every changed page");
            }
            continue;
        }
        changed = true;
        if (!can_normalize_partial_page(replacement_pages[index], new_columns[index])) {
            throw std::logic_error("KVMem replacement page coverage or ownership is invalid");
        }
        changed_pages.push_back(replacement_pages[index]);
        changed_columns.push_back(new_columns[index]);
    }
    if (!changed) {
        throw std::invalid_argument("KVMem partial-tail replacement did not change any page");
    }

    for (std::size_t index = 0; index < owned.pages.size(); ++index) {
        if (replacement_pages[index] == owned.pages[index]) { continue; }
        const LogicalKVPageHandle old_page = owned.pages[index];
        if (pages_->active_address_references(old_page) != 0 ||
            !pages_->can_release_reference(old_page, false)) {
            throw std::logic_error("KVMem cannot replace a slot page with an active address view");
        }
    }
    for (const Slot& other : slots_) {
        if (&other == &owned || !other.occupied || !other.pages_materialized) { continue; }
        for (const LogicalKVPageHandle page : replacement_pages) {
            if (std::find(other.pages.begin(), other.pages.end(), page) != other.pages.end()) {
                throw std::logic_error("KVMem replacement page is owned by another GPU slot");
            }
        }
    }

    normalize_partial_pages(changed_pages, changed_columns);
    for (const LogicalKVPageHandle page : changed_pages) { pages_->retain_reference(page, false); }
    const auto old_pages = owned.pages;
    for (std::size_t index = 0; index < old_pages.size(); ++index) {
        if (replacement_pages[index] == old_pages[index]) { continue; }
        if (!pages_->release_reference(old_pages[index], false)) { std::terminate(); }
    }
    owned.pages = replacement_pages;
    owned.valid_tokens = new_tokens;
}

void KVMemPageBackend::replace_inactive_tail_address(
    std::uint32_t block_id, std::int32_t slot, KVAddressSpaceStore& addresses,
    KVAddressSpaceHandle source, std::uint32_t execution_begin,
    std::uint32_t expected_tokens, std::uint32_t new_tokens) {
    constexpr std::uint32_t page_tokens = static_cast<std::uint32_t>(kPagedKVPageSize);
    constexpr std::uint32_t block_tokens = 2U * page_tokens;
    if (expected_tokens == 0 || expected_tokens >= block_tokens ||
        new_tokens <= expected_tokens || new_tokens > block_tokens ||
        execution_begin % block_tokens != 0 ||
        execution_begin > std::numeric_limits<std::uint32_t>::max() - new_tokens ||
        addresses.active(source) ||
        (new_tokens == block_tokens
             ? addresses.committed_frontier(source) < execution_begin + new_tokens
             : addresses.committed_frontier(source) != execution_begin + new_tokens) ||
        addresses.mapped_pages(source) <
            execution_begin / page_tokens + 1U + (new_tokens - 1U) / page_tokens) {
        throw std::invalid_argument("KVMem tail writer is not an inactive accepted block");
    }
    const auto old_pages = pages_for_slot(block_id, slot);
    const std::uint32_t first_page = execution_begin / page_tokens;
    std::array<LogicalKVPageHandle, 2> replacement_pages{
        addresses.logical_page(source, first_page), old_pages[1]};
    if (addresses.mapped_pages(source) > first_page + 1U) {
        replacement_pages[1] = addresses.logical_page(source, first_page + 1U);
    }
    replace_partial_tail_block(block_id, slot, old_pages, expected_tokens,
                               replacement_pages, new_tokens);
}

void KVMemPageBackend::replace_replayed_block(
    std::uint32_t block_id, std::int32_t slot, KVAddressSpaceStore& addresses,
    KVAddressSpaceHandle inactive_writer, std::uint32_t execution_begin,
    std::uint32_t valid_tokens) {
    constexpr std::uint32_t page_tokens = static_cast<std::uint32_t>(kPagedKVPageSize);
    constexpr std::uint32_t block_tokens = 2U * page_tokens;
    Slot& owned = require_slot(slot);
    if (owned.reserved_for_replay) {
        if (owned.pages_materialized || owned.block_id != block_id ||
            owned.valid_tokens != valid_tokens) {
            throw std::invalid_argument("KVMem replay reservation has stale block geometry");
        }
        adopt_inactive_prefill_address(block_id, slot, addresses, inactive_writer,
                                       execution_begin, valid_tokens);
        return;
    }
    if (!owned.pages_materialized || owned.block_id != block_id || !owned.valid_tokens ||
        *owned.valid_tokens != valid_tokens || valid_tokens == 0 ||
        valid_tokens > block_tokens || execution_begin % block_tokens != 0 ||
        execution_begin > std::numeric_limits<std::uint32_t>::max() - valid_tokens ||
        !addresses.valid(inactive_writer) || addresses.active(inactive_writer)) {
        throw std::invalid_argument("KVMem replay replacement has a stale block or writer address");
    }

    const std::uint32_t block_end = execution_begin + valid_tokens;
    const std::uint32_t frontier = addresses.committed_frontier(inactive_writer);
    const std::uint32_t page_count = 1U + (valid_tokens - 1U) / page_tokens;
    const std::uint32_t first_page = execution_begin / page_tokens;
    if (frontier < block_end ||
        (valid_tokens < block_tokens && frontier != block_end) ||
        addresses.mapped_pages(inactive_writer) < first_page + page_count) {
        throw std::invalid_argument("KVMem replay writer does not contain the accepted block");
    }

    std::array<LogicalKVPageHandle, 2> replacement_pages = owned.pages;
    for (std::uint32_t index = 0; index < page_count; ++index) {
        replacement_pages[index] =
            addresses.logical_page(inactive_writer, first_page + index);
    }
    if (replacement_pages[0] == replacement_pages[1]) {
        throw std::logic_error("KVMem replay replacement pages are not distinct");
    }

    const std::array<std::uint32_t, 2> columns{
        std::min(valid_tokens, page_tokens),
        valid_tokens > page_tokens ? valid_tokens - page_tokens : 0U};
    std::vector<LogicalKVPageHandle> changed_pages;
    std::vector<std::uint32_t> changed_columns;
    changed_pages.reserve(2);
    changed_columns.reserve(2);
    for (std::uint32_t index = 0; index < page_count; ++index) {
        if (replacement_pages[index] == owned.pages[index]) {
            const LogicalKVPageHandle page = replacement_pages[index];
            if (!pages_->valid(page) || !pages_->device_resident(page) ||
                pages_->committed_columns(page) != page_tokens ||
                pages_->writer_references(page) != 0 ||
                pages_->address_references(page) < 2) {
                throw std::logic_error("KVMem replay preserved page is not read-only shared history");
            }
            continue;
        }
        if (!can_normalize_partial_page(replacement_pages[index], columns[index])) {
            throw std::logic_error("KVMem replay page is not exclusively writable");
        }
        changed_pages.push_back(replacement_pages[index]);
        changed_columns.push_back(columns[index]);
    }
    if (changed_pages.empty()) {
        throw std::invalid_argument("KVMem replay did not replace any block page");
    }

    for (std::size_t index = 0; index < owned.pages.size(); ++index) {
        if (replacement_pages[index] == owned.pages[index]) { continue; }
        const LogicalKVPageHandle old_page = owned.pages[index];
        if (pages_->active_address_references(old_page) != 0 ||
            !pages_->can_release_reference(old_page, false)) {
            throw std::logic_error("KVMem cannot replace a page with an active address view");
        }
    }
    for (const Slot& other : slots_) {
        if (&other == &owned || !other.occupied || !other.pages_materialized) { continue; }
        for (const LogicalKVPageHandle page : replacement_pages) {
            if (std::find(other.pages.begin(), other.pages.end(), page) != other.pages.end()) {
                throw std::logic_error("KVMem replay page is owned by another GPU slot");
            }
        }
    }

    normalize_partial_pages(changed_pages, changed_columns);
    for (const LogicalKVPageHandle page : changed_pages) { pages_->retain_reference(page, false); }
    const auto old_pages = owned.pages;
    for (std::size_t index = 0; index < old_pages.size(); ++index) {
        if (replacement_pages[index] == old_pages[index]) { continue; }
        if (!pages_->release_reference(old_pages[index], false)) { std::terminate(); }
    }
    owned.pages = replacement_pages;
}

std::array<LogicalKVPageHandle, 2>
KVMemPageBackend::pages_for_slot(std::uint32_t block_id, std::int32_t slot) const {
    const Slot& owned = require_slot(slot);
    if (!owned.pages_materialized || owned.block_id != block_id) {
        throw std::invalid_argument("KVMem block does not match the requested GPU slot");
    }
    return owned.pages;
}

std::vector<KVMemSelectedBlockOffset> KVMemPageBackend::install_selected_blocks(
    const kvmem::KvMemStore& store, std::span<const std::uint32_t> selected_ids,
    KVAddressSpaceStore& addresses, KVAddressSpaceHandle destination,
    bool require_working_set) {
    constexpr std::uint32_t block_tokens = 2U * static_cast<std::uint32_t>(kPagedKVPageSize);
    if (store.config().block_tokens != block_tokens ||
        selected_ids.size() > slots_.size() ||
        selected_ids.size() > std::numeric_limits<std::uint32_t>::max() / block_tokens) {
        throw std::invalid_argument("KVMem selection does not fit the 128-token page adapter");
    }
    std::vector<LogicalKVPageHandle> ordered_pages;
    std::vector<KVMemSelectedBlockOffset> positions;
    ordered_pages.reserve(selected_ids.size() * 2U);
    positions.reserve(selected_ids.size());
    std::uint32_t prior_end = 0;
    std::uint32_t execution_tokens = 0;
    for (std::size_t index = 0; index < selected_ids.size(); ++index) {
        const std::uint32_t id = selected_ids[index];
        if (id >= store.block_count()) {
            throw std::invalid_argument("KVMem selection contains an unknown block");
        }
        const kvmem::KvMemBlock& block = store.blocks()[id];
        if (block.block_id != id || block.n_tokens == 0 || block.n_tokens > block_tokens ||
            block.tier != kvmem::KvTier::GPU || block.gpu_slot < 0 ||
            (require_working_set && !block.in_working_set) ||
            (positions.size() != 0 && (id <= positions.back().block_id ||
                                        block.orig_pos_start < prior_end)) ||
            block.orig_pos_start > std::numeric_limits<std::uint32_t>::max() - block.n_tokens ||
            (block.n_tokens < block_tokens &&
             (index + 1U != selected_ids.size() || id + 1U != store.block_count()))) {
            throw std::invalid_argument("KVMem selected block is not an ordered resident block");
        }
        const auto pages = pages_for_slot(id, block.gpu_slot);
        const Slot& owned = require_slot(block.gpu_slot);
        if (owned.valid_tokens && block.n_tokens > *owned.valid_tokens) {
            throw std::logic_error("KVMem block grew without replacing its partial-tail pages");
        }
        const std::uint32_t page_count =
            1U + (block.n_tokens - 1U) / static_cast<std::uint32_t>(kPagedKVPageSize);
        ordered_pages.insert(ordered_pages.end(), pages.begin(), pages.begin() + page_count);
        positions.push_back({.block_id = id,
                             .original_begin = block.orig_pos_start,
                             .execution_begin = execution_tokens,
                             .tokens = block.n_tokens});
        execution_tokens += block.n_tokens;
        prior_end = block.orig_pos_start + block.n_tokens;
    }
    addresses.install_inactive_execution_prefix(destination, ordered_pages, execution_tokens);
    for (const KVMemSelectedBlockOffset& position : positions) {
        Slot& owned = require_slot(store.blocks()[position.block_id].gpu_slot);
        if (!owned.valid_tokens || position.tokens < *owned.valid_tokens) {
            owned.valid_tokens = position.tokens;
        }
    }
    return positions;
}

std::vector<KVMemSelectedBlockOffset> KVMemPageBackend::install_selected_for_append(
    const kvmem::KvMemStore& store, std::span<const std::uint32_t> selected_ids,
    KVAddressSpaceStore& addresses, KVAddressSpaceHandle read_only_source,
    KVAddressSpaceHandle writable_destination, std::uint32_t page_entitlement,
    std::int32_t execution_row, bool require_working_set) {
    if (selected_ids.empty() || read_only_source == writable_destination) {
        throw std::invalid_argument("KVMem writable selection requires distinct nonempty addresses");
    }
    auto positions = install_selected_blocks(store, selected_ids, addresses, read_only_source,
                                             require_working_set);
    const std::uint32_t visible_tokens =
        positions.back().execution_begin + positions.back().tokens;
    auto fork = addresses.prepare_prefix_fork(read_only_source, writable_destination,
                                              visible_tokens, page_entitlement, execution_row);
    if (fork.needs_tail_copy()) {
        pages_->physical_pool().copy_page(addresses.prefix_fork_tail_source(fork),
                                          addresses.prefix_fork_tail_destination(fork),
                                          device_->transfer_stream);
        CUDA_CHECK(cudaStreamSynchronize(device_->transfer_stream));
    }
    addresses.commit_prefix_fork(std::move(fork), device_->stream);
    return positions;
}

std::uint32_t KVMemPageBackend::install_selected_for_replay(
    const kvmem::KvMemStore& store, std::span<const std::uint32_t> selected_ids,
    std::uint32_t replay_logical_begin, KVAddressSpaceStore& addresses,
    KVAddressSpaceHandle read_only_source, KVAddressSpaceHandle writable_destination,
    std::uint32_t page_entitlement, std::int32_t execution_row) {
    constexpr std::uint32_t page_tokens = static_cast<std::uint32_t>(kPagedKVPageSize);
    constexpr std::uint32_t block_tokens = 2U * page_tokens;
    if (store.config().block_tokens != block_tokens || selected_ids.empty() ||
        selected_ids.size() > slots_.size() ||
        selected_ids.size() > std::numeric_limits<std::uint32_t>::max() / block_tokens ||
        read_only_source == writable_destination || !addresses.valid(read_only_source) ||
        !addresses.valid(writable_destination) || addresses.active(read_only_source) ||
        addresses.active(writable_destination) ||
        addresses.mapped_pages(read_only_source) != 0 ||
        addresses.committed_frontier(read_only_source) != 0 ||
        addresses.mapped_pages(writable_destination) != 0 ||
        addresses.committed_frontier(writable_destination) != 0) {
        throw std::invalid_argument("KVMem replay selection or address endpoints are invalid");
    }

    struct SelectedBlockView {
        std::uint32_t block_id;
        std::uint32_t original_begin;
        std::uint32_t tokens;
        std::array<LogicalKVPageHandle, 2> pages;
    };
    std::vector<SelectedBlockView> selected;
    selected.reserve(selected_ids.size());
    std::optional<std::size_t> query_block_index;
    std::uint32_t prior_end = 0;
    std::uint32_t prior_id = 0;

    for (std::size_t index = 0; index < selected_ids.size(); ++index) {
        const std::uint32_t id = selected_ids[index];
        if (id >= store.block_count()) {
            throw std::invalid_argument("KVMem replay selection contains an unknown block");
        }
        const kvmem::KvMemBlock& block = store.blocks()[id];
        if (block.block_id != id || block.n_tokens == 0 || block.n_tokens > block_tokens ||
            block.tier != kvmem::KvTier::GPU || block.gpu_slot < 0 ||
            !block.in_working_set ||
            (index != 0 && (id <= prior_id || block.orig_pos_start < prior_end)) ||
            block.orig_pos_start > std::numeric_limits<std::uint32_t>::max() - block.n_tokens ||
            (block.n_tokens < block_tokens &&
             (index + 1U != selected_ids.size() || id + 1U != store.block_count()))) {
            throw std::invalid_argument("KVMem replay selection is not ordered resident history");
        }

        const auto block_pages = pages_for_slot(id, block.gpu_slot);
        const Slot& owned = require_slot(block.gpu_slot);
        if (block_pages[0] == block_pages[1] ||
            (owned.valid_tokens && block.n_tokens > *owned.valid_tokens)) {
            throw std::logic_error("KVMem selected block has stale resident coverage");
        }
        for (const LogicalKVPageHandle page : block_pages) {
            if (!pages_->valid(page) || !pages_->device_resident(page) ||
                pages_->committed_columns(page) != page_tokens ||
                pages_->writer_references(page) != 0) {
                throw std::logic_error("KVMem replay selection contains an unavailable page");
            }
            for (const SelectedBlockView& prior : selected) {
                if (std::find(prior.pages.begin(), prior.pages.end(), page) != prior.pages.end()) {
                    throw std::logic_error("KVMem replay selection aliases a page across blocks");
                }
            }
        }

        const std::uint32_t block_end = block.orig_pos_start + block.n_tokens;
        if (replay_logical_begin >= block.orig_pos_start && replay_logical_begin < block_end) {
            if (query_block_index) {
                throw std::invalid_argument("KVMem replay position matches multiple selected blocks");
            }
            query_block_index = index;
        }
        selected.push_back({.block_id = id,
                            .original_begin = block.orig_pos_start,
                            .tokens = block.n_tokens,
                            .pages = block_pages});
        prior_id = id;
        prior_end = block_end;
    }

    if (!query_block_index) {
        throw std::invalid_argument("KVMem replay query block is not selected and resident");
    }

    // The selected old history may have original-position gaps; the query and
    // observations being re-executed must be the complete contiguous suffix.
    // Do not release a sparse selection as if its missing rows were replayed.
    for (std::size_t index = *query_block_index + 1U; index < selected.size(); ++index) {
        if (selected[index].original_begin !=
            selected[index - 1U].original_begin + selected[index - 1U].tokens) {
            throw std::invalid_argument("KVMem replay suffix is not contiguous original input");
        }
    }
    if (selected.back().original_begin + selected.back().tokens != store.total_tokens()) {
        throw std::invalid_argument("KVMem replay selection does not cover the completed suffix");
    }

    std::vector<LogicalKVPageHandle> ordered_pages;
    ordered_pages.reserve((*query_block_index + 1U) * 2U);
    std::uint32_t compact_frontier = 0;
    for (std::size_t index = 0; index <= *query_block_index; ++index) {
        const SelectedBlockView& block = selected[index];
        const std::uint32_t tokens =
            index == *query_block_index ? replay_logical_begin - block.original_begin
                                        : block.tokens;
        if (tokens > std::numeric_limits<std::uint32_t>::max() - compact_frontier) {
            throw std::overflow_error("KVMem replay compact frontier overflow");
        }
        const std::uint32_t page_count =
            tokens == 0 ? 0U : 1U + (tokens - 1U) / page_tokens;
        for (std::uint32_t page_index = 0; page_index < page_count; ++page_index) {
            const LogicalKVPageHandle page = block.pages[page_index];
            if (std::find(ordered_pages.begin(), ordered_pages.end(), page) !=
                ordered_pages.end()) {
                throw std::logic_error("KVMem replay prefix page order contains a duplicate");
            }
            ordered_pages.push_back(page);
        }
        compact_frontier += tokens;
    }

    const std::uint32_t required_pages =
        compact_frontier == 0 ? 0U : 1U + (compact_frontier - 1U) / page_tokens;
    if (page_entitlement == 0 || page_entitlement < required_pages) {
        throw std::invalid_argument("KVMem replay page entitlement is too small");
    }

    // Replay changes only the contiguous mandatory suffix; old query K/V will
    // not be read under the restored pre-query state. Validate its release
    // before publishing a prefix or mutating native page ownership. Unrelated
    // inactive views may retain their own copies, but no old GPU reader may
    // still observe pages which this replay is about to invalidate.
    for (std::size_t index = *query_block_index; index < selected.size(); ++index) {
        for (const LogicalKVPageHandle page : selected[index].pages) {
            if (pages_->active_address_references(page) != 0 ||
                !pages_->can_release_reference(page, false)) {
                throw std::logic_error("KVMem replay suffix still has an active or pinned page");
            }
        }
    }

    addresses.install_inactive_execution_prefix(read_only_source, ordered_pages,
                                                compact_frontier);
    for (const SelectedBlockView& block : selected) {
        Slot& owned = require_slot(store.blocks()[block.block_id].gpu_slot);
        if (!owned.valid_tokens || block.tokens < *owned.valid_tokens) {
            owned.valid_tokens = block.tokens;
        }
    }

    if (compact_frontier == 0) {
        addresses.activate(writable_destination, page_entitlement, execution_row,
                           device_->stream);
    } else {
        auto fork = addresses.prepare_prefix_fork(read_only_source, writable_destination,
                                                  compact_frontier, page_entitlement,
                                                  execution_row);
        if (fork.needs_tail_copy()) {
            pages_->physical_pool().copy_page(addresses.prefix_fork_tail_source(fork),
                                              addresses.prefix_fork_tail_destination(fork),
                                              device_->transfer_stream);
            CUDA_CHECK(cudaStreamSynchronize(device_->transfer_stream));
        }
        addresses.commit_prefix_fork(std::move(fork), device_->stream);
    }

    // Keep Store/Runtime selection and slot identity intact. Only obsolete
    // query-page backing is discarded, after the exact prefix (including a
    // possible COW tail) is owned by the replay writer. The accepted writer
    // will supply replacement pages through the existing prefill handoff.
    for (std::size_t index = *query_block_index; index < selected.size(); ++index) {
        const SelectedBlockView& block = selected[index];
        Slot& owned = require_slot(store.blocks()[block.block_id].gpu_slot);
        for (const LogicalKVPageHandle page : owned.pages) {
            if (!pages_->release_reference(page, false)) { std::terminate(); }
        }
        owned.pages = {};
        owned.pages_materialized = false;
        owned.reserved_for_replay = true;
    }
    return compact_frontier;
}

std::int32_t KVMemPageBackend::alloc_gpu_slot() {
    if (host_archive_slot_ >= 0) {
        throw std::logic_error("KVMem Host archive traversal admits only one block at a time");
    }
    if (host_archive_active_) {
        if (occupied_slots_ != 0) {
            throw std::logic_error("KVMem Host archive traversal cannot overlap GPU residency");
        }
        host_archive_slot_ = reserve_empty_slot();
        return host_archive_slot_;
    }
    if (admission_active_) {
        if (admission_cursor_ == admission_reserve_only_.size()) {
            throw std::logic_error("KVMem admitted more blocks than its prefill pressure plan");
        }
        if (admission_reserve_only_[admission_cursor_]) {
            const std::int32_t slot = reserve_gpu_slot_for_append();
            ++admission_cursor_;
            return slot;
        }
    }
    if (free_slots_.empty()) {
        throw std::runtime_error("KVMem has no free GPU block slot");
    }
    auto reservation = pages_->physical_pool().reserve(2);
    if (!reservation) {
        throw std::runtime_error("KVMem GPU page pool has no two-page block capacity");
    }
    std::array<LogicalKVPageHandle, 2> logical_pages{};
    std::uint32_t materialized = 0;
    try {
        for (; materialized < 2; ++materialized) {
            logical_pages[materialized] = pages_->materialize_transfer_destination(
                *reservation, static_cast<std::uint32_t>(kPagedKVPageSize));
        }
    } catch (...) {
        for (std::uint32_t index = 0; index < materialized; ++index) {
            pages_->abort_transfer_destination(logical_pages[index], *reservation);
        }
        throw;
    }
    for (const LogicalKVPageHandle page : logical_pages) {
        pages_->publish_transfer_destination(page, false);
    }
    const std::int32_t slot_id = free_slots_.back();
    free_slots_.pop_back();
    slots_[static_cast<std::size_t>(slot_id)] =
        Slot{.pages = logical_pages, .block_id = std::nullopt,
             .occupied = true, .pages_materialized = true};
    ++occupied_slots_;
    if (admission_active_) { ++admission_cursor_; }
    return slot_id;
}

void KVMemPageBackend::free_gpu_slot(std::int32_t slot) {
    const Slot& owned = require_slot(slot);
    if (!owned.pages_materialized) {
        if (slot == host_archive_slot_) { host_archive_slot_ = -1; }
        slots_[static_cast<std::size_t>(slot)] = {};
        free_slots_.push_back(slot);
        --occupied_slots_;
        return;
    }
    for (const LogicalKVPageHandle page : owned.pages) {
        if (pages_->active_address_references(page) != 0 ||
            pages_->address_references(page) != 1 ||
            !pages_->can_release_reference(page, false)) {
            throw std::logic_error("KVMem cannot free a page still used by an execution address");
        }
    }
    const auto logical_pages = owned.pages;
    for (const LogicalKVPageHandle page : logical_pages) {
        if (!pages_->release_reference(page, false)) {
            throw std::logic_error("KVMem GPU slot release failed after validation");
        }
    }
    slots_[static_cast<std::size_t>(slot)] = {};
    free_slots_.push_back(slot);
    --occupied_slots_;
}

void KVMemPageBackend::copy_block_to_host(std::uint32_t block_id, std::int32_t slot,
                                          void* host, std::uint64_t bytes) {
    const Slot& owned = require_slot(slot);
    if (owned.block_id != block_id || host == nullptr || bytes != block_bytes_) {
        throw std::invalid_argument("KVMem stage-out block or byte count is invalid");
    }
    if (slot == host_archive_slot_) {
        if (!host_archive_active_ || owned.pages_materialized) {
            throw std::logic_error("KVMem Host archive block is not in an active traversal");
        }
        std::memcpy(host, bounce_->data(), static_cast<std::size_t>(block_bytes_));
        return;
    }
    const auto physical = physical_pages(owned);
    // Clear Host layout padding so the opaque KVMem block never publishes stale pinned bytes.
    std::memset(bounce_->data(), 0, static_cast<std::size_t>(block_bytes_));
    pages_->physical_pool().copy_to_host(
        physical, static_cast<std::byte*>(bounce_->data()), layout_, device_->transfer_stream);
    synchronize_host_transfer(device_->transfer_stream);
    std::memcpy(host, bounce_->data(), static_cast<std::size_t>(block_bytes_));
}

void KVMemPageBackend::copy_block_from_host(std::uint32_t block_id, std::int32_t slot,
                                            const void* host, std::uint64_t bytes) {
    Slot& owned = require_slot(slot);
    if ((owned.block_id && owned.block_id != block_id) || host == nullptr ||
        bytes != block_bytes_) {
        throw std::invalid_argument("KVMem stage-in block or byte count is invalid");
    }
    if (slot == host_archive_slot_) {
        if (!host_archive_active_ || owned.pages_materialized) {
            throw std::logic_error("KVMem Host archive block is not in an active traversal");
        }
        std::memcpy(bounce_->data(), host, static_cast<std::size_t>(block_bytes_));
        owned.block_id = block_id;
        return;
    }
    std::memcpy(bounce_->data(), host, static_cast<std::size_t>(block_bytes_));
    const auto physical = physical_pages(owned);
    pages_->physical_pool().copy_from_host(
        static_cast<const std::byte*>(bounce_->data()), layout_, physical,
        device_->transfer_stream);
    synchronize_host_transfer(device_->transfer_stream);
    owned.block_id = block_id;
}

} // namespace ninfer::models::qwen3_5::detail
