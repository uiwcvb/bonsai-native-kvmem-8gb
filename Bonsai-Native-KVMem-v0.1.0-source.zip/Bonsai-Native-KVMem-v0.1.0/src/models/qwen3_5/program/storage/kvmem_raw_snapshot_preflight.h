// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include "models/qwen3_5/program/storage/kvmem_session_transfer.h"

#include <kvmem/raw_kv_store.hpp>
#include <kvmem/snapshot.hpp>

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <exception>
#include <functional>
#include <limits>
#include <stdexcept>
#include <vector>

namespace ninfer::models::qwen3_5::detail {

struct KVMemRawSnapshotFootprint {
    std::uint64_t resident_bytes = 0;
    std::uint64_t scratch_bytes = 0;
};

// Native Raw framing is length-delimited per block. Reuse its writer for the
// config header and its reader for all block vectors; this only adapts framing.
inline KVMemRawSnapshotFootprint inspect_kvmem_raw_snapshot(
    kvmem::SnapshotReader& in, const kvmem::RawKvStoreConfig& config,
    std::uint32_t max_blocks,
    const std::function<void(std::uint32_t, const kvmem::RawKvStore&)>& inspect_block = {}) {
    kvmem::RawKvStore probe(config);

    kvmem::SnapshotWriter header_sizing;
    probe.snapshot_write(header_sizing);
    if (header_sizing.bytes() > std::numeric_limits<std::size_t>::max()) {
        throw std::length_error("native RawKvStore header is too large");
    }
    std::vector<std::uint8_t> empty_header;
    empty_header.reserve(static_cast<std::size_t>(header_sizing.bytes()));
    kvmem::SnapshotWriter header_writer([&empty_header](const void* data, std::size_t size) {
        const auto* first = static_cast<const std::uint8_t*>(data);
        empty_header.insert(empty_header.end(), first, first + size);
    });
    probe.snapshot_write(header_writer);
    if (header_writer.bytes() != header_sizing.bytes() ||
        empty_header.size() != header_sizing.bytes() ||
        empty_header.size() < sizeof(std::uint64_t)) {
        throw std::logic_error("native RawKvStore empty header changed while inspecting");
    }

    // The empty native header ends at its block-count scalar. Read the input
    // prefix verbatim, then reuse it as the prefix of each synthetic one-block stream.
    const std::size_t count_offset = empty_header.size() - sizeof(std::uint64_t);
    const std::uint64_t synthetic_prefix_bytes = kvmem_session_checked_add(
        static_cast<std::uint64_t>(count_offset), 2 * sizeof(std::uint64_t));
    if (synthetic_prefix_bytes > std::numeric_limits<std::size_t>::max()) {
        throw std::length_error("native RawKvStore synthetic header is too large");
    }
    std::vector<std::uint8_t> synthetic_header;
    synthetic_header.reserve(static_cast<std::size_t>(synthetic_prefix_bytes));
    synthetic_header.resize(count_offset);
    in.read(synthetic_header.data(), synthetic_header.size());
    if (!std::equal(synthetic_header.begin(), synthetic_header.end(), empty_header.begin())) {
        throw kvmem::SnapshotCorrupt("incompatible native RawKvStore snapshot header");
    }

    const std::uint64_t block_count = in.scalar<std::uint64_t>();
    if (block_count > static_cast<std::uint64_t>(max_blocks) + 1 ||
        block_count > in.remaining() / sizeof(std::uint64_t)) {
        throw kvmem::SnapshotCorrupt("invalid native RawKvStore snapshot block count");
    }

    const std::uint64_t empty_base = static_cast<std::uint64_t>(probe.allocated_bytes());
    KVMemRawSnapshotFootprint footprint;
    footprint.resident_bytes = empty_base;
    const auto header_bytes = [&]() {
        return kvmem_session_checked_add(
            static_cast<std::uint64_t>(empty_header.capacity()),
            static_cast<std::uint64_t>(synthetic_header.capacity()));
    };
    footprint.scratch_bytes = kvmem_session_checked_add(empty_base, header_bytes());

    for (std::uint64_t block_index = 0; block_index < block_count; ++block_index) {
        const std::uint64_t section_size = in.scalar<std::uint64_t>();
        const std::uint64_t later_blocks = block_count - block_index - 1;
        if (later_blocks > in.remaining() / sizeof(std::uint64_t)) {
            throw kvmem::SnapshotCorrupt("truncated native RawKvStore block framing");
        }
        const std::uint64_t later_headers = later_blocks * sizeof(std::uint64_t);
        if (section_size > in.remaining() - later_headers) {
            throw kvmem::SnapshotCorrupt("truncated native RawKvStore block section");
        }

        synthetic_header.resize(count_offset);
        kvmem::SnapshotWriter section_header([&synthetic_header](const void* data,
                                                                 std::size_t size) {
            const auto* first = static_cast<const std::uint8_t*>(data);
            synthetic_header.insert(synthetic_header.end(), first, first + size);
        });
        section_header.scalar(std::uint64_t{1});
        section_header.scalar(section_size);

        const std::uint64_t nested_size = kvmem_session_checked_add(
            static_cast<std::uint64_t>(synthetic_header.size()), section_size);
        std::size_t header_offset = 0;
        std::uint64_t section_remaining = section_size;
        std::exception_ptr source_error;
        const auto source = [&in, &synthetic_header, &header_offset,
                             &section_remaining, &source_error](void* destination,
                                                               std::size_t size) {
            auto* output = static_cast<std::uint8_t*>(destination);
            const std::size_t prefix_available = synthetic_header.size() - header_offset;
            const std::size_t prefix_size = std::min(size, prefix_available);
            if (prefix_size != 0) {
                std::memcpy(output, synthetic_header.data() + header_offset, prefix_size);
                header_offset += prefix_size;
            }
            const std::size_t body_size = size - prefix_size;
            if (static_cast<std::uint64_t>(body_size) > section_remaining) {
                throw kvmem::SnapshotCorrupt("native RawKvStore block read crossed its section");
            }
            if (body_size != 0) {
                try {
                    in.read(output + prefix_size, body_size);
                } catch (...) {
                    source_error = std::current_exception();
                    throw;
                }
                section_remaining -= static_cast<std::uint64_t>(body_size);
            }
        };

        const std::uint64_t probe_before = static_cast<std::uint64_t>(probe.allocated_bytes());
        kvmem::SnapshotReader nested(source, nested_size);
        try {
            probe.snapshot_read(nested, 0);
        } catch (const std::runtime_error&) {
            if (source_error) { std::rethrow_exception(source_error); }
            throw kvmem::SnapshotCorrupt("invalid native RawKvStore snapshot block");
        }
        if (nested.remaining() != 0 || header_offset != synthetic_header.size() ||
            section_remaining != 0) {
            throw kvmem::SnapshotCorrupt("native RawKvStore block section was not fully consumed");
        }

        const std::uint64_t probe_after = static_cast<std::uint64_t>(probe.allocated_bytes());
        if (probe_after < empty_base) {
            throw std::logic_error("native RawKvStore probe allocation fell below its empty base");
        }
        const std::uint64_t block_bytes = probe_after - empty_base;
        footprint.resident_bytes = kvmem_session_checked_add(footprint.resident_bytes,
                                                              block_bytes);

        // snapshot_read builds its replacement block before swapping it into the
        // probe. Include the cleared probe plus that one-block allocation at peak.
        const std::uint64_t decode_peak = kvmem_session_checked_add(probe_before, block_bytes);
        const std::uint64_t small_headers = kvmem_session_checked_add(
            header_bytes(), sizeof(kvmem::SnapshotReader) + sizeof(source));
        footprint.scratch_bytes = std::max(
            footprint.scratch_bytes,
            kvmem_session_checked_add(decode_peak, small_headers));

        if (inspect_block) {
            inspect_block(static_cast<std::uint32_t>(block_index), probe);
        }
        // Native clear drops the decoded payload before the next bounded read.
        probe.clear();
    }

    if (in.remaining() != 0) {
        throw kvmem::SnapshotCorrupt("native RawKvStore snapshot has trailing bytes");
    }
    return footprint;
}

}  // namespace ninfer::models::qwen3_5::detail
