// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#include "models/qwen3_5/program/storage/kvmem_follower_page_backend.h"

#include <kvmem/raw_kv_store.hpp>

#include <cuda_runtime_api.h>

#include <cstring>
#include <limits>
#include <span>
#include <stdexcept>
#include <type_traits>
#include <vector>

namespace ninfer::models::qwen3_5::detail {
namespace {

constexpr std::uint32_t kPageTokens = static_cast<std::uint32_t>(kPagedKVPageSize);

std::size_t checked_mul(std::size_t left, std::size_t right, const char* label) {
    if (right != 0 && left > std::numeric_limits<std::size_t>::max() / right) {
        throw std::overflow_error(label);
    }
    return left * right;
}

std::size_t checked_add(std::size_t left, std::size_t right, const char* label) {
    if (right > std::numeric_limits<std::size_t>::max() - left) {
        throw std::overflow_error(label);
    }
    return left + right;
}

bool same_page_handle(DeviceKVPageHandle left, DeviceKVPageHandle right) noexcept {
    static_assert(std::is_trivially_copyable_v<DeviceKVPageHandle>);
    static_assert(std::has_unique_object_representations_v<DeviceKVPageHandle>,
                  "page-handle identity must have a unique object representation");
    return std::memcmp(&left, &right, sizeof(DeviceKVPageHandle)) == 0;
}

HostKVPageLayout checked_host_layout(const DeviceKVPagePool& pages,
                                     std::uint32_t mtp_layer_count) {
    const KVPageGeometry& geometry = pages.geometry();
    if (mtp_layer_count != 1 || geometry.page_tokens != kPageTokens ||
        geometry.device_plane_order != PagedKVPlaneOrder::PageMajor ||
        (geometry.planes.size() != 2 && geometry.planes.size() != 4)) {
        throw std::invalid_argument(
            "MTP follower transfer requires one page-major K/V layer with optional K/V scales");
    }
    return plan_host_kv_page_layout(geometry);
}

std::size_t checked_bounce_bytes(const HostKVPageLayout& layout) {
    return checked_mul(layout.page_stride, 2U, "MTP follower page-pair size overflow");
}

std::size_t plane_head_row_bytes(const KVPlaneGeometry& plane) {
    if (plane.leading_extent <= 0 || plane.head_extent <= 0 || dtype_size(plane.dtype) == 0) {
        throw std::invalid_argument("MTP follower plane geometry is invalid");
    }
    return checked_mul(static_cast<std::size_t>(plane.leading_extent), dtype_size(plane.dtype),
                       "MTP follower plane row size overflow");
}

std::size_t plane_row_bytes(const KVPlaneGeometry& plane) {
    return checked_mul(plane_head_row_bytes(plane), static_cast<std::size_t>(plane.head_extent),
                       "MTP follower packed row size overflow");
}

void validate_host_plane(const HostKVPageLayout& layout, std::size_t plane_index) {
    const KVPlaneGeometry& geometry = layout.geometry.planes.at(plane_index);
    const HostKVPlaneLayout& host = layout.planes.at(plane_index);
    const std::size_t one_head_row = plane_head_row_bytes(geometry);
    if (host.head_payload_bytes != checked_mul(one_head_row, kPageTokens,
                                               "MTP follower host plane size overflow")) {
        throw std::invalid_argument("MTP follower host page plane layout is inconsistent");
    }
}

void copy_plane_token(std::byte* destination, const std::byte* page_base,
                      const HostKVPageLayout& layout, std::size_t plane_index,
                      std::uint32_t page_token, std::int32_t head) {
    const KVPlaneGeometry& geometry = layout.geometry.planes[plane_index];
    const HostKVPlaneLayout& host = layout.planes[plane_index];
    const std::size_t head_row = plane_head_row_bytes(geometry);
    const std::byte* source = page_base + host.offset +
                              static_cast<std::size_t>(head) * host.head_payload_bytes +
                              static_cast<std::size_t>(page_token) * head_row;
    std::memcpy(destination, source, head_row);
}

void copy_token_to_plane(std::byte* page_base, const std::byte* source,
                         const HostKVPageLayout& layout, std::size_t plane_index,
                         std::uint32_t page_token, std::int32_t head) {
    const KVPlaneGeometry& geometry = layout.geometry.planes[plane_index];
    const HostKVPlaneLayout& host = layout.planes[plane_index];
    const std::size_t head_row = plane_head_row_bytes(geometry);
    std::byte* destination = page_base + host.offset +
                             static_cast<std::size_t>(head) * host.head_payload_bytes +
                             static_cast<std::size_t>(page_token) * head_row;
    std::memcpy(destination, source, head_row);
}

} // namespace

KVMemFollowerPageBackend::KVMemFollowerPageBackend(DeviceContext& device,
                                                   DeviceKVPagePool& mtp_pages,
                                                   std::uint32_t mtp_layer_count)
    : device_(&device), pages_(&mtp_pages),
      host_layout_(checked_host_layout(mtp_pages, mtp_layer_count)),
      bounce_(checked_bounce_bytes(host_layout_)),
      key_row_bytes_(checked_add(
          plane_row_bytes(host_layout_.geometry.planes[0]),
          host_layout_.geometry.planes.size() == 4
              ? plane_row_bytes(host_layout_.geometry.planes[2])
              : 0U,
          "MTP follower K row size overflow")),
      value_row_bytes_(checked_add(
          plane_row_bytes(host_layout_.geometry.planes[1]),
          host_layout_.geometry.planes.size() == 4
              ? plane_row_bytes(host_layout_.geometry.planes[3])
              : 0U,
          "MTP follower V row size overflow")),
      has_scale_planes_(host_layout_.geometry.planes.size() == 4) {
    if (mtp_pages.plane_count() != host_layout_.geometry.planes.size()) {
        throw std::invalid_argument("MTP follower physical plane inventory is inconsistent");
    }
    validate_host_plane(host_layout_, 0);
    validate_host_plane(host_layout_, 1);
    if (host_layout_.geometry.planes[0].head_extent !=
        host_layout_.geometry.planes[1].head_extent) {
        throw std::invalid_argument("MTP follower K/V planes do not match head count");
    }
    if (has_scale_planes_) {
        validate_host_plane(host_layout_, 2);
        validate_host_plane(host_layout_, 3);
        if (host_layout_.geometry.planes[0].head_extent !=
                host_layout_.geometry.planes[2].head_extent ||
            host_layout_.geometry.planes[1].head_extent !=
                host_layout_.geometry.planes[3].head_extent) {
            throw std::invalid_argument("MTP follower scale planes do not match K/V heads");
        }
    }
}

void KVMemFollowerPageBackend::validate_position(std::uint32_t original_pos_begin) const {
    if (original_pos_begin % kBlockTokens != 0 ||
        original_pos_begin > std::numeric_limits<std::uint32_t>::max() - (kBlockTokens - 1U)) {
        throw std::invalid_argument("MTP follower transfer requires an aligned 128-token block start");
    }
}

std::uint32_t KVMemFollowerPageBackend::validate_page_prefix(
    const BlockPages& pages, std::uint32_t committed_rows) const {
    if (committed_rows == 0 || committed_rows > kBlockTokens) {
        throw std::invalid_argument("MTP follower committed row count must be in [1, 128]");
    }
    const std::uint32_t page_count =
        (committed_rows + kPageTokens - 1U) / kPageTokens;
    if (!pages[0].valid() || (page_count == 2 && !pages[1].valid())) {
        throw std::invalid_argument("MTP follower transfer is missing a required physical page");
    }
    if (page_count == 1 && pages[1].valid()) {
        throw std::invalid_argument("MTP follower transfer with <=64 rows requires only the first page");
    }
    if (page_count == 2 && same_page_handle(pages[0], pages[1])) {
        throw std::invalid_argument("MTP follower transfer contains a duplicate physical page");
    }
    (void)pages_->contiguous_run_count(
        std::span<const DeviceKVPageHandle>(pages.data(), page_count));
    return page_count;
}

void KVMemFollowerPageBackend::validate_raw(const kvmem::RawKvStore& raw) const {
    const kvmem::RawKvStoreConfig& config = raw.config();
    if (config.block_tokens != kBlockTokens || config.n_layer != 1 ||
        config.k_gpu_row_bytes != key_row_bytes_ ||
        config.v_gpu_row_bytes != value_row_bytes_) {
        throw std::invalid_argument(
            "follower RawKvStore must be configured for one 128-token MTP block and matching "
            "packed K/V row widths");
    }
}

void KVMemFollowerPageBackend::stage_out(std::uint32_t original_pos_begin,
                                         const BlockPages& resident_pages,
                                         kvmem::RawKvStore& follower_raw) {
    stage_out(original_pos_begin, resident_pages, kBlockTokens, follower_raw);
}

void KVMemFollowerPageBackend::stage_out(std::uint32_t original_pos_begin,
                                         const BlockPages& resident_pages,
                                         std::uint32_t committed_rows,
                                         kvmem::RawKvStore& follower_raw) {
    validate_position(original_pos_begin);
    const std::uint32_t page_count = validate_page_prefix(resident_pages, committed_rows);
    validate_raw(follower_raw);
    const std::uint32_t raw_block = original_pos_begin / kBlockTokens;
    if (committed_rows < kBlockTokens &&
        (follower_raw.has_k_gpu(raw_block, 0, committed_rows + 1U) ||
         follower_raw.has_v_gpu(raw_block, 0, committed_rows + 1U))) {
        throw std::invalid_argument(
            "follower RawKvStore has packed rows beyond the committed prefix; invalidate from "
            "the caller-selected frontier before replaying a shorter block");
    }

    device_->bind_to_current_thread();
    device_->synchronize();
    auto* bounce = static_cast<std::byte*>(bounce_.data());
    const std::size_t transfer_bytes = checked_mul(
        host_layout_.page_stride, page_count, "MTP follower page-prefix size overflow");
    std::memset(bounce, 0, transfer_bytes);
    const std::span<const DeviceKVPageHandle> page_prefix(resident_pages.data(), page_count);
    pages_->copy_to_host(page_prefix, bounce, host_layout_, device_->transfer_stream);
    CUDA_CHECK(cudaStreamSynchronize(device_->transfer_stream));

    std::vector<std::uint8_t> key_rows(checked_mul(committed_rows, key_row_bytes_,
                                                   "MTP follower K block size overflow"));
    std::vector<std::uint8_t> value_rows(checked_mul(committed_rows, value_row_bytes_,
                                                     "MTP follower V block size overflow"));
    const std::array<std::size_t, 2> key_planes{0, 2};
    const std::array<std::size_t, 2> value_planes{1, 3};
    const std::size_t key_plane_count = has_scale_planes_ ? 2U : 1U;
    const std::size_t value_plane_count = has_scale_planes_ ? 2U : 1U;

    for (std::uint32_t token = 0; token < committed_rows; ++token) {
        const std::size_t page_index = token / kPageTokens;
        const std::uint32_t page_token = token % kPageTokens;
        const std::byte* page_base = bounce + page_index * host_layout_.page_stride;
        std::byte* key_destination = reinterpret_cast<std::byte*>(key_rows.data()) +
                                     static_cast<std::size_t>(token) * key_row_bytes_;
        std::byte* value_destination = reinterpret_cast<std::byte*>(value_rows.data()) +
                                       static_cast<std::size_t>(token) * value_row_bytes_;
        for (std::int32_t head = 0; head < host_layout_.geometry.planes[0].head_extent; ++head) {
            for (std::size_t index = 0; index < key_plane_count; ++index) {
                const std::size_t plane = key_planes[index];
                copy_plane_token(key_destination, page_base, host_layout_, plane, page_token,
                                 head);
                key_destination += plane_head_row_bytes(host_layout_.geometry.planes[plane]);
            }

            for (std::size_t index = 0; index < value_plane_count; ++index) {
                const std::size_t plane = value_planes[index];
                copy_plane_token(value_destination, page_base, host_layout_, plane, page_token,
                                 head);
                value_destination += plane_head_row_bytes(host_layout_.geometry.planes[plane]);
            }
        }
    }

    follower_raw.write_layer_k_gpu(original_pos_begin, committed_rows, 0, key_rows.data());
    follower_raw.write_layer_v_gpu(original_pos_begin, committed_rows, 0, value_rows.data());
}

void KVMemFollowerPageBackend::stage_in(std::uint32_t original_pos_begin,
                                       const BlockPages& target_slot_pages,
                                       const kvmem::RawKvStore& follower_raw) {
    stage_in(original_pos_begin, target_slot_pages, kBlockTokens, follower_raw);
}

void KVMemFollowerPageBackend::stage_in(std::uint32_t original_pos_begin,
                                       const BlockPages& target_slot_pages,
                                       std::uint32_t committed_rows,
                                       const kvmem::RawKvStore& follower_raw) {
    validate_position(original_pos_begin);
    const std::uint32_t page_count = validate_page_prefix(target_slot_pages, committed_rows);
    validate_raw(follower_raw);
    const std::uint32_t raw_block = original_pos_begin / kBlockTokens;
    if (!follower_raw.has_k_gpu(raw_block, 0, committed_rows) ||
        !follower_raw.has_v_gpu(raw_block, 0, committed_rows)) {
        throw std::invalid_argument("follower RawKvStore does not contain the committed packed MTP rows");
    }

    std::vector<std::uint8_t> key_rows(checked_mul(committed_rows, key_row_bytes_,
                                                   "MTP follower K block size overflow"));
    std::vector<std::uint8_t> value_rows(checked_mul(committed_rows, value_row_bytes_,
                                                     "MTP follower V block size overflow"));
    if (!follower_raw.copy_k_gpu(raw_block, 0, key_rows.data(), committed_rows) ||
        !follower_raw.copy_v_gpu(raw_block, 0, value_rows.data(), committed_rows)) {
        throw std::runtime_error("follower RawKvStore failed to read the committed packed MTP rows");
    }

    auto* bounce = static_cast<std::byte*>(bounce_.data());
    const std::size_t transfer_bytes = checked_mul(
        host_layout_.page_stride, page_count, "MTP follower page-prefix size overflow");
    std::memset(bounce, 0, transfer_bytes);
    const std::array<std::size_t, 2> key_planes{0, 2};
    const std::array<std::size_t, 2> value_planes{1, 3};
    const std::size_t key_plane_count = has_scale_planes_ ? 2U : 1U;
    const std::size_t value_plane_count = has_scale_planes_ ? 2U : 1U;

    for (std::uint32_t token = 0; token < committed_rows; ++token) {
        const std::size_t page_index = token / kPageTokens;
        const std::uint32_t page_token = token % kPageTokens;
        std::byte* page_base = bounce + page_index * host_layout_.page_stride;
        const std::byte* key_source = reinterpret_cast<const std::byte*>(key_rows.data()) +
                                      static_cast<std::size_t>(token) * key_row_bytes_;
        const std::byte* value_source = reinterpret_cast<const std::byte*>(value_rows.data()) +
                                        static_cast<std::size_t>(token) * value_row_bytes_;
        for (std::int32_t head = 0; head < host_layout_.geometry.planes[0].head_extent; ++head) {
            for (std::size_t index = 0; index < key_plane_count; ++index) {
                const std::size_t plane = key_planes[index];
                copy_token_to_plane(page_base, key_source, host_layout_, plane, page_token, head);
                key_source += plane_head_row_bytes(host_layout_.geometry.planes[plane]);
            }

            for (std::size_t index = 0; index < value_plane_count; ++index) {
                const std::size_t plane = value_planes[index];
                copy_token_to_plane(page_base, value_source, host_layout_, plane, page_token,
                                    head);
                value_source += plane_head_row_bytes(host_layout_.geometry.planes[plane]);
            }
        }
    }

    device_->bind_to_current_thread();
    device_->synchronize();
    pages_->copy_from_host(bounce, host_layout_,
                           std::span<const DeviceKVPageHandle>(target_slot_pages.data(), page_count),
                           device_->transfer_stream);
    CUDA_CHECK(cudaStreamSynchronize(device_->transfer_stream));
}

} // namespace ninfer::models::qwen3_5::detail
