// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#include "models/qwen3_5/program/storage/kvmem_follower_replay_prefix.h"

#include "core/device.h"
#include "models/qwen3_5/program/storage/kvmem_follower_page_backend.h"
#include "models/qwen3_5/program/storage/kvmem_follower_retained_pages.h"

#include <kvmem/kvmem_store.hpp>
#include <kvmem/raw_kv_store.hpp>

#include <algorithm>
#include <exception>
#include <limits>
#include <optional>
#include <stdexcept>
#include <utility>

namespace ninfer::models::qwen3_5::detail {
namespace {

constexpr std::uint32_t kPageTokens  = KVMemFollowerExecutionMap::kPageTokens;
constexpr std::uint32_t kBlockTokens = KVMemFollowerExecutionMap::kBlockTokens;

void synchronize_device_noexcept(DeviceContext& device) noexcept {
    device.bind_to_current_thread_noexcept();
    if (cudaStreamSynchronize(device.transfer_stream) != cudaSuccess) { std::terminate(); }
    try {
        device.synchronize();
    } catch (...) { std::terminate(); }
}

class ActiveAddressReleaseGuard final {
public:
    ActiveAddressReleaseGuard(DeviceContext& device, KVAddressSpaceStore& addresses) noexcept
        : device_(&device), addresses_(&addresses) {}

    ~ActiveAddressReleaseGuard() noexcept {
        if (!address_) { return; }
        synchronize_device_noexcept(*device_);
        if (!addresses_->release_after_deactivate(*address_)) { std::terminate(); }
    }

    ActiveAddressReleaseGuard(const ActiveAddressReleaseGuard&)            = delete;
    ActiveAddressReleaseGuard& operator=(const ActiveAddressReleaseGuard&) = delete;

    void own(KVAddressSpaceHandle address) noexcept { address_ = address; }

    [[nodiscard]] bool release_now() noexcept {
        if (!address_) { return true; }
        if (!addresses_->release_after_deactivate(*address_)) { return false; }
        address_.reset();
        return true;
    }

    void dismiss() noexcept { address_.reset(); }

private:
    DeviceContext* device_          = nullptr;
    KVAddressSpaceStore* addresses_ = nullptr;
    std::optional<KVAddressSpaceHandle> address_;
};

class TemporaryPagePairReleaseGuard final {
public:
    using PagePair = KVMemFollowerRetainedPages::PagePair;

    TemporaryPagePairReleaseGuard(DeviceContext& device, LogicalKVPageStore& pages) noexcept
        : device_(&device), pages_(&pages) {}

    ~TemporaryPagePairReleaseGuard() noexcept {
        if (!armed_) { return; }
        synchronize_device_noexcept(*device_);
        for (const LogicalKVPageHandle page : pair_) {
            if (page.valid() && pages_->valid(page)) {
                const bool writer = pages_->writer_references(page) != 0;
                if (!pages_->release_reference(page, writer)) { std::terminate(); }
            }
        }
    }

    TemporaryPagePairReleaseGuard(const TemporaryPagePairReleaseGuard&) = delete;
    TemporaryPagePairReleaseGuard& operator=(const TemporaryPagePairReleaseGuard&) = delete;

    [[nodiscard]] PagePair& pages() noexcept { return pair_; }
    void dismiss() noexcept { armed_ = false; }

private:
    DeviceContext* device_ = nullptr;
    LogicalKVPageStore* pages_ = nullptr;
    PagePair pair_{};
    bool armed_ = true;
};

struct SelectedBlock {
    std::uint32_t id               = 0;
    const kvmem::KvMemBlock* block = nullptr;
};

struct RequiredBlock {
    KVMemFollowerExecutionRecord execution;
    bool retained = false;
    bool cold_partial_tail = false;
};

} // namespace

KVMemFollowerReplayPrefix install_kvmem_follower_replay_prefix(
    const kvmem::KvMemStore& store, std::span<const std::uint32_t> ordered_selected_block_ids,
    std::uint32_t replay_logical_begin, DeviceContext& device, LogicalKVPageStore& pages,
    KVAddressSpaceStore& addresses, KVMemFollowerPageBackend& follower_backend,
    const kvmem::RawKvStore& follower_raw, std::uint32_t page_entitlement, std::uint32_t lane,
    KVMemFollowerRetainedPages* retained) {
    if (store.config().block_tokens != kBlockTokens || ordered_selected_block_ids.empty() ||
        replay_logical_begin > store.total_tokens()) {
        throw std::invalid_argument(
            "MTP follower replay selection has invalid geometry or boundary");
    }
    const bool resume_at_accepted_end = replay_logical_begin == store.total_tokens();
    if (lane > static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max())) {
        throw std::invalid_argument("MTP follower replay lane exceeds the execution-row range");
    }

    const kvmem::RawKvStoreConfig& raw_config = follower_raw.config();
    if (raw_config.block_tokens != kBlockTokens || raw_config.n_layer != 1 ||
        raw_config.k_gpu_row_bytes != follower_backend.key_gpu_row_bytes() ||
        raw_config.v_gpu_row_bytes != follower_backend.value_gpu_row_bytes()) {
        throw std::invalid_argument(
            "MTP follower replay RawKvStore geometry does not match its backend");
    }
    if (retained != nullptr && &retained->owner() != &pages) {
        throw std::invalid_argument("MTP follower retained pages belong to a different page store");
    }

    if (page_entitlement == 0 || page_entitlement > pages.capacity() ||
        page_entitlement > pages.physical_pool().capacity_pages()) {
        throw std::invalid_argument(
            "MTP follower replay page entitlement exceeds available capacity");
    }

    std::vector<SelectedBlock> selected;
    selected.reserve(ordered_selected_block_ids.size());
    std::uint32_t prior_id           = 0;
    std::uint32_t prior_original_end = 0;
    std::size_t query_block_index    = ordered_selected_block_ids.size();

    for (std::size_t index = 0; index < ordered_selected_block_ids.size(); ++index) {
        const std::uint32_t id = ordered_selected_block_ids[index];
        if (id >= store.block_count()) {
            throw std::invalid_argument("MTP follower replay selection contains an unknown block");
        }
        const kvmem::KvMemBlock& block              = store.blocks()[id];
        const std::uint64_t expected_original_begin = static_cast<std::uint64_t>(id) * kBlockTokens;
        if (block.block_id != id || block.n_tokens == 0 || block.n_tokens > kBlockTokens ||
            block.tier != kvmem::KvTier::GPU || block.gpu_slot < 0 || !block.in_working_set ||
            block.in_flight || block.orig_pos_start % kBlockTokens != 0 ||
            block.orig_pos_start != expected_original_begin ||
            block.orig_pos_start > std::numeric_limits<std::uint32_t>::max() - block.n_tokens ||
            block.orig_pos_end() > store.total_tokens() ||
            (index != 0 && (id <= prior_id || block.orig_pos_start < prior_original_end)) ||
            (block.n_tokens < kBlockTokens &&
             (index + 1U != ordered_selected_block_ids.size() || id + 1U != store.block_count()))) {
            throw std::invalid_argument(
                "MTP follower replay selection is not ordered resident history");
        }

        if (!resume_at_accepted_end && replay_logical_begin >= block.orig_pos_start &&
            replay_logical_begin < block.orig_pos_end()) {
            if (query_block_index != ordered_selected_block_ids.size()) {
                throw std::invalid_argument(
                    "MTP follower replay boundary matches multiple selected blocks");
            }
            query_block_index = index;
        }

        selected.push_back({.id = id, .block = &block});
        prior_id           = id;
        prior_original_end = block.orig_pos_end();
    }

    if (resume_at_accepted_end) {
        if (selected.back().block->orig_pos_end() != store.total_tokens()) {
            throw std::invalid_argument(
                "MTP follower accepted-end resume requires the final selected block to reach the store frontier");
        }
        query_block_index = selected.size() - 1U;
    }

    if (query_block_index == ordered_selected_block_ids.size()) {
        throw std::invalid_argument("MTP follower replay boundary is not in the selected history");
    }

    KVMemFollowerReplayPrefix installed;
    installed.execution.reserve(query_block_index + 1U);
    std::vector<RequiredBlock> required;
    required.reserve(query_block_index + 1U);
    std::vector<LogicalKVPageHandle> retained_prefix_pages;
    retained_prefix_pages.reserve((query_block_index + 1U) * 2U);
    std::uint64_t compact_frontier = 0;
    for (std::size_t index = 0; index <= query_block_index; ++index) {
        const SelectedBlock& selected_block = selected[index];
        const kvmem::KvMemBlock& block      = *selected_block.block;
        const std::uint32_t committed_rows =
            index == query_block_index
                ? (resume_at_accepted_end ? block.n_tokens
                                          : replay_logical_begin - block.orig_pos_start)
                : block.n_tokens;
        if (committed_rows == 0) { continue; }
        if (compact_frontier > std::numeric_limits<std::uint32_t>::max() ||
            compact_frontier % kPageTokens != 0 ||
            committed_rows > std::numeric_limits<std::uint32_t>::max() - compact_frontier) {
            throw std::overflow_error(
                "MTP follower replay compact frontier is invalid or too large");
        }

        const KVMemFollowerExecutionRecord execution{
            .native_block_id   = selected_block.id,
            .original_position = block.orig_pos_start,
            .execution_begin   = static_cast<std::uint32_t>(compact_frontier),
            .committed_rows    = committed_rows,
        };
        const bool has_retained = retained != nullptr && retained->has(selected_block.id);
        const bool cold_partial_tail = index == query_block_index && !has_retained;
        if (!has_retained &&
            (!follower_raw.has_k_gpu(selected_block.id, 0, committed_rows) ||
             !follower_raw.has_v_gpu(selected_block.id, 0, committed_rows))) {
            throw std::invalid_argument(
                "MTP follower replay RawKvStore is missing packed prefix K/V for a cold block");
        }
        if (!has_retained && !cold_partial_tail && committed_rows != kBlockTokens) {
            throw std::logic_error("MTP follower cold history block is not complete");
        }

        if (has_retained) {
            const KVMemFollowerRetainedPages::PagePair pair = retained->pages(selected_block.id);
            if (retained->committed_rows(selected_block.id) < committed_rows) {
                throw std::logic_error(
                    "MTP follower retained block does not cover the requested prefix");
            }
            const std::uint32_t first_page_rows = std::min(committed_rows, kPageTokens);
            if (!pair[0].valid() || !pages.valid(pair[0]) ||
                !pages.device_resident(pair[0]) ||
                pages.committed_columns(pair[0]) < first_page_rows ||
                pages.writer_references(pair[0]) != 0) {
                throw std::logic_error(
                    "MTP follower retained first page does not cover the requested prefix");
            }
            if (committed_rows > kPageTokens &&
                (!pair[1].valid() || pair[1] == pair[0] || !pages.valid(pair[1]) ||
                 !pages.device_resident(pair[1]) ||
                 pages.committed_columns(pair[1]) < committed_rows - kPageTokens ||
                 pages.writer_references(pair[1]) != 0)) {
                throw std::logic_error(
                    "MTP follower retained second page does not cover the requested prefix");
            }
            const std::size_t used_pages = committed_rows > kPageTokens ? 2U : 1U;
            for (std::size_t page = 0; page < used_pages; ++page) {
                if (std::find(retained_prefix_pages.begin(), retained_prefix_pages.end(),
                              pair[page]) != retained_prefix_pages.end()) {
                    throw std::logic_error("MTP follower retained selection aliases a page");
                }
                retained_prefix_pages.push_back(pair[page]);
            }
        }

        installed.execution.push_back(execution);
        required.push_back({.execution = execution,
                            .retained = has_retained,
                            .cold_partial_tail = cold_partial_tail});
        compact_frontier += committed_rows;
    }
    if (compact_frontier > std::numeric_limits<std::uint32_t>::max()) {
        throw std::overflow_error("MTP follower replay compact frontier exceeds uint32");
    }
    installed.compact_frontier = static_cast<std::uint32_t>(compact_frontier);

    const std::uint64_t required_pages = (compact_frontier + kPageTokens - 1U) / kPageTokens;
    if (required_pages > page_entitlement) {
        throw std::invalid_argument(
            "MTP follower replay page entitlement is too small for its prefix");
    }
    std::uint64_t mapped_rows = 0;
    for (const KVMemFollowerExecutionRecord& record : installed.execution) {
        if (record.execution_begin != mapped_rows) {
            throw std::logic_error("MTP follower replay prefix contains an execution hole");
        }
        mapped_rows += record.committed_rows;
    }
    if (mapped_rows != compact_frontier) {
        throw std::logic_error("MTP follower replay records do not cover the compact frontier");
    }

    const bool needs_local_retained = std::any_of(
        required.begin(), required.end(), [](const RequiredBlock& block) {
            return !block.retained && !block.cold_partial_tail;
        });
    std::optional<KVMemFollowerRetainedPages> local_retained;
    if (needs_local_retained) {
        local_retained.emplace(pages, static_cast<std::uint32_t>(store.block_count()));
    }

    const RequiredBlock* cold_partial_tail = nullptr;
    std::uint64_t source_frontier = 0;
    for (const RequiredBlock& block : required) {
        if (block.cold_partial_tail) {
            cold_partial_tail = &block;
        } else {
            source_frontier += block.execution.committed_rows;
        }
    }
    if (source_frontier > std::numeric_limits<std::uint32_t>::max() ||
        source_frontier +
                (cold_partial_tail == nullptr ? 0U : cold_partial_tail->execution.committed_rows) !=
            compact_frontier ||
        (cold_partial_tail != nullptr && source_frontier % kPageTokens != 0)) {
        throw std::logic_error("MTP follower replay mixed-page prefix is inconsistent");
    }

    device.bind_to_current_thread();
    device.synchronize();
    const auto destination = addresses.create_inactive();
    if (!destination) {
        throw std::runtime_error("MTP follower replay has no free writable KV address descriptor");
    }
    ActiveAddressReleaseGuard release_destination_on_failure(device, addresses);
    release_destination_on_failure.own(*destination);

    std::optional<KVAddressSpaceHandle> source;
    ActiveAddressReleaseGuard release_source_on_failure(device, addresses);
    if (source_frontier != 0) {
        source = addresses.create_inactive();
        if (!source) {
            throw std::runtime_error("MTP follower replay has no read-only prefix descriptor");
        }
        release_source_on_failure.own(*source);
    }

    // Cold complete blocks become immutable page pairs. A cold partial query tail is
    // deliberately left for the active writer's growth pages below.
    for (const RequiredBlock& block : required) {
        if (block.retained || block.cold_partial_tail) { continue; }
        if (!local_retained) {
            throw std::logic_error("MTP follower cold history has no local page owner");
        }
        const std::uint32_t id = block.execution.native_block_id;
        auto reservation = pages.physical_pool().make_empty_reservation();
        pages.physical_pool().resize_reservation(reservation, 2U);
        TemporaryPagePairReleaseGuard release_on_failure(device, pages);
        auto& pair = release_on_failure.pages();
        pair[0] = pages.materialize(reservation);
        pair[1] = pages.materialize(reservation);
        const KVMemFollowerPageBackend::BlockPages physical{
            pages.physical(pair[0]), pages.physical(pair[1]),
        };
        follower_backend.stage_in(block.execution.original_position, physical,
                                  block.execution.committed_rows, follower_raw);
        for (const LogicalKVPageHandle page : pair) {
            pages.commit_coverage(page, kPageTokens);
            pages.set_writer(page, false);
        }
        local_retained->adopt_new(id, pair);
        release_on_failure.dismiss();
    }

    std::vector<LogicalKVPageHandle> source_pages;
    source_pages.reserve(required.size() * 2U);
    for (const RequiredBlock& block : required) {
        if (block.cold_partial_tail || block.execution.committed_rows == 0) { continue; }
        const KVMemFollowerRetainedPages::PagePair pair =
            block.retained ? retained->pages(block.execution.native_block_id)
                           : local_retained->pages(block.execution.native_block_id);
        source_pages.push_back(pair[0]);
        if (block.execution.committed_rows > kPageTokens) { source_pages.push_back(pair[1]); }
    }
    if (source_pages.size() != (source_frontier + kPageTokens - 1U) / kPageTokens) {
        throw std::logic_error("MTP follower replay source-page count does not match its frontier");
    }

    if (source) {
        addresses.install_inactive_execution_prefix(
            *source, source_pages, static_cast<std::uint32_t>(source_frontier));
        auto fork = addresses.prepare_prefix_fork(
            *source, *destination, static_cast<std::uint32_t>(source_frontier), page_entitlement,
            static_cast<std::int32_t>(lane));
        if (fork.needs_tail_copy()) {
            pages.physical_pool().copy_page(addresses.prefix_fork_tail_source(fork),
                                            addresses.prefix_fork_tail_destination(fork),
                                            device.transfer_stream);
            CUDA_CHECK(cudaStreamSynchronize(device.transfer_stream));
        }
        addresses.commit_prefix_fork(std::move(fork), device.stream);
    } else {
        addresses.activate(*destination, page_entitlement, static_cast<std::int32_t>(lane),
                           device.stream);
    }

    if (cold_partial_tail != nullptr) {
        const KVMemFollowerExecutionRecord& tail = cold_partial_tail->execution;
        const std::uint32_t first_page = tail.execution_begin / kPageTokens;
        if (tail.execution_begin != source_frontier ||
            tail.execution_begin % kPageTokens != 0 ||
            first_page != addresses.mapped_pages(*destination)) {
            throw std::logic_error("MTP follower cold replay tail is not at the writer growth frontier");
        }
        addresses.ensure_mapped_to_tokens(*destination, installed.compact_frontier, device.stream);
        const LogicalKVPageHandle first_logical = addresses.logical_page(*destination, first_page);
        if (!pages.valid(first_logical) || !pages.device_resident(first_logical) ||
            pages.address_references(first_logical) != 1 ||
            pages.writer_references(first_logical) != 1) {
            throw std::logic_error("MTP follower cold replay tail is not an exclusive writer page");
        }
        KVMemFollowerPageBackend::BlockPages physical{
            pages.physical(first_logical), {},
        };
        if (tail.committed_rows > kPageTokens) {
            const LogicalKVPageHandle second_logical =
                addresses.logical_page(*destination, first_page + 1U);
            if (!pages.valid(second_logical) || !pages.device_resident(second_logical) ||
                pages.address_references(second_logical) != 1 ||
                pages.writer_references(second_logical) != 1 ||
                second_logical == first_logical) {
                throw std::logic_error(
                    "MTP follower cold replay tail's second page is not an exclusive writer page");
            }
            physical[1] = pages.physical(second_logical);
        }
        follower_backend.stage_in(tail.original_position, physical, tail.committed_rows,
                                  follower_raw);
        addresses.commit_frontier(*destination, installed.compact_frontier);
    }

    if (addresses.committed_frontier(*destination) != installed.compact_frontier) {
        throw std::logic_error("MTP follower replay address published the wrong compact frontier");
    }
    (void)KVMemFollowerExecutionMap::resolve(installed.execution, addresses, *destination);

    if (source && !release_source_on_failure.release_now()) {
        throw std::logic_error("MTP follower replay failed to release its temporary prefix address");
    }
    installed.address = *destination;
    release_destination_on_failure.dismiss();
    return installed;
}

} // namespace ninfer::models::qwen3_5::detail
