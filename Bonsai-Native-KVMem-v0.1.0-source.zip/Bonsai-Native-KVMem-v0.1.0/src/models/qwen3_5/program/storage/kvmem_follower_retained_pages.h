// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#pragma once

#include "models/qwen3_5/program/storage/kv_store.h"

#include <array>
#include <cstdint>
#include <vector>

namespace ninfer::models::qwen3_5::detail {

class KVMemFollowerRetainedPages final {
public:
    using PagePair = std::array<LogicalKVPageHandle, 2>;

    KVMemFollowerRetainedPages(LogicalKVPageStore& pages, std::uint32_t block_count);
    ~KVMemFollowerRetainedPages() noexcept;

    KVMemFollowerRetainedPages(const KVMemFollowerRetainedPages&)            = delete;
    KVMemFollowerRetainedPages& operator=(const KVMemFollowerRetainedPages&) = delete;
    KVMemFollowerRetainedPages(KVMemFollowerRetainedPages&&)                 = delete;
    KVMemFollowerRetainedPages& operator=(KVMemFollowerRetainedPages&&)      = delete;

    [[nodiscard]] bool has(std::uint32_t block_id) const noexcept;
    [[nodiscard]] LogicalKVPageStore& owner() const noexcept { return *store_; }
    [[nodiscard]] PagePair pages(std::uint32_t block_id) const;
    [[nodiscard]] std::uint32_t committed_rows(std::uint32_t block_id) const;

    // A partial block retains only its actual committed prefix. Up to one
    // 64-token page requires an invalid second handle, not a fabricated page.
    void retain_existing(std::uint32_t block_id, const PagePair& pair,
                         std::uint32_t committed_rows = 128);
    void adopt_new(std::uint32_t block_id, const PagePair& pair);

private:
    void validate_block_id(std::uint32_t block_id) const;
    void validate_pair(const PagePair& pair, std::uint32_t committed_rows) const;

    LogicalKVPageStore* store_ = nullptr;
    std::vector<PagePair> pages_;
    std::vector<std::uint32_t> committed_rows_;
};

} // namespace ninfer::models::qwen3_5::detail
