// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#pragma once

#include "core/device.h"
#include "core/host_kv_arena.h"

#include <array>
#include <cstddef>
#include <cstdint>

namespace kvmem {
class RawKvStore;
}

namespace ninfer::models::qwen3_5::detail {

/*
 * Synchronous byte-preserving transfer primitive for the one-layer Qwen3.5
 * MTP cache and a native KVMem block. The caller supplies the physical pages
 * already selected for the resident/target slot; this class neither allocates
 * slots nor edits a KV address table or position map.
 *
 * RawKvStore stores opaque per-token rows. We serialize each K/V row as the
 * concatenated NInfer code and optional scale planes, head by head, without
 * decoding, requantizing, or changing any stored bits. Its k_gpu_row_bytes and
 * v_gpu_row_bytes must match these serialized row widths.
 *
 * This object reuses one pinned bounce buffer and provides no cross-K/V/store
 * transaction lock; callers must serialize its calls and RawKvStore mutations.
 */
class KVMemFollowerPageBackend final {
public:
    static constexpr std::uint32_t kBlockTokens = 128;
    using BlockPages = std::array<DeviceKVPageHandle, 2>;

    KVMemFollowerPageBackend(DeviceContext& device, DeviceKVPagePool& mtp_pages,
                             std::uint32_t mtp_layer_count);

    [[nodiscard]] std::size_t key_gpu_row_bytes() const noexcept { return key_row_bytes_; }
    [[nodiscard]] std::size_t value_gpu_row_bytes() const noexcept { return value_row_bytes_; }

    // `original_pos_begin` is the original, 128-token-aligned MTP position.
    // `resident_pages` are the corresponding first and second 64-token pages,
    // in order. For a full block, both pages must be valid and distinct.
    // GPU producers must have completed before this call; the method enforces
    // a device barrier before copying into RawKvStore.
    void stage_out(std::uint32_t original_pos_begin, const BlockPages& resident_pages,
                   kvmem::RawKvStore& follower_raw);

    // Transfer exactly `committed_rows` (1..128). One page is required for
    // <=64 rows and two distinct pages for 65..128 rows. For a one-page
    // transfer, the second handle must be invalid. If RawKvStore already marks
    // either packed plane valid beyond this count, the call throws; the caller
    // must invalidate from its chosen frontier before replaying a shorter prefix.
    void stage_out(std::uint32_t original_pos_begin, const BlockPages& resident_pages,
                   std::uint32_t committed_rows, kvmem::RawKvStore& follower_raw);

    // Read and restore exactly `committed_rows`. Any uncommitted suffix in the
    // target page(s) is zeroed and is never read from RawKvStore.
    void stage_in(std::uint32_t original_pos_begin, const BlockPages& target_slot_pages,
                  std::uint32_t committed_rows,
                  const kvmem::RawKvStore& follower_raw);

    // Restore the packed bytes into the exact MTP physical pages assigned by
    // the target-side slot plan. The caller must ensure those pages are not
    // concurrently visible through an active execution address; this primitive
    // does not publish metadata or alter the address mapping. This full-block
    // overload remains equivalent to 128 committed rows.
    void stage_in(std::uint32_t original_pos_begin, const BlockPages& target_slot_pages,
                  const kvmem::RawKvStore& follower_raw);

private:
    void validate_raw(const kvmem::RawKvStore& raw) const;
    void validate_position(std::uint32_t original_pos_begin) const;
    [[nodiscard]] std::uint32_t validate_page_prefix(const BlockPages& pages,
                                                     std::uint32_t committed_rows) const;

    DeviceContext* device_ = nullptr;
    DeviceKVPagePool* pages_ = nullptr;
    HostKVPageLayout host_layout_;
    PinnedHostBuffer bounce_;
    std::size_t key_row_bytes_ = 0;
    std::size_t value_row_bytes_ = 0;
    bool has_scale_planes_ = false;
};

} // namespace ninfer::models::qwen3_5::detail
