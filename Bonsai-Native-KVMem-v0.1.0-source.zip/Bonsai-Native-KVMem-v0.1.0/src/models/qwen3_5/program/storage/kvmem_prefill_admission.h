// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <kvmem/kvmem_store.hpp>

#include <algorithm>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <vector>

namespace ninfer::models::qwen3_5::detail {

// Native prepare_working_set registers the whole forward batch, then selects
// its incoming blocks as mandatory. Preview that same operation on CPU-only
// Store metadata before changing the live Runtime or reserving any pages.
// No local sink/recency/media selector or GPU allocation is introduced here.
inline std::uint32_t preview_kvmem_prefill_append_tokens(
    const kvmem::KvMemStore& store, std::uint32_t requested_tokens,
    std::uint32_t pool_tokens) {
    const auto block_tokens = store.config().block_tokens;
    if (block_tokens == 0 || requested_tokens == 0 || pool_tokens < block_tokens) {
        throw std::invalid_argument("KVMem prefill needs positive batch and whole-slot capacity");
    }
    const auto usable_pool_tokens = pool_tokens - pool_tokens % block_tokens;
    const auto requested = std::min(requested_tokens, usable_pool_tokens);
    const auto tail = store.total_tokens() % block_tokens;
    // Existing partial pages still represent the old accepted geometry. Their
    // pressure handoff must complete that one block before a multi-block batch.
    if (tail != 0) { return std::min(requested, block_tokens - tail); }

    std::uint64_t resident = 0;
    for (const auto& block : store.blocks()) {
        if (block.gpu_slot >= 0) { resident += block.n_tokens; }
    }
    if (resident + requested > std::numeric_limits<std::uint32_t>::max() ||
        store.total_tokens() > std::numeric_limits<std::uint32_t>::max() - requested) {
        throw std::overflow_error("KVMem prefill token count exceeds uint32");
    }
    if (!store.prefill_needs_offload(static_cast<std::uint32_t>(resident), requested,
                                    usable_pool_tokens)) {
        return requested;
    }

    const auto native_pool_blocks = usable_pool_tokens / block_tokens;
    for (auto candidate = requested; candidate != 0;
         candidate = ((candidate - 1U) / block_tokens) * block_tokens) {
        if (!store.prefill_needs_offload(static_cast<std::uint32_t>(resident), candidate,
                                        usable_pool_tokens)) {
            return candidate;
        }
        auto preview = store;
        preview.register_append(candidate);
        std::vector<std::uint32_t> incoming;
        for (const auto& block : preview.blocks()) {
            if (block.orig_pos_start >= store.total_tokens()) {
                incoming.push_back(block.block_id);
            }
        }
        std::vector<std::uint32_t> selected;
        try {
            selected = preview.pick_prefill_pressure_blocks(incoming);
        } catch (const std::runtime_error&) {
            // Pinned constrain_media rejects a mandatory image/sink/incoming
            // group that exceeds the native budget. Try one fewer new block,
            // without applying that failed selection to the live owner.
            continue;
        }
        if (selected.size() <= native_pool_blocks &&
            std::includes(selected.begin(), selected.end(), incoming.begin(), incoming.end())) {
            return candidate;
        }
    }
    return 0;
}

} // namespace ninfer::models::qwen3_5::detail
