// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include "models/qwen3_5/program/storage/kv_store.h"
#include "models/qwen3_5/program/storage/kvmem_follower_execution_map.h"

#include <cstdint>
#include <span>
#include <vector>

namespace ninfer {
struct DeviceContext;
} // namespace ninfer

namespace kvmem {
class KvMemStore;
class RawKvStore;
} // namespace kvmem

namespace ninfer::models::qwen3_5::detail {

class KVMemFollowerPageBackend;
class KVMemFollowerRetainedPages;

// An active, writable MTP address containing the selected history before the
// target replay boundary. The caller owns `address` and must release it after
// replay, including through release_after_deactivate when it remains active.
struct KVMemFollowerReplayPrefix {
    KVAddressSpaceHandle address;
    std::vector<KVMemFollowerExecutionRecord> execution;
    std::uint32_t compact_frontier = 0;
};

// Restore follower K/V for the original-order selected blocks before
// replay_logical_begin. Below store.total_tokens(), the selected block
// containing the boundary contributes only the rows preceding it. At the
// accepted end, equality with store.total_tokens() resumes after the final
// selected block's actual committed rows, without deferring a follower row.
// `page_entitlement` is the active address's total writable page entitlement,
// and `lane` is its MTP execution row. The returned compact frontier should
// equal the target query selection's replay_compact_begin (or its full
// accepted frontier when resuming at store.total_tokens()).
//
// The caller must pass the same page store/device that back `addresses` and
// `follower_backend`, and keep device execution quiescent while installing the
// returned address. Original-position gaps between selected blocks are
// intentional and are compacted. Non-tail partial blocks, non-aligned or
// inconsistently indexed block starts, and missing packed K/V rows in a cold
// required block are rejected. Read-only pages supplied through `retained`
// are indexed by native block id and need no RawKvStore mirror; retained row
// and page coverage must include the requested prefix. The execution records
// themselves always cover one gap-free compact prefix.
[[nodiscard]] KVMemFollowerReplayPrefix install_kvmem_follower_replay_prefix(
    const kvmem::KvMemStore& store, std::span<const std::uint32_t> ordered_selected_block_ids,
    std::uint32_t replay_logical_begin, DeviceContext& device, LogicalKVPageStore& pages,
    KVAddressSpaceStore& addresses, KVMemFollowerPageBackend& follower_backend,
    const kvmem::RawKvStore& follower_raw, std::uint32_t page_entitlement, std::uint32_t lane,
    KVMemFollowerRetainedPages* retained = nullptr);

} // namespace ninfer::models::qwen3_5::detail
