// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include "models/qwen3_5/program/storage/kv_store.h"
#include "models/qwen3_5/program/storage/kvmem_follower_execution_map.h"

#include <cstdint>
#include <vector>

namespace kvmem {
class KvMemStore;
}

namespace ninfer::models::qwen3_5::detail {

class KVMemPageBackend;

struct KVMemPrefillCommitSpan {
    std::uint32_t logical_begin = 0;
    std::uint32_t logical_end = 0;
    std::uint32_t execution_end = 0;
    std::uint32_t materialized_tail_tokens = 0;
    bool replay = false;
    bool publish_partial_tail = false;
    bool deferred_follower_last_row = false;
};

struct KVMemPrefillFollowerCommit {
    KVAddressSpaceStore* addresses = nullptr;
    KVAddressSpaceHandle address{};
    std::uint32_t committed_frontier = 0;
    std::vector<KVMemFollowerExecutionRecord>* records = nullptr;
};

// Local adapter for the pinned 128-token Store contract. The caller must
// reserve a GPU slot for each incoming block before forward.
// Publish accepted blocks from an inactive writer; Program owns reactivation.
[[nodiscard]] std::uint32_t commit_kvmem_prefill_blocks(
    const kvmem::KvMemStore& store, KVMemPageBackend& backend,
    KVAddressSpaceStore& addresses, KVAddressSpaceHandle address,
    KVMemPrefillCommitSpan span,
    const KVMemPrefillFollowerCommit* follower = nullptr);

} // namespace ninfer::models::qwen3_5::detail
