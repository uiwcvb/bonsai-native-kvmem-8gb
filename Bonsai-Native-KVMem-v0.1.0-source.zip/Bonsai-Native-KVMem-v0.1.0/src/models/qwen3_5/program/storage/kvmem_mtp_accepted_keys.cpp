// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0

#include "models/qwen3_5/program/storage/kvmem_mtp_accepted_keys.h"

#include "core/device.h"
#include "models/qwen3_5/config.h"
#include "ninfer/ops/attention_feature_sum.h"

#include <kvmem/raw_kv_store.hpp>

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <utility>

namespace ninfer::models::qwen3_5::detail {
namespace {

constexpr std::uint32_t kNativeBlockTokens = 128;

std::size_t checked_product(std::size_t lhs, std::size_t rhs, const char* what) {
    if (lhs != 0 && rhs > std::numeric_limits<std::size_t>::max() / lhs) {
        throw std::overflow_error(what);
    }
    return lhs * rhs;
}

} // namespace

KVMemMtpAcceptedKeys::KVMemMtpAcceptedKeys(const TextConfig& text, kvmem::RawKvStore& raw,
                                           Tensor staged_storage, Tensor reduction_storage,
                                           std::uint32_t accepted_key_frontier)
    : raw_(&raw), key_frontier_(accepted_key_frontier), staged_storage_(staged_storage),
      reduction_storage_(reduction_storage) {
    const auto& raw_config = raw_->config();
    if (!text.attention || text.full_attention_layers == 0 ||
        text.layer_types.size() != text.compact_layer_indices.size()) {
        throw std::invalid_argument("MTP accepted-key staging requires valid attention geometry/capacity");
    }

    std::uint32_t full_layers = 0;
    std::uint32_t linear_layers = 0;
    for (std::size_t layer = 0; layer < text.layer_types.size(); ++layer) {
        const std::uint32_t expected = text.layer_types[layer] == MixerKind::FullAttention
                                           ? full_layers++
                                           : linear_layers++;
        if (text.compact_layer_indices[layer] != expected) {
            throw std::invalid_argument("Qwen compact layer mapping is not contiguous by mixer kind");
        }
    }
    if (full_layers != text.full_attention_layers || raw_config.n_layer != full_layers ||
        raw_config.block_tokens != kNativeBlockTokens ||
        full_layers > static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max())) {
        throw std::invalid_argument("MTP accepted-key RawKvStore layer/block geometry mismatch");
    }

    const auto& attention = *text.attention;
    const auto key_width = attention.key_width();
    constexpr auto max_tensor_dim =
        static_cast<std::uint64_t>(std::numeric_limits<std::int32_t>::max());
    if (attention.head_dim == 0 || attention.num_key_value_heads == 0 || key_width == 0 ||
        attention.head_dim > max_tensor_dim || attention.num_key_value_heads > max_tensor_dim ||
        key_width > max_tensor_dim || raw_config.n_embd_k != key_width ||
        key_width > std::numeric_limits<std::int32_t>::max()) {
        throw std::invalid_argument("MTP accepted-key dimensions do not match RawKvStore");
    }

    attention_layers_ = full_layers;
    head_dim_ = attention.head_dim;
    kv_heads_ = attention.num_key_value_heads;
    key_width_ = static_cast<std::size_t>(key_width);

    if (staged_storage_.data == nullptr || reduction_storage_.data == nullptr ||
        staged_storage_.dtype != DType::BF16 || reduction_storage_.dtype != DType::FP32) {
        throw std::invalid_argument("MTP accepted-key storage must be non-null BF16/F32 tensors");
    }
    if (staged_storage_.ne[0] != static_cast<std::int32_t>(head_dim_) ||
        staged_storage_.ne[1] != static_cast<std::int32_t>(kv_heads_) ||
        staged_storage_.ne[2] <= 0 ||
        staged_storage_.ne[3] != static_cast<std::int32_t>(attention_layers_)) {
        throw std::invalid_argument(
            "MTP staged-key storage must have shape [D,Hkv,max_verify_columns,L]");
    }
    max_verify_columns_ = static_cast<std::uint32_t>(staged_storage_.ne[2]);
    if (max_verify_columns_ == 0 ||
        max_verify_columns_ >
            static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max())) {
        throw std::invalid_argument("MTP accepted-key staging capacity is outside int32");
    }

    const auto key_elements = checked_product(key_width_, max_verify_columns_,
                                              "MTP staged-key layer size overflows");
    staged_layer_bytes_ = checked_product(key_elements, sizeof(std::uint16_t),
                                          "MTP staged-key layer byte size overflows");
    const auto all_staged_bytes = checked_product(
        staged_layer_bytes_, attention_layers_, "MTP staged-key storage size overflows");
    max_reduction_segments_ = static_cast<std::uint32_t>(
        (static_cast<std::uint64_t>(max_verify_columns_) + 2U * kNativeBlockTokens - 2U) /
        kNativeBlockTokens);
    if (reduction_storage_.ne[0] != static_cast<std::int32_t>(head_dim_) ||
        reduction_storage_.ne[1] != static_cast<std::int32_t>(kv_heads_) ||
        reduction_storage_.ne[2] != static_cast<std::int32_t>(attention_layers_) ||
        reduction_storage_.ne[3] != static_cast<std::int32_t>(max_reduction_segments_)) {
        throw std::invalid_argument(
            "MTP reduction storage must have shape [D,Hkv,L,max_reduction_segments]");
    }
    const auto reduction_elements = checked_product(
        checked_product(key_width_, attention_layers_,
                        "MTP reduction layer size overflows"),
        max_reduction_segments_, "MTP reduction segment size overflows");
    const auto reduction_bytes = checked_product(reduction_elements, sizeof(float),
                                                 "MTP reduction storage size overflows");

    staged_storage_bytes_ = staged_storage_.bytes();
    reduction_storage_bytes_ = reduction_storage_.bytes();
    if (staged_storage_bytes_ != all_staged_bytes ||
        reduction_storage_bytes_ != reduction_bytes) {
        throw std::invalid_argument("MTP accepted-key storage byte size does not match its shape");
    }
    if (!staged_storage_.is_contiguous() || !reduction_storage_.is_contiguous()) {
        throw std::invalid_argument("MTP accepted-key storage must be contiguous");
    }

    const auto staged_address = reinterpret_cast<std::uintptr_t>(staged_storage_.data);
    const auto reduction_address = reinterpret_cast<std::uintptr_t>(reduction_storage_.data);
    if (staged_address % alignof(std::uint16_t) != 0 ||
        reduction_address % alignof(float) != 0) {
        throw std::invalid_argument("MTP accepted-key storage is not element-aligned");
    }
    if (staged_address <= reduction_address
            ? reduction_address - staged_address < staged_storage_bytes_
            : staged_address - reduction_address < reduction_storage_bytes_) {
        throw std::invalid_argument("MTP accepted-key storage tensors must not overlap");
    }

    staged_key_views_.reserve(attention_layers_);
    for (std::uint32_t layer = 0; layer < attention_layers_; ++layer) {
        staged_key_views_.push_back(
            staged_storage_.slice(3, static_cast<std::int32_t>(layer), 1));
    }
    capture_view_.staged_keys =
        std::span<const Tensor>{staged_key_views_.data(), staged_key_views_.size()};
    host_sum_.resize(reduction_elements);
}

const execution::AttentionFeatureCapture& KVMemMtpAcceptedKeys::begin_verify(
    std::int32_t verify_width, std::int32_t batch, cudaStream_t stream) {
    if (state_ == State::Failed) {
        throw std::logic_error("MTP accepted-key staging failed and must be reconstructed");
    }
    if (state_ != State::Idle) {
        throw std::logic_error("MTP accepted-key verify is already in flight");
    }
    if (batch != 1) {
        throw std::invalid_argument("MTP accepted-key staging currently requires batch size one");
    }
    if (verify_width <= 0 || static_cast<std::uint32_t>(verify_width) > max_verify_columns_) {
        throw std::invalid_argument("MTP verify width exceeds accepted-key staging capacity");
    }

    active_columns_ = verify_width;
    capture_stream_ = stream;
    state_ = State::Capturing;
    try {
        // One bounded clear replaces one launch per attention layer. The
        // captured graph overwrites the active columns before reduction.
        CUDA_CHECK(cudaMemsetAsync(staged_storage_.data, 0, staged_storage_bytes_,
                                   capture_stream_));
    } catch (...) {
        state_ = State::Failed;
        throw;
    }
    return capture_view_;
}

void KVMemMtpAcceptedKeys::commit_accepted_prefix(std::uint32_t logical_first,
                                                  std::int32_t accepted_count) {
    if (state_ == State::Failed) {
        throw std::logic_error("MTP accepted-key staging failed and must be reconstructed");
    }
    if (state_ != State::Capturing) {
        throw std::logic_error("MTP accepted-key commit has no active verify");
    }
    if (accepted_count < 0 || accepted_count > active_columns_ ||
        logical_first != key_frontier_ ||
        static_cast<std::uint64_t>(logical_first) + static_cast<std::uint32_t>(accepted_count) >
            std::numeric_limits<std::uint32_t>::max()) {
        throw std::invalid_argument("MTP accepted prefix is outside the verify/frontier interval");
    }

    try {
        if (accepted_count == 0) {
            CUDA_CHECK(cudaStreamSynchronize(capture_stream_));
            state_ = State::Idle;
            active_columns_ = 0;
            capture_stream_ = nullptr;
            return;
        }

        const auto logical_end = logical_first + static_cast<std::uint32_t>(accepted_count);
        const auto prefix_count = logical_first % kNativeBlockTokens;
        if (prefix_count != 0) {
            const auto checkpoint = raw_->mean_checkpoint(logical_first);
            const auto stride = key_width_ + 1U;
            if (checkpoint.size() != static_cast<std::size_t>(attention_layers_) * stride) {
                throw std::logic_error("MTP accepted K tail has no complete native checkpoint");
            }
            for (std::uint32_t layer = 0; layer < attention_layers_; ++layer) {
                const auto* source = checkpoint.data() + static_cast<std::size_t>(layer) * stride;
                if (source[0] != static_cast<float>(prefix_count)) {
                    throw std::logic_error("MTP accepted K tail mean count differs from frontier");
                }
                // The first reduction continues the existing native block's
                // FP32 recurrence. This owned source outlives its H2D transfer.
                std::copy_n(source + 1U, key_width_, host_sum_.data() +
                            static_cast<std::size_t>(layer) * key_width_);
            }
        }
        raw_->ensure_blocks((logical_end - 1) / kNativeBlockTokens + 1);

        std::vector<std::pair<std::uint32_t, std::uint32_t>> segments;
        std::uint32_t accepted_offset = 0;
        while (accepted_offset < static_cast<std::uint32_t>(accepted_count)) {
            const std::uint32_t token_position = logical_first + accepted_offset;
            const std::uint32_t block_offset = token_position % kNativeBlockTokens;
            const auto count = std::min(
                static_cast<std::uint32_t>(accepted_count) - accepted_offset,
                kNativeBlockTokens - block_offset);
            if (segments.size() >= max_reduction_segments_) {
                throw std::logic_error("MTP accepted-key segment count exceeds staging capacity");
            }
            const std::size_t segment = segments.size();
            segments.emplace_back(token_position, count);
            for (std::uint32_t layer = 0; layer < attention_layers_; ++layer) {
                const auto element_offset =
                    (segment * attention_layers_ + layer) * key_width_;
                auto* destination = reinterpret_cast<float*>(
                    static_cast<std::uint8_t*>(reduction_storage_.data) +
                    element_offset * sizeof(float));
                Tensor reduction_view{destination, DType::FP32,
                                      {static_cast<std::int32_t>(head_dim_),
                                       static_cast<std::int32_t>(kv_heads_)}};
                if (block_offset != 0) {
                    CUDA_CHECK(cudaMemcpyAsync(destination, host_sum_.data() + element_offset,
                                               key_width_ * sizeof(float), cudaMemcpyHostToDevice,
                                               capture_stream_));
                } else {
                    CUDA_CHECK(cudaMemsetAsync(destination, 0, key_width_ * sizeof(float),
                                               capture_stream_));
                }
                ops::attention_feature_sum(staged_key_views_[layer],
                                           static_cast<std::int32_t>(accepted_offset),
                                           static_cast<std::int32_t>(count), reduction_view,
                                           capture_stream_);
            }
            accepted_offset += count;
        }
        // The verify graph and all reductions share one stream. One barrier and
        // one transfer suffice; per-layer D2H round trips would hurt TPS.
        CUDA_CHECK(cudaStreamSynchronize(capture_stream_));
        const auto used_elements = checked_product(
            checked_product(segments.size(), attention_layers_,
                            "MTP used reduction layer count overflows"),
            key_width_, "MTP used reduction element count overflows");
        const auto used_bytes = checked_product(used_elements, sizeof(float),
                                                "MTP used reduction byte count overflows");
        if (used_bytes > reduction_storage_bytes_) {
            throw std::logic_error("MTP used reduction readback exceeds borrowed storage");
        }
        CUDA_CHECK(cudaMemcpy(host_sum_.data(), reduction_storage_.data, used_bytes,
                              cudaMemcpyDeviceToHost));
        for (std::size_t segment = 0; segment < segments.size(); ++segment) {
            const auto [token_position, count] = segments[segment];
            const auto block_offset = token_position % kNativeBlockTokens;
            for (std::uint32_t layer = 0; layer < attention_layers_; ++layer) {
                const auto element_offset =
                    (segment * attention_layers_ + layer) * key_width_;
                // Offset zero replaces the complete accepted block prefix;
                // adding a separately reduced suffix would change FP32 order.
                raw_->write_layer_mean_sum(token_position - block_offset, block_offset + count, layer,
                                           host_sum_.data() + element_offset);
            }
        }

        key_frontier_ = logical_end;
        state_ = State::Idle;
        active_columns_ = 0;
        capture_stream_ = nullptr;
    } catch (...) {
        // RawKvStore has no multi-layer transaction; never retry a possibly
        // partial publication with inconsistent layer/block frontiers.
        state_ = State::Failed;
        throw;
    }
}

void KVMemMtpAcceptedKeys::discard_verify() {
    if (state_ == State::Failed) {
        throw std::logic_error("MTP accepted-key staging failed and must be reconstructed");
    }
    if (state_ != State::Capturing) {
        throw std::logic_error("MTP accepted-key discard has no active verify");
    }
    try {
        CUDA_CHECK(cudaStreamSynchronize(capture_stream_));
    } catch (...) {
        state_ = State::Failed;
        throw;
    }
    state_ = State::Idle;
    active_columns_ = 0;
    capture_stream_ = nullptr;
}

void KVMemMtpAcceptedKeys::reset_key_frontier(std::uint32_t logical_frontier) {
    if (state_ != State::Idle) {
        throw std::logic_error("MTP accepted-key frontier cannot reset during verify");
    }
    key_frontier_ = logical_frontier;
}

void KVMemMtpAcceptedKeys::rebind_raw(kvmem::RawKvStore& raw,
                                      std::uint32_t logical_frontier) {
    if (state_ == State::Capturing) {
        throw std::logic_error("MTP accepted-key RawKvStore cannot rebind during verify");
    }

    const auto& raw_config = raw.config();
    if (raw_config.n_layer != attention_layers_ || raw_config.n_embd_k != key_width_ ||
        raw_config.block_tokens != kNativeBlockTokens) {
        throw std::invalid_argument("MTP accepted-key RawKvStore geometry mismatch");
    }

    raw_ = &raw;
    key_frontier_ = logical_frontier;
    if (state_ == State::Failed) {
        active_columns_ = 0;
        capture_stream_ = nullptr;
        state_ = State::Idle;
    }
}

} // namespace ninfer::models::qwen3_5::detail
