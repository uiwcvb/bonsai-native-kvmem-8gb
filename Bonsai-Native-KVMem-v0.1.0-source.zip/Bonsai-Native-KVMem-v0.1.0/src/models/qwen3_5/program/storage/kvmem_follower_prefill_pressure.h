// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include "models/qwen3_5/program/storage/kvmem_follower_execution_map.h"

#include <cstdint>
#include <span>

namespace kvmem {
class KvMemStore;
class RawKvStore;
} // namespace kvmem

namespace ninfer::models::qwen3_5::detail {

class KVMemFollowerPageBackend;
class KVMemFollowerRetainedPages;

// Preserve outgoing packed rows and retain selected resident follower pages
// while an active, committed native-prefill source address is detached. A final
// partially committed native block remains resident and is retained with its
// exact row count; it is never staged through RawKvStore.
void preserve_kvmem_prefill_follower(
    const kvmem::KvMemStore& store,
    std::span<const KVMemFollowerExecutionRecord> execution,
    KVAddressSpaceStore& addresses, KVAddressSpaceHandle address,
    KVMemFollowerPageBackend& follower_backend, kvmem::RawKvStore& follower_raw,
    std::span<const std::uint32_t> outgoing_ids,
    std::uint32_t committed_original_frontier,
    std::uint32_t committed_execution_frontier,
    KVMemFollowerRetainedPages& retained);

} // namespace ninfer::models::qwen3_5::detail
