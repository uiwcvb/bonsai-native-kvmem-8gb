// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <kvmem/snapshot.hpp>

#include <algorithm>
#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

namespace ninfer::models::qwen3_5::detail {

inline constexpr std::uint64_t kKVMemParkedSnapshotMaxBytes = 8ULL * 1024ULL * 1024ULL * 1024ULL;
inline constexpr std::uint64_t kKVMemParkedSnapshotMaxStringBytes = 1024ULL * 1024ULL;

// The parked/Runtime archive uses Native's exact FNV scope and seed. Borrow
// that state for fresh native streams instead of computing a second identical
// checksum over every payload. The trailer is excluded from this archive hash,
// while Native continues hashing it for its transport scope. Byte
// encoding, bounds and span/config behavior remain the existing local codec.
class KVMemParkedSnapshotWriter final {
public:
    KVMemParkedSnapshotWriter() = default;
    explicit KVMemParkedSnapshotWriter(kvmem::SnapshotWriter& stream, bool sizing)
        : stream_(&stream), sizing_(sizing) {
        if (stream.bytes() != 0) {
            throw std::invalid_argument("KVMem parked snapshot requires a fresh native writer");
        }
    }

    void reserve_additional(std::uint64_t count) {
        const std::uint64_t total = checked_total(count);
        if (stream_ == nullptr) { data_.reserve(static_cast<std::size_t>(total)); }
    }

    void count_bytes(std::uint64_t count) {
        if (finished_) { throw std::logic_error("KVMem parked snapshot already finished"); }
        if (!sizing_) { throw std::logic_error("KVMem snapshot counting requires a sizing pass"); }
        const auto total = checked_total(count);
        stream_->write(nullptr, count);
        size_ = total;
    }

    void put_u8(std::uint8_t value) { put_integer(value); }
    void put_u32(std::uint32_t value) { put_integer(value); }
    void put_u64(std::uint64_t value) { put_integer(value); }
    void put_i32(std::int32_t value) { put_integer(std::bit_cast<std::uint32_t>(value)); }
    void put_i64(std::int64_t value) { put_integer(std::bit_cast<std::uint64_t>(value)); }
    void put_f32(float value) { put_integer(std::bit_cast<std::uint32_t>(value)); }
    void put_f64(double value) { put_integer(std::bit_cast<std::uint64_t>(value)); }

    template <class E>
    void put_enum(E value) {
        static_assert(std::is_enum_v<E>);
        using U = std::underlying_type_t<E>;
        if constexpr (sizeof(U) == 1) {
            put_u8(static_cast<std::uint8_t>(value));
        } else if constexpr (sizeof(U) == 4) {
            put_u32(static_cast<std::uint32_t>(value));
        } else {
            static_assert(sizeof(U) == 1 || sizeof(U) == 4);
        }
    }

    void put_bool(bool value) { put_u8(value ? 1U : 0U); }

    void put_string(std::string_view value) {
        if (value.size() > kKVMemParkedSnapshotMaxStringBytes) {
            throw std::length_error("KVMem parked snapshot configuration string is too long");
        }
        put_u64(static_cast<std::uint64_t>(value.size()));
        put_bytes(std::span<const std::uint8_t>(
            reinterpret_cast<const std::uint8_t*>(value.data()), value.size()));
    }

    void put_bytes(std::span<const std::uint8_t> bytes) {
        write_bytes(bytes, true);
    }

    void put_blob(std::span<const std::uint8_t> bytes) {
        put_u64(static_cast<std::uint64_t>(bytes.size()));
        put_bytes(bytes);
    }

    [[nodiscard]] std::uint64_t hash() const noexcept {
        return stream_ != nullptr && !finished_ ? stream_->hash() : hash_;
    }
    [[nodiscard]] std::size_t size() const noexcept { return static_cast<std::size_t>(size_); }
    [[nodiscard]] const std::vector<std::uint8_t>& data() const noexcept { return data_; }
    [[nodiscard]] std::vector<std::uint8_t> take() && { return std::move(data_); }

    void put_trailer_u64(std::uint64_t value) {
        if (finished_) { throw std::logic_error("KVMem parked snapshot already finished"); }
        const auto body_hash = hash();
        put_integer_unhashed(value);
        hash_ = body_hash;
        finished_ = true;
    }

private:
    [[nodiscard]] std::uint64_t checked_total(std::uint64_t add) const {
        if (add > kKVMemParkedSnapshotMaxBytes || size_ > kKVMemParkedSnapshotMaxBytes - add) {
            throw std::length_error("KVMem parked snapshot exceeds its byte limit");
        }
        const std::uint64_t total = size_ + add;
        if (total > std::numeric_limits<std::size_t>::max()) {
            throw std::length_error("KVMem parked snapshot is too large for this process");
        }
        return total;
    }

    template <class U>
    void put_integer_impl(U value, bool include_in_hash) {
        static_assert(std::is_unsigned_v<U>);
        std::array<std::uint8_t, sizeof(U)> encoded{};
        for (std::size_t i = 0; i < encoded.size(); ++i) {
            encoded[i] = static_cast<std::uint8_t>(value & U{0xff});
            value >>= 8U;
        }
        write_bytes(encoded, include_in_hash);
    }

    template <class U>
    void put_integer(U value) {
        put_integer_impl(value, true);
    }

    void put_integer_unhashed(std::uint64_t value) {
        put_integer_impl(value, false);
    }

    void update_hash(std::span<const std::uint8_t> bytes) noexcept {
        for (const std::uint8_t byte : bytes) {
            hash_ = (hash_ ^ byte) * 1099511628211ull;
        }
    }

    void write_bytes(std::span<const std::uint8_t> bytes, bool include_in_hash) {
        if (finished_) { throw std::logic_error("KVMem parked snapshot already finished"); }
        const auto total = checked_total(bytes.size());
        if (sizing_) { stream_->write(bytes.data(), bytes.size()); }
        else {
            if (stream_ != nullptr) { stream_->write(bytes.data(), bytes.size()); }
            else { data_.insert(data_.end(), bytes.begin(), bytes.end()); }
            // Native hashes streamed bytes already; only the vector-backed
            // config encoder owns a separate local checksum scope.
            if (stream_ == nullptr && include_in_hash) { update_hash(bytes); }
        }
        size_ = total;
    }

    std::vector<std::uint8_t> data_;
    kvmem::SnapshotWriter* stream_ = nullptr;
    bool sizing_ = false;
    bool finished_ = false;
    std::uint64_t size_ = 0;
    std::uint64_t hash_ = 14695981039346656037ull;
};

class KVMemParkedSnapshotReader final {
public:
    explicit KVMemParkedSnapshotReader(std::span<const std::uint8_t> bytes) : bytes_(bytes) {}
    explicit KVMemParkedSnapshotReader(kvmem::SnapshotReader& stream)
        : stream_(&stream), stream_bytes_(stream.remaining()) {
        // The factories supply a fresh reader for this exact archive. Native
        // exposes no consumed-byte accessor; never borrow a containing reader
        // whose checksum scope began before this archive.
        if (stream.hash() != 14695981039346656037ULL) {
            throw std::invalid_argument("KVMem parked snapshot requires a fresh native reader");
        }
    }

    [[nodiscard]] std::uint8_t u8() { return integer<std::uint8_t>(); }
    [[nodiscard]] std::uint32_t u32() { return integer<std::uint32_t>(); }
    [[nodiscard]] std::uint64_t u64() { return integer<std::uint64_t>(); }
    [[nodiscard]] std::int32_t i32() { return std::bit_cast<std::int32_t>(u32()); }
    [[nodiscard]] std::int64_t i64() { return std::bit_cast<std::int64_t>(u64()); }
    [[nodiscard]] float f32() { return std::bit_cast<float>(u32()); }
    [[nodiscard]] double f64() { return std::bit_cast<double>(u64()); }

    [[nodiscard]] bool boolean() {
        const std::uint8_t value = u8();
        if (value > 1) { throw kvmem::SnapshotCorrupt("invalid KVMem parked snapshot boolean"); }
        return value != 0;
    }

    [[nodiscard]] std::string string() {
        const std::uint64_t count = u64();
        if (count > kKVMemParkedSnapshotMaxStringBytes || count > remaining()) {
            throw kvmem::SnapshotCorrupt("invalid KVMem parked snapshot string length");
        }
        const auto source = read_bytes(static_cast<std::size_t>(count));
        return std::string(reinterpret_cast<const char*>(source.data()), source.size());
    }

    [[nodiscard]] std::span<const std::uint8_t> read_bytes(std::size_t count) {
        if (count > remaining()) {
            throw kvmem::SnapshotCorrupt("truncated KVMem parked snapshot");
        }
        if (stream_ != nullptr) {
            scratch_.resize(count);
            read_into(scratch_.data(), count);
            return scratch_;
        }
        const auto out = bytes_.subspan(cursor_, count);
        read_into(nullptr, count);
        return out;
    }

    void read_into(void* destination, std::size_t count) {
        if (finished_) { throw std::logic_error("KVMem parked snapshot already finished"); }
        if (count > remaining()) { throw kvmem::SnapshotCorrupt("truncated KVMem parked snapshot"); }
        if (stream_ != nullptr) {
            // The native stream owns this exact body hash; do not walk a
            // second time over each packed block or drained Raw chunk.
            stream_->read(destination, count);
        } else {
            const auto source = bytes_.subspan(cursor_, count);
            if (destination != nullptr && count != 0) {
                std::memcpy(destination, source.data(), count);
            }
            update_hash(source);
        }
        cursor_ += count;
    }

    void skip(std::uint64_t count) {
        std::array<std::uint8_t, 64 * 1024> buffer{};
        if (count > remaining()) { throw kvmem::SnapshotCorrupt("truncated KVMem parked snapshot"); }
        while (count != 0) {
            const auto part = static_cast<std::size_t>(std::min<std::uint64_t>(count, buffer.size()));
            read_into(buffer.data(), part);
            count -= part;
        }
    }

    [[nodiscard]] std::span<const std::uint8_t> blob() {
        const std::uint64_t count = u64();
        if (count > remaining() || count > std::numeric_limits<std::size_t>::max()) {
            throw kvmem::SnapshotCorrupt("invalid KVMem parked snapshot blob length");
        }
        return read_bytes(static_cast<std::size_t>(count));
    }

    [[nodiscard]] std::uint64_t trailer_u64() {
        if (finished_) { throw std::logic_error("KVMem parked snapshot already finished"); }
        if (remaining() < sizeof(std::uint64_t)) {
            throw kvmem::SnapshotCorrupt("truncated KVMem parked snapshot checksum");
        }
        const auto body_hash = hash();
        std::array<std::uint8_t, sizeof(std::uint64_t)> encoded{};
        if (stream_ != nullptr) { stream_->read(encoded.data(), encoded.size()); }
        else { std::memcpy(encoded.data(), bytes_.data() + cursor_, encoded.size()); }
        cursor_ += encoded.size();
        hash_ = body_hash;
        finished_ = true;
        std::uint64_t value = 0;
        for (unsigned i = 0; i < sizeof(value); ++i) {
            value |= static_cast<std::uint64_t>(encoded[i]) << (8U * i);
        }
        return value;
    }

    [[nodiscard]] std::size_t remaining() const noexcept {
        return static_cast<std::size_t>((stream_ != nullptr ? stream_bytes_ : bytes_.size()) - cursor_);
    }
    [[nodiscard]] std::uint64_t hash() const noexcept {
        return stream_ != nullptr && !finished_ ? stream_->hash() : hash_;
    }

private:
    template <class U>
    [[nodiscard]] U integer() {
        static_assert(std::is_unsigned_v<U>);
        const auto encoded = read_bytes(sizeof(U));
        U value = 0;
        for (std::size_t i = 0; i < encoded.size(); ++i) {
            value |= static_cast<U>(encoded[i]) << (8U * i);
        }
        return value;
    }

    void update_hash(std::span<const std::uint8_t> bytes) noexcept {
        for (const std::uint8_t byte : bytes) {
            hash_ = (hash_ ^ byte) * 1099511628211ull;
        }
    }

    std::span<const std::uint8_t> bytes_;
    kvmem::SnapshotReader* stream_ = nullptr;
    std::uint64_t stream_bytes_ = 0;
    std::vector<std::uint8_t> scratch_;
    std::size_t cursor_ = 0;
    bool finished_ = false;
    std::uint64_t hash_ = 14695981039346656037ull;
};

} // namespace ninfer::models::qwen3_5::detail
