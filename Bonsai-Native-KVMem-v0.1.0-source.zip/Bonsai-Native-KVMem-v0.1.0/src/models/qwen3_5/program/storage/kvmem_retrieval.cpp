// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
//
// Derived from KVMem-qw3 / kvmem-llama.cpp, pinned commit
// 95a2155b75f41eada1398c86b19dcf9703581b30:
//   third_party/kvmem/src/adapter/llama-memory-kvmem.cpp
//   llama_memory_kvmem::score_retrieval, with input semantics
//   from its constructor and harvest_from_host/harvest_capture.
// K means are provided directly by the unmodified native implementation:
//   third_party/kvmem/kvmem/src/host/raw_kv_store.cpp
//   RawKvStore::add_mean_f32, write_layer_mean_k and mean_k.
//
// Modification notice: extracted the native scoring loop into a NInfer host
// adapter with borrowed query views, explicit geometry validation and a score
// return value in place of store.set_retrieval_scores. Query-only GQA means
// and norms are prepared once per call, preserving their native FP32 order;
// they are not cached across queries. No selection policy.
// The pinned upstream README "License" declares this source Apache-2.0
// (no standalone upstream LICENSE/NOTICE accompanies this adapter source).
// A copy of Apache License 2.0 is provided in this repository's root LICENSE.
// Licensed under the Apache License, Version 2.0 (the "License"); you may not
// use this file except in compliance with the License. You may obtain a copy at
// https://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
// WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations.

#include "models/qwen3_5/program/storage/kvmem_retrieval.h"

#include <kvmem/raw_kv_store.hpp>

#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>

namespace ninfer::models::qwen3_5::detail {

std::vector<double> score_kvmem_retrieval(
    const kvmem::RawKvStore& raw, std::uint32_t block_count,
    KVMemRetrievalGeometry geometry, std::span<const KVMemRetrievalQueryLayer> queries) {
    const auto& config = raw.config();
    const auto [n_embd_head, n_head, n_head_kv] = geometry;

    // NInfer adapter validation, not upstream's permissive geometry guards.
    // Only well-formed, uniform MHA/GQA geometry enters the native arithmetic.
    if (n_embd_head == 0 || n_head == 0 || n_head_kv == 0 ||
        n_head % n_head_kv != 0 || config.n_layer == 0 || config.block_tokens == 0 ||
        queries.size() != config.n_layer ||
        std::uint64_t{n_embd_head} * n_head_kv != config.n_embd_k) {
        throw std::invalid_argument("KVMem retrieval geometry does not match RawKvStore");
    }
    const std::uint64_t query_width = std::uint64_t{n_embd_head} * n_head;
    if (query_width > std::numeric_limits<std::uint32_t>::max()) {
        throw std::invalid_argument("KVMem retrieval query geometry exceeds native indexing");
    }
    const std::uint32_t g = n_head / n_head_kv;
    for (const auto& query : queries) {
        if (query.pre_rope_sum.size() != query_width &&
            !(query.count == 0 && query.pre_rope_sum.empty())) {
            throw std::invalid_argument("KVMem retrieval requires one sum per original Q head");
        }
        if (query.count > std::numeric_limits<std::uint32_t>::max() / g) {
            throw std::invalid_argument("KVMem retrieval count times GQA group overflows");
        }
    }

    std::vector<double> scores(block_count, 0.0);
    if (block_count == 0) { return scores; }

    // Q is the same for every historical block. Preserve the native ordered
    // FP32 group sum, reciprocal multiply and squared-norm reduction, but do
    // them once instead of allocating/reducing one Q head per block. Keep
    // this preparation call-local so a changed Q/count can never reuse it.
    struct PreparedQueryLayer {
        std::uint32_t native_layer;
        std::vector<float> means;
        std::vector<float> norms;
    };
    std::vector<PreparedQueryLayer> prepared;
    prepared.reserve(queries.size());
    for (std::uint32_t il = 0; il < config.n_layer; ++il) {
        const auto& query = queries[il];
        if (query.count == 0) { continue; }
        auto& layer = prepared.emplace_back();
        layer.native_layer = il;
        layer.means.assign(config.n_embd_k, 0.0f);
        layer.norms.resize(n_head_kv);
        const float invq = 1.0f / static_cast<float>(query.count * std::max(1u, g));
        for (std::uint32_t h = 0; h < n_head_kv; ++h) {
            float* qh = layer.means.data() + h * n_embd_head;
            for (std::uint32_t gi = 0; gi < g; ++gi) {
                const float* q = query.pre_rope_sum.data() +
                                 (h * g + gi) * n_embd_head;
                for (std::uint32_t d = 0; d < n_embd_head; ++d) {
                    qh[d] += q[d];
                }
            }
            float nq = 0;
            for (std::uint32_t d = 0; d < n_embd_head; ++d) {
                const float qv = qh[d] * invq;
                qh[d] = qv;
                nq += qv * qv;
            }
            layer.norms[h] = std::sqrt(nq);
        }
    }
    if (prepared.empty()) { return scores; }

    // Native scoring precision: ordered FP32 dot/K-norm/epsilon, followed by
    // FP64 head and available-Q-layer reductions. Missing K still contributes
    // a zero score to that layer's average. Neither a concatenated-vector
    // cosine nor an average of individual Q-head cosines is equivalent.
    std::vector<float> mk(config.n_embd_k, 0.0f);
    for (std::uint32_t b = 0; b < block_count; ++b) {
        if (!raw.has_block(b)) { continue; }
        double acc = 0;
        for (const auto& query : prepared) {
            raw.mean_k(b, query.native_layer, mk.data());
            double layer = 0;
            for (std::uint32_t h = 0; h < n_head_kv; ++h) {
                const float* qh = query.means.data() + h * n_embd_head;
                const float* kh = mk.data() + h * n_embd_head;
                float dot = 0, nk = 0;
                for (std::uint32_t d = 0; d < n_embd_head; ++d) {
                    const float qv = qh[d];
                    dot += qv * kh[d];
                    nk += kh[d] * kh[d];
                }
                layer += dot / (query.norms[h] * std::sqrt(nk) + 1e-6f);
            }
            acc += layer / static_cast<double>(std::max(1u, n_head_kv));
        }
        scores[b] = acc / static_cast<double>(prepared.size());
    }
    return scores;
}

} // namespace ninfer::models::qwen3_5::detail
