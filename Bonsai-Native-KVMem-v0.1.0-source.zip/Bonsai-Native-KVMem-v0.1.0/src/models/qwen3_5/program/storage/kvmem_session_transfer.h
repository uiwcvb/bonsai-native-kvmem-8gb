// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <span>
#include <stdexcept>
#include <vector>

namespace ninfer::models::qwen3_5::detail {

// Adapted from the pinned tools/kvmem-session-cache.h::session_balance and
// tools/kvmem-session-transfer.h::kvmem_plan_session_transfer. The unchanged
// Runtime owns a private CPU arena and remains an indivisible transfer unit.
// Raw/follower units are the unchanged native SnapshotBuffer chunk manifest:
// payload size, actual released capacity, and restore scratch are distinct.
// Input order is ResourceManager's authorized idle LRU; target/active owners
// are structurally absent. Planning never writes, deletes, allocates KV or
// evicts. In particular, a temporary-space failure cannot cause eviction.
inline constexpr std::uint32_t kKVMemRuntimeTransferUnit = UINT32_MAX;

struct KVMemSessionTransferUnit {
    std::uint32_t index = kKVMemRuntimeTransferUnit;
    std::uint64_t released_ram = 0;
    std::uint64_t disk_bytes = 0;
    std::uint64_t spill_bytes = 0;
    std::uint64_t spill_scratch = 0;
    std::uint64_t restore_bytes = 0;
    std::uint64_t restore_peak = 0;
    bool resident = true;
};

struct KVMemSessionTransferItem {
    std::size_t ordinal = 0;
    std::uint64_t ram_bytes = 0;
    std::uint64_t released_ram = 0;
    std::uint64_t disk_bytes = 0;
    std::uint64_t spill_bytes = 0;
    std::uint64_t spill_scratch = 0;
    std::uint64_t restore_bytes = 0;
    std::uint64_t restore_peak = 0;
    std::vector<KVMemSessionTransferUnit> units;
};

struct KVMemSessionTransferBudget {
    std::uint64_t ram_used = 0;
    std::uint64_t ram_soft_limit = 0;
    std::uint64_t ram_available = 0;
    std::uint64_t disk_used = 0;
    std::uint64_t disk_limit = 0;
    // Physical filesystem headroom is not a reduction of the configured quota.
    // Only tracked-file deletion credits it; planned writes consume it.
    std::uint64_t disk_available = 0;
};

// A selected cold archive must be reconstructed to run the request. Hot/fresh
// requests only attempt optional retention, so physical-space pressure alone
// must not destroy their cached owners. The caller owns that distinction.
enum class KVMemSessionTransferPurpose : std::uint8_t { OptionalRetention, RequiredRestore };

struct KVMemSessionTransferMove {
    std::size_t ordinal = 0;
    bool restore = false;
    std::uint32_t unit = kKVMemRuntimeTransferUnit;
    std::uint64_t required_ram = 0;
};

struct KVMemSessionTransferPlan {
    enum class Path { DiskFirst, RamFirst, Exchange };
    Path path = Path::DiskFirst;
    std::vector<std::size_t> evictions;
    std::vector<KVMemSessionTransferMove> moves;
    std::uint64_t peak_disk = 0;
    std::uint64_t final_disk = 0;
};

inline std::uint64_t kvmem_session_checked_add(std::uint64_t a, std::uint64_t b) {
    if (b > (std::numeric_limits<std::uint64_t>::max)() - a) {
        throw std::overflow_error("native session transfer byte count overflow");
    }
    return a + b;
}

inline KVMemSessionTransferPlan plan_kvmem_session_transfer(
    KVMemSessionTransferBudget budget,
    const std::optional<KVMemSessionTransferItem>& incoming,
    std::span<const KVMemSessionTransferItem> idle_lru,
    KVMemSessionTransferPurpose purpose) {
    const auto add = kvmem_session_checked_add;
    if (purpose == KVMemSessionTransferPurpose::RequiredRestore && !incoming) {
        throw std::logic_error("required native restore has no selected archive");
    }
    if (budget.disk_used > budget.disk_limit ||
        (incoming && (incoming->disk_bytes > budget.disk_used ||
                      incoming->restore_peak < incoming->restore_bytes))) {
        throw std::runtime_error("native session disk/headroom state changed before transfer");
    }
    const auto validate_units = [&](const KVMemSessionTransferItem& item, bool target) {
        if (item.units.empty()) { return; } // RAM-only/empty-destination whole unit.
        std::uint64_t disk = 0, released = 0, writes = 0, restores = 0;
        std::uint64_t scratch = 0;
        for (const auto& unit : item.units) {
            if (unit.restore_peak < unit.restore_bytes ||
                (unit.resident && unit.restore_bytes) ||
                (!unit.resident && (unit.released_ram || unit.spill_bytes))) {
                throw std::logic_error("native session unit ownership is inconsistent");
            }
            disk = add(disk, unit.disk_bytes);
            released = add(released, unit.released_ram);
            writes = add(writes, unit.spill_bytes);
            restores = add(restores, unit.restore_bytes);
            scratch = std::max(scratch, unit.restore_peak - unit.restore_bytes);
        }
        if (disk != item.disk_bytes || (target
            ? (restores != item.restore_bytes || add(restores, scratch) > item.restore_peak)
            : (released != item.released_ram || writes != item.spill_bytes ||
               released > item.ram_bytes))) {
            throw std::logic_error("native session aggregate footprint is inconsistent");
        }
    };
    if (incoming) { validate_units(*incoming, true); }
    std::uint64_t known_disk = incoming ? incoming->disk_bytes : 0;
    for (const auto& item : idle_lru) {
        validate_units(item, false);
        known_disk = add(known_disk, item.disk_bytes);
    }
    if (known_disk > budget.disk_used) {
        throw std::logic_error("native session charged-file ownership is inconsistent");
    }
    std::uint64_t projected = add(budget.ram_used, incoming ? incoming->restore_bytes : 0);
    std::uint64_t freed_ram = 0;
    std::vector<bool> spill(idle_lru.size());
    for (std::size_t i = 0; i < idle_lru.size(); ++i) {
        const bool soft_pressure = budget.ram_soft_limit && projected > budget.ram_soft_limit;
        const bool restore_pressure = incoming &&
            incoming->restore_peak > add(budget.ram_available, freed_ram);
        if (!soft_pressure && !restore_pressure) { break; }
        const auto& item = idle_lru[i];
        if (!item.released_ram) { continue; }
        if (item.released_ram > item.ram_bytes) {
            throw std::logic_error("native session spill manifest is inconsistent");
        }
        projected -= std::min(projected, item.released_ram);
        freed_ram = add(freed_ram, item.released_ram);
        spill[i] = true;
    }

    KVMemSessionTransferPlan result;
    std::uint64_t final_disk = budget.disk_used - (incoming ? incoming->disk_bytes : 0);
    for (std::size_t i = 0; i < idle_lru.size(); ++i) {
        if (spill[i]) { final_disk = add(final_disk, idle_lru[i].spill_bytes); }
    }
    // Native session_balance also bounds FINAL placement by charged bytes plus
    // actual filesystem headroom. Keep quota and transient ledgers independent:
    // a required reconstruction may reclaim authorized idle files for a true
    // final physical deficit, but optional retention still preserves its owners.
    // A fully resident target with only duplicate cleanup needs no new payload.
    auto final_disk_limit = budget.disk_limit;
    if (purpose == KVMemSessionTransferPurpose::RequiredRestore &&
        incoming->restore_bytes != 0 &&
        budget.disk_available < budget.disk_limit - budget.disk_used) {
        final_disk_limit = budget.disk_used + budget.disk_available;
    }
    // A restore credits its actual charged file; spill-first being temporarily
    // full is not a final-capacity deficit and cannot select additional victims.
    for (std::size_t i = 0; i < idle_lru.size() && final_disk > final_disk_limit; ++i) {
        const auto& item = idle_lru[i];
        const auto saved = add(item.disk_bytes, spill[i] ? item.spill_bytes : 0);
        if (!saved) { continue; }
        if (saved > final_disk || item.disk_bytes > budget.disk_used) {
            throw std::logic_error("native session eviction manifest is inconsistent");
        }
        final_disk -= saved;
        budget.disk_used -= item.disk_bytes;
        budget.disk_available = add(budget.disk_available, item.disk_bytes);
        budget.ram_available = add(budget.ram_available, item.ram_bytes);
        spill[i] = false;
        result.evictions.push_back(item.ordinal);
    }
    if (final_disk > final_disk_limit) {
        throw std::runtime_error("cannot free final native session disk capacity");
    }

    std::uint64_t write_disk = 0;
    for (std::size_t i = 0; i < idle_lru.size(); ++i) {
        if (spill[i]) { write_disk = add(write_disk, idle_lru[i].spill_bytes); }
    }
    result.path = write_disk <= budget.disk_limit - budget.disk_used &&
                  write_disk <= budget.disk_available
        ? KVMemSessionTransferPlan::Path::DiskFirst
        : (!incoming || incoming->restore_peak <= budget.ram_available)
            ? KVMemSessionTransferPlan::Path::RamFirst
            : KVMemSessionTransferPlan::Path::Exchange;
    result.peak_disk = budget.disk_used;
    result.final_disk = final_disk;
    struct Pending {
        KVMemSessionTransferMove move;
        KVMemSessionTransferUnit footprint;
        bool done = false;
    };
    std::vector<Pending> reads, writes_pending;
    const auto append = [&](const KVMemSessionTransferItem& item, bool restore,
                            std::vector<Pending>& pending) {
        const auto put = [&](KVMemSessionTransferUnit unit) {
            if (restore ? (!unit.resident || unit.disk_bytes != 0)
                        : (unit.resident && unit.released_ram != 0)) {
                pending.push_back({{item.ordinal, restore, unit.index,
                    restore ? unit.restore_peak : unit.spill_scratch}, unit});
            }
        };
        if (item.units.empty()) {
            put({.released_ram = item.released_ram, .disk_bytes = item.disk_bytes,
                 .spill_bytes = item.spill_bytes, .spill_scratch = item.spill_scratch,
                 .restore_bytes = item.restore_bytes, .restore_peak = item.restore_peak,
                 .resident = !restore});
        } else {
            for (const auto& unit : item.units) { put(unit); }
        }
    };
    if (incoming) { append(*incoming, true, reads); }
    for (std::size_t i = 0; i < idle_lru.size(); ++i) {
        if (spill[i]) { append(idle_lru[i], false, writes_pending); }
    }
    const auto schedule = [&](std::vector<Pending>& pending, bool restore) {
        bool progress = false;
        for (auto& entry : pending) {
            const auto& unit = entry.footprint;
            if (entry.done || (restore ? unit.restore_peak > budget.ram_available
                : (unit.spill_bytes > budget.disk_limit - budget.disk_used ||
                   unit.spill_bytes > budget.disk_available ||
                   unit.spill_scratch > budget.ram_available))) { continue; }
            result.moves.push_back(entry.move);
            if (restore) {
                if (unit.restore_bytes > budget.ram_available || unit.disk_bytes > budget.disk_used) {
                    throw std::logic_error("native session move ledger underflow");
                }
                budget.ram_available -= unit.restore_bytes;
                budget.disk_used -= unit.disk_bytes;
                budget.disk_available = add(budget.disk_available, unit.disk_bytes);
            } else {
                budget.disk_used = add(budget.disk_used, unit.spill_bytes);
                budget.disk_available -= unit.spill_bytes;
                budget.ram_available = add(budget.ram_available, unit.released_ram);
                result.peak_disk = std::max(result.peak_disk, budget.disk_used);
            }
            entry.done = true;
            progress = true;
        }
        return progress;
    };
    const auto restore = [&] {
        return schedule(reads, true);
    };
    const auto writes = [&] {
        return schedule(writes_pending, false);
    };
    const auto pending = [&] {
        return std::any_of(reads.begin(), reads.end(), [](const auto& p) { return !p.done; }) ||
               std::any_of(writes_pending.begin(), writes_pending.end(),
                           [](const auto& p) { return !p.done; });
    };
    while (pending()) {
        bool progress = false;
        if (result.path == KVMemSessionTransferPlan::Path::RamFirst) {
            progress = restore();
            progress = writes() || progress;
        } else {
            progress = writes();
            progress = restore() || progress;
        }
        if (!progress) {
            throw std::runtime_error(
                "insufficient temporary RAM/disk for native session exchange; caches retained");
        }
    }
    return result;
}

// Optional public-slot captures may have occupied filesystem space after the
// first plan. Reuse the same native-derived planner with live headroom, but
// never let those captures authorize another cached-owner deletion.
inline KVMemSessionTransferPlan replan_kvmem_session_transfer_after_capture(
    KVMemSessionTransferBudget budget,
    const std::optional<KVMemSessionTransferItem>& incoming,
    std::span<const KVMemSessionTransferItem> idle_lru,
    KVMemSessionTransferPurpose purpose,
    std::span<const std::size_t> authorized_evictions) {
    auto plan = plan_kvmem_session_transfer(budget, incoming, idle_lru, purpose);
    for (const auto ordinal : plan.evictions) {
        if (std::find(authorized_evictions.begin(), authorized_evictions.end(), ordinal) ==
            authorized_evictions.end()) {
            throw std::runtime_error(
                "optional snapshot capture requires additional native cache eviction");
        }
    }
    return plan;
}

} // namespace ninfer::models::qwen3_5::detail
