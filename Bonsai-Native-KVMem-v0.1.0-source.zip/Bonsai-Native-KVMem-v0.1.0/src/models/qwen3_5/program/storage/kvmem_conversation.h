// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <kvmem/kvmem_runtime.hpp>
#include <kvmem/raw_kv_store.hpp>

#include "models/qwen3_5/frontend/prepared_prompt.h"
#include "models/qwen3_5/program/storage/kvmem_session_transfer.h"

#include <array>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <stdexcept>
#include <utility>
#include <vector>

namespace kvmem {
class SnapshotWriter;
class SnapshotReader;
}

namespace ninfer::models::qwen3_5::detail {

class KVMemPageBackend;
class KVMemParkedFileCache;
class KVMemParkedSnapshotFile;
class KVMemFrozenRaw;
class KVMemQueryBoundaryCheckpoint;
struct KVMemRetrievalGeometry;

// Match Native's query_max_tokens suffix cap while retaining the source user origin.
[[nodiscard]] RetrievalQuerySpan clamp_native_query_span(
    const RetrievalQuerySpan& query, std::uint32_t query_max_tokens);

// Emitted by byte-budget/allocation preflight before snapshot tier movement.
// Callers may preserve the parked owner on this failure, unlike a transfer error.
class KVMemSnapshotPreflightError final : public std::length_error {
public:
    using std::length_error::length_error;
};

// Optional file migration failed with the authoritative archive still owned;
// completed chunks may now have mixed RAM/disk residency.
class KVMemSnapshotStorageError : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};

// The source archive is corrupt, but its owner remains available for explicit
// invalidation/retirement after any temporary GPU state has been cleaned up.
class KVMemSnapshotCorruptError final : public KVMemSnapshotStorageError {
public:
    using KVMemSnapshotStorageError::KVMemSnapshotStorageError;
};

// One conversation's native host archive, optional follower mirror, and block
// table. This class can drain resident blocks to host, then park, restore, or
// exchange those owners. It does not synchronize outstanding device work; the
// caller must quiesce Program work and detach its KV views through the drain
// callback. The follower mirror is host-side ownership; Program hooks stage
// its GPU pages at the native target movement boundaries.
//
// Draining requires no Program work can still access this conversation; the
// supplied callback releases all of its KVMem KV views after target spill. The
// implementation checks the runtime/backend state it can observe and waits
// for RawKvStore writes. A parked conversation contains host-side KVMem state
// only; restoring it does not stage blocks back to GPU or rebuild KV views.
//
// The Program-owned backend must outlive this object and every Parked handle
// originating from it. Operations are externally serialized with Program use.
class KVMemConversation final {
public:
    // Source-compatible representation of llama_memory_kvmem::RowPosition:
    // llama_pos and llama_token are both int32_t in the pinned adapter.
    struct RowPosition {
        std::array<std::int32_t, 4> pos{};
        std::int32_t token = -1;
        bool spatial = false;
    };

    // Per-conversation fields that accompany the runtime/raw owner bundle
    // through detach/attach and the local park/restore/swap/retire paths.
    struct SessionMetadata {
        bool cold = false;
        std::vector<RowPosition> row_positions;
        std::vector<std::vector<float>> q_sum;
        std::vector<std::uint32_t> q_count;
        // Exact user origin and Native-capped Q range that produced q_sum/q_count.
        // A suffix probe clears the flag; begin=0 remains a valid query frontier.
        bool exact_query_valid = false;
        std::uint32_t exact_query_user_begin = 0;
        std::uint32_t exact_query_begin = 0;
        std::uint32_t exact_query_end = 0;
        // Immutable identity of every media item in the Q-producing prompt,
        // including tool observations after that user. No pixel payloads.
        // Rewinding token/KV state does not truncate this source identity.
        std::vector<VisionItem> exact_query_media;
        // GPU-resident block ids captured before the native detach drains them.
        std::vector<std::uint32_t> prior_resident_block_ids;

        [[nodiscard]] bool empty() const noexcept {
            return !cold && row_positions.empty() && q_sum.empty() && q_count.empty() &&
                   !exact_query_valid && exact_query_user_begin == 0 &&
                   exact_query_begin == 0 && exact_query_end == 0 && exact_query_media.empty() &&
                   prior_resident_block_ids.empty();
        }

        // The caller separately licenses the exact token/position prefix at base.
        [[nodiscard]] bool matches_exact_query(const PreparedPromptData& prompt,
                                               std::uint32_t base,
                                               std::uint32_t query_max_tokens) const;

        void clear() noexcept {
            cold = false;
            row_positions.clear();
            q_sum.clear();
            q_count.clear();
            exact_query_valid = false;
            exact_query_user_begin = 0;
            exact_query_begin = 0;
            exact_query_end = 0;
            exact_query_media.clear();
            prior_resident_block_ids.clear();
        }

        void swap(SessionMetadata& other) noexcept {
            using std::swap;
            swap(cold, other.cold);
            row_positions.swap(other.row_positions);
            q_sum.swap(other.q_sum);
            q_count.swap(other.q_count);
            swap(exact_query_valid, other.exact_query_valid);
            swap(exact_query_user_begin, other.exact_query_user_begin);
            swap(exact_query_begin, other.exact_query_begin);
            swap(exact_query_end, other.exact_query_end);
            exact_query_media.swap(other.exact_query_media);
            prior_resident_block_ids.swap(other.prior_resident_block_ids);
        }
    };

    struct AppendPlan {
        std::uint32_t old_frontier = 0;
        std::uint32_t new_frontier = 0;
        std::uint32_t prior_tail_tokens = 0;
        std::vector<std::uint32_t> incoming_blocks;
        bool pressure = false;
    };

    // Program supplies the MTP GPU-page ownership transaction. The first hook
    // receives the outgoing target IDs and the full pre-spill Store; it must
    // preserve every follower page that its view detachment will release,
    // including still-selected pages if Program cannot retain them. The second
    // hook follows the settled target slot assignment. Native Store/RawKvStore
    // remain this conversation's sole history owner.
    struct FollowerTransition {
        std::function<void(std::span<const std::uint32_t>, const kvmem::KvMemStore&,
                           kvmem::RawKvStore&)> before_target_spill;
        std::function<void(const kvmem::KvMemStore&, kvmem::RawKvStore&)> after_target_admit;
    };

    struct QuerySelectionPreview {
        std::uint32_t logical_rows = 0;
        std::vector<std::uint32_t> resident_blocks;
        std::vector<std::uint32_t> selected_blocks;
        std::vector<std::uint32_t> mandatory_blocks;
        std::vector<std::uint32_t> replay_blocks;
        // Physical cache coordinates for replaying [replay_begin,logical_rows)
        // after compacting the selected original-order blocks. Invalid unless
        // replay_fits is true; the Store's logical positions remain unchanged.
        std::uint32_t replay_compact_begin = 0;
        std::uint32_t replay_compact_end = 0;
        bool replay_fits = false;
    };

    class Parked final {
    public:
        Parked() noexcept;
        Parked(const Parked&) = delete;
        Parked& operator=(const Parked&) = delete;
        Parked(Parked&& other) noexcept;
        ~Parked() noexcept;
        // Reassigning over a live handle would silently discard that session.
        Parked& operator=(Parked&& other) = delete;

        [[nodiscard]] bool empty() const noexcept {
            return backend_ == nullptr && runtime_ == nullptr && raw_ == nullptr &&
                   follower_raw_ == nullptr && compact_snapshot_.empty() &&
                   compact_file_ == nullptr && frozen_raw_ == nullptr &&
                   metadata_.empty() && !transition_failed_;
        }

        [[nodiscard]] bool compacted() const noexcept {
            return !compact_snapshot_.empty() || compact_file_ != nullptr || frozen_raw_ != nullptr;
        }
        [[nodiscard]] bool snapshot_requires_gpu() const noexcept { return runtime_ != nullptr; }
        [[nodiscard]] bool transition_failed() const noexcept { return transition_failed_; }
        [[nodiscard]] bool reusable() const noexcept;
        void invalidate_for_eviction() noexcept;
        [[nodiscard]] std::uint64_t ram_bytes() const;
        [[nodiscard]] std::uint64_t released_ram_bytes() const;
        [[nodiscard]] std::uint64_t disk_bytes() const noexcept;
        [[nodiscard]] std::uint64_t restore_bytes() const noexcept;
        [[nodiscard]] std::uint64_t restore_peak_bytes() const;
        [[nodiscard]] std::uint64_t spill_scratch_bytes() const;
        // Freeze actual native Raw/follower and associated recurrent vectors,
        // not a serialized copy. Checkpoint storage is pinned by the manifest.
        void freeze_for_transfer(KVMemParkedFileCache& files, std::uint32_t query_width,
            std::span<const std::shared_ptr<const KVMemQueryBoundaryCheckpoint>> checkpoints = {});
        // Body-only output; the v6 caller owns its unchanged count/framing.
        void write_checkpoint_image(const KVMemQueryBoundaryCheckpoint& checkpoint,
                                    const std::function<void(const void*, std::size_t)>& sink) const;
        void write_checkpoint_tail_mean(const KVMemQueryBoundaryCheckpoint& checkpoint,
                                        const std::function<void(const void*, std::size_t)>& sink) const;
        // Retry removal of unfinished, non-authoritative native files while
        // their Raw allocations remain resident, before measuring a new plan.
        void prepare_transfer();
        [[nodiscard]] std::vector<KVMemSessionTransferUnit> transfer_units(
            std::uint32_t query_width);
        void spill_transfer_unit(KVMemParkedFileCache& files, std::uint32_t unit,
                                 std::uint32_t query_width);
        void restore_transfer_unit(std::uint32_t unit,
                                   kvmem::KvMemRuntimeConfig runtime_config,
                                   kvmem::RawKvStoreConfig raw_config,
                                   std::optional<kvmem::RawKvStoreConfig> follower_config,
                                   std::uint32_t query_width);
        void validate_compact(kvmem::KvMemRuntimeConfig runtime_config,
                              kvmem::RawKvStoreConfig raw_config,
                              std::optional<kvmem::RawKvStoreConfig> follower_config,
                              std::uint32_t query_width) const;
        // A failed native deletion must never be mistaken for reclaimed quota.
        bool erase_file() noexcept;

        // Opt-in cold parking retains the existing canonical block archive and
        // drops the fixed-size native CPU arena. The complete output and writer
        // scratch must fit measured Host headroom, and the output must release
        // more owner RAM than it retains. Rebuild only at the next hit.
        void compact(std::uint32_t query_width, std::uint64_t available_host_bytes);
        // Native same-run file cache; no full-session serialization buffer.
        // Each Raw chunk / indivisible Runtime publishes before its release.
        void compact_to_file(KVMemParkedFileCache& files, std::uint32_t query_width);
        void materialize_compact(kvmem::KvMemRuntimeConfig runtime_config,
                                 kvmem::RawKvStoreConfig raw_config,
                                 std::optional<kvmem::RawKvStoreConfig> follower_config,
                                 std::uint32_t query_width,
                                 const std::function<void()>& prepare_destination = {},
                                 bool prevalidated = false);

        [[nodiscard]] std::uint32_t logical_tokens() const;
        [[nodiscard]] SessionMetadata& metadata();
        [[nodiscard]] const SessionMetadata& metadata() const;
        // Rewind a fully materialized, host-only archive. Retain the old
        // selection below the checkpoint and admit its partial final block
        // on the next restage. Caller owns recurrent state and logical identity.
        [[nodiscard]] std::uint32_t rewind_to(std::uint32_t frontier,
                                               const std::vector<float>& tail_mean);
        // The native Store has a media-range setter but no snapshot getter.
        // Program reconstructs these exact ranges from its serialized
        // structural VisionItem identity after restoring the block archive.
        void set_media_ranges(std::vector<std::pair<std::uint32_t, std::uint32_t>> ranges);

        // Retire only a quiescent host-only owner. Its private Runtime arena
        // and bookkeeping are destroyed together; native NVMe is prohibited
        // by this archive geometry, and all GPU slots are already released.
        void retire();

    private:
        friend class KVMemConversation;

        void write_checkpoint_part(const KVMemQueryBoundaryCheckpoint& checkpoint,
            bool tail_mean, const std::function<void(const void*, std::size_t)>& sink) const;

        KVMemPageBackend* backend_ = nullptr;
        std::unique_ptr<kvmem::KvMemRuntime> runtime_;
        std::unique_ptr<kvmem::RawKvStore> raw_;
        std::unique_ptr<kvmem::RawKvStore> follower_raw_;
        SessionMetadata metadata_;
        std::vector<std::uint8_t> compact_snapshot_;
        std::unique_ptr<KVMemParkedSnapshotFile> compact_file_;
        std::unique_ptr<KVMemFrozenRaw> frozen_raw_;
        std::uint64_t runtime_raw_insert_offset_ = 0;
        std::uint32_t compact_logical_tokens_ = 0;
        std::uint32_t compact_query_width_ = 0;
        // Trusted same-run sizing facts; not derived from file contents.
        std::uint64_t compact_restore_bytes_ = 0;
        // Logical cache invalidation; it does not alter physical ownership/health.
        bool cache_invalidated_ = false;
        bool transition_failed_ = false;
    };

    KVMemConversation(kvmem::KvMemRuntimeConfig runtime_config,
                       kvmem::RawKvStoreConfig raw_config,
                       KVMemPageBackend& backend,
                       std::optional<kvmem::RawKvStoreConfig> follower_raw_config = std::nullopt);

    KVMemConversation(const KVMemConversation&) = delete;
    KVMemConversation& operator=(const KVMemConversation&) = delete;
    KVMemConversation(KVMemConversation&&) = delete;
    KVMemConversation& operator=(KVMemConversation&&) = delete;

    [[nodiscard]] kvmem::KvMemRuntime& runtime();
    [[nodiscard]] const kvmem::KvMemRuntime& runtime() const;
    [[nodiscard]] kvmem::RawKvStore& raw();
    [[nodiscard]] const kvmem::RawKvStore& raw() const;
    // Nullable optional host mirror. It is transferred with this conversation;
    // Program callbacks perform the GPU staging during selection/pressure.
    [[nodiscard]] kvmem::RawKvStore* follower_raw();
    [[nodiscard]] const kvmem::RawKvStore* follower_raw() const;
    [[nodiscard]] SessionMetadata& metadata();
    [[nodiscard]] const SessionMetadata& metadata() const;
    [[nodiscard]] bool attached() const noexcept { return runtime_ != nullptr && raw_ != nullptr; }
    [[nodiscard]] std::uint64_t ram_bytes() const;
    // Measured once from the actual startup-created empty native bundle.
    [[nodiscard]] std::uint64_t empty_host_ram_bytes() const noexcept {
        return empty_host_ram_bytes_;
    }
    [[nodiscard]] const kvmem::KvMemRuntimeConfig& runtime_config() const noexcept {
        return runtime_config_;
    }
    [[nodiscard]] const kvmem::RawKvStoreConfig& raw_config() const noexcept { return raw_config_; }
    [[nodiscard]] const std::optional<kvmem::RawKvStoreConfig>& follower_config() const noexcept {
        return follower_config_;
    }
    // Recreate an empty, detached destination for a fresh owner or after a
    // retryable cold read failure. Available RAM is observed at the physical
    // request boundary, separately from optional retention's soft limit.
    // Insufficient headroom leaves the destination and retained source intact;
    // construction commits the owner pair only after all allocations.
    void ensure_empty_host_archive(std::uint64_t ram_available);

    // Discard a healthy owner after Program has drained GPU execution and
    // released its execution addresses. Reuse the fixed native Runtime arena,
    // as pinned reset_policy does; do not use this to recover a partial plan.
    void clear_for_fresh_owner();

    // Read-only prefill admission bound. Non-pinned first-pass prefill remains
    // governed by the native pressure high-watermark and previews the whole
    // incoming batch against Native's sink/media/mandatory selection. Pinned appends at an
    // aligned frontier use free whole native slots; pinned prefill at a partial
    // tail remains limited to completing its current block.
    [[nodiscard]] std::uint32_t prefill_append_limit(std::uint32_t requested_tokens,
                                                       std::uint32_t pool_tokens,
                                                       bool selection_pinned = false) const;

    // Read-only whole-slot bound for a full pinned append span. A settled
    // partial tail contributes its remaining tokens plus free whole slots.
    // Crossing that seam is for one speculative transaction whose caller owns
    // COW and all accepted completed blocks; ordinary pinned partial-tail
    // prefill remains seam-bounded by prefill_append_limit.
    [[nodiscard]] std::uint32_t pinned_append_limit(std::uint32_t requested_tokens,
                                                     std::uint32_t pool_tokens) const;

    // Native pressure for growth inside the current GPU tail, decided with the
    // same post-register resident count but applied before changing its length.
    // The tail is mandatory; Program publishes its current accepted pages,
    // applies spill/detach/admit and reinstalls a writable selected prefix.
    // Only afterward may plan_prefill_append(..., selection_pinned=true) grow
    // it. No future rows or new logical blocks exist during this transition.
    [[nodiscard]] bool prepare_partial_tail_pressure(std::uint32_t n_tokens,
                                                      std::uint32_t pool_tokens);

    // Source-aligned prepare_working_set half: register exact new token count
    // before forward, preserve a resident partial tail, and either reserve new
    // slot identities or leave a native pressure plan for apply_prefill_pressure.
    // `selection_pinned` preserves native retrieval-pinned selection, including
    // generation. Pinned full-span admission uses pinned_append_limit and skips
    // first-pass prefill pressure; unpinned batches retain native pressure rules.
    // Crossing a partial-tail seam is for one speculative transaction whose
    // caller owns COW and all-accepted-block publication. A returned plan is not
    // a committed KV write. Program owns the selected page-table view, forward,
    // page adoption, and accepted rollback.
    [[nodiscard]] AppendPlan plan_prefill_append(std::uint32_t n_tokens,
                                                  std::uint32_t pool_tokens,
                                                  bool selection_pinned);

    // Apply a prepared native prefill-pressure plan in the same order as the
    // pinned Bonsai adapter: spill outgoing bytes, detach every NInfer view of
    // those pages, then admit incoming blocks. The callback is Program-owned
    // and must not leave any selected/read-only/writer address reference to a
    // stage-out slot. Newly appended stage-in blocks reserve only a slot ID;
    // Program adopts their actual writer pages after forward. A throw after
    // spill is fail-stop for this request, not a retryable plan rollback.
    void apply_prefill_pressure(std::uint32_t pre_append_frontier,
                                const std::function<void()>& detach_execution_views,
                                const FollowerTransition& follower = {});

    // Native query selection policy after the first query pass: score the
    // captured pre-RoPE Q against archived mean-K, publish those scores to the
    // pinned Store, then ask its own top-K selector for a preview. This does
    // not stage blocks or alter the active attention view. Mandatory selection
    // and the suffix that would be replayed have independent boundaries.
    [[nodiscard]] QuerySelectionPreview preview_query_selection(
        KVMemRetrievalGeometry geometry, std::uint32_t mandatory_begin,
        std::uint32_t mandatory_end, std::uint32_t replay_begin);

    // Pinned multimodal server's pre-suffix cached-Q reselect preview. The
    // current Store ends at cached_frontier; [observed_begin,cached_frontier)
    // and an unfinished last block are mandatory. A caller with a deferred
    // MTP follower row also keeps the final cached block, even when full.
    // Future suffix/generation slots are counted separately from the native
    // history selector. Return no preview if any required block cannot fit;
    // tier movement occurs only when Program applies the returned preview.
    [[nodiscard]] std::optional<QuerySelectionPreview> preview_cached_query_selection(
        KVMemRetrievalGeometry geometry, std::uint32_t observed_begin,
        std::uint32_t suffix_end, std::uint32_t generation_rows,
        std::uint32_t physical_pool_tokens, bool require_deferred_tail);

    // Apply only the exact preview for the unchanged conversation frontier and
    // resident view. Returns false when the native Store can commit its already
    // resident selection without moving pages. force_rebind rebuilds only
    // the caller's execution view when the query crossed an earlier pressure
    // transition but the final selected IDs equal the current residents.
    // A changed selection follows pinned spill -> detach -> admit.
    [[nodiscard]] bool apply_query_selection(
        const QuerySelectionPreview& preview,
        const std::function<void()>& detach_execution_views,
        const FollowerTransition& follower = {}, bool force_rebind = false);

    // Drain every resident block to host before parking this conversation.
    // Saves the old resident ids in metadata, prepares an empty selection,
    // persists follower pages before target spill, releases the caller's old
    // execution views after spill, then admits the empty selection. A follower
    // after-admit hook runs after that admission. Successful return guarantees
    // no GPU or in-flight blocks remain; park() is still a separate operation.
    // Once the drain transition starts, any exception leaves this object
    // fail-stop and it cannot be retried or parked.
    void drain_resident_to_host(const std::function<void()>& detach_execution_views,
                                const FollowerTransition& follower = {});

    // Move the active owner pair into a host-only handle. The caller must first
    // quiesce Program/device work, release its KVMem KV views, and drain every
    // GPU-resident block with drain_resident_to_host(). Throws without moving
    // ownership if local checks fail.
    [[nodiscard]] Parked park();

    // Restore a host-only handle into an empty conversation object. The caller
    // remains responsible for preparing Program state; this does not stage-in.
    void restore(Parked&& parked);

    // Re-admit the exact target block IDs saved by drain_resident_to_host()
    // through this conversation's native Runtime and the same backend. This
    // does not build an NInfer execution view or stage the optional follower;
    // Program owns those later steps.
    [[nodiscard]] std::vector<std::uint32_t> restage_prior_resident();

    // Exchange the host archive owner bundle and all locally represented
    // per-conversation metadata. Program remains responsible for its own KV
    // views and for any GPU-side follower behavior.
    void swap_host_archive_with(Parked& parked);

    // Release an unused destination Runtime before reconstructing a compact
    // archive, avoiding two full logical-context CPU arenas at the cold hit.
    void release_empty_host_archive();

    // Self-contained, versioned host snapshot. The snapshot path temporarily
    // stages one logical block at a time through the native Runtime so the
    // packed page payload is retained independently of process-local tiers.
    // Row positions/query metadata survive this archive; Program rebuilds
    // native media ranges from its separately serialized VisionItem identity.
    // Size-only traversal never stages blocks or reads cold payloads. Streaming
    // writes one archive through a fresh native writer (outer envelopes use its
    // sink), avoiding a second complete archive vector at the Program caller.
    [[nodiscard]] static std::uint64_t snapshot_parked_size(
        Parked& archive, std::uint32_t query_width);
    static void snapshot_parked_write(Parked& archive, std::uint32_t query_width,
                                      kvmem::SnapshotWriter& stream);
    // Whole-vector ownership is still needed by in-RAM compact parking.
    [[nodiscard]] static std::vector<std::uint8_t> snapshot_parked(
        Parked& archive, std::uint32_t query_width);
    [[nodiscard]] static Parked restore_parked_snapshot(
        std::span<const std::uint8_t> bytes,
        kvmem::KvMemRuntimeConfig runtime_config,
        kvmem::RawKvStoreConfig raw_config,
        KVMemPageBackend& backend,
        std::optional<kvmem::RawKvStoreConfig> follower_config,
        std::uint32_t query_width,
        // Called after complete read-only validation, before constructing an
        // imported owner. Metadata is borrowed only for this call. Program may
        // check its ledger, park the old owner and release an empty placeholder.
        // The third argument is measured Raw allocation plus bounded import
        // scratch/metadata beyond empty_host_ram_bytes(), not a file-size proxy.
        const std::function<void(std::uint32_t, const SessionMetadata&, std::uint64_t)>& prepare_destination);

private:
    static void stream_parked_snapshot(Parked& archive, std::uint32_t query_width,
                                       kvmem::SnapshotWriter& stream, bool sizing);
    // A sizing pass never stages blocks or copies Raw payloads. The streamed
    // read first validates through a one-block Native Raw probe, without
    // constructing a complete owner or allocating a GPU slot.
    static void write_parked_snapshot(Parked& archive, std::uint32_t query_width,
                                      kvmem::SnapshotWriter& stream, bool sizing,
                                      bool external_raw = false);
    [[nodiscard]] static Parked read_parked_snapshot(
        kvmem::SnapshotReader& stream, kvmem::KvMemRuntimeConfig runtime_config,
        kvmem::RawKvStoreConfig raw_config, KVMemPageBackend& backend,
        std::optional<kvmem::RawKvStoreConfig> follower_config,
        std::uint32_t query_width, bool validation_only, bool external_raw = false,
        const std::function<void(std::uint32_t, const SessionMetadata&, std::uint64_t)>&
            prepare_destination = {});
    static void require_transferable(const KVMemPageBackend& backend,
                                     const kvmem::KvMemRuntime& runtime);
    static void require_metadata_transferable(const SessionMetadata& metadata,
                                              const kvmem::KvMemRuntime& runtime);
    void require_attached() const;

    KVMemPageBackend* backend_ = nullptr;
    kvmem::KvMemRuntimeConfig runtime_config_;
    kvmem::RawKvStoreConfig raw_config_;
    std::optional<kvmem::RawKvStoreConfig> follower_config_;
    std::unique_ptr<kvmem::KvMemRuntime> runtime_;
    std::unique_ptr<kvmem::RawKvStore> raw_;
    std::unique_ptr<kvmem::RawKvStore> follower_raw_;
    SessionMetadata metadata_;
    std::uint64_t empty_host_ram_bytes_ = 0;
    // A partially applied native transition cannot be rolled back safely.
    bool transition_failed_ = false;
};

} // namespace ninfer::models::qwen3_5::detail
