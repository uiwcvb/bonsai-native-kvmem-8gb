// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#include "models/qwen3_5/program/storage/kvmem_query_checkpoint.h"

#include "core/device.h"

#include <cstring>
#include <limits>
#include <stdexcept>
#include <utility>

namespace ninfer::models::qwen3_5::detail {
namespace {

std::size_t expected_tail_mean_size(std::uint32_t logical_frontier, std::uint32_t n_layer,
                                    std::uint32_t n_embd_k, std::uint32_t block_tokens) {
    if (block_tokens == 0) {
        throw std::invalid_argument(
            "KVMem query checkpoint requires a nonzero RawKvStore block size");
    }
    if (logical_frontier % block_tokens == 0) { return 0; }

    const std::size_t key_width = static_cast<std::size_t>(n_embd_k);
    if (key_width == std::numeric_limits<std::size_t>::max()) {
        throw std::invalid_argument("KVMem query checkpoint tail-mean geometry overflows");
    }
    const std::size_t per_layer = key_width + 1U;
    const std::size_t layers = static_cast<std::size_t>(n_layer);
    if (layers != 0 && per_layer > std::numeric_limits<std::size_t>::max() / layers) {
        throw std::invalid_argument("KVMem query checkpoint tail-mean geometry overflows");
    }
    return layers * per_layer;
}

} // namespace

KVMemQueryBoundaryCheckpoint::KVMemQueryBoundaryCheckpoint(
    std::shared_ptr<const Storage> storage, KVMemQueryBoundaryState state) noexcept
    : storage_(std::move(storage)), state_(state) {}

KVMemQueryBoundaryCheckpoint KVMemQueryBoundaryCheckpoint::capture(
    StateImageDevicePool& device_images, std::int32_t active_device_slot,
    kvmem::RawKvStore& raw_store, KVMemQueryBoundaryState state, cudaStream_t stream) {
    if (state.mtp_draft_count > state.mtp_draft_tokens.size()) {
        throw std::invalid_argument("KVMem query checkpoint MTP draft count is out of range");
    }
    const kvmem::RawKvStoreConfig& raw_config = raw_store.config();
    if (raw_config.block_tokens == 0) {
        throw std::invalid_argument("KVMem query checkpoint requires a nonzero RawKvStore block size");
    }

    raw_store.wait_writes();
    std::vector<float> tail_mean = raw_store.mean_checkpoint(state.logical_frontier);
    StateImageHostLayout state_image_layout = device_images.host_layout();
    std::vector<std::uint8_t> state_image(state_image_layout.image_bytes);
    if (state_image.empty()) {
        throw std::invalid_argument("KVMem query checkpoint requires a nonempty StateImage");
    }

    try {
        CUDA_CHECK(cudaStreamSynchronize(stream));
        device_images.copy_to_host(
            active_device_slot,
            HostStateImageView{.data = reinterpret_cast<std::byte*>(state_image.data()),
                               .layout = &state_image_layout},
            stream);
        CUDA_CHECK(cudaStreamSynchronize(stream));
    } catch (...) {
        // Keep the pageable destination alive until any partially enqueued D2H work drains.
        (void)cudaStreamSynchronize(stream);
        throw;
    }

    return KVMemQueryBoundaryCheckpoint(std::make_shared<const Storage>(Storage{
        .state_image_layout = std::move(state_image_layout),
        .state_image = std::move(state_image),
        .raw_mean_geometry = RawMeanGeometry{.n_layer = raw_config.n_layer,
                                             .n_embd_k = raw_config.n_embd_k,
                                             .block_tokens = raw_config.block_tokens},
        .tail_mean = std::move(tail_mean),
    }), state);
}

void KVMemQueryBoundaryCheckpoint::validate_host_image(
    HostStateImageConstView source, const kvmem::RawKvStoreConfig& raw_config,
    KVMemQueryBoundaryState state, std::size_t tail_mean_count) {
    if (source.data == nullptr || source.layout == nullptr ||
        source.layout->image_bytes == 0) {
        throw std::invalid_argument("KVMem host checkpoint requires a nonempty StateImage");
    }
    if (state.mtp_draft_count > state.mtp_draft_tokens.size()) {
        throw std::invalid_argument("KVMem query checkpoint MTP draft count is out of range");
    }
    if (raw_config.block_tokens == 0) {
        throw std::invalid_argument("KVMem query checkpoint requires a nonzero RawKvStore block size");
    }

    const std::size_t expected_tail_mean = expected_tail_mean_size(
        state.logical_frontier, raw_config.n_layer, raw_config.n_embd_k,
        raw_config.block_tokens);
    if (tail_mean_count != expected_tail_mean) {
        throw std::invalid_argument("KVMem host checkpoint tail-mean geometry does not match");
    }
}

KVMemQueryBoundaryCheckpoint KVMemQueryBoundaryCheckpoint::from_host_image(
    HostStateImageConstView source, const kvmem::RawKvStoreConfig& raw_config,
    KVMemQueryBoundaryState state, std::vector<float> tail_mean) {
    validate_host_image(source, raw_config, state, tail_mean.size());

    StateImageHostLayout state_image_layout = *source.layout;
    std::vector<std::uint8_t> state_image(state_image_layout.image_bytes);
    std::memcpy(state_image.data(), source.data, state_image.size());
    return KVMemQueryBoundaryCheckpoint(std::make_shared<const Storage>(Storage{
        .state_image_layout = std::move(state_image_layout),
        .state_image = std::move(state_image),
        .raw_mean_geometry = RawMeanGeometry{.n_layer = raw_config.n_layer,
                                             .n_embd_k = raw_config.n_embd_k,
                                             .block_tokens = raw_config.block_tokens},
        .tail_mean = std::move(tail_mean),
    }), state);
}

KVMemQueryBoundaryCheckpoint::KVMemQueryBoundaryCheckpoint(
    KVMemQueryBoundaryCheckpoint&& other) noexcept
    : storage_(std::move(other.storage_)), state_(other.state_) {}

KVMemQueryBoundaryCheckpoint& KVMemQueryBoundaryCheckpoint::operator=(
    KVMemQueryBoundaryCheckpoint&& other) noexcept {
    if (this != &other) {
        storage_ = std::move(other.storage_);
        state_ = other.state_;
    }
    return *this;
}

KVMemQueryBoundaryCheckpoint::~KVMemQueryBoundaryCheckpoint() = default;

const KVMemQueryBoundaryState& KVMemQueryBoundaryCheckpoint::state() const {
    require_metadata_valid();
    return state_;
}

const StateImageHostLayout& KVMemQueryBoundaryCheckpoint::host_layout() const {
    require_metadata_valid();
    return storage_->state_image_layout;
}

bool KVMemQueryBoundaryCheckpoint::image_resident() const noexcept {
    return storage_ && storage_->state_image_layout.image_bytes > 0 &&
           storage_->state_image.size() == storage_->state_image_layout.image_bytes;
}

std::size_t KVMemQueryBoundaryCheckpoint::tail_mean_size() const {
    require_metadata_valid();
    const RawMeanGeometry& geometry = storage_->raw_mean_geometry;
    return expected_tail_mean_size(state_.logical_frontier, geometry.n_layer,
                                   geometry.n_embd_k, geometry.block_tokens);
}

HostStateImageConstView KVMemQueryBoundaryCheckpoint::host_view() const {
    require_valid();
    return {.data = reinterpret_cast<const std::byte*>(storage_->state_image.data()),
            .layout = &storage_->state_image_layout};
}

std::size_t KVMemQueryBoundaryCheckpoint::allocated_bytes() const noexcept {
    return storage_ ? storage_->state_image.capacity() +
                          storage_->tail_mean.capacity() * sizeof(float) : 0U;
}

const std::vector<float>& KVMemQueryBoundaryCheckpoint::tail_mean() const {
    require_metadata_valid();
    if (storage_->tail_mean.size() != tail_mean_size()) {
        throw std::logic_error("KVMem query checkpoint tail mean is nonresident or truncated");
    }
    return storage_->tail_mean;
}

void KVMemQueryBoundaryCheckpoint::append_snapshot_buffers(
    std::vector<kvmem::SnapshotBuffer>& buffers) const {
    require_metadata_valid();
    const std::size_t expected_image_bytes = storage_->state_image_layout.image_bytes;
    const std::size_t expected_mean_size = tail_mean_size();
    if (storage_->state_image.size() != expected_image_bytes) {
        throw std::logic_error("KVMem query checkpoint StateImage is nonresident or truncated");
    }
    if (storage_->tail_mean.size() != expected_mean_size) {
        throw std::logic_error("KVMem query checkpoint tail mean is nonresident or truncated");
    }

    const std::size_t binding_count = storage_->tail_mean.capacity() == 0 ? 1U : 2U;
    if (binding_count > buffers.max_size() - buffers.size()) {
        throw std::length_error("KVMem query checkpoint snapshot binding count overflows");
    }
    buffers.reserve(buffers.size() + binding_count);
    buffers.push_back(kvmem::SnapshotBuffer::bind(storage_->state_image));
    if (storage_->tail_mean.capacity() != 0) {
        buffers.push_back(kvmem::SnapshotBuffer::bind(storage_->tail_mean));
    }
}

bool KVMemQueryBoundaryCheckpoint::shares_storage_with(
    const KVMemQueryBoundaryCheckpoint& other) const noexcept {
    return storage_ && storage_ == other.storage_;
}

KVMemQueryBoundaryCheckpoint KVMemQueryBoundaryCheckpoint::with_draft_carry(
    std::array<TokenId, kMtpDecodeMaximumDrafts> tokens, std::uint32_t count) const {
    require_metadata_valid();
    if (count > tokens.size()) {
        throw std::invalid_argument("KVMem query checkpoint MTP draft count is out of range");
    }
    KVMemQueryBoundaryState state = state_;
    state.mtp_draft_tokens = tokens;
    state.mtp_draft_count = count;
    return KVMemQueryBoundaryCheckpoint(storage_, state);
}

void KVMemQueryBoundaryCheckpoint::restore_for_query_replay(
    StateImageDevicePool& device_images, std::int32_t destination_device_slot,
    cudaStream_t stream) const {
    restore_state_image(device_images, destination_device_slot, stream);
}

void KVMemQueryBoundaryCheckpoint::restore_for_failure_rollback(
    StateImageDevicePool& device_images, std::int32_t destination_device_slot,
    kvmem::RawKvStore& raw_store, cudaStream_t stream) const {
    require_metadata_valid();
    const kvmem::RawKvStoreConfig& raw_config = raw_store.config();
    const auto& geometry = storage_->raw_mean_geometry;
    if (raw_config.n_layer != geometry.n_layer ||
        raw_config.n_embd_k != geometry.n_embd_k ||
        raw_config.block_tokens != geometry.block_tokens) {
        throw std::invalid_argument("KVMem query checkpoint RawKvStore mean geometry does not match");
    }

    const std::size_t expected_tail_mean = tail_mean_size();
    if (storage_->tail_mean.size() != expected_tail_mean) {
        throw std::logic_error("KVMem query checkpoint tail mean is nonresident or truncated");
    }

    raw_store.wait_writes();
    restore_state_image(device_images, destination_device_slot, stream);
    raw_store.restore_mean_checkpoint(state_.logical_frontier, storage_->tail_mean);
}

void KVMemQueryBoundaryCheckpoint::require_metadata_valid() const {
    if (!storage_ || storage_->state_image_layout.image_bytes == 0) {
        throw std::logic_error("KVMem query checkpoint is empty or moved from");
    }
}

void KVMemQueryBoundaryCheckpoint::require_valid() const {
    require_metadata_valid();
    if (storage_->state_image.size() != storage_->state_image_layout.image_bytes) {
        throw std::logic_error("KVMem query checkpoint StateImage is nonresident or truncated");
    }
}

void KVMemQueryBoundaryCheckpoint::restore_state_image(
    StateImageDevicePool& device_images, std::int32_t destination_device_slot,
    cudaStream_t stream) const {
    require_valid();
    try {
        device_images.copy_from_host(host_view(), destination_device_slot, stream);
        CUDA_CHECK(cudaStreamSynchronize(stream));
    } catch (...) {
        // Keep the owned source bytes alive until any partially enqueued H2D work has drained.
        (void)cudaStreamSynchronize(stream);
        throw;
    }
}

} // namespace ninfer::models::qwen3_5::detail
