// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstdint>
#include <span>
#include <vector>

namespace kvmem {
class RawKvStore;
}

namespace ninfer::models::qwen3_5::detail {

// NInfer adapter metadata. The native scorer uses one attention geometry for
// all layers, taken from the model's first attention layer.
struct KVMemRetrievalGeometry {
    std::uint32_t head_dim = 0;
    std::uint32_t query_heads = 0;
    std::uint32_t kv_heads = 0;
};

// NInfer adapter view of native q_sum_[il]/q_count_[il]. Borrowed HOST FP32
// storage is [query_head][coordinate], coordinate contiguous. Each original
// Q head contains the ordered FP32 sum of actual captured pre-RoPE attention Q
// for the query rows; count is the number of those rows, shared by that layer's
// heads. Do not supply already GQA-reduced heads, averages, or reconstructed Q.
// A count-zero layer is skipped; its sum may be empty or full-sized/stale.
struct KVMemRetrievalQueryLayer {
    std::span<const float> pre_rope_sum;
    std::uint32_t count = 0;
};

// NInfer adapter extraction of llama_memory_kvmem::score_retrieval at upstream
// 95a2155b75f41eada1398c86b19dcf9703581b30; source/license details are in the .cpp.
//
// queries is indexed by native layer id and must cover raw.config().n_layer,
// including uncaptured layers. block_count is the caller's native runtime
// block count. RawKvStore owns K sums, lazy means and its FP16-row fallback.
// Missing whole blocks score zero. A layer with Q but missing K contributes
// zero AND participates in the layer average, exactly as upstream.
// Query-only GQA means/norms are prepared once per call; the FP32 grouping,
// reciprocal and reduction order are unchanged. No prepared Q outlives the call.
//
// This host-only call borrows a coherent, quiescent RawKvStore/query snapshot;
// the caller completes capture/transfers and prevents concurrent mutation.
// It returns scores indexed by block id; publishing to the native store,
// capture, query lifetime, selection and Program integration belong to caller.
// Throws invalid_argument for incompatible geometry, shape or an overflowing
// native uint32 count*GQA-group denominator; never substitutes another scorer.
[[nodiscard]] std::vector<double> score_kvmem_retrieval(
    const kvmem::RawKvStore& raw, std::uint32_t block_count,
    KVMemRetrievalGeometry geometry, std::span<const KVMemRetrievalQueryLayer> queries);

} // namespace ninfer::models::qwen3_5::detail
