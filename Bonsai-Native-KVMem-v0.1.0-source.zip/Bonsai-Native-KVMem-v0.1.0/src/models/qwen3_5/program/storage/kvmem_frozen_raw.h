// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include "models/qwen3_5/program/storage/kvmem_parked_file.h"

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <memory>

namespace ninfer::models::qwen3_5::detail {

// Frozen Native bindings into RawKvStore and associated recurrent checkpoint
// allocations. The caller keeps every RawKvStore alive at the same address,
// and parked, until complete(); this manifest pins checkpoint storage itself.
// Destroying this handle removes only its native files; it never thaws, clears,
// or relocates a bound RawKvStore.
class KVMemFrozenRaw {
public:
    struct Chunk {
        bool in_ram;
        std::uint64_t ram_bytes;
        std::uint64_t disk_bytes;
        std::uint64_t spill_bytes;
        std::uint64_t restore_bytes;
    };

    ~KVMemFrozenRaw() noexcept;

    KVMemFrozenRaw(const KVMemFrozenRaw &) = delete;
    KVMemFrozenRaw & operator=(const KVMemFrozenRaw &) = delete;
    KVMemFrozenRaw(KVMemFrozenRaw &&) = delete;
    KVMemFrozenRaw & operator=(KVMemFrozenRaw &&) = delete;

    std::uint32_t chunk_count() const;
    Chunk chunk(std::uint32_t index) const;
    bool complete() const;
    bool valid() const noexcept;
    // Native eviction marks the manifest invalid BEFORE possibly partial
    // multi-file deletion. It may be retained for charged cleanup, not reuse.
    void invalidate() noexcept;
    std::uint64_t ram_bytes() const;
    std::uint64_t restore_bytes() const;
    std::uint64_t disk_bytes() const noexcept;
    std::uint64_t metadata_bytes() const;
    std::uint64_t store_snapshot_bytes(std::size_t store_index) const;

    // Remove all non-authoritative unfinished files backed by resident Raw chunks.
    bool prepare_transfer();
    void spill(std::uint32_t index);
    void restore(std::uint32_t index);
    // Read-only, bounded validation of every disk-only native chunk. RAM
    // duplicates are already trusted and remain available for delete retry.
    void validate() const;
    bool erase() noexcept;
    std::filesystem::path path(std::uint32_t index) const;

    // Emit the exact RawKvStore::snapshot_write stream without restoring
    // spilled allocations. KV payloads are streamed through a 64 KiB buffer.
    void write_store(std::size_t store_index, kvmem::SnapshotWriter & out) const;
    bool owns_checkpoint(const KVMemQueryBoundaryCheckpoint& checkpoint) const noexcept;
    // Emit only the original vector body, without its Native count prefix.
    // Mixed/cold checkpoint bytes stream from their existing Native chunk;
    // no complete StateImage is restored or copied to export a continuation.
    void write_checkpoint_image(const KVMemQueryBoundaryCheckpoint& checkpoint,
                                const kvmem::SnapshotWriter::Sink& sink) const;
    void write_checkpoint_tail_mean(const KVMemQueryBoundaryCheckpoint& checkpoint,
                                    const kvmem::SnapshotWriter::Sink& sink) const;

private:
    friend class KVMemParkedFileCache;
    struct Impl;

    KVMemFrozenRaw(
        std::shared_ptr<KVMemParkedFileState> state,
        std::span<kvmem::RawKvStore * const> stores,
        KVMemParkedFileState::PayloadIdentity identity,
        std::uint64_t group_bytes,
        std::span<const std::shared_ptr<const KVMemQueryBoundaryCheckpoint>> checkpoints);

    void write_checkpoint_part(const KVMemQueryBoundaryCheckpoint& checkpoint,
                                bool tail_mean, const kvmem::SnapshotWriter::Sink& sink) const;

    std::unique_ptr<Impl> impl_;
};

} // namespace ninfer::models::qwen3_5::detail
