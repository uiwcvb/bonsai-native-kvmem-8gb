// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
//
// Provenance: the capture coordinates follow the normalized pre-RoPE Q/K
// points added by the pinned KVMem patch at
// third_party/kvmem/patches/llama-kvmem-current.patch (submodule commit
// 95a2155b75f41eada1398c86b19dcf9703581b30). Native K accumulation follows
// kvmem::RawKvStore::write_layer_mean_sum in
// third_party/kvmem/kvmem/src/host/raw_kv_store.cpp; query layout/count follow
// llama_memory_kvmem::q_sum_/q_count_ and score_retrieval in
// third_party/kvmem/src/adapter/llama-memory-kvmem.cpp. This bounded workspace
// and its transaction checks are NInfer code; no native selection is invoked.

#include "models/qwen3_5/program/storage/kvmem_feature_workspace.h"

#include "core/device.h"
#include "models/qwen3_5/config.h"

#include <kvmem/raw_kv_store.hpp>

#include <algorithm>
#include <cstddef>
#include <limits>
#include <stdexcept>

namespace ninfer::models::qwen3_5::detail {
namespace {

std::size_t checked_product(std::size_t lhs, std::size_t rhs, const char* what) {
    if (lhs != 0 && rhs > std::numeric_limits<std::size_t>::max() / lhs) {
        throw std::overflow_error(what);
    }
    return lhs * rhs;
}

std::size_t checked_bytes(std::size_t elements, const char* what) {
    return checked_product(elements, sizeof(float), what);
}

void validate_interval(std::int32_t first, std::int32_t count, std::int32_t frontier,
                       const char* what) {
    if (frontier < 0 || first < 0 || count < 0 ||
        static_cast<std::int64_t>(first) + count > frontier) {
        throw std::invalid_argument(what);
    }
}

std::uint32_t touched_blocks(std::int32_t first, std::int32_t count,
                             std::uint32_t block_tokens) {
    return count == 0 ? 0U : static_cast<std::uint32_t>(
        1U + (static_cast<std::uint64_t>(first) % block_tokens + count - 1U) /
                 block_tokens);
}

} // namespace

KVMemFeatureWorkspace::KVMemFeatureWorkspace(const TextConfig& text, kvmem::RawKvStore& raw,
                                             Tensor key_storage, Tensor query_storage,
                                             std::uint32_t accepted_key_frontier)
    : raw_(&raw), key_frontier_(accepted_key_frontier), key_storage_(key_storage),
      query_storage_(query_storage) {
    const auto& raw_config = raw_->config();
    if (!text.attention || text.full_attention_layers == 0 ||
        text.layer_types.size() != text.compact_layer_indices.size() ||
        accepted_key_frontier > static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max())) {
        throw std::invalid_argument("KVMem feature workspace requires valid attention config/frontier");
    }

    std::uint32_t full_layers = 0;
    std::uint32_t linear_layers = 0;
    for (std::size_t layer = 0; layer < text.layer_types.size(); ++layer) {
        std::uint32_t expected = 0;
        if (text.layer_types[layer] == MixerKind::FullAttention) {
            expected = full_layers++;
        } else {
            expected = linear_layers++;
        }
        if (text.compact_layer_indices[layer] != expected) {
            throw std::invalid_argument("Qwen compact layer mapping is not contiguous by mixer kind");
        }
    }
    if (full_layers != text.full_attention_layers || raw_config.n_layer != full_layers ||
        raw_config.block_tokens == 0 || raw_config.block_tokens >
            static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max()) ||
        full_layers > static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max())) {
        throw std::invalid_argument("KVMem layer count/block size does not match Qwen attention");
    }

    const auto& attention = *text.attention;
    if (attention.head_dim == 0 || attention.num_attention_heads == 0 ||
        attention.num_key_value_heads == 0 ||
        attention.num_attention_heads % attention.num_key_value_heads != 0) {
        throw std::invalid_argument("KVMem feature workspace has invalid attention geometry");
    }
    const auto key_width = attention.key_width();
    const auto query_width = attention.query_width();
    constexpr auto max_tensor_dim =
        static_cast<std::uint64_t>(std::numeric_limits<std::int32_t>::max());
    if (attention.head_dim > max_tensor_dim || attention.num_key_value_heads > max_tensor_dim ||
        attention.num_attention_heads > max_tensor_dim || key_width > max_tensor_dim ||
        query_width > max_tensor_dim || key_width != raw_config.n_embd_k) {
        throw std::invalid_argument("KVMem feature dimensions do not match RawKvStore");
    }

    block_tokens_ = raw_config.block_tokens;
    attention_layers_ = full_layers;
    raw_value_width_ = raw_config.n_embd_v;
    head_dim_ = attention.head_dim;
    kv_heads_ = attention.num_key_value_heads;
    query_heads_ = attention.num_attention_heads;
    key_width_ = static_cast<std::size_t>(key_width);
    query_width_ = static_cast<std::size_t>(query_width);
    geometry_ = {head_dim_, query_heads_, kv_heads_};

    const auto validate_storage = [&](const Tensor& storage, std::uint32_t heads) {
        if (storage.data == nullptr || storage.dtype != DType::FP32 ||
            storage.ne[0] != static_cast<std::int32_t>(head_dim_) ||
            storage.ne[1] != static_cast<std::int32_t>(heads) || storage.ne[2] <= 0 ||
            storage.ne[3] != static_cast<std::int32_t>(attention_layers_) ||
            !storage.is_contiguous() ||
            reinterpret_cast<std::uintptr_t>(storage.data) % alignof(float) != 0) {
            throw std::invalid_argument(
                "KVMem feature storage must be contiguous F32 [D,H,S,L]");
        }
    };
    validate_storage(key_storage_, kv_heads_);
    validate_storage(query_storage_, query_heads_);
    if (query_storage_.ne[2] != 1) {
        throw std::invalid_argument("KVMem canonical Q storage requires one sum plane");
    }
    sum_planes_ = static_cast<std::uint32_t>(key_storage_.ne[2]);
    key_layer_elements_ = checked_product(key_width_, sum_planes_,
                                          "KVMem K sum layer size overflows");
    const auto key_elements = checked_product(attention_layers_, key_layer_elements_,
                                              "KVMem K sum storage size overflows");
    const auto query_elements = checked_product(attention_layers_, query_width_,
                                                "KVMem Q sum storage size overflows");
    key_storage_bytes_ = checked_bytes(key_elements, "KVMem K sum storage size overflows");
    query_storage_bytes_ = checked_bytes(query_elements, "KVMem Q sum storage size overflows");
    const auto key_address = reinterpret_cast<std::uintptr_t>(key_storage_.data);
    const auto query_address = reinterpret_cast<std::uintptr_t>(query_storage_.data);
    if (key_address <= query_address ? query_address - key_address < key_storage_bytes_
                                    : key_address - query_address < query_storage_bytes_) {
        throw std::invalid_argument("KVMem K/Q sum storage must not overlap");
    }
    raw_k_row_bytes_ = raw_config.k_row_bytes;
    raw_k_gpu_row_bytes_ = raw_config.k_gpu_row_bytes;
    raw_v_gpu_row_bytes_ = raw_config.v_gpu_row_bytes;
    host_key_sums_.resize(key_elements);
    host_query_sums_.resize(query_elements);
    host_query_aggregate_sums_.resize(checked_product(
        attention_layers_, query_width_, "KVMem canonical Q sum size overflows"));
    key_views_.reserve(attention_layers_);
    query_views_.reserve(attention_layers_);
    decode_key_views_.reserve(attention_layers_);
    host_query_layers_.resize(attention_layers_);
    for (std::uint32_t layer = 0; layer < attention_layers_; ++layer) {
        key_views_.push_back(key_storage_.slice(3, static_cast<std::int32_t>(layer), 1));
        query_views_.push_back(query_storage_.slice(3, static_cast<std::int32_t>(layer), 1));
        decode_key_views_.push_back(key_views_.back().slice(2, 0, 1));
        host_query_layers_[layer] = {{}, 0};
    }
    decode_capture_view_.key_sums =
        std::span<const Tensor>{decode_key_views_.data(), decode_key_views_.size()};
    decode_capture_view_.key_first = 0;
    decode_capture_view_.key_count = 1;
    decode_capture_view_.query_count = 0;
}

void KVMemFeatureWorkspace::begin_query(std::int32_t query_first,
                                        std::int32_t query_count) {
    if (state_ != State::Idle && state_ != State::Committed) {
        throw std::logic_error("KVMem feature workspace has an unfinished segment");
    }
    if (query_first < 0 || query_count < 0 ||
        static_cast<std::int64_t>(query_first) + query_count >
            std::numeric_limits<std::int32_t>::max()) {
        throw std::invalid_argument("KVMem canonical query interval is invalid");
    }

    std::fill(host_query_aggregate_sums_.begin(), host_query_aggregate_sums_.end(), 0.0f);
    query_first_ = query_first;
    query_count_ = query_count;
    accepted_query_count_ = 0;
    query_active_ = true;
    for (auto& query : host_query_layers_) {
        query = {{}, 0};
    }
    if (query_count_ == 0) {
        publish_query_layers();
    }
}

execution::AttentionFeatureCapture KVMemFeatureWorkspace::begin_segment(
    KVMemFeatureSegment segment, cudaStream_t stream) {
    if ((state_ != State::Idle && state_ != State::Committed) || decode_accum_count_ != 0) {
        throw std::logic_error("KVMem feature workspace has an unfinished segment");
    }
    validate_interval(segment.key_first, segment.key_count, segment.logical_frontier,
                      "KVMem key segment is outside its logical frontier");
    validate_interval(segment.query_first, segment.query_count, segment.logical_frontier,
                      "KVMem query segment is outside its logical frontier");
    if (touched_blocks(segment.key_first, segment.key_count, block_tokens_) > sum_planes_) {
        throw std::invalid_argument("KVMem feature segment exceeds its block-sum capacity");
    }
    if (static_cast<std::uint32_t>(segment.key_first) != key_frontier_) {
        throw std::invalid_argument("KVMem key segment does not start at the accepted key frontier");
    }
    if (query_active_) {
        const auto next_query = static_cast<std::int64_t>(query_first_) + accepted_query_count_;
        if (segment.query_count > 0 &&
            (segment.query_first != next_query ||
             segment.query_count > query_count_ - accepted_query_count_)) {
            throw std::invalid_argument(
                "KVMem query segment is not the next slice of the canonical query");
        }
    } else if (segment.query_count != 0) {
        throw std::logic_error("KVMem query capture requires begin_query");
    }
    const auto gqa_group = query_heads_ / kv_heads_;
    if (static_cast<std::uint32_t>(segment.query_count) >
        std::numeric_limits<std::uint32_t>::max() / gqa_group) {
        throw std::invalid_argument("KVMem query count times GQA group overflows native indexing");
    }

    segment_ = segment;
    state_ = State::Capturing;
    try {
        if (segment.key_count > 0) {
            initialize_key_sums(static_cast<std::uint32_t>(segment.key_first), stream);
        }
        if (segment.query_count > 0) {
            CUDA_CHECK(cudaMemcpyAsync(query_storage_.data, host_query_aggregate_sums_.data(),
                                       query_storage_bytes_, cudaMemcpyHostToDevice, stream));
        }
    } catch (...) {
        state_ = State::Failed;
        throw;
    }

    execution::AttentionFeatureCapture capture;
    capture.key_sums = std::span<const Tensor>{key_views_.data(), key_views_.size()};
    capture.key_first = segment.key_first;
    capture.key_count = segment.key_count;
    capture.key_block_tokens = static_cast<std::int32_t>(block_tokens_);
    capture.query_sums = std::span<const Tensor>{query_views_.data(), query_views_.size()};
    capture.query_first = segment.query_first;
    capture.query_count = segment.query_count;
    return capture;
}

void KVMemFeatureWorkspace::initialize_key_sums(std::uint32_t logical_first,
                                                cudaStream_t stream) {
    if (raw_ == nullptr) {
        throw std::logic_error("KVMem feature workspace has no bound RawKvStore");
    }
    const auto prefix_count = logical_first % block_tokens_;
    if (prefix_count != 0) {
        const auto checkpoint = raw_->mean_checkpoint(logical_first);
        const auto stride = key_width_ + 1U;
        if (checkpoint.size() != static_cast<std::size_t>(attention_layers_) * stride) {
            throw std::logic_error("KVMem accepted K tail has no complete native checkpoint");
        }
        for (std::uint32_t layer = 0; layer < attention_layers_; ++layer) {
            const auto* source = checkpoint.data() + static_cast<std::size_t>(layer) * stride;
            if (source[0] != static_cast<float>(prefix_count)) {
                throw std::logic_error("KVMem accepted K tail mean count differs from frontier");
            }
            // Keep the H2D source alive until the caller's stream completes.
            std::copy_n(source + 1U, key_width_, host_key_sums_.data() +
                        static_cast<std::size_t>(layer) * key_layer_elements_);
        }
    }
    CUDA_CHECK(cudaMemsetAsync(key_storage_.data, 0, key_storage_bytes_, stream));
    if (prefix_count != 0) {
        for (std::uint32_t layer = 0; layer < attention_layers_; ++layer) {
            const auto offset = static_cast<std::size_t>(layer) * key_layer_elements_;
            CUDA_CHECK(cudaMemcpyAsync(static_cast<float*>(key_storage_.data) + offset,
                                       host_key_sums_.data() + offset,
                                       key_width_ * sizeof(float), cudaMemcpyHostToDevice, stream));
        }
    }
}

const execution::AttentionFeatureCapture& KVMemFeatureWorkspace::begin_decode_token(
    std::uint32_t logical_first, cudaStream_t stream) {
    constexpr auto max_frontier =
        static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max());
    if (raw_ == nullptr || logical_first >= max_frontier ||
        logical_first != key_frontier_ || query_active_ ||
        (state_ != State::Idle && state_ != State::Committed)) {
        throw std::logic_error("KVMem decode capture is not at its accepted input frontier");
    }
    if (decode_accum_count_ == 0) {
        decode_accum_first_ = logical_first;
        try {
            initialize_key_sums(logical_first, stream);
        } catch (...) {
            state_ = State::Failed;
            throw;
        }
    } else if (decode_accum_first_ + decode_accum_count_ != logical_first ||
               decode_accum_first_ / block_tokens_ != logical_first / block_tokens_) {
        throw std::logic_error("KVMem decode K accumulation crossed a native block");
    }
    segment_ = KVMemFeatureSegment{
        .logical_frontier = static_cast<std::int32_t>(logical_first + 1U),
        .key_first = static_cast<std::int32_t>(logical_first),
        .key_count = 1,
    };
    state_ = State::Capturing;
    return decode_capture_view_;
}

void KVMemFeatureWorkspace::accept_decode_token(std::uint32_t logical_first) {
    if (state_ != State::Capturing || raw_ == nullptr ||
        segment_.key_first != static_cast<std::int32_t>(logical_first) ||
        key_frontier_ != logical_first ||
        decode_accum_count_ >= block_tokens_) {
        throw std::logic_error("KVMem decode K capture was not accepted in order");
    }
    ++decode_accum_count_;
    ++key_frontier_;
    state_ = State::Committed;
    if (key_frontier_ % block_tokens_ == 0) { flush_decode_tail(); }
}

void KVMemFeatureWorkspace::flush_decode_tail() {
    if (state_ != State::Idle && state_ != State::Committed) {
        throw std::logic_error("KVMem decode tail has in-flight capture work");
    }
    if (decode_accum_count_ == 0) { return; }
    if (raw_ == nullptr || decode_accum_first_ + decode_accum_count_ != key_frontier_ ||
        (decode_accum_first_ / block_tokens_) !=
            ((key_frontier_ - 1U) / block_tokens_)) {
        throw std::logic_error("KVMem decode tail is not one accepted native block");
    }
    // The caller synchronized the CUDA Graph. The GPU sum already includes
    // any accepted prefix. Native's offset-zero API replaces that whole prefix
    // rather than regrouping the new suffix into an independently rounded sum.
    state_ = State::Failed;
    CUDA_CHECK(cudaMemcpy(host_key_sums_.data(), key_storage_.data, key_storage_bytes_,
                           cudaMemcpyDeviceToHost));
    raw_->ensure_blocks(decode_accum_first_ / block_tokens_ + 1U);
    const auto prefix_count = decode_accum_first_ % block_tokens_;
    const auto block_first = decode_accum_first_ - prefix_count;
    for (std::uint32_t layer = 0; layer < attention_layers_; ++layer) {
        const auto* sum = host_key_sums_.data() +
                          static_cast<std::size_t>(layer) * key_layer_elements_;
        raw_->write_layer_mean_sum(block_first, prefix_count + decode_accum_count_, layer, sum);
    }
    decode_accum_first_ = key_frontier_;
    decode_accum_count_ = 0;
    state_ = State::Committed;
}

void KVMemFeatureWorkspace::bind_raw(kvmem::RawKvStore& raw,
                                      std::uint32_t logical_frontier,
                                      bool discard_failed_decode) {
    if (!discard_failed_decode &&
        (decode_accum_count_ != 0 || state_ == State::Capturing ||
         state_ == State::HostReady || state_ == State::Failed)) {
        throw std::logic_error("KVMem decode capture cannot silently discard accepted rows");
    }
    // The previous owner may already have been destroyed. Fail closed until
    // the replacement passes validation so no later commit uses a stale pointer.
    raw_ = nullptr;
    key_frontier_ = 0;
    segment_ = {};
    decode_accum_first_ = 0;
    decode_accum_count_ = 0;
    query_active_ = false;
    query_first_ = 0;
    query_count_ = 0;
    accepted_query_count_ = 0;
    state_ = State::Failed;

    if (logical_frontier > static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max())) {
        throw std::invalid_argument("KVMem key frontier exceeds int32 logical indexing");
    }

    const auto& config = raw.config();
    if (config.n_layer != attention_layers_ || config.n_embd_k != key_width_ ||
        config.n_embd_v != raw_value_width_ || config.block_tokens != block_tokens_ ||
        config.k_row_bytes != raw_k_row_bytes_ ||
        config.k_gpu_row_bytes != raw_k_gpu_row_bytes_ ||
        config.v_gpu_row_bytes != raw_v_gpu_row_bytes_) {
        throw std::invalid_argument(
            "replacement KVMem RawKvStore configuration does not match feature workspace");
    }

    raw_ = &raw;
    key_frontier_ = logical_frontier;
    state_ = State::Idle;
}

void KVMemFeatureWorkspace::reset_key_frontier(std::uint32_t logical_frontier) {
    if ((state_ != State::Idle && state_ != State::Committed) || decode_accum_count_ != 0) {
        throw std::logic_error("KVMem key frontier cannot reset with an unfinished segment");
    }
    if (logical_frontier > static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max())) {
        throw std::invalid_argument("KVMem key frontier exceeds int32 logical indexing");
    }
    key_frontier_ = logical_frontier;
}

void KVMemFeatureWorkspace::copy_sums_to_host() {
    if (state_ != State::Capturing) {
        throw std::logic_error("KVMem feature sums are not awaiting readback");
    }
    if (segment_.key_count > 0) {
        CUDA_CHECK(cudaMemcpy(host_key_sums_.data(), key_storage_.data, key_storage_bytes_,
                               cudaMemcpyDeviceToHost));
    }
    if (segment_.query_count > 0) {
        CUDA_CHECK(cudaMemcpy(host_query_sums_.data(), query_storage_.data, query_storage_bytes_,
                               cudaMemcpyDeviceToHost));
    }
    state_ = State::HostReady;
}

void KVMemFeatureWorkspace::commit_accepted_segment(std::int32_t accepted_first,
                                                    std::int32_t accepted_count) {
    if (state_ != State::HostReady) {
        throw std::logic_error("KVMem feature sums must be copied before commit");
    }
    if (accepted_first < 0 || accepted_count < 0 || accepted_first != segment_.key_first ||
        accepted_count != segment_.key_count) {
        throw std::invalid_argument("accepted K range must equal the captured key-sum interval");
    }

    // RawKvStore has no multi-layer transaction API. Ensure block metadata
    // before the first layer write, then fail-stop if any native layer write
    // throws: some native layers may already have published the new prefix.
    state_ = State::Failed;
    if (accepted_count > 0) {
        if (raw_ == nullptr) {
            throw std::logic_error("KVMem feature workspace has no bound RawKvStore");
        }
        const auto first = static_cast<std::uint32_t>(accepted_first);
        const auto count = static_cast<std::uint32_t>(accepted_count);
        raw_->ensure_blocks((first + count - 1U) / block_tokens_ + 1U);
        std::uint32_t consumed = 0;
        std::uint32_t plane = 0;
        while (consumed != count) {
            const auto logical = first + consumed;
            const auto prefix_count = logical % block_tokens_;
            const auto rows = std::min(count - consumed, block_tokens_ - prefix_count);
            for (std::uint32_t layer = 0; layer < attention_layers_; ++layer) {
                const auto offset = static_cast<std::size_t>(layer) * key_layer_elements_ +
                                    static_cast<std::size_t>(plane) * key_width_;
                raw_->write_layer_mean_sum(logical - prefix_count, prefix_count + rows, layer,
                                           host_key_sums_.data() + offset);
            }
            consumed += rows;
            ++plane;
        }
    }

    if (segment_.query_count > 0) {
        // Capture began from the accepted canonical sum and advanced it in
        // logical token order. Publish the candidate only after K acceptance.
        std::copy(host_query_sums_.begin(), host_query_sums_.end(),
                  host_query_aggregate_sums_.begin());
        accepted_query_count_ += segment_.query_count;
    }
    key_frontier_ = static_cast<std::uint32_t>(accepted_first) +
                    static_cast<std::uint32_t>(accepted_count);
    if (query_active_ && accepted_query_count_ == query_count_) {
        publish_query_layers();
    }
    state_ = State::Committed;
}

void KVMemFeatureWorkspace::discard_segment() {
    if (state_ != State::Capturing && state_ != State::HostReady) {
        throw std::logic_error("KVMem feature workspace has no discardable segment");
    }
    state_ = State::Idle;
}

void KVMemFeatureWorkspace::publish_query_layers() noexcept {
    for (std::uint32_t layer = 0; layer < attention_layers_; ++layer) {
        if (query_count_ == 0) {
            host_query_layers_[layer] = {{}, 0};
            continue;
        }
        const auto offset = static_cast<std::size_t>(layer) * query_width_;
        host_query_layers_[layer] = {
            {host_query_aggregate_sums_.data() + offset, query_width_},
            static_cast<std::uint32_t>(query_count_)};
    }
}

std::span<const KVMemRetrievalQueryLayer> KVMemFeatureWorkspace::host_query_layers() const {
    if (!query_active_ || state_ == State::Failed ||
        accepted_query_count_ != query_count_) {
        throw std::logic_error("KVMem canonical query is not fully accepted");
    }
    return {host_query_layers_.data(), host_query_layers_.size()};
}

} // namespace ninfer::models::qwen3_5::detail
