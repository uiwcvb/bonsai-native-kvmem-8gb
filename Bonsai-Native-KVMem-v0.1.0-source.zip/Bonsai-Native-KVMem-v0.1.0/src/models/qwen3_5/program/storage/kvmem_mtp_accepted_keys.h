// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include "core/tensor.h"
#include "models/qwen3_5/execution/attention_features.h"

#include <cstddef>
#include <cstdint>
#include <vector>

namespace kvmem {
class RawKvStore;
}

namespace ninfer::models::qwen3_5 {
struct TextConfig;
}

namespace ninfer::models::qwen3_5::detail {

// Bounded bridge from target-verify pre-RoPE K capture to accepted native
// mean-K blocks. Program owns the supplied storage and must keep both tensors
// alive until all graphs and GPU work referencing this object have finished.
// This first version accepts a single sequence lane only.
class KVMemMtpAcceptedKeys final {
public:
    KVMemMtpAcceptedKeys(const TextConfig& text, kvmem::RawKvStore& raw,
                         Tensor staged_storage, Tensor reduction_storage,
                         std::uint32_t accepted_key_frontier = 0);
    ~KVMemMtpAcceptedKeys() = default;

    KVMemMtpAcceptedKeys(const KVMemMtpAcceptedKeys&) = delete;
    KVMemMtpAcceptedKeys& operator=(const KVMemMtpAcceptedKeys&) = delete;
    KVMemMtpAcceptedKeys(KVMemMtpAcceptedKeys&&) = delete;
    KVMemMtpAcceptedKeys& operator=(KVMemMtpAcceptedKeys&&) = delete;

    // Stable for this object's lifetime; safe to bind into graph construction.
    [[nodiscard]] const execution::AttentionFeatureCapture& capture_view() const noexcept {
        return capture_view_;
    }
    [[nodiscard]] bool verify_in_flight() const noexcept {
        return state_ == State::Capturing;
    }

    // Starts capture for one actual verify shape and clears its active columns
    // on stream. The returned view remains stable for this object's lifetime;
    // execute the verify graph on the same stream before committing.
    [[nodiscard]] const execution::AttentionFeatureCapture& begin_verify(
        std::int32_t verify_width, std::int32_t batch, cudaStream_t stream);

    // Synchronizes the completed verify graph, reduces only the accepted
    // leading columns from the existing native FP32 block-prefix accumulator,
    // and replaces each complete accepted native 128-token block prefix.
    // logical_first is an absolute token position, never a block or slot id.
    void commit_accepted_prefix(std::uint32_t logical_first,
                                std::int32_t accepted_count);

    // Synchronizes and abandons an in-flight verify without publishing K.
    void discard_verify();

    // Program owns the authoritative logical frontier because RawKvStore does
    // not expose one for mean-K. Rebase only while no verify is in flight.
    void reset_key_frontier(std::uint32_t logical_frontier);

    // Rebinds the mean-K destination without reallocating graph-bound staging.
    // The new store must match the attention/Raw geometry used at construction.
    // Capturing cannot be rebound. To recover Failed state, the caller must
    // first drain device work and replace the old RawKvStore owner; this call
    // then discards the failed capture bookkeeping and returns to Idle.
    void rebind_raw(kvmem::RawKvStore& raw, std::uint32_t logical_frontier);

    [[nodiscard]] std::uint32_t key_frontier() const noexcept { return key_frontier_; }
    [[nodiscard]] std::uint32_t max_verify_columns() const noexcept {
        return max_verify_columns_;
    }

private:
    enum class State : std::uint8_t { Idle, Capturing, Failed };

    kvmem::RawKvStore* raw_ = nullptr;
    std::uint32_t max_verify_columns_ = 0;
    std::uint32_t key_frontier_ = 0;
    std::uint32_t attention_layers_ = 0;
    std::uint32_t head_dim_ = 0;
    std::uint32_t kv_heads_ = 0;
    std::size_t key_width_ = 0;
    std::size_t staged_layer_bytes_ = 0;
    std::size_t staged_storage_bytes_ = 0;
    std::size_t reduction_storage_bytes_ = 0;
    std::uint32_t max_reduction_segments_ = 0;

    Tensor staged_storage_{};
    Tensor reduction_storage_{};
    std::vector<Tensor> staged_key_views_;
    execution::AttentionFeatureCapture capture_view_{};
    std::vector<float> host_sum_;

    std::int32_t active_columns_ = 0;
    cudaStream_t capture_stream_ = nullptr;
    State state_ = State::Idle;
};

} // namespace ninfer::models::qwen3_5::detail
