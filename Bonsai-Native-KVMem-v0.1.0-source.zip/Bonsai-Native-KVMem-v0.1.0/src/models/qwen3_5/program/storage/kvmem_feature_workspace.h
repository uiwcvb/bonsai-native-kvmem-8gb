// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include "core/tensor.h"
#include "models/qwen3_5/execution/attention_features.h"
#include "models/qwen3_5/program/storage/kvmem_retrieval.h"

#include <cstdint>
#include <span>
#include <vector>

namespace kvmem {
class RawKvStore;
}

namespace ninfer::models::qwen3_5 {
struct TextConfig;
}

namespace ninfer::models::qwen3_5::detail {

// Intervals are absolute logical token positions. logical_frontier is an
// exclusive upper bound supplied by Program for this execution transaction.
// Key and query intervals are independent. K is partitioned at native block
// boundaries; Q continues one accumulator for the complete canonical query.
struct KVMemFeatureSegment {
    std::int32_t logical_frontier = 0;
    std::int32_t key_first = 0;
    std::int32_t key_count = 0;
    std::int32_t query_first = 0;
    std::int32_t query_count = 0;
};

// Program-owned bounded bridge between pre-RoPE attention capture and the
// native KVMem mean-K/query-sum contracts. Program supplies contiguous F32
// [D,Hkv,S,L] K and [D,Hq,1,L] Q storage: S bounded K block sums and one
// canonical Q sum per compact full-attention layer. No per-token K rows are
// retained, and this bridge performs no device allocation.
//
// The returned AttentionFeatureCapture borrows this object's stable tensor
// views. Keep the workspace alive through capture, readback and commit; submit
// its capture calls on the same stream passed to begin_segment. The caller
// must synchronize capture work before copy_sums_to_host.
class KVMemFeatureWorkspace final {
public:
    // accepted_key_frontier is Program's authoritative logical frontier; the
    // native store has no global mean-K frontier query to derive it from.
    KVMemFeatureWorkspace(const TextConfig& text, kvmem::RawKvStore& raw,
                          Tensor key_storage, Tensor query_storage,
                          std::uint32_t accepted_key_frontier = 0);
    ~KVMemFeatureWorkspace() = default;

    KVMemFeatureWorkspace(const KVMemFeatureWorkspace&) = delete;
    KVMemFeatureWorkspace& operator=(const KVMemFeatureWorkspace&) = delete;
    KVMemFeatureWorkspace(KVMemFeatureWorkspace&&) = delete;
    KVMemFeatureWorkspace& operator=(KVMemFeatureWorkspace&&) = delete;

    // Starts one canonical logical query interval and clears its bounded
    // per-layer Q sums. Accepted capture segments must cover this interval
    // contiguously; host_query_layers() becomes available once it is complete.
    // This may replace a prior query only when no segment is in flight.
    void begin_query(std::int32_t query_first, std::int32_t query_count);

    // Starts a segment by initializing sums on stream, then returns stable
    // borrowed views with these absolute logical intervals. An existing K tail
    // and the accepted Q sum seed the same ordered FP32 recurrence as Native.
    // key_first must equal key_frontier(); accepted keys advance that frontier
    // only after commit_accepted_segment succeeds. Each touched native K block
    // requires its own sum plane and, while a query is active, Q must begin at
    // the next unaccepted position in its canonical interval.
    [[nodiscard]] execution::AttentionFeatureCapture begin_segment(
        KVMemFeatureSegment segment, cudaStream_t stream);

    // Ordinary decode accumulates pre-RoPE K on GPU across one native block.
    // The graph always addresses local column zero; logical_first is tracked
    // separately and must equal key_frontier(). Only the first token of an
    // accumulation interval initializes the sum from its accepted block prefix.
    [[nodiscard]] const execution::AttentionFeatureCapture&
    begin_decode_token(std::uint32_t logical_first, cudaStream_t stream);
    // Call after that input's forward has synchronized. The full block is
    // flushed to RawKvStore once; a partial suffix stays on GPU until turn end.
    void accept_decode_token(std::uint32_t logical_first);
    // Caller synchronizes the graph before ending a turn. This publishes only
    // accepted, already-executed input rows, never the pending sampled token.
    void flush_decode_tail();

    // Stable view for ordinary-decode CUDA Graph capture before a transaction
    // begins. Program owns its Tensor pointers for the workspace's lifetime.
    [[nodiscard]] const execution::AttentionFeatureCapture& decode_capture_view() const noexcept {
        return decode_capture_view_;
    }

    // Rebinds the non-owning RawKvStore target and synchronizes its accepted
    // frontier. The caller must first synchronize every stream that may use
    // these buffers. An accepted decode tail may only be discarded after an
    // explicit failed-owner reset; normal rebind refuses that loss. Device
    // allocations and views stay unchanged. The replacement must match the
    // layer, width, block and row-layout geometry. Failure leaves the workspace
    // unbound and failed until another successful bind_raw call.
    void bind_raw(kvmem::RawKvStore& raw, std::uint32_t logical_frontier,
                  bool discard_failed_decode = false);

    // Synchronizes the accepted logical K frontier after out-of-band prefill
    // progress. This changes transaction metadata only; device views stay put.
    // An unfinished segment cannot be rebased.
    void reset_key_frontier(std::uint32_t logical_frontier);

    // The caller must first synchronize every stream that wrote these sums.
    // This performs only the required device-to-host copies; it does not wait
    // on a stream or device itself.
    void copy_sums_to_host();

    // Confirms and commits the complete captured segment. A summed K/Q buffer
    // cannot be trimmed to a shorter accepted prefix, so a partially accepted
    // segment must be discarded and its accepted prefix captured separately.
    // Accepted Q candidates replace the active canonical sum. A zero-Q
    // segment does not change its sum or count; a zero-key segment may commit
    // with count zero.
    void commit_accepted_segment(std::int32_t accepted_first, std::int32_t accepted_count);

    // Discards an uncommitted segment. The caller must ensure its capture work
    // is no longer using the buffers before reusing or destroying the workspace.
    void discard_segment();

    // Returns the complete accepted canonical query in the existing scorer's
    // [head][coordinate] FP32 sum order. Count is the exact number of logical
    // query rows, not an average. Storage remains stable until begin_query or
    // destruction.
    [[nodiscard]] std::span<const KVMemRetrievalQueryLayer> host_query_layers() const;
    [[nodiscard]] KVMemRetrievalGeometry retrieval_geometry() const noexcept {
        return geometry_;
    }
    [[nodiscard]] std::uint32_t key_frontier() const noexcept { return key_frontier_; }

private:
    enum class State : std::uint8_t { Idle, Capturing, HostReady, Committed, Failed };

    kvmem::RawKvStore* raw_ = nullptr;
    std::uint32_t block_tokens_ = 0;
    std::uint32_t key_frontier_ = 0;
    std::uint32_t attention_layers_ = 0;
    std::uint32_t raw_value_width_ = 0;
    std::uint32_t head_dim_ = 0;
    std::uint32_t kv_heads_ = 0;
    std::uint32_t query_heads_ = 0;
    std::size_t key_width_ = 0;
    std::size_t query_width_ = 0;
    std::uint32_t sum_planes_ = 0;
    std::size_t key_layer_elements_ = 0;
    std::size_t key_storage_bytes_ = 0;
    std::size_t query_storage_bytes_ = 0;
    std::uint64_t raw_k_row_bytes_ = 0;
    std::uint64_t raw_k_gpu_row_bytes_ = 0;
    std::uint64_t raw_v_gpu_row_bytes_ = 0;
    KVMemRetrievalGeometry geometry_{};

    Tensor key_storage_{};
    Tensor query_storage_{};
    std::vector<Tensor> key_views_;
    std::vector<Tensor> query_views_;
    std::vector<Tensor> decode_key_views_;
    execution::AttentionFeatureCapture decode_capture_view_{};
    std::vector<float> host_key_sums_;
    std::vector<float> host_query_sums_;
    std::vector<float> host_query_aggregate_sums_;
    std::vector<KVMemRetrievalQueryLayer> host_query_layers_;

    KVMemFeatureSegment segment_{};
    std::uint32_t decode_accum_first_ = 0;
    std::uint32_t decode_accum_count_ = 0;
    std::int32_t query_first_ = 0;
    std::int32_t query_count_ = 0;
    std::int32_t accepted_query_count_ = 0;
    bool query_active_ = false;
    State state_ = State::Idle;

    void initialize_key_sums(std::uint32_t logical_first, cudaStream_t stream);
    void publish_query_layers() noexcept;
};

} // namespace ninfer::models::qwen3_5::detail
