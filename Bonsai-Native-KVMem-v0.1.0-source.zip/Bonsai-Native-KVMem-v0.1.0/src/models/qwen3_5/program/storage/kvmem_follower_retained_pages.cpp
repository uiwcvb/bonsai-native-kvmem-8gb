// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#include "models/qwen3_5/program/storage/kvmem_follower_retained_pages.h"

#include <algorithm>
#include <exception>
#include <stdexcept>

namespace ninfer::models::qwen3_5::detail {
namespace {

constexpr std::uint32_t kRequiredPageColumns =
    static_cast<std::uint32_t>(kPagedKVPageSize);

} // namespace

KVMemFollowerRetainedPages::KVMemFollowerRetainedPages(LogicalKVPageStore& pages,
                                                       std::uint32_t block_count)
    : store_(&pages), pages_(block_count), committed_rows_(block_count, 0) {}

KVMemFollowerRetainedPages::~KVMemFollowerRetainedPages() noexcept {
    for (const PagePair& pair : pages_) {
        if (!pair[0].valid()) { continue; }
        for (const LogicalKVPageHandle page : pair) {
            if (page.valid() && !store_->release_reference(page, false)) {
                std::terminate();
            }
        }
    }
}

bool KVMemFollowerRetainedPages::has(std::uint32_t block_id) const noexcept {
    return block_id < pages_.size() && pages_[block_id][0].valid();
}

KVMemFollowerRetainedPages::PagePair
KVMemFollowerRetainedPages::pages(std::uint32_t block_id) const {
    validate_block_id(block_id);
    if (!has(block_id)) {
        throw std::logic_error("MTP follower retained pages are not present for this block");
    }
    return pages_[block_id];
}

std::uint32_t KVMemFollowerRetainedPages::committed_rows(std::uint32_t block_id) const {
    validate_block_id(block_id);
    if (!has(block_id)) {
        throw std::logic_error("MTP follower retained coverage is not present for this block");
    }
    return committed_rows_[block_id];
}

void KVMemFollowerRetainedPages::retain_existing(std::uint32_t block_id,
                                                const PagePair& pair,
                                                std::uint32_t committed_rows) {
    validate_block_id(block_id);
    if (has(block_id)) {
        throw std::logic_error("MTP follower block already owns retained pages");
    }
    validate_pair(pair, committed_rows);
    for (const LogicalKVPageHandle page : pair) {
        if (!page.valid()) { continue; }
        if (!store_->can_retain_reference(page, false)) {
            throw std::logic_error("MTP follower page reference is not retainable");
        }
    }

    store_->retain_reference(pair[0], false);
    try {
        if (pair[1].valid()) { store_->retain_reference(pair[1], false); }
    } catch (...) {
        if (!store_->release_reference(pair[0], false)) { std::terminate(); }
        throw;
    }
    pages_[block_id] = pair;
    committed_rows_[block_id] = committed_rows;
}

void KVMemFollowerRetainedPages::adopt_new(std::uint32_t block_id, const PagePair& pair) {
    validate_block_id(block_id);
    if (has(block_id)) {
        throw std::logic_error("MTP follower block already owns retained pages");
    }
    validate_pair(pair, 2U * kRequiredPageColumns);
    for (const LogicalKVPageHandle page : pair) {
        if (!page.valid()) { continue; }
        if (store_->address_references(page) == 0 ||
            !store_->can_release_reference(page, false)) {
            throw std::logic_error("MTP follower page has no adoptable external reference");
        }
    }

    pages_[block_id] = pair;
    committed_rows_[block_id] = 2U * kRequiredPageColumns;
}

void KVMemFollowerRetainedPages::validate_block_id(std::uint32_t block_id) const {
    if (block_id >= pages_.size()) {
        throw std::out_of_range("MTP follower block id exceeds retained-page capacity");
    }
}

void KVMemFollowerRetainedPages::validate_pair(const PagePair& pair,
                                              std::uint32_t committed_rows) const {
    const bool two_pages = committed_rows > kRequiredPageColumns;
    if (committed_rows == 0 || committed_rows > 2U * kRequiredPageColumns ||
        !pair[0].valid() || pair[1].valid() != two_pages ||
        (two_pages && pair[0] == pair[1])) {
        throw std::invalid_argument("MTP follower pages do not match their committed row prefix");
    }
    std::uint32_t remaining = committed_rows;
    for (const LogicalKVPageHandle page : pair) {
        if (!page.valid()) { continue; }
        const std::uint32_t required_columns = std::min(remaining, kRequiredPageColumns);
        if (!store_->valid(page) || !store_->device_resident(page) ||
            store_->committed_columns(page) < required_columns ||
            store_->writer_references(page) != 0) {
            throw std::invalid_argument(
                "MTP follower pages must cover the committed prefix and be resident/read-only");
        }
        remaining -= required_columns;
    }
}

} // namespace ninfer::models::qwen3_5::detail
