// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#include "models/qwen3_5/program/storage/kvmem_follower_execution_map.h"

#include "models/qwen3_5/program/storage/kv_store.h"

#include <kvmem/kvmem_store.hpp>

#include <cstring>
#include <stdexcept>
#include <type_traits>
#include <unordered_set>

namespace ninfer::models::qwen3_5::detail {

static_assert(kPagedKVPageSize ==
              static_cast<std::int32_t>(KVMemFollowerExecutionMap::kPageTokens));
static_assert(std::is_trivially_copyable_v<DeviceKVPageHandle>);
static_assert(std::has_unique_object_representations_v<DeviceKVPageHandle>);

std::vector<KVMemFollowerExecutionRecord> KVMemFollowerExecutionMap::from_native_resident(
    const kvmem::KvMemStore& store, std::uint32_t target_frontier,
    std::uint32_t follower_frontier) {
    if (store.config().block_tokens != kBlockTokens || target_frontier < follower_frontier ||
        target_frontier - follower_frontier > 1U) {
        throw std::logic_error("native follower has incompatible resident frontiers");
    }
    const bool deferred_last_row = target_frontier != follower_frontier;
    if (deferred_last_row &&
        (store.blocks().empty() || store.blocks().back().gpu_slot < 0 ||
         store.blocks().back().orig_pos_end() != store.total_tokens())) {
        throw std::logic_error("native follower deferred row is not the resident logical tail");
    }
    std::vector<KVMemFollowerExecutionRecord> records;
    records.reserve(store.block_count());
    std::uint64_t execution = 0;
    for (const auto& block : store.blocks()) {
        if (block.gpu_slot < 0 || block.n_tokens == 0) { continue; }
        const std::uint32_t rows = block.n_tokens -
            (deferred_last_row && block.orig_pos_end() == store.total_tokens() ? 1U : 0U);
        if (block.block_id >= store.block_count() ||
            block.orig_pos_start % kBlockTokens != 0 || block.n_tokens > kBlockTokens ||
            execution > follower_frontier || rows > follower_frontier - execution) {
            throw std::logic_error("native follower resident block is not a compact prefix");
        }
        if (rows == 0) { continue; }
        records.push_back(KVMemFollowerExecutionRecord{
            .native_block_id = block.block_id,
            .original_position = block.orig_pos_start,
            .execution_begin = static_cast<std::uint32_t>(execution),
            .committed_rows = rows,
        });
        execution += rows;
    }
    if (execution != follower_frontier) {
        throw std::logic_error("native follower resident rows do not cover the accepted prefix");
    }
    return records;
}

std::vector<KVMemFollowerResolvedBlock> KVMemFollowerExecutionMap::resolve(
    std::span<const KVMemFollowerExecutionRecord> records,
    const KVAddressSpaceStore& addresses, KVAddressSpaceHandle mtp_address) {
    if (!addresses.valid(mtp_address)) {
        throw std::invalid_argument("MTP follower execution map requires a valid KV address");
    }

    const std::uint32_t committed_frontier = addresses.committed_frontier(mtp_address);
    const std::uint32_t mapped_pages = addresses.mapped_pages(mtp_address);
    std::unordered_set<std::uint32_t> native_block_ids;
    std::unordered_set<std::uint32_t> original_positions;
    native_block_ids.reserve(records.size());
    original_positions.reserve(records.size());

    std::vector<KVMemFollowerResolvedBlock> resolved;
    resolved.reserve(records.size());
    std::uint64_t prior_execution_end = 0;
    bool have_prior_record = false;

    for (const KVMemFollowerExecutionRecord& record : records) {
        if (record.original_position % kBlockTokens != 0 ||
            record.execution_begin % kPageTokens != 0 || record.committed_rows == 0 ||
            record.committed_rows > kBlockTokens) {
            throw std::invalid_argument(
                "MTP follower execution record has invalid alignment or row count");
        }
        if (!native_block_ids.insert(record.native_block_id).second ||
            !original_positions.insert(record.original_position).second) {
            throw std::invalid_argument(
                "MTP follower execution records repeat a native or original block");
        }

        const std::uint64_t execution_end =
            static_cast<std::uint64_t>(record.execution_begin) + record.committed_rows;
        if (have_prior_record && record.execution_begin < prior_execution_end) {
            throw std::invalid_argument(
                "MTP follower execution records must be sorted and non-overlapping");
        }
        if (execution_end > committed_frontier) {
            throw std::invalid_argument(
                "MTP follower execution record extends beyond the committed MTP frontier");
        }

        const std::uint64_t required_pages =
            (execution_end + kPageTokens - 1U) / kPageTokens;
        if (required_pages > mapped_pages) {
            throw std::invalid_argument(
                "MTP follower execution record is not covered by mapped address pages");
        }

        const std::uint32_t first_page = record.execution_begin / kPageTokens;
        const LogicalKVPageHandle first_logical = addresses.logical_page(mtp_address, first_page);
        if (!first_logical.valid()) {
            throw std::logic_error("MTP follower address contains an invalid mapped page");
        }

        // Check both lease identity and physical identity. A caller may never
        // stage a 128-row block through an aliased page pair.
        std::array<DeviceKVPageHandle, 2> pages{};
        pages[0] = addresses.physical_page(mtp_address, first_page);
        if (!pages[0].valid()) {
            throw std::logic_error("MTP follower address page has no valid physical handle");
        }

        if (record.committed_rows > kPageTokens) {
            const std::uint32_t second_page = first_page + 1U;
            const LogicalKVPageHandle second_logical =
                addresses.logical_page(mtp_address, second_page);
            if (!second_logical.valid() || second_logical == first_logical) {
                throw std::logic_error(
                    "MTP follower two-page record requires distinct mapped pages");
            }
            pages[1] = addresses.physical_page(mtp_address, second_page);
            if (!pages[1].valid() ||
                std::memcmp(&pages[0], &pages[1], sizeof(DeviceKVPageHandle)) == 0) {
                throw std::logic_error(
                    "MTP follower second page has no distinct physical handle");
            }
        }

        resolved.push_back({.record = record, .mtp_pages = pages});
        prior_execution_end = execution_end;
        have_prior_record = true;
    }

    return resolved;
}

} // namespace ninfer::models::qwen3_5::detail
