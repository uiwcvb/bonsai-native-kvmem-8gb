// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <kvmem/snapshot.hpp>

#include <cstdint>
#include <filesystem>
#include <functional>
#include <memory>
#include <span>

namespace kvmem { class RawKvStore; }
struct kvmem_session_payload;

namespace ninfer::models::qwen3_5::detail {

class KVMemFrozenRaw;
class KVMemParkedSnapshotFile;
class KVMemQueryBoundaryCheckpoint;

struct KVMemParkedFileState {
    using WriteCallback = std::function<void(kvmem::SnapshotWriter &)>;
    using ReadCallback = std::function<void(kvmem::SnapshotReader &)>;

    struct PayloadIdentity {
        int id;
        std::uint64_t generation;
    };

    KVMemParkedFileState(std::filesystem::path root, std::uint64_t byte_limit);
    ~KVMemParkedFileState();
    KVMemParkedFileState(const KVMemParkedFileState &) = delete;
    KVMemParkedFileState & operator=(const KVMemParkedFileState &) = delete;

    int allocate_id();
    PayloadIdentity allocate_payload_identity();
    std::uint64_t file_generation() const noexcept;
    std::uint64_t bytes() const noexcept;
    std::uint64_t limit() const noexcept;
    std::uint64_t available() const;
    std::uint64_t session_bytes(int id) const noexcept;
    bool erase_session(int id) noexcept;
    void save_legacy(int id, std::uint64_t payload_bytes, const WriteCallback & write);
    void load_legacy(int id, const ReadCallback & read) const;
    void spill(kvmem_session_payload & payload, std::uint32_t index);
    void restore(kvmem_session_payload & payload, std::uint32_t index);
    void load_chunk(int id, std::uint32_t index, const ReadCallback & read) const;
    bool chunk_ready(int id, std::uint32_t index) const noexcept;
    bool chunk_present(int id, std::uint32_t index) const noexcept;
    std::uint64_t chunk_bytes(int id, std::uint32_t index) const noexcept;
    std::filesystem::path path(int id, std::uint32_t index = 0) const;
    void set_fault(std::function<void(const char *, int, std::uint32_t)> fault);

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

class KVMemParkedFileCache {
public:
    using WriteCallback = std::function<void(kvmem::SnapshotWriter &)>;

    KVMemParkedFileCache(std::filesystem::path root, std::uint64_t byte_limit);
    ~KVMemParkedFileCache();

    KVMemParkedFileCache(const KVMemParkedFileCache &) = delete;
    KVMemParkedFileCache & operator=(const KVMemParkedFileCache &) = delete;
    KVMemParkedFileCache(KVMemParkedFileCache &&) noexcept;
    KVMemParkedFileCache & operator=(KVMemParkedFileCache &&) noexcept;

    // The callback receives a fresh payload-only Native stream. Its checksum
    // excludes the containing file's identity header, and it must emit exactly
    // payload_bytes. The Native file manager retains its own whole-file scope.
    std::unique_ptr<KVMemParkedSnapshotFile> write(
        std::uint64_t payload_bytes,
        const WriteCallback & write);

    std::unique_ptr<KVMemFrozenRaw> freeze_raw(
        std::span<kvmem::RawKvStore * const> stores,
        std::uint64_t group_bytes = 16ull * 1024 * 1024,
        std::span<const std::shared_ptr<const KVMemQueryBoundaryCheckpoint>> checkpoints = {});

    // bytes() reports native charged bytes, including each snapshot checksum.
    std::uint64_t bytes() const noexcept;
    std::uint64_t limit() const noexcept;
    std::uint64_t available() const;
    static std::uint64_t charged_bytes(std::uint64_t payload_bytes);
    // Forward the pinned file manager's deterministic transfer fault hook.
    void set_fault(std::function<void(const char*, int, std::uint32_t)> fault);

private:
    std::shared_ptr<KVMemParkedFileState> state_;
};

class KVMemParkedSnapshotFile {
public:
    using ReadCallback = std::function<void(kvmem::SnapshotReader &)>;

    ~KVMemParkedSnapshotFile() noexcept;

    KVMemParkedSnapshotFile(const KVMemParkedSnapshotFile &) = delete;
    KVMemParkedSnapshotFile & operator=(const KVMemParkedSnapshotFile &) = delete;
    KVMemParkedSnapshotFile(KVMemParkedSnapshotFile &&) = delete;
    KVMemParkedSnapshotFile & operator=(KVMemParkedSnapshotFile &&) = delete;

    std::uint64_t payload_bytes() const noexcept { return payload_bytes_; }
    std::uint64_t charged_bytes() const noexcept;
    // Explicit release is required before a planner may credit disk space.
    // Failure retains both the native record and its charge for retry.
    bool erase() noexcept;
    std::filesystem::path path() const;
    // The callback receives a fresh payload-only Native stream and must consume
    // the complete payload. Whole-file validation follows in the Native owner.
    void load(const ReadCallback & read) const;

private:
    friend class KVMemParkedFileCache;

    KVMemParkedSnapshotFile(
        std::shared_ptr<KVMemParkedFileState> state,
        int id,
        std::uint64_t payload_bytes) noexcept;

    std::shared_ptr<KVMemParkedFileState> state_;
    int id_;
    std::uint64_t payload_bytes_;
};

} // namespace ninfer::models::qwen3_5::detail
