// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#pragma once

#include "core/device.h"
#include "core/host_kv_arena.h"
#include "models/qwen3_5/program/storage/kv_store.h"

#include <kvmem/kvmem_backend.hpp>

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <vector>

namespace kvmem {
class KvMemStore;
}

namespace ninfer::models::qwen3_5::detail {

struct KVMemSelectedBlockOffset {
    std::uint32_t block_id = 0;
    std::uint32_t original_begin = 0;
    std::uint32_t execution_begin = 0;
    std::uint32_t tokens = 0;
};

/*
 * Local NInfer adapter for KVMem's byte-and-slot backend contract. It maps each
 * KVMem GPU slot to two NInfer 64-token Device pages and serializes those pages
 * with NInfer's HostKVPageLayout. Exclusive Host archive traversal instead
 * routes the same Native byte hooks through the existing one-block buffer.
 *
 * Upstream interface provenance: kvmem::KvMemBackend in
 * third_party/kvmem/kvmem/include/kvmem/kvmem_backend.hpp, from the pinned
 * third_party/kvmem submodule commit 95a2155b75f41eada1398c86b19dcf9703581b30.
 * The page mapping, layout conversion, and ownership checks below are NInfer
 * code; this file is not an upstream KVMem implementation or a verbatim copy.
 *
 * The owner must drain/truncate its KvMemRuntime and detach execution-address
 * references before destroying this adapter. DeviceContext and page store
 * outlive the adapter. Adopting pages retains one inactive reference; the
 * caller releases its previous address reference before runtime eviction.
 */
class KVMemPageBackend final : public kvmem::KvMemBackend {
public:
    KVMemPageBackend(DeviceContext& device, LogicalKVPageStore& pages);

    [[nodiscard]] std::uint64_t block_bytes() const noexcept { return block_bytes_; }
    [[nodiscard]] std::uint32_t occupied_slots() const noexcept { return occupied_slots_; }

    // An exclusive, synchronous archive traversal uses Native's ordinary
    // slot/copy hooks with the existing one-block Host bounce buffer. No
    // inference pages are materialized. The caller must return each block to
    // Native CPU ownership before publishing bytes or leaving successfully;
    // its existing recovery/fail-stop rules still own an interrupted traversal.
    class HostArchiveScope {
    public:
        explicit HostArchiveScope(KVMemPageBackend& backend);
        ~HostArchiveScope() noexcept;
        HostArchiveScope(const HostArchiveScope&) = delete;
        HostArchiveScope& operator=(const HostArchiveScope&) = delete;
    private:
        KVMemPageBackend* backend_;
    };

    // Native prepare_working_set assigns an incoming block a slot before its
    // prefill writes. Reserve only the slot identity here; NInfer's writer
    // supplies the actual pages to adopt afterward, without duplicate GPU
    // placeholder pages during prefill. Stage-in of an old block still uses
    // alloc_gpu_slot(), which materializes pages immediately.
    [[nodiscard]] std::int32_t reserve_gpu_slot_for_append();

    // KvMemRuntime::admit_incoming invokes alloc_gpu_slot() for each nonresident
    // stage_in block, in plan order. An appended block whose original start is
    // at/after the pre-append frontier has no Host bytes yet: reserve only its
    // slot identity, then adopt the real writer pages after forward. Older
    // blocks still need materialized pages for the native Host->GPU copy.
    // Program must bracket exactly one admit_incoming call with these methods;
    // abort_prefill_admission is for its failure path only.
    void begin_prefill_admission(const kvmem::KvMemStore& store,
                                 std::span<const std::uint32_t> stage_in,
                                 std::uint32_t pre_append_frontier);
    void finish_prefill_admission();
    void abort_prefill_admission() noexcept;

    // Post-prefill handoff into the native GPU slot reserved by
    // prepare_working_set, or into an exact same-geometry replay reservation.
    // The slot has no published block pages; any materialized placeholder
    // pages are released only after source normalization and retention.
    // `valid_tokens` is the native block frontier
    // (1..128). Bytes after that frontier are zeroed before the pages become
    // full-page inputs to KVAddressSpaceStore; selected views still publish
    // only valid_tokens. This does not make an unbound native slot a
    // KVAddressSpaceStore write target: Program must publish the accepted
    // prefill pages through this operation before selection or stage-out.
    // Real NInfer writer addresses must be deactivated first; exclusive
    // inactive pages and detached producer pages are both accepted.
    void adopt_prefilled_block(std::uint32_t block_id, std::int32_t slot,
                               std::array<LogicalKVPageHandle, 2> pages,
                               std::uint32_t valid_tokens);

    // Handoff from a deactivated NInfer prefill address. The new native block
    // may follow selected history in that address, so the caller supplies its
    // compact execution start. It must begin at a 128-token page-pair boundary;
    // an unaligned selected view needs a separate packing path, not misindexed
    // KV pages. A one-page tail gets a second zero-filled page from this adapter.
    // A complete 128-token block may precede the source's committed frontier;
    // a partial block must end exactly at that frontier.
    // The source address remains caller-owned until released by the caller.
    void adopt_inactive_prefill_address(std::uint32_t block_id, std::int32_t slot,
                                       KVAddressSpaceStore& addresses,
                                       KVAddressSpaceHandle source,
                                       std::uint32_t execution_begin,
                                       std::uint32_t valid_tokens);

    // Replace the pages of an already adopted partial tail after accepted
    // COW growth. expected_pages/tokens make the operation a checked handoff.
    // Replaced slot references are released only with no active address view;
    // other inactive address references keep the old logical page alive until
    // those views release it.
    void replace_partial_tail_block(std::uint32_t block_id, std::int32_t slot,
                                    std::array<LogicalKVPageHandle, 2> expected_pages,
                                    std::uint32_t expected_tokens,
                                    std::array<LogicalKVPageHandle, 2> replacement_pages,
                                    std::uint32_t new_tokens);

    // Checked growth handoff from a deactivated NInfer COW writer address.
    // The old native slot must have no active execution view. For a tail that
    // still fits in its first 64-token page, keep the native slot's empty
    // second page when the writer did not map one. A completed 128-token head
    // may precede further accepted blocks in this writer; a partial block must
    // remain its exact committed end.
    void replace_inactive_tail_address(std::uint32_t block_id, std::int32_t slot,
                                       KVAddressSpaceStore& addresses,
                                       KVAddressSpaceHandle source,
                                       std::uint32_t execution_begin,
                                       std::uint32_t expected_tokens,
                                       std::uint32_t new_tokens);

    // Replace an already adopted or replay-reserved block with accepted pages.
    // The inactive writer must contain the same-length block at the supplied
    // 128-token-aligned compact execution start. Unchanged prefix pages stay
    // slot-owned as-is; replaced pages are normalized before the slot refs are
    // switched. A replay-reserved slot adopts its new pages without allocating
    // duplicate old-query backing. Active views of replaced old pages prevent
    // the handoff.
    void replace_replayed_block(std::uint32_t block_id, std::int32_t slot,
                                KVAddressSpaceStore& addresses,
                                KVAddressSpaceHandle inactive_writer,
                                std::uint32_t execution_begin,
                                std::uint32_t valid_tokens);

    [[nodiscard]] std::array<LogicalKVPageHandle, 2>
    pages_for_slot(std::uint32_t block_id, std::int32_t slot) const;

    // Bind native-selected blocks to one inactive NInfer address in original
    // order. A partial final block exposes only n_tokens, not its padded GPU
    // columns. Its shared tail must be forked before any subsequent write.
    // Release the address after GPU work and before KVMem evicts a slot.
    // `require_working_set=false` is only for rebuilding a pinned generation
    // view from an externally checked exact GPU-resident block list: a short
    // all-resident prompt and newly generated blocks may lack that Store flag.
    [[nodiscard]] std::vector<KVMemSelectedBlockOffset> install_selected_blocks(
        const kvmem::KvMemStore& store, std::span<const std::uint32_t> selected_ids,
        KVAddressSpaceStore& addresses, KVAddressSpaceHandle destination,
        bool require_working_set = true);

    // Install the native selection into an inactive, read-only address, then
    // fork it into an active writer. A partial final page is copied before the
    // writer can append; completed pages remain shared with KVMem. The caller
    // owns both addresses and must release the read-only address before native
    // stage-out/eviction. On failure it must release any installed source view.
    [[nodiscard]] std::vector<KVMemSelectedBlockOffset> install_selected_for_append(
        const kvmem::KvMemStore& store, std::span<const std::uint32_t> selected_ids,
        KVAddressSpaceStore& addresses, KVAddressSpaceHandle read_only_source,
        KVAddressSpaceHandle writable_destination, std::uint32_t page_entitlement,
        std::int32_t execution_row, bool require_working_set = true);

    // Install selected original-order history strictly before the selected
    // block containing replay_logical_begin, then fork it into an active
    // replay writer. The returned frontier is compact execution-token count,
    // not an original position. A split 64-token tail is copied by the prefix
    // fork; a zero-length prefix activates an empty writer. The caller owns
    // read_only_source and must release it, including after a failed call that
    // installed the source view. After the prefix fork, obsolete query/suffix
    // slot references are released, but native IDs, slots and row geometry are
    // retained. Those slots cannot be read or staged out until accepted replay
    // pages are published by replace_replayed_block. Failure after this point
    // requires the caller's existing physical-transition fail-stop cleanup.
    [[nodiscard]] std::uint32_t install_selected_for_replay(
        const kvmem::KvMemStore& store, std::span<const std::uint32_t> selected_ids,
        std::uint32_t replay_logical_begin, KVAddressSpaceStore& addresses,
        KVAddressSpaceHandle read_only_source,
        KVAddressSpaceHandle writable_destination, std::uint32_t page_entitlement,
        std::int32_t execution_row);

    std::int32_t alloc_gpu_slot() override;
    bool has_dynamic_cpu_storage() const noexcept override { return true; }
    std::unique_ptr<kvmem::KvMemCpuStorage> make_cpu_storage(
        std::uint32_t slots, std::uint64_t bytes) override;
    void free_gpu_slot(std::int32_t slot) override;
    void copy_block_to_host(std::uint32_t block_id, std::int32_t slot, void* host,
                            std::uint64_t bytes) override;
    void copy_block_from_host(std::uint32_t block_id, std::int32_t slot, const void* host,
                              std::uint64_t bytes) override;

private:
    struct Slot {
        std::array<LogicalKVPageHandle, 2> pages{};
        std::optional<std::uint32_t> block_id;
        std::optional<std::uint32_t> valid_tokens;
        bool occupied = false;
        bool pages_materialized = false;
        bool reserved_for_replay = false;
    };

    [[nodiscard]] Slot& require_slot(std::int32_t slot);
    [[nodiscard]] const Slot& require_slot(std::int32_t slot) const;
    [[nodiscard]] std::int32_t reserve_empty_slot();
    [[nodiscard]] std::array<DeviceKVPageHandle, 2> physical_pages(const Slot& slot) const;
    [[nodiscard]] bool can_normalize_partial_page(LogicalKVPageHandle page,
                                                  std::uint32_t valid_columns) const noexcept;
    void normalize_partial_pages(std::span<const LogicalKVPageHandle> pages,
                                std::span<const std::uint32_t> valid_columns);

    DeviceContext* device_ = nullptr;
    LogicalKVPageStore* pages_ = nullptr;
    HostKVPageLayout layout_;
    std::optional<PinnedHostBuffer> bounce_;
    std::uint64_t block_bytes_ = 0;
    std::uint32_t occupied_slots_ = 0;
    std::vector<Slot> slots_;
    std::vector<std::int32_t> free_slots_;
    std::vector<bool> admission_reserve_only_;
    std::size_t admission_cursor_ = 0;
    bool admission_active_ = false;
    bool host_archive_active_ = false;
    std::int32_t host_archive_slot_ = -1;
};

} // namespace ninfer::models::qwen3_5::detail
