// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#pragma once

#include <kvmem/snapshot.hpp>

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <span>
#include <stdexcept>
#include <utility>

namespace ninfer::models::qwen3_5::detail {

// Native v5 keeps its established outer FNV seed, which deliberately differs
// from the inner native archive seed. Adapt Native's bounded sink traversal,
// but compute only the required outer hash, not another unused archive hash.
class KVMemSnapshotOutput final {
public:
    using Sink = std::function<void(std::span<const std::uint8_t>)>;

    explicit KVMemSnapshotOutput(Sink sink) : sink_(std::move(sink)) {}

    KVMemSnapshotOutput(const KVMemSnapshotOutput&) = delete;
    KVMemSnapshotOutput& operator=(const KVMemSnapshotOutput&) = delete;
    KVMemSnapshotOutput(KVMemSnapshotOutput&&) = delete;
    KVMemSnapshotOutput& operator=(KVMemSnapshotOutput&&) = delete;

    void write(const void* data, std::size_t count) {
        if (finished_) { throw std::logic_error("native snapshot output already finished"); }
        if (count > std::numeric_limits<std::uint64_t>::max() - bytes_) {
            throw std::length_error("native snapshot output size overflow");
        }
        const auto* next = static_cast<const std::uint8_t*>(data);
        while (count != 0) {
            const auto part = std::min<std::size_t>(count, kvmem::snapshot_chunk);
            const auto input = std::span(next, part);
            sink_(input);
            for (const auto byte : input) { hash_ = (hash_ ^ byte) * 1099511628211ULL; }
            bytes_ += part;
            next += part;
            count -= part;
        }
    }
    void finish() {
        if (finished_) { throw std::logic_error("native snapshot output already finished"); }
        const std::uint64_t checksum = hash_;
        write(&checksum, sizeof(checksum));
        finished_ = true;
    }
    [[nodiscard]] std::uint64_t bytes() const noexcept { return bytes_; }

private:
    Sink sink_;
    std::uint64_t hash_ = 1469598103934665603ULL;
    std::uint64_t bytes_ = 0;
    bool finished_ = false;
};

} // namespace ninfer::models::qwen3_5::detail
