// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#include "models/qwen3_5/program/storage/kvmem_conversation.h"

#include "models/qwen3_5/program/prefix_identity.h"
#include "models/qwen3_5/program/storage/kvmem_page_backend.h"
#include "models/qwen3_5/program/storage/kvmem_prefill_admission.h"
#include "models/qwen3_5/program/storage/kvmem_parked_file.h"
#include "models/qwen3_5/program/storage/kvmem_frozen_raw.h"
#include "models/qwen3_5/program/storage/kvmem_parked_snapshot_io.h"
#include "models/qwen3_5/program/storage/kvmem_query_checkpoint.h"
#include "models/qwen3_5/program/storage/kvmem_raw_snapshot_preflight.h"
#include "models/qwen3_5/program/storage/kvmem_retrieval.h"
#include "models/qwen3_5/program/storage/kvmem_session_transfer.h"

#include <algorithm>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstring>
#include <exception>
#include <filesystem>
#include <fstream>
#include <ios>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>

#include <kvmem/snapshot.hpp>

namespace ninfer::models::qwen3_5::detail {
namespace {

constexpr std::array<std::uint8_t, 8> kParkedSnapshotMagic = {
    'K', 'V', 'P', 'A', 'R', 'K', '0', '1'};
constexpr std::uint32_t kParkedSnapshotVersion = 5;
// Same-run Runtime record. Raw/follower shape and payloads are owned by the
// separate native KVCHUNK2 manifest; this format is not a portable snapshot.
constexpr std::uint32_t kRuntimeSnapshotVersion = 6;
constexpr std::uint32_t kLogicalBlockTokens = 128;
constexpr std::uint64_t kMaxParkedSnapshotBytes = kKVMemParkedSnapshotMaxBytes;
constexpr std::uint64_t kMaxParkedBlockBytes = 64ull * 1024ull * 1024ull;
constexpr std::uint32_t kMaxParkedLogicalTokens = 16u * 1024u * 1024u;
// Native save_chunk/load_chunk keep the stream and snapshot adapter alive
// together. These explicit allowances count their C++ object storage only;
// dynamic filebuf and OS caching are outside this estimate, with the existing
// Native headroom margin still in effect.
constexpr std::uint64_t kNativeRawWriteScratchBytes =
    sizeof(std::ofstream) + sizeof(kvmem::SnapshotWriter);
constexpr std::uint64_t kNativeRawReadScratchBytes =
    sizeof(std::ifstream) + sizeof(kvmem::SnapshotReader);

[[noreturn]] void throw_snapshot_data_error(bool reading_snapshot, const char* message) {
    if (reading_snapshot) { throw kvmem::SnapshotCorrupt(message); }
    throw std::invalid_argument(message);
}

std::uint64_t metadata_ram_bytes(const KVMemConversation::SessionMetadata& metadata) {
    auto bytes = std::uint64_t(metadata.row_positions.capacity()) *
                 sizeof(KVMemConversation::RowPosition);
    bytes = kvmem_session_checked_add(bytes,
        std::uint64_t(metadata.q_sum.capacity()) * sizeof(std::vector<float>));
    for (const auto& layer : metadata.q_sum) {
        bytes = kvmem_session_checked_add(bytes, std::uint64_t(layer.capacity()) * sizeof(float));
    }
    bytes = kvmem_session_checked_add(bytes,
        std::uint64_t(metadata.q_count.capacity()) * sizeof(std::uint32_t));
    bytes = kvmem_session_checked_add(bytes,
        std::uint64_t(metadata.exact_query_media.capacity()) * sizeof(VisionItem));
    for (const auto& item : metadata.exact_query_media) {
        bytes = kvmem_session_checked_add(bytes,
            std::uint64_t(item.timestamps.capacity()) * sizeof(double));
        bytes = kvmem_session_checked_add(bytes,
            std::uint64_t(item.token_spans.capacity()) * sizeof(TokenSpan));
    }
    return kvmem_session_checked_add(bytes,
        std::uint64_t(metadata.prior_resident_block_ids.capacity()) * sizeof(std::uint32_t));
}

std::uint64_t host_bundle_ram_bytes(const kvmem::KvMemRuntime* runtime,
                                   const kvmem::RawKvStore* raw,
                                   const kvmem::RawKvStore* follower) {
    std::uint64_t bytes = runtime ? runtime->allocated_bytes() : 0;
    bytes = kvmem_session_checked_add(bytes, raw ? raw->allocated_bytes() : 0);
    return kvmem_session_checked_add(bytes, follower ? follower->allocated_bytes() : 0);
}

std::uint64_t checksum64(std::span<const std::uint8_t> bytes) noexcept {
    std::uint64_t hash = 14695981039346656037ull;
    for (const std::uint8_t byte : bytes) {
        hash = (hash ^ byte) * 1099511628211ull;
    }
    return hash;
}

using ParkedSnapshotWriter = KVMemParkedSnapshotWriter;
using ParkedSnapshotReader = KVMemParkedSnapshotReader;

void encode_raw_config(ParkedSnapshotWriter& out, const kvmem::RawKvStoreConfig& cfg) {
    out.put_u32(cfg.n_layer);
    out.put_u32(cfg.n_embd_k);
    out.put_u32(cfg.n_embd_v);
    out.put_u32(cfg.block_tokens);
    out.put_u64(cfg.k_row_bytes);
    out.put_u64(cfg.k_gpu_row_bytes);
    out.put_u64(cfg.v_gpu_row_bytes);
    out.put_u64(cfg.nvme_bytes);
    out.put_string(cfg.nvme_dir);
    out.put_string(cfg.nvme_file);
}

void encode_runtime_config(ParkedSnapshotWriter& out,
                           const kvmem::KvMemRuntimeConfig& cfg) {
    const kvmem::KvMemStoreConfig& s = cfg.store;
    out.put_u64(cfg.cpu_bytes);
    out.put_u64(cfg.nvme_bytes);
    out.put_string(cfg.nvme_dir);

    out.put_u32(s.block_tokens);
    out.put_u32(s.select_budget);
    out.put_u32(s.prefill_budget);
    out.put_u32(s.gen_budget);
    out.put_u32(s.sink_blocks);
    out.put_u32(s.recent_blocks);
    out.put_enum(s.select_method);
    out.put_enum(s.select_policy);
    out.put_enum(s.retrieval_method);
    out.put_enum(s.index_placement);
    out.put_u64(s.index_staging_bytes);
    out.put_string(s.numa_policy);
    out.put_enum(s.adaptive_score_mode);
    out.put_u32(s.n_subblocks);
    out.put_enum(s.prototype_mode);
    out.put_f64(s.adaptive_gain_1to2);
    out.put_f64(s.adaptive_gain_2to4);
    out.put_enum(s.subblock_reduce);
    out.put_enum(s.semantic_expansion);
    out.put_enum(s.group_score_reduce);
    out.put_f64(s.group_length_norm_alpha);
    out.put_enum(s.update_mode);
    out.put_bool(s.optimize_stage_out);
    out.put_bool(s.optimize_stage_in);
    out.put_bool(s.optimize_pack);
    out.put_bool(s.immutable_source_k);
    out.put_bool(s.mtp_enabled);
    out.put_u32(s.immutable_refresh_remaps);
    out.put_u64(s.immutable_refresh_abs_delta_tokens);
    out.put_u64(s.immutable_max_baked_position);
    out.put_u32(s.deltanet_layers);
    out.put_enum(s.deltanet_layer_policy);
    out.put_u64(s.deltanet_mem_budget_bytes);
    out.put_bool(s.deltanet_decay);
    out.put_u32(s.deltanet_topk_q);
    out.put_u32(s.deltanet_topk_h);
    out.put_u32(s.retrieval_blocks);
    out.put_u32(s.profile_blocks);
    out.put_f64(s.gpu_memory_ratio);
    out.put_f64(s.gpu_high_watermark);
    out.put_f64(s.gpu_low_watermark);
    out.put_u32(s.estimated_gpu_block_capacity);
    out.put_u64(s.gpu_resident_block_bytes);
    out.put_u64(s.estimated_block_bytes);
    out.put_u64(s.cpu_tier_bytes);
    out.put_u64(s.nvme_tier_bytes);
    out.put_string(s.nvme_tier_dir);
    out.put_bool(s.raw_k_nvme);
}

std::vector<std::uint8_t> encode_raw_config(const kvmem::RawKvStoreConfig& cfg) {
    ParkedSnapshotWriter writer;
    encode_raw_config(writer, cfg);
    return std::move(writer).take();
}

std::vector<std::uint8_t> encode_runtime_config(const kvmem::KvMemRuntimeConfig& cfg) {
    ParkedSnapshotWriter writer;
    encode_runtime_config(writer, cfg);
    return std::move(writer).take();
}

void expect_config_blob(ParkedSnapshotReader& in, std::span<const std::uint8_t> expected,
                        const char* label) {
    const auto actual = in.blob();
    if (!std::equal(actual.begin(), actual.end(), expected.begin(), expected.end())) {
        // Expected configuration comes from the immutable Program, not the
        // file. Match native SnapshotReader::expect on incompatible bytes;
        // trusted caller geometry is validated separately before parsing.
        throw kvmem::SnapshotCorrupt(std::string("KVMem parked snapshot ") + label +
                                     " configuration does not match");
    }
}

void write_raw_store(ParkedSnapshotWriter& out, kvmem::RawKvStore& raw, bool sizing_only) {
    kvmem::SnapshotWriter sizing;
    raw.snapshot_write(sizing);
    if (sizing.bytes() > kMaxParkedSnapshotBytes ||
        sizing.bytes() > std::numeric_limits<std::size_t>::max()) {
        throw std::length_error("KVMem RawKvStore snapshot exceeds its byte limit");
    }
    out.put_u64(sizing.bytes());
    if (sizing_only) { out.count_bytes(sizing.bytes()); return; }
    kvmem::SnapshotWriter writer([&out](const void* data, std::size_t count) {
        out.put_bytes({static_cast<const std::uint8_t*>(data), count});
    });
    raw.snapshot_write(writer);
    if (writer.bytes() != sizing.bytes()) {
        throw std::runtime_error("KVMem RawKvStore snapshot changed while encoding");
    }
}

std::uint64_t read_raw_store(ParkedSnapshotReader& in, kvmem::RawKvStore* raw,
                             const kvmem::RawKvStoreConfig& config,
                             std::uint32_t logical_tokens, std::uint32_t max_blocks,
                             std::span<const std::uint32_t> required_blocks = {}) {
    const std::uint64_t bytes = in.u64();
    if (bytes > in.remaining()) {
        throw kvmem::SnapshotCorrupt("truncated KVMem parked RawKvStore payload");
    }
    kvmem::SnapshotReader reader(
        [&in](void* destination, std::size_t count) { in.read_into(destination, count); }, bytes);
    std::uint64_t extra_bytes = 0;
    if (raw != nullptr) {
        raw->snapshot_read(reader, max_blocks);
    } else {
        std::size_t required_seen = 0;
        const auto footprint = inspect_kvmem_raw_snapshot(reader, config, max_blocks,
            [&](std::uint32_t id, const kvmem::RawKvStore& block) {
                const auto expected = id < max_blocks
                    ? std::min(kLogicalBlockTokens, logical_tokens - id * kLogicalBlockTokens)
                    : 0U;
                const auto tokens = block.n_tokens(0);
                if (tokens > expected || block.has_block(0) != (tokens != 0)) {
                    throw kvmem::SnapshotCorrupt("KVMem parked RawKvStore block frontier is invalid");
                }
                if (std::binary_search(required_blocks.begin(), required_blocks.end(), id)) {
                    if (!block.has_block(0) || tokens != expected) {
                        throw kvmem::SnapshotCorrupt(
                            "KVMem parked saved resident ID lacks complete target RawKvStore coverage");
                    }
                    ++required_seen;
                }
            });
        if (required_seen != required_blocks.size()) {
            throw kvmem::SnapshotCorrupt("KVMem parked RawKvStore omits a saved resident block");
        }
        // The measured empty bundle already includes each empty Raw object.
        extra_bytes = footprint.resident_bytes - sizeof(kvmem::RawKvStore);
    }
    if (reader.remaining() != 0) {
        throw kvmem::SnapshotCorrupt("KVMem parked RawKvStore payload has trailing bytes");
    }
    return extra_bytes;
}

void validate_raw_geometry(const kvmem::KvMemRuntimeConfig& runtime_config,
                           const kvmem::RawKvStoreConfig& raw_config,
                           const std::optional<kvmem::RawKvStoreConfig>& follower_config,
                           std::uint64_t block_bytes) {
    if (runtime_config.store.block_tokens != kLogicalBlockTokens ||
        raw_config.block_tokens != kLogicalBlockTokens || raw_config.n_layer == 0 ||
        raw_config.n_embd_k == 0 || raw_config.n_embd_v == 0 ||
        raw_config.nvme_bytes != 0 || block_bytes == 0 ||
        block_bytes > kMaxParkedBlockBytes ||
        runtime_config.nvme_bytes != 0 ||
        (runtime_config.store.immutable_source_k &&
         !runtime_config.store.optimize_stage_in) ||
        runtime_config.store.estimated_block_bytes != block_bytes ||
        (runtime_config.store.gpu_resident_block_bytes != 0 &&
         runtime_config.store.gpu_resident_block_bytes != block_bytes) ||
        runtime_config.store.select_method != kvmem::KvMemMethod::Retrieval) {
        throw std::invalid_argument("KVMem parked snapshot geometry or tier configuration is unsupported");
    }
    if (follower_config &&
        (follower_config->block_tokens != kLogicalBlockTokens ||
         follower_config->n_layer != 1 ||
         follower_config->n_embd_k != raw_config.n_embd_k ||
         follower_config->n_embd_v != raw_config.n_embd_v ||
         follower_config->k_gpu_row_bytes == 0 ||
         follower_config->v_gpu_row_bytes == 0 || follower_config->nvme_bytes != 0)) {
        throw std::invalid_argument("KVMem parked follower RawKvStore geometry is invalid");
    }
}

void validate_raw_frontier(const kvmem::RawKvStore& raw, std::uint32_t block_count,
                           std::span<const std::uint32_t> block_tokens, bool frozen = false,
                           bool reading_snapshot = false) {
    if (block_tokens.size() != block_count) {
        throw std::logic_error("KVMem parked snapshot block frontier is inconsistent");
    }
    for (std::uint32_t id = 0; id < block_count; ++id) {
        const std::uint32_t raw_tokens = raw.n_tokens(id);
        // Native has_block inspects vector presence, not just trusted shape.
        // A frozen disk chunk intentionally has no such resident vectors.
        if (raw_tokens > block_tokens[id] ||
            (!frozen && raw.has_block(id) != (raw_tokens != 0))) {
            throw_snapshot_data_error(reading_snapshot,
                "KVMem parked RawKvStore block frontier is invalid");
        }
    }
    if (raw.n_tokens(block_count) != 0 || (!frozen && raw.has_block(block_count))) {
        throw_snapshot_data_error(reading_snapshot,
            "KVMem parked RawKvStore extends beyond the logical frontier");
    }
}

void validate_metadata_shape(const KVMemConversation::SessionMetadata& metadata,
                             std::uint32_t logical_tokens, std::uint32_t block_count,
                             const kvmem::RawKvStoreConfig& raw_config,
                             std::uint32_t query_width, bool reading_snapshot = false) {
    if (metadata.row_positions.size() != logical_tokens ||
        metadata.q_sum.size() != metadata.q_count.size() ||
        (!metadata.q_sum.empty() && metadata.q_sum.size() != raw_config.n_layer) ||
        (metadata.q_sum.empty() && !metadata.q_count.empty())) {
        throw_snapshot_data_error(reading_snapshot,
            "KVMem parked snapshot metadata frontiers are invalid");
    }
    for (const auto& layer_sum : metadata.q_sum) {
        if (layer_sum.size() != query_width ||
            !std::all_of(layer_sum.begin(), layer_sum.end(),
                         [](float value) { return std::isfinite(value); })) {
            throw_snapshot_data_error(reading_snapshot,
                "KVMem parked query-sum geometry or value is invalid");
        }
    }
    if (std::any_of(metadata.q_count.begin(), metadata.q_count.end(),
                    [logical_tokens](std::uint32_t count) {
                        return count > logical_tokens;
                    })) {
        throw_snapshot_data_error(reading_snapshot,
            "KVMem parked query-count frontier is invalid");
    }
    if ((!metadata.exact_query_valid &&
         (metadata.exact_query_user_begin != 0 || metadata.exact_query_begin != 0 ||
          metadata.exact_query_end != 0 || !metadata.exact_query_media.empty())) ||
        (metadata.exact_query_valid &&
         (metadata.exact_query_user_begin > metadata.exact_query_begin ||
          metadata.exact_query_begin >= metadata.exact_query_end ||
          metadata.exact_query_end > logical_tokens ||
          metadata.q_sum.size() != raw_config.n_layer ||
          metadata.q_count.empty() ||
          *std::max_element(metadata.q_count.begin(), metadata.q_count.end()) !=
              metadata.exact_query_end - metadata.exact_query_begin))) {
        throw_snapshot_data_error(reading_snapshot,
            "KVMem parked exact-query provenance is invalid");
    }
    // This is the identity of the full Q-producing prompt, not its current
    // checkpoint prefix. Future tool media may lie beyond logical_tokens;
    // retaining it unchanged is required by the native same-query decision.
    std::size_t media_end = 0;
    for (const VisionItem& item : metadata.exact_query_media) {
        if ((item.modality != PromptModality::Image && item.modality != PromptModality::Video) ||
            item.grid.temporal <= 0 || item.grid.height <= 0 || item.grid.width <= 0 ||
            item.patch_count == 0 ||
            item.patch_begin > std::numeric_limits<std::size_t>::max() - item.patch_count ||
            item.token_spans.empty() ||
            !std::all_of(item.timestamps.begin(), item.timestamps.end(),
                         [](double value) { return std::isfinite(value); })) {
            throw_snapshot_data_error(reading_snapshot,
                "KVMem parked exact-query media identity is invalid");
        }
        for (const TokenSpan& span : item.token_spans) {
            if (span.count == 0 || span.begin < media_end ||
                span.begin > kMaxParkedLogicalTokens ||
                span.count > kMaxParkedLogicalTokens - span.begin) {
                throw_snapshot_data_error(reading_snapshot,
                    "KVMem parked exact-query media spans are invalid");
            }
            media_end = span.begin + span.count;
        }
    }
    bool first = true;
    std::uint32_t previous = 0;
    for (const std::uint32_t id : metadata.prior_resident_block_ids) {
        if (id >= block_count || (!first && id <= previous)) {
            throw_snapshot_data_error(reading_snapshot,
                "KVMem parked prior resident IDs are invalid");
        }
        first = false;
        previous = id;
    }
}

void write_metadata(ParkedSnapshotWriter& out,
                    const KVMemConversation::SessionMetadata& metadata) {
    out.put_bool(metadata.cold);
    out.put_u64(metadata.row_positions.size());
    for (const auto& row : metadata.row_positions) {
        for (const std::int32_t position : row.pos) { out.put_i32(position); }
        out.put_i32(row.token);
        out.put_bool(row.spatial);
    }
    out.put_u32(static_cast<std::uint32_t>(metadata.q_sum.size()));
    for (const auto& layer : metadata.q_sum) {
        out.put_u32(static_cast<std::uint32_t>(layer.size()));
        for (const float value : layer) { out.put_f32(value); }
    }
    out.put_u32(static_cast<std::uint32_t>(metadata.q_count.size()));
    for (const std::uint32_t count : metadata.q_count) { out.put_u32(count); }
    out.put_bool(metadata.exact_query_valid);
    out.put_u32(metadata.exact_query_user_begin);
    out.put_u32(metadata.exact_query_begin);
    out.put_u32(metadata.exact_query_end);
    out.put_u32(static_cast<std::uint32_t>(metadata.exact_query_media.size()));
    for (const VisionItem& item : metadata.exact_query_media) {
        out.put_u8(static_cast<std::uint8_t>(item.modality));
        out.put_i32(item.grid.temporal);
        out.put_i32(item.grid.height);
        out.put_i32(item.grid.width);
        out.put_u64(item.patch_begin);
        out.put_u64(item.patch_count);
        out.put_bytes(item.content_digest);
        out.put_u32(static_cast<std::uint32_t>(item.timestamps.size()));
        for (const double timestamp : item.timestamps) { out.put_f64(timestamp); }
        out.put_u32(static_cast<std::uint32_t>(item.token_spans.size()));
        for (const TokenSpan& span : item.token_spans) {
            out.put_u64(span.begin);
            out.put_u64(span.count);
        }
    }
    out.put_u32(static_cast<std::uint32_t>(metadata.prior_resident_block_ids.size()));
    for (const std::uint32_t id : metadata.prior_resident_block_ids) { out.put_u32(id); }
}

KVMemConversation::SessionMetadata read_metadata(
    ParkedSnapshotReader& in, std::uint32_t logical_tokens, std::uint32_t block_count,
    const kvmem::RawKvStoreConfig& raw_config, std::uint32_t query_width) {
    KVMemConversation::SessionMetadata metadata;
    metadata.cold = in.boolean();
    const std::uint64_t rows = in.u64();
    constexpr std::uint64_t kRowBytes = 21;
    if (rows != logical_tokens || rows > in.remaining() / kRowBytes) {
        throw kvmem::SnapshotCorrupt("KVMem parked row-position frontier is invalid");
    }
    metadata.row_positions.reserve(static_cast<std::size_t>(rows));
    for (std::uint64_t i = 0; i < rows; ++i) {
        KVMemConversation::RowPosition row;
        for (std::int32_t& position : row.pos) { position = in.i32(); }
        row.token = in.i32();
        row.spatial = in.boolean();
        metadata.row_positions.push_back(row);
    }
    const std::uint32_t layers = in.u32();
    if (layers > raw_config.n_layer || (layers != 0 && layers != raw_config.n_layer) ||
        layers > in.remaining() / sizeof(std::uint32_t)) {
        throw kvmem::SnapshotCorrupt("KVMem parked query-sum layer count is invalid");
    }
    metadata.q_sum.resize(layers);
    for (auto& layer : metadata.q_sum) {
        const std::uint32_t width = in.u32();
        if (width != query_width || width > in.remaining() / sizeof(float)) {
            throw kvmem::SnapshotCorrupt("KVMem parked query-sum width is invalid");
        }
        layer.resize(width);
        for (float& value : layer) {
            value = in.f32();
            if (!std::isfinite(value)) {
                throw kvmem::SnapshotCorrupt(
                    "KVMem parked query sum contains a non-finite value");
            }
        }
    }
    const std::uint32_t counts = in.u32();
    if (counts != layers || counts > in.remaining() / sizeof(std::uint32_t)) {
        throw kvmem::SnapshotCorrupt("KVMem parked query-count layer count is invalid");
    }
    metadata.q_count.resize(counts);
    for (std::uint32_t& count : metadata.q_count) { count = in.u32(); }
    metadata.exact_query_valid = in.boolean();
    metadata.exact_query_user_begin = in.u32();
    metadata.exact_query_begin = in.u32();
    metadata.exact_query_end = in.u32();
    const std::uint32_t media_items = in.u32();
    constexpr std::uint64_t kMinimumMediaBytes = 85;
    if (media_items > kMaxParkedLogicalTokens ||
        media_items > in.remaining() / kMinimumMediaBytes) {
        throw kvmem::SnapshotCorrupt("KVMem parked exact-query media count is invalid");
    }
    metadata.exact_query_media.resize(media_items);
    for (VisionItem& item : metadata.exact_query_media) {
        item.modality = static_cast<PromptModality>(in.u8());
        item.grid.temporal = in.i32();
        item.grid.height = in.i32();
        item.grid.width = in.i32();
        item.patch_begin = static_cast<std::size_t>(in.u64());
        item.patch_count = static_cast<std::size_t>(in.u64());
        const auto digest = in.read_bytes(item.content_digest.size());
        std::copy(digest.begin(), digest.end(), item.content_digest.begin());
        const std::uint32_t timestamps = in.u32();
        if (timestamps > kMaxParkedLogicalTokens ||
            timestamps > in.remaining() / sizeof(double)) {
            throw kvmem::SnapshotCorrupt("KVMem parked exact-query timestamp count is invalid");
        }
        item.timestamps.resize(timestamps);
        for (double& timestamp : item.timestamps) { timestamp = in.f64(); }
        const std::uint32_t spans = in.u32();
        if (spans == 0 || spans > kMaxParkedLogicalTokens ||
            spans > in.remaining() / (2U * sizeof(std::uint64_t))) {
            throw kvmem::SnapshotCorrupt("KVMem parked exact-query media span count is invalid");
        }
        item.token_spans.resize(spans);
        for (TokenSpan& span : item.token_spans) {
            span.begin = static_cast<std::size_t>(in.u64());
            span.count = static_cast<std::size_t>(in.u64());
        }
    }
    const std::uint32_t selected = in.u32();
    if (selected > block_count || selected > in.remaining() / sizeof(std::uint32_t)) {
        throw kvmem::SnapshotCorrupt("KVMem parked selected-ID count is invalid");
    }
    metadata.prior_resident_block_ids.resize(selected);
    for (std::uint32_t& id : metadata.prior_resident_block_ids) { id = in.u32(); }
    validate_metadata_shape(metadata, logical_tokens, block_count, raw_config,
                            query_width, true);
    return metadata;
}

struct ParkedBlockRecord {
    std::uint32_t block_id = 0;
    std::uint32_t orig_pos_start = 0;
    std::uint32_t n_tokens = 0;
    std::int64_t baked_pos = 0;
    double attn_score = 0.0;
    double profile_score = 0.0;
    double retrieval_score = 0.0;
    std::span<const std::uint8_t> packed_payload;
};

void write_block_record(ParkedSnapshotWriter& out, const kvmem::KvMemBlock& block,
                        std::span<const std::uint8_t> payload) {
    out.put_u32(block.block_id);
    out.put_u32(block.orig_pos_start);
    out.put_u32(block.n_tokens);
    out.put_i64(block.baked_pos);
    out.put_f64(block.attn_score);
    out.put_f64(block.profile_score);
    out.put_f64(block.retrieval_score);
    out.put_u64(payload.size());
    out.put_u64(checksum64(payload));
    out.put_bytes(payload);
}

ParkedBlockRecord read_block_record(ParkedSnapshotReader& in, std::uint32_t expected_id,
                                    std::uint32_t logical_tokens,
                                    std::uint64_t block_bytes) {
    ParkedBlockRecord record;
    record.block_id = in.u32();
    record.orig_pos_start = in.u32();
    record.n_tokens = in.u32();
    record.baked_pos = in.i64();
    record.attn_score = in.f64();
    record.profile_score = in.f64();
    record.retrieval_score = in.f64();
    const std::uint64_t payload_bytes = in.u64();
    const std::uint64_t payload_checksum = in.u64();
    const std::uint64_t expected_start = static_cast<std::uint64_t>(expected_id) *
                                         kLogicalBlockTokens;
    const std::uint32_t expected_tokens = static_cast<std::uint32_t>(std::min<std::uint64_t>(
        kLogicalBlockTokens, static_cast<std::uint64_t>(logical_tokens) - expected_start));
    if (record.block_id != expected_id || record.orig_pos_start != expected_start ||
        record.n_tokens != expected_tokens || record.n_tokens == 0 ||
        record.baked_pos < 0 || record.baked_pos > std::numeric_limits<std::int32_t>::max() ||
        static_cast<std::uint64_t>(record.baked_pos) + record.n_tokens >
            static_cast<std::uint64_t>(std::numeric_limits<std::int32_t>::max()) ||
        std::isnan(record.attn_score) || std::isnan(record.profile_score) ||
        std::isnan(record.retrieval_score) ||
        (record.attn_score != record.profile_score &&
         record.attn_score != record.retrieval_score) ||
        payload_bytes != block_bytes || payload_bytes > in.remaining()) {
        throw kvmem::SnapshotCorrupt("KVMem parked block metadata or payload length is invalid");
    }
    record.packed_payload = in.read_bytes(static_cast<std::size_t>(payload_bytes));
    if (checksum64(record.packed_payload) != payload_checksum) {
        throw kvmem::SnapshotCorrupt("KVMem parked block payload checksum mismatch");
    }
    return record;
}

void validate_host_backing(kvmem::KvMemRuntime& runtime,
                           const KVMemPageBackend& backend,
                           std::uint32_t logical_tokens) {
    const kvmem::KvMemStore& store = runtime.store();
    const std::uint64_t expected_blocks = logical_tokens == 0 ? 0 :
        (static_cast<std::uint64_t>(logical_tokens) + kLogicalBlockTokens - 1U) /
            kLogicalBlockTokens;
    if (logical_tokens > static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max()) ||
        expected_blocks != store.block_count()) {
        throw std::invalid_argument("KVMem parked logical frontier is invalid");
    }
    const std::uint64_t block_bytes = backend.block_bytes();
    const kvmem::PinnedKvTier* cpu = runtime.cpu_tier();
    if (store.block_count() != 0 &&
        (cpu == nullptr || !cpu->enabled() || cpu->config().slot_bytes != block_bytes ||
         cpu->slot_count() < store.block_count())) {
        throw std::invalid_argument("KVMem parked snapshot needs one full CPU payload slot per block");
    }
    const kvmem::NvmeKvTier* nvme = runtime.nvme_tier();
    std::uint32_t cpu_mappings = 0;
    for (std::uint32_t id = 0; id < store.block_count(); ++id) {
        const kvmem::KvMemBlock& block = store.blocks()[id];
        const std::uint64_t begin = static_cast<std::uint64_t>(id) * kLogicalBlockTokens;
        const std::uint32_t expected_tokens = static_cast<std::uint32_t>(std::min<std::uint64_t>(
            kLogicalBlockTokens, static_cast<std::uint64_t>(logical_tokens) - begin));
        if (block.block_id != id || block.orig_pos_start != begin ||
            block.n_tokens != expected_tokens || block.in_flight || block.dirty_gpu ||
            block.in_working_set || block.tier == kvmem::KvTier::GPU || block.gpu_slot >= 0 ||
            block.baked_pos < 0 || block.baked_pos > std::numeric_limits<std::int32_t>::max() ||
            static_cast<std::uint64_t>(block.baked_pos) + block.n_tokens >
                static_cast<std::uint64_t>(std::numeric_limits<std::int32_t>::max()) ||
            std::isnan(block.attn_score) || std::isnan(block.profile_score) ||
            std::isnan(block.retrieval_score) ||
            (block.attn_score != block.profile_score &&
             block.attn_score != block.retrieval_score)) {
            throw std::invalid_argument("KVMem parked Runtime block metadata is invalid");
        }
        if (block.cpu_slot >= 0) {
            if (cpu == nullptr || cpu->block_slot(id) != block.cpu_slot) {
                throw std::invalid_argument("KVMem parked CPU block mapping is inconsistent");
            }
            ++cpu_mappings;
        } else if (cpu != nullptr && cpu->block_slot(id) >= 0) {
            throw std::invalid_argument("KVMem parked CPU tier has an unindexed block mapping");
        }
        if (block.tier == kvmem::KvTier::CPU) {
            if (block.cpu_slot < 0) {
                throw std::invalid_argument("KVMem parked CPU block has no packed payload");
            }
        } else if (block.tier == kvmem::KvTier::SSD) {
            if (nvme == nullptr || !nvme->enabled() || block.nvme_slot < 0 ||
                !block.ssd_clean || nvme->block_slot(id) != block.nvme_slot) {
                throw std::invalid_argument("KVMem parked SSD block has no clean payload");
            }
        } else {
            throw std::invalid_argument("KVMem parked block has an unsupported host tier");
        }
    }
    if (cpu != nullptr && cpu->used_slots() != cpu_mappings) {
        throw std::invalid_argument("KVMem parked CPU tier contains unaccounted payload slots");
    }
}

void validate_restored_cpu_backing(kvmem::KvMemRuntime& runtime,
                                   const KVMemPageBackend& backend) {
    const kvmem::KvMemStore& store = runtime.store();
    const kvmem::PinnedKvTier* cpu = runtime.cpu_tier();
    if (store.block_count() != 0 &&
        (cpu == nullptr || !cpu->enabled() || cpu->config().slot_bytes != backend.block_bytes() ||
         cpu->slot_count() < store.block_count() || cpu->used_slots() != store.block_count())) {
        throw std::runtime_error("KVMem parked restore did not retain every packed block on CPU");
    }
    for (std::uint32_t id = 0; id < store.block_count(); ++id) {
        const kvmem::KvMemBlock& block = store.blocks()[id];
        if (block.block_id != id || block.tier != kvmem::KvTier::CPU ||
            block.gpu_slot != -1 || block.cpu_slot < 0 || block.in_flight ||
            block.in_working_set || cpu->block_slot(id) != block.cpu_slot) {
            throw std::runtime_error("KVMem parked restore left inconsistent block residency");
        }
    }
}

void restore_source_block_metadata(kvmem::KvMemStore& store, std::uint32_t id,
                                   const kvmem::KvMemBlock& source) {
    store.set_block_tier(id, source.tier, source.cpu_slot, source.nvme_slot);
    store.set_block_cpu_copy(id, source.cpu_slot);
    store.set_block_ssd_backing(id, source.nvme_slot, source.ssd_clean);
    store.set_block_baked_pos(id, source.baked_pos);
}

void validate_prior_resident_raw(const KVMemConversation::SessionMetadata& metadata,
                                 const kvmem::KvMemStore& store,
                                 const kvmem::RawKvStore& raw,
                                 bool reading_snapshot = false) {
    for (const std::uint32_t id : metadata.prior_resident_block_ids) {
        if (id >= store.block_count() || !raw.has_block(id) ||
            raw.n_tokens(id) != store.blocks()[id].n_tokens) {
            throw_snapshot_data_error(reading_snapshot,
                "KVMem parked saved resident ID lacks complete target RawKvStore coverage");
        }
    }
}

void restore_scores(kvmem::KvMemStore& store, const std::vector<double>& retrieval,
                    const std::vector<double>& profile, const std::vector<double>& attn) {
    store.set_retrieval_scores(retrieval);
    store.accumulate_attn(profile);
    if (attn != profile) { store.set_retrieval_scores(retrieval); }
}

void require_follower_transition(
    const kvmem::RawKvStore* raw,
    const KVMemConversation::FollowerTransition& transition) {
    const bool before = static_cast<bool>(transition.before_target_spill);
    const bool after = static_cast<bool>(transition.after_target_admit);
    if (raw != nullptr && (!before || !after)) {
        throw std::logic_error("KVMem follower movement requires both GPU transition hooks");
    }
    if (raw == nullptr && (before || after)) {
        throw std::logic_error("KVMem target-only movement received follower hooks");
    }
}

} // namespace

RetrievalQuerySpan clamp_native_query_span(
    const RetrievalQuerySpan& query, std::uint32_t query_max_tokens) {
    if (query.begin >= query.end || query_max_tokens == 0 ||
        (query.user_begin && *query.user_begin > query.begin)) {
        throw std::invalid_argument("native KVMem query span or cap is invalid");
    }
    const std::uint32_t capped_width = std::min(query_max_tokens, query.end);
    return {std::max(query.begin, query.end - capped_width), query.end, query.user_begin};
}

bool KVMemConversation::SessionMetadata::matches_exact_query(
    const PreparedPromptData& prompt, std::uint32_t base,
    std::uint32_t query_max_tokens) const {
    const auto& query = prompt.retrieval_query_span;
    if (!query || !query->user_begin || query->end > base || !exact_query_valid) {
        return false;
    }
    RetrievalQuerySpan capped_query;
    try {
        capped_query = clamp_native_query_span(*query, query_max_tokens);
    } catch (const std::invalid_argument&) {
        return false;
    }
    return exact_query_user_begin == *query->user_begin &&
           exact_query_begin == capped_query.begin && exact_query_end == capped_query.end &&
           exact_query_begin < exact_query_end && !q_sum.empty() &&
           q_sum.size() == q_count.size() &&
           *std::max_element(q_count.begin(), q_count.end()) ==
               capped_query.end - capped_query.begin &&
           vision_items_equal(exact_query_media, prompt.vision_items);
}

KVMemConversation::Parked::Parked() noexcept = default;

KVMemConversation::Parked::Parked(Parked&& other) noexcept
    : backend_(std::exchange(other.backend_, nullptr)),
      runtime_(std::move(other.runtime_)),
      raw_(std::move(other.raw_)),
      follower_raw_(std::move(other.follower_raw_)),
      metadata_(std::move(other.metadata_)),
      compact_snapshot_(std::move(other.compact_snapshot_)),
      compact_file_(std::move(other.compact_file_)),
      frozen_raw_(std::move(other.frozen_raw_)),
      runtime_raw_insert_offset_(std::exchange(other.runtime_raw_insert_offset_, 0)),
      compact_logical_tokens_(std::exchange(other.compact_logical_tokens_, 0)),
      compact_query_width_(std::exchange(other.compact_query_width_, 0)),
      compact_restore_bytes_(std::exchange(other.compact_restore_bytes_, 0)),
      cache_invalidated_(std::exchange(other.cache_invalidated_, false)),
      transition_failed_(std::exchange(other.transition_failed_, false)) {
    other.metadata_.clear();
    other.compact_snapshot_.clear();
}

KVMemConversation::Parked::~Parked() noexcept {
    if (empty()) { return; }
    try {
        retire();
    } catch (...) { std::terminate(); }
}

void KVMemConversation::Parked::retire() {
    if (empty()) { return; }
    if (frozen_raw_) {
        if (transition_failed_ || backend_ == nullptr || raw_ == nullptr ||
            (runtime_ && runtime_->pending())) {
            throw std::logic_error("KVMem frozen archive is not safe to retire");
        }
        if (runtime_) {
            KVMemConversation::require_metadata_transferable(metadata_, *runtime_);
            for (const auto& block : runtime_->store().blocks()) {
                if (block.in_flight || block.gpu_slot >= 0 || block.tier == kvmem::KvTier::GPU) {
                    throw std::logic_error("KVMem frozen archive retained a GPU block");
                }
            }
            // No external slot needs releasing: this fully host-owned
            // Runtime and its private bookkeeping are destroyed below.
        }
        // Drop the trusted bindings before destroying their Raw owners.
        frozen_raw_.reset();
        compact_file_.reset();
        runtime_.reset();
        raw_.reset();
        follower_raw_.reset();
        metadata_.clear();
        backend_ = nullptr;
        compact_logical_tokens_ = compact_query_width_ = 0;
        compact_restore_bytes_ = runtime_raw_insert_offset_ = 0;
        cache_invalidated_ = false;
        return;
    }
    if (compacted()) {
        if (transition_failed_ || backend_ == nullptr || runtime_ != nullptr ||
            raw_ != nullptr || follower_raw_ != nullptr) {
            throw std::logic_error("KVMem compact parked archive has an invalid owner pair");
        }
        std::vector<std::uint8_t>{}.swap(compact_snapshot_);
        compact_file_.reset();
        compact_logical_tokens_ = 0;
        compact_query_width_ = 0;
        compact_restore_bytes_ = 0;
        metadata_.clear();
        backend_ = nullptr;
        cache_invalidated_ = false;
        return;
    }
    if (backend_ == nullptr || runtime_ == nullptr || raw_ == nullptr || runtime_->pending()) {
        throw std::logic_error("KVMem parked conversation is not safe to retire");
    }
    KVMemConversation::require_metadata_transferable(metadata_, *runtime_);
    for (const kvmem::KvMemBlock& block : runtime_->store().blocks()) {
        if (block.in_flight || block.tier == kvmem::KvTier::GPU || block.gpu_slot >= 0) {
            throw std::logic_error("KVMem parked conversation retained a GPU or in-flight block");
        }
    }
    raw_->wait_writes();
    if (follower_raw_ != nullptr) {
        follower_raw_->wait_writes();
    }
    // Avoid allocating native dropped-block metadata just to destroy an
    // already host-only arena, including final-capacity LRU retirement.
    raw_.reset();
    follower_raw_.reset();
    runtime_.reset();
    metadata_.clear();
    backend_ = nullptr;
    cache_invalidated_ = false;
    transition_failed_ = false;
}

std::uint64_t KVMemConversation::Parked::released_ram_bytes() const {
    if (frozen_raw_) {
        return kvmem_session_checked_add(runtime_ ? runtime_->allocated_bytes() : 0,
                                         frozen_raw_->ram_bytes());
    }
    return host_bundle_ram_bytes(runtime_.get(), raw_.get(), follower_raw_.get());
}

bool KVMemConversation::Parked::reusable() const noexcept {
    return backend_ != nullptr && !cache_invalidated_ && !transition_failed_ &&
           (!frozen_raw_ || frozen_raw_->valid());
}

void KVMemConversation::Parked::invalidate_for_eviction() noexcept {
    if (backend_ == nullptr) { return; }
    cache_invalidated_ = true;
    if (frozen_raw_) { frozen_raw_->invalidate(); }
}

std::uint64_t KVMemConversation::Parked::ram_bytes() const {
    auto bytes = metadata_ram_bytes(metadata_);
    bytes = kvmem_session_checked_add(bytes,
        host_bundle_ram_bytes(runtime_.get(), raw_.get(), follower_raw_.get()));
    if (frozen_raw_) { bytes = kvmem_session_checked_add(bytes, frozen_raw_->metadata_bytes()); }
    return kvmem_session_checked_add(bytes, compact_snapshot_.capacity());
}

std::uint64_t KVMemConversation::Parked::disk_bytes() const noexcept {
    return (compact_file_ ? compact_file_->charged_bytes() : 0) +
           (frozen_raw_ ? frozen_raw_->disk_bytes() : 0);
}

std::uint64_t KVMemConversation::Parked::restore_bytes() const noexcept {
    return (runtime_ ? 0 : compact_restore_bytes_) +
           (frozen_raw_ ? frozen_raw_->restore_bytes() : 0);
}

std::uint64_t KVMemConversation::Parked::restore_peak_bytes() const {
    if (!compacted()) { return 0; }
    // A validated Runtime may already be resident after an interrupted
    // exchange. Only missing native vectors remain to restore, but each
    // checked Native chunk keeps its stream reader alive while allocating
    // those vectors; do not charge the Runtime parser/packed-block scratch a
    // second time.
    if (frozen_raw_ && runtime_) {
        std::uint64_t reader_scratch = 0;
        for (std::uint32_t i = 0; i < frozen_raw_->chunk_count(); ++i) {
            if (!frozen_raw_->chunk(i).in_ram) {
                reader_scratch = kNativeRawReadScratchBytes;
                break;
            }
        }
        return kvmem_session_checked_add(frozen_raw_->restore_bytes(), reader_scratch);
    }
    const auto blocks = (std::uint64_t(compact_logical_tokens_) + kLogicalBlockTokens - 1) /
                        kLogicalBlockTokens;
    // The reconstructed Raw/Runtime capacities are bounded by the measured
    // source bundle. Account separately for the parser's duplicate metadata,
    // one packed block, score arrays and temporary shape/checking vectors.
    auto scratch = kvmem_session_checked_add(metadata_ram_bytes(metadata_),
                                             backend_->block_bytes() + 64U * 1024U);
    scratch = kvmem_session_checked_add(scratch,
        blocks * (2 * sizeof(kvmem::KvMemBlock) + 3 * sizeof(double) + 8 * sizeof(std::uint32_t)));
    // Native Raw chunks and the Runtime record restore in separate transfer
    // units. Their temporary IO/parser scratch is serial, so only the larger
    // allowance contributes to the whole-operation peak.
    if (frozen_raw_) {
        for (std::uint32_t i = 0; i < frozen_raw_->chunk_count(); ++i) {
            if (!frozen_raw_->chunk(i).in_ram) {
                scratch = (std::max)(scratch, kNativeRawReadScratchBytes);
                break;
            }
        }
    }
    return kvmem_session_checked_add(restore_bytes(), scratch);
}

std::uint64_t KVMemConversation::Parked::spill_scratch_bytes() const {
    if (!backend_) { return 0; }
    const auto blocks = runtime_ ? runtime_->store().block_count()
        : (std::uint64_t(compact_logical_tokens_) + kLogicalBlockTokens - 1) / kLogicalBlockTokens;
    return kvmem_session_checked_add(backend_->block_bytes() + 64U * 1024U,
        blocks * (sizeof(kvmem::KvMemBlock) + 8 * sizeof(std::uint32_t)));
}

bool KVMemConversation::Parked::erase_file() noexcept {
    const bool runtime_ok = !compact_file_ || compact_file_->erase();
    const bool raw_ok = !frozen_raw_ || frozen_raw_->erase();
    return runtime_ok && raw_ok;
}

std::uint32_t KVMemConversation::Parked::logical_tokens() const {
    if (frozen_raw_ && !transition_failed_ && backend_ != nullptr && raw_ != nullptr) {
        return compact_logical_tokens_;
    }
    if (compacted() && !transition_failed_ && backend_ != nullptr &&
        runtime_ == nullptr && raw_ == nullptr && follower_raw_ == nullptr) {
        return compact_logical_tokens_;
    }
    if (transition_failed_ || backend_ == nullptr || runtime_ == nullptr || raw_ == nullptr) {
        throw std::logic_error("KVMem parked conversation has no healthy owner pair");
    }
    return runtime_->store().total_tokens();
}

void KVMemConversation::Parked::set_media_ranges(
    std::vector<std::pair<std::uint32_t, std::uint32_t>> ranges) {
    if (compacted()) {
        throw std::logic_error("KVMem compact archive must be materialized before setting media ranges");
    }
    const std::uint32_t tokens = logical_tokens();
    for (const auto& [begin, end] : ranges) {
        if (begin >= end || end > tokens) {
            throw std::invalid_argument("KVMem parked media range exceeds its logical history");
        }
    }
    std::sort(ranges.begin(), ranges.end());
    runtime_->store().set_media_ranges(std::move(ranges));
}

KVMemConversation::SessionMetadata& KVMemConversation::Parked::metadata() {
    if (transition_failed_ || backend_ == nullptr ||
        ((runtime_ == nullptr || raw_ == nullptr) && !compacted())) {
        throw std::logic_error("KVMem parked conversation has no complete owner pair");
    }
    return metadata_;
}

const KVMemConversation::SessionMetadata& KVMemConversation::Parked::metadata() const {
    if (transition_failed_ || backend_ == nullptr ||
        ((runtime_ == nullptr || raw_ == nullptr) && !compacted())) {
        throw std::logic_error("KVMem parked conversation has no complete owner pair");
    }
    return metadata_;
}

std::uint32_t KVMemConversation::Parked::rewind_to(
    std::uint32_t frontier, const std::vector<float>& tail_mean) {
    if (!reusable() || compacted() || runtime_ == nullptr || raw_ == nullptr ||
        runtime_->pending() || backend_->occupied_slots() != 0 || frontier == 0 ||
        frontier > runtime_->store().total_tokens() ||
        metadata_.row_positions.size() != runtime_->store().total_tokens()) {
        throw std::logic_error("native rewind requires a complete quiescent host archive");
    }
    const auto& config = raw_->config();
    if (config.block_tokens == 0 ||
        tail_mean.size() != (frontier % config.block_tokens == 0 ? 0U :
                            static_cast<std::size_t>(config.n_layer) * (config.n_embd_k + 1U))) {
        // RawKvStore's mean checkpoint contains count + sum for each layer.
        // Validate before any truncation; its exact parser remains authoritative.
        throw std::invalid_argument("native rewind tail-mean geometry does not match its archive");
    }
    const std::uint32_t last = (frontier - 1U) / config.block_tokens;
    std::vector<std::uint32_t> selected;
    selected.reserve(metadata_.prior_resident_block_ids.size() + 1U);
    for (const auto id : metadata_.prior_resident_block_ids) {
        if (id <= last) { selected.push_back(id); }
    }
    selected.push_back(last);
    std::sort(selected.begin(), selected.end());
    selected.erase(std::unique(selected.begin(), selected.end()), selected.end());
    std::uint64_t visible = 0;
    for (const auto id : selected) {
        const auto begin = static_cast<std::uint64_t>(id) * config.block_tokens;
        visible += std::min<std::uint64_t>(config.block_tokens, frontier - begin);
    }
    if (visible == 0 || visible > std::numeric_limits<std::uint32_t>::max()) {
        throw std::logic_error("native rewind has an invalid selected prefix");
    }
    try {
        raw_->wait_writes();
        if (follower_raw_) { follower_raw_->wait_writes(); }
        raw_->truncate_to(frontier);
        if (follower_raw_) { follower_raw_->truncate_to(frontier); }
        (void)runtime_->truncate_to(frontier);
        raw_->restore_mean_checkpoint(frontier, tail_mean);
        metadata_.row_positions.resize(frontier);
        metadata_.prior_resident_block_ids.swap(selected);
        if (metadata_.exact_query_valid && metadata_.exact_query_end > frontier) {
            metadata_.exact_query_valid = false;
            metadata_.exact_query_user_begin = 0;
            metadata_.exact_query_begin = metadata_.exact_query_end = 0;
            metadata_.exact_query_media.clear();
            metadata_.q_sum.clear();
            metadata_.q_count.clear();
        }
    } catch (...) {
        transition_failed_ = true;
        throw;
    }
    return static_cast<std::uint32_t>(visible);
}

void KVMemConversation::Parked::compact(std::uint32_t query_width,
                                      std::uint64_t available_host_bytes) {
    if (cache_invalidated_ || compacted() || transition_failed_ || backend_ == nullptr ||
        runtime_ == nullptr ||
        raw_ == nullptr) {
        throw std::logic_error("KVMem cold compaction requires a complete host archive");
    }
    const std::uint32_t tokens = logical_tokens();
    std::vector<std::uint8_t> bytes;
    const auto restore_bytes = released_ram_bytes();
    try {
        // Native's no-sink writer validates/counts without staging any payload.
        // The old owner remains authoritative throughout this preflight. A
        // same-run RAM copy must fit its whole transient output plus scratch,
        // not just the smaller steady-state bytes after the old arena is gone.
        const auto size = KVMemConversation::snapshot_parked_size(*this, query_width);
        const auto scratch = spill_scratch_bytes();
        if (size >= restore_bytes || size > available_host_bytes ||
            scratch > available_host_bytes - size) {
            throw KVMemSnapshotPreflightError(
                "KVMem RAM compaction cannot fit its peak or reduce retained owner RAM");
        }
        bytes.reserve(static_cast<std::size_t>(size));
        // reserve may retain more than requested. Check its actual capacity
        // before the first Runtime/GPU traversal, without crediting old RAM.
        if (bytes.capacity() >= restore_bytes || bytes.capacity() > available_host_bytes ||
            scratch > available_host_bytes - bytes.capacity()) {
            throw KVMemSnapshotPreflightError(
                "KVMem RAM compaction allocation exceeds its proven headroom");
        }
        kvmem::SnapshotWriter out([&](const void* data, std::size_t count) {
            if (count > size - bytes.size()) {
                throw std::logic_error("KVMem RAM snapshot exceeds its preflight size");
            }
            const auto* first = static_cast<const std::uint8_t*>(data);
            bytes.insert(bytes.end(), first, first + count);
        });
        KVMemConversation::snapshot_parked_write(*this, query_width, out);
        if (out.bytes() != size) {
            throw std::logic_error("KVMem RAM snapshot changed after preflight");
        }
    } catch (const std::bad_alloc&) {
        if (transition_failed_) { throw; }
        std::throw_with_nested(KVMemSnapshotPreflightError(
            "KVMem compact allocation failed with the host archive intact"));
    }
    // Successful export has restored every source block to its original CPU
    // backing and left no pending plan/GPU slot. Release the whole private
    // arena after publication, without allocating a dropped-block vector.
    validate_host_backing(*runtime_, *backend_, tokens);
    raw_.reset();
    follower_raw_.reset();
    runtime_.reset();
    compact_snapshot_ = std::move(bytes);
    compact_logical_tokens_ = tokens;
    compact_query_width_ = query_width;
    compact_restore_bytes_ = restore_bytes;
}

void KVMemConversation::Parked::compact_to_file(
    KVMemParkedFileCache& files, std::uint32_t query_width) {
    if (cache_invalidated_) {
        throw std::logic_error("KVMem invalidated archive cannot be parked to files");
    }
    try {
        freeze_for_transfer(files, query_width);
        prepare_transfer();
        const auto units = transfer_units(query_width);
        std::uint64_t required_disk = 0;
        for (const auto& unit : units) {
            required_disk = kvmem_session_checked_add(required_disk, unit.spill_bytes);
        }
        if (required_disk > files.limit() - files.bytes() || required_disk > files.available()) {
            throw KVMemSnapshotStorageError("insufficient disk for native archive publication");
        }
        for (const auto& unit : units) {
            if (unit.resident) { spill_transfer_unit(files, unit.index, query_width); }
        }
    } catch (...) {
        if (transition_failed_) { throw; }
        // Failure before publication has no cold allocations to retain. A
        // later failure keeps the authoritative mixed manifest for retry.
        if (frozen_raw_ && runtime_ && !compact_file_ && frozen_raw_->complete() &&
            frozen_raw_->disk_bytes() == 0) {
            frozen_raw_.reset();
            compact_logical_tokens_ = compact_query_width_ = 0;
            compact_restore_bytes_ = runtime_raw_insert_offset_ = 0;
        }
        std::throw_with_nested(KVMemSnapshotStorageError(
            "KVMem disk parking failed; native archive ownership retained"));
    }
}

void KVMemConversation::Parked::freeze_for_transfer(
    KVMemParkedFileCache& files, std::uint32_t query_width,
    std::span<const std::shared_ptr<const KVMemQueryBoundaryCheckpoint>> checkpoints) {
    if (cache_invalidated_) {
        throw std::logic_error("KVMem invalidated archive cannot be frozen for transfer");
    }
    if (frozen_raw_) {
        if (transition_failed_ || compact_query_width_ != query_width) {
            throw std::logic_error("KVMem frozen archive geometry changed");
        }
        return;
    }
    if (compacted() || transition_failed_ || !runtime_ || !raw_ || !backend_) {
        throw std::logic_error("KVMem freeze requires a healthy detached host archive");
    }
    kvmem::SnapshotWriter sizing;
    KVMemConversation::write_parked_snapshot(*this, query_width, sizing, true, true);
    std::array<kvmem::RawKvStore*, 2> owners{raw_.get(), follower_raw_.get()};
    auto frozen = files.freeze_raw({owners.data(), follower_raw_ ? 2U : 1U},
                                   16ULL * 1024ULL * 1024ULL, checkpoints);
    compact_logical_tokens_ = runtime_->store().total_tokens();
    compact_query_width_ = query_width;
    compact_restore_bytes_ = runtime_->allocated_bytes();
    frozen_raw_ = std::move(frozen);
}

void KVMemConversation::Parked::write_checkpoint_image(
    const KVMemQueryBoundaryCheckpoint& checkpoint,
    const std::function<void(const void*, std::size_t)>& sink) const {
    write_checkpoint_part(checkpoint, false, sink);
}

void KVMemConversation::Parked::write_checkpoint_tail_mean(
    const KVMemQueryBoundaryCheckpoint& checkpoint,
    const std::function<void(const void*, std::size_t)>& sink) const {
    write_checkpoint_part(checkpoint, true, sink);
}

void KVMemConversation::Parked::write_checkpoint_part(
    const KVMemQueryBoundaryCheckpoint& checkpoint, bool tail_mean,
    const std::function<void(const void*, std::size_t)>& sink) const {
    if (!reusable()) { throw std::logic_error("recurrent export has no reusable parked owner"); }
    if (!sink) { throw std::invalid_argument("recurrent export requires a payload sink"); }
    try {
        if (frozen_raw_ && frozen_raw_->owns_checkpoint(checkpoint)) {
            if (tail_mean) { frozen_raw_->write_checkpoint_tail_mean(checkpoint, sink); }
            else { frozen_raw_->write_checkpoint_image(checkpoint, sink); }
        } else if (tail_mean) {
            const auto& mean = checkpoint.tail_mean();
            if (!mean.empty()) { sink(mean.data(), mean.size() * sizeof(float)); }
        } else {
            const auto view = checkpoint.host_view();
            sink(view.data, view.layout->image_bytes);
        }
    } catch (const std::logic_error&) { throw; }
    catch (const kvmem::SnapshotCorrupt&) {
        std::throw_with_nested(KVMemSnapshotCorruptError(
            "native recurrent archive is corrupt; frozen source retained"));
    } catch (const std::exception&) {
        std::throw_with_nested(KVMemSnapshotStorageError(
            "native recurrent export failed; frozen source retained"));
    }
}

void KVMemConversation::Parked::prepare_transfer() {
    if (cache_invalidated_ || transition_failed_ || !backend_) {
        throw std::logic_error("KVMem transfer preparation has no healthy owner");
    }
    if (!frozen_raw_) { return; }
    try {
        (void)frozen_raw_->prepare_transfer();
    } catch (const std::logic_error&) { throw; }
    catch (...) {
        std::throw_with_nested(KVMemSnapshotStorageError(
            "cannot remove unfinished native Raw files; resident source retained"));
    }
}

std::vector<KVMemSessionTransferUnit> KVMemConversation::Parked::transfer_units(
    std::uint32_t query_width) {
    if (cache_invalidated_) {
        throw std::logic_error("KVMem invalidated archive has no transfer units");
    }
    if (!frozen_raw_) {
        if (!compacted()) { throw std::logic_error("native transfer requires a frozen manifest"); }
        return {{.disk_bytes = disk_bytes(), .restore_bytes = restore_bytes(),
                 .restore_peak = restore_peak_bytes(), .resident = false}};
    }
    std::vector<KVMemSessionTransferUnit> units;
    units.reserve(std::size_t(frozen_raw_->chunk_count()) + 1);
    KVMemSessionTransferUnit runtime_unit;
    runtime_unit.resident = runtime_ != nullptr;
    runtime_unit.disk_bytes = compact_file_ ? compact_file_->charged_bytes() : 0;
    if (runtime_) {
        runtime_unit.released_ram = runtime_->allocated_bytes();
        if (!compact_file_) {
            kvmem::SnapshotWriter sizing;
            KVMemConversation::write_parked_snapshot(*this, query_width, sizing, true, true);
            runtime_unit.spill_bytes = KVMemParkedFileCache::charged_bytes(sizing.bytes());
            runtime_unit.spill_scratch = spill_scratch_bytes();
        }
    } else {
        runtime_unit.restore_bytes = compact_restore_bytes_;
        // Runtime reconstruction is separate from the native vector reads.
        runtime_unit.restore_peak = restore_peak_bytes() - frozen_raw_->restore_bytes();
    }
    units.push_back(runtime_unit);
    for (std::uint32_t index = 0; index < frozen_raw_->chunk_count(); ++index) {
        const auto raw = frozen_raw_->chunk(index);
        // Unit scheduling can restore Raw before Runtime. Its reader lifetime
        // is independent of whether the Runtime unit is already resident.
        const auto reader_scratch = !raw.in_ram ? kNativeRawReadScratchBytes : 0;
        units.push_back({.index = index, .released_ram = raw.ram_bytes,
                         .disk_bytes = raw.disk_bytes, .spill_bytes = raw.spill_bytes,
                         .spill_scratch = raw.in_ram ? kNativeRawWriteScratchBytes : 0,
                         .restore_bytes = raw.restore_bytes,
                         .restore_peak = kvmem_session_checked_add(
                             raw.restore_bytes, reader_scratch),
                         .resident = raw.in_ram});
    }
    return units;
}

void KVMemConversation::Parked::spill_transfer_unit(
    KVMemParkedFileCache& files, std::uint32_t unit, std::uint32_t query_width) {
    if (cache_invalidated_ || !frozen_raw_ || transition_failed_ ||
        compact_query_width_ != query_width) {
        throw std::logic_error("KVMem transfer has no healthy frozen owner");
    }
    try {
        if (unit != kKVMemRuntimeTransferUnit) { frozen_raw_->spill(unit); return; }
        if (!runtime_) { return; }
        if (runtime_->pending()) {
            throw std::logic_error("native Runtime spill has an unapplied plan");
        }
        validate_host_backing(*runtime_, *backend_, compact_logical_tokens_);
        if (!compact_file_) {
            kvmem::SnapshotWriter sizing;
            KVMemConversation::write_parked_snapshot(*this, query_width, sizing, true, true);
            compact_file_ = files.write(sizing.bytes(), [&](kvmem::SnapshotWriter& out) {
                KVMemConversation::write_parked_snapshot(*this, query_width, out, false, true);
            });
        }
        // This owner has no GPU slots, pending plan or native NVMe tier. Its
        // private CPU arena and tier bookkeeping are destroyed together, only
        // after complete publication. Truncating just before reset would
        // allocate a dropped-block vector under the pressure we must relieve.
        runtime_.reset();
    } catch (...) {
        if (transition_failed_) { throw; }
        std::throw_with_nested(KVMemSnapshotStorageError(
            "native frozen spill failed; completed chunks retained"));
    }
}

void KVMemConversation::Parked::restore_transfer_unit(
    std::uint32_t unit, kvmem::KvMemRuntimeConfig runtime_config,
    kvmem::RawKvStoreConfig raw_config,
    std::optional<kvmem::RawKvStoreConfig> follower_config, std::uint32_t query_width) {
    if (cache_invalidated_) {
        throw std::logic_error("KVMem invalidated archive cannot be restored");
    }
    if (!frozen_raw_) {
        materialize_compact(runtime_config, raw_config, follower_config, query_width, {}, true);
        return;
    }
    if (transition_failed_ || query_width != compact_query_width_) {
        throw std::logic_error("KVMem frozen restore has an invalid owner");
    }
    if (unit != kKVMemRuntimeTransferUnit) {
        try { frozen_raw_->restore(unit); }
        catch (const std::logic_error&) { throw; }
        catch (const kvmem::SnapshotCorrupt&) {
            if (!frozen_raw_) {
                std::throw_with_nested(KVMemSnapshotStorageError(
                    "native Raw corruption found after its source owner was lost"));
            }
            std::throw_with_nested(KVMemSnapshotCorruptError(
                "native Raw archive is corrupt; frozen source retained"));
        }
        catch (...) {
            // Native vector restoration touches no Runtime/GPU owner and
            // rolls back unvalidated vectors through its unchanged manifest.
            std::throw_with_nested(KVMemSnapshotStorageError(
                "native Raw restore failed; trusted mixed manifest retained"));
        }
        return;
    }
    const auto storage_failure = [&] {
        if (backend_->occupied_slots() != 0) {
            throw std::runtime_error("native Runtime restore left its temporary GPU slot occupied");
        }
        std::throw_with_nested(KVMemSnapshotStorageError(
            "native Runtime restore transport/allocation failed; source retained"));
    };
    const auto corruption_failure = [&] {
        if (backend_->occupied_slots() != 0) {
            throw std::runtime_error("native Runtime restore left its temporary GPU slot occupied");
        }
        if (runtime_ != nullptr || (!compact_file_ && !frozen_raw_)) {
            std::throw_with_nested(KVMemSnapshotStorageError(
                "native Runtime corruption found without a retained source record"));
        }
        std::throw_with_nested(KVMemSnapshotCorruptError(
            "native Runtime archive is corrupt; parked source retained"));
    };
    try {
        if (!runtime_) {
            if (!compact_file_) { throw kvmem::SnapshotCorrupt("missing native Runtime record"); }
            std::optional<Parked> candidate;
            compact_file_->load([&](kvmem::SnapshotReader& in) {
                candidate.emplace(KVMemConversation::read_parked_snapshot(
                    in, runtime_config, raw_config, *backend_, follower_config,
                    query_width, false, true));
            });
            if (candidate->logical_tokens() != compact_logical_tokens_) {
                throw std::logic_error("native Runtime frontier changed during restore");
            }
            runtime_ = std::move(candidate->runtime_);
            candidate->raw_.reset();
            candidate->follower_raw_.reset();
            candidate->metadata_.clear();
            candidate->backend_ = nullptr;
        }
        // Same rule as native payload::restore: validated RAM survives a
        // deletion failure, and a retry removes only the duplicate file.
        if (compact_file_ && !compact_file_->erase()) {
            throw KVMemSnapshotStorageError("cannot remove restored Runtime; both copies retained");
        }
        compact_file_.reset();
    } catch (const KVMemSnapshotStorageError&) { throw; }
    catch (const std::bad_alloc&) { storage_failure(); }
    catch (const std::ios_base::failure&) { storage_failure(); }
    catch (const kvmem::SnapshotCorrupt&) { corruption_failure(); }
    catch (const std::filesystem::filesystem_error&) { storage_failure(); }
    catch (const std::invalid_argument&) { storage_failure(); }
    // Unknown native/device transition failures are not an optional I/O miss.
    // The Program execution boundary must fail-stop them, even after cleanup.
}

void KVMemConversation::Parked::validate_compact(
    kvmem::KvMemRuntimeConfig runtime_config,
    kvmem::RawKvStoreConfig raw_config,
    std::optional<kvmem::RawKvStoreConfig> follower_config,
    std::uint32_t query_width) const {
    if (cache_invalidated_) {
        throw std::logic_error("KVMem invalidated archive cannot be validated");
    }
    if (frozen_raw_) {
        if (transition_failed_ || !backend_ || !raw_ || compact_query_width_ != query_width) {
            throw std::logic_error("KVMem frozen archive cannot be validated here");
        }
        try {
            frozen_raw_->validate();
            if (!runtime_) {
                if (!compact_file_) { throw kvmem::SnapshotCorrupt("missing Runtime snapshot"); }
                compact_file_->load([&](kvmem::SnapshotReader& in) {
                    (void)KVMemConversation::read_parked_snapshot(
                        in, runtime_config, raw_config, *backend_, follower_config,
                        query_width, true, true);
                });
            }
        } catch (const kvmem::SnapshotCorrupt&) {
            if (!frozen_raw_) {
                std::throw_with_nested(KVMemSnapshotStorageError(
                    "native frozen archive corruption found without a retained source"));
            }
            std::throw_with_nested(KVMemSnapshotCorruptError(
                "native frozen archive is corrupt; source retained"));
        } catch (const std::exception&) {
            std::throw_with_nested(KVMemSnapshotStorageError("native frozen archive preflight failed"));
        }
        return;
    }
    if (!compacted() || transition_failed_ || backend_ == nullptr ||
        runtime_ != nullptr || raw_ != nullptr || follower_raw_ != nullptr ||
        compact_file_ != nullptr || query_width != compact_query_width_) {
        throw std::logic_error("KVMem cold archive cannot be validated here");
    }
    const auto validate = [&](kvmem::SnapshotReader& in) {
        (void)KVMemConversation::read_parked_snapshot(
            in, runtime_config, raw_config, *backend_, follower_config, query_width, true);
    };
    try {
        std::size_t cursor = 0;
        kvmem::SnapshotReader in([&](void* destination, std::size_t count) {
            std::memcpy(destination, compact_snapshot_.data() + cursor, count);
            cursor += count;
        }, compact_snapshot_.size());
        validate(in);
    } catch (const kvmem::SnapshotCorrupt&) {
        if (compact_snapshot_.empty()) {
            std::throw_with_nested(KVMemSnapshotStorageError(
                "KVMem cold archive corruption found without a retained source"));
        }
        std::throw_with_nested(KVMemSnapshotCorruptError(
            "KVMem cold archive is corrupt; snapshot source retained"));
    } catch (const std::exception&) {
        std::throw_with_nested(KVMemSnapshotStorageError("KVMem cold archive preflight failed"));
    }
}

void KVMemConversation::Parked::materialize_compact(
    kvmem::KvMemRuntimeConfig runtime_config,
    kvmem::RawKvStoreConfig raw_config,
    std::optional<kvmem::RawKvStoreConfig> follower_config,
    std::uint32_t query_width, const std::function<void()>& prepare_destination,
    bool prevalidated) {
    if (cache_invalidated_) {
        throw std::logic_error("KVMem invalidated archive cannot be materialized");
    }
    if (frozen_raw_) {
        if (!prevalidated) {
            validate_compact(runtime_config, raw_config, follower_config, query_width);
        }
        prepare_transfer();
        if (prepare_destination) { prepare_destination(); }
        for (const auto& unit : transfer_units(query_width)) {
            if (!unit.resident || unit.disk_bytes) {
                restore_transfer_unit(unit.index, runtime_config, raw_config,
                                      follower_config, query_width);
            }
        }
        if (!runtime_ || !frozen_raw_->complete() || frozen_raw_->disk_bytes() || compact_file_) {
            throw std::logic_error("native frozen archive cannot thaw an incomplete manifest");
        }
        // Inference may move/resize vectors only after the trusted bindings go.
        frozen_raw_.reset();
        compact_logical_tokens_ = compact_query_width_ = 0;
        compact_restore_bytes_ = runtime_raw_insert_offset_ = 0;
        cache_invalidated_ = false;
        return;
    }
    if (!compacted() || transition_failed_ || backend_ == nullptr ||
        runtime_ != nullptr || raw_ != nullptr || follower_raw_ != nullptr ||
        compact_file_ != nullptr || query_width != compact_query_width_) {
        throw std::logic_error("KVMem cold archive cannot be materialized here");
    }
    const auto load = [&](const std::function<void(kvmem::SnapshotReader&)>& read) {
        std::size_t cursor = 0;
        kvmem::SnapshotReader in([&](void* destination, std::size_t count) {
            std::memcpy(destination, compact_snapshot_.data() + cursor, count);
            cursor += count;
        }, compact_snapshot_.size());
        read(in);
    };
    // Validation is read-only and can run while the outgoing owner is still
    // attached. Do not drain it for a missing, locked, or corrupt target file.
    if (!prevalidated) {
        validate_compact(runtime_config, raw_config, follower_config, query_width);
    }
    if (prepare_destination) { prepare_destination(); }
    std::optional<Parked> candidate;
    try {
        load([&](kvmem::SnapshotReader& in) {
            candidate.emplace(KVMemConversation::read_parked_snapshot(
                in, runtime_config, raw_config, *backend_, follower_config, query_width, false));
        });
    } catch (const std::bad_alloc&) {
        if (backend_->occupied_slots() != 0) { throw; }
        std::throw_with_nested(KVMemSnapshotStorageError("KVMem cold restore allocation failed"));
    } catch (const std::ios_base::failure&) {
        if (backend_->occupied_slots() != 0) { throw; }
        std::throw_with_nested(KVMemSnapshotStorageError("KVMem cold restore I/O failed"));
    } catch (const kvmem::SnapshotCorrupt&) {
        if (backend_->occupied_slots() != 0) { throw; }
        if (compact_snapshot_.empty() || runtime_ != nullptr || raw_ != nullptr ||
            follower_raw_ != nullptr || frozen_raw_ != nullptr) {
            std::throw_with_nested(KVMemSnapshotStorageError(
                "KVMem cold restore corruption found without a retained source"));
        }
        std::throw_with_nested(KVMemSnapshotCorruptError(
            "KVMem cold restore found a corrupt archive; source retained"));
    } catch (const std::filesystem::filesystem_error&) {
        if (backend_->occupied_slots() != 0) { throw; }
        std::throw_with_nested(KVMemSnapshotStorageError("KVMem cold restore file access failed"));
    } catch (const std::invalid_argument&) {
        if (backend_->occupied_slots() != 0) { throw; }
        std::throw_with_nested(KVMemSnapshotStorageError("KVMem cold restore payload is invalid"));
    }
    Parked restored(std::move(*candidate));
    if (restored.logical_tokens() != compact_logical_tokens_) {
        throw std::logic_error("KVMem cold archive frontier changed on materialization");
    }
    if (!erase_file()) {
        throw KVMemSnapshotStorageError("cannot remove restored native session snapshot; charge retained");
    }
    runtime_ = std::move(restored.runtime_);
    raw_ = std::move(restored.raw_);
    follower_raw_ = std::move(restored.follower_raw_);
    metadata_.clear();
    metadata_.swap(restored.metadata_);
    restored.backend_ = nullptr;
    std::vector<std::uint8_t>{}.swap(compact_snapshot_);
    compact_file_.reset();
    compact_logical_tokens_ = 0;
    compact_query_width_ = 0;
    compact_restore_bytes_ = 0;
    cache_invalidated_ = false;
}

KVMemConversation::KVMemConversation(kvmem::KvMemRuntimeConfig runtime_config,
                                     kvmem::RawKvStoreConfig raw_config,
                                     KVMemPageBackend& backend,
                                     std::optional<kvmem::RawKvStoreConfig> follower_raw_config)
    : backend_(&backend),
      runtime_config_(std::move(runtime_config)), raw_config_(std::move(raw_config)),
      follower_config_(std::move(follower_raw_config)),
      runtime_(std::make_unique<kvmem::KvMemRuntime>(runtime_config_, &backend)),
      raw_(std::make_unique<kvmem::RawKvStore>(raw_config_)),
      follower_raw_(follower_config_
                        ? std::make_unique<kvmem::RawKvStore>(*follower_config_)
                        : std::unique_ptr<kvmem::RawKvStore>{}) {
    empty_host_ram_bytes_ = host_bundle_ram_bytes(runtime_.get(), raw_.get(), follower_raw_.get());
}

std::uint64_t KVMemConversation::ram_bytes() const {
    return kvmem_session_checked_add(
        host_bundle_ram_bytes(runtime_.get(), raw_.get(), follower_raw_.get()),
        metadata_ram_bytes(metadata_));
}

void KVMemConversation::ensure_empty_host_archive(std::uint64_t ram_available) {
    if (attached()) { return; }
    if (transition_failed_ || backend_ == nullptr || backend_->occupied_slots() != 0 ||
        runtime_ != nullptr || raw_ != nullptr || follower_raw_ != nullptr || !metadata_.empty()) {
        throw std::logic_error("KVMem destination is not safely empty");
    }
    if (empty_host_ram_bytes_ > ram_available) {
        throw KVMemSnapshotStorageError(
            "available RAM cannot create an empty native session; cached owners retained");
    }
    auto runtime = std::make_unique<kvmem::KvMemRuntime>(runtime_config_, backend_);
    auto raw = std::make_unique<kvmem::RawKvStore>(raw_config_);
    auto follower = follower_config_
                        ? std::make_unique<kvmem::RawKvStore>(*follower_config_)
                        : std::unique_ptr<kvmem::RawKvStore>{};
    runtime_ = std::move(runtime);
    raw_ = std::move(raw);
    follower_raw_ = std::move(follower);
}

void KVMemConversation::clear_for_fresh_owner() {
    require_attached();
    if (runtime_->pending()) {
        throw std::logic_error("KVMem owner reset has an unapplied runtime plan");
    }
    raw_->wait_writes();
    if (follower_raw_) { follower_raw_->wait_writes(); }

    // Truncation can release physical slots before a later step fails. Keep
    // that partial reset fail-stop instead of advertising an empty new owner.
    transition_failed_ = true;
    (void)runtime_->truncate_to(0);
    if (backend_->occupied_slots() != 0) {
        throw std::logic_error("KVMem owner reset left GPU slots occupied");
    }
    raw_->clear();
    if (follower_raw_) { follower_raw_->clear(); }
    runtime_->store().set_media_ranges({});
    metadata_.clear();
    transition_failed_ = false;
}

void KVMemConversation::require_attached() const {
    if (transition_failed_) {
        throw std::logic_error("KVMem conversation is fail-stop after an incomplete resident transition");
    }
    if (backend_ == nullptr || runtime_ == nullptr || raw_ == nullptr) {
        throw std::logic_error("KVMem conversation has no attached owner pair");
    }
}

void KVMemConversation::require_transferable(const KVMemPageBackend& backend,
                                            const kvmem::KvMemRuntime& runtime) {
    if (runtime.pending()) {
        throw std::logic_error("KVMem conversation has an unapplied runtime plan");
    }

    const kvmem::KvMemStore& store = runtime.store();
    for (std::uint32_t block_id = 0; block_id < store.block_count(); ++block_id) {
        const kvmem::KvMemBlock& block = store.blocks()[block_id];
        if (block.in_flight) {
            throw std::logic_error("KVMem conversation has an in-flight block");
        }
        if (block.tier == kvmem::KvTier::GPU || block.gpu_slot >= 0) {
            throw std::logic_error("KVMem conversation still owns a GPU-resident block");
        }
    }
    if (backend.occupied_slots() != 0) {
        throw std::logic_error("KVMem page backend still owns GPU slots");
    }
}

void KVMemConversation::require_metadata_transferable(
    const SessionMetadata& metadata, const kvmem::KvMemRuntime& runtime) {
    // The pinned adapter records one original model-position row per logical
    // token before a conversation can be detached. Without that map, a later
    // selected GPU slot cannot recover its RoPE/MRoPE position from block IDs.
    if (metadata.row_positions.size() != runtime.store().total_tokens()) {
        throw std::logic_error("KVMem conversation row positions do not cover its logical history");
    }
    if (metadata.q_sum.size() != metadata.q_count.size()) {
        throw std::logic_error("KVMem query sum/count metadata has mismatched layer counts");
    }
    if (!metadata.q_sum.empty()) {
        const std::size_t query_width = metadata.q_sum.front().size();
        for (const std::vector<float>& layer_sum : metadata.q_sum) {
            if (layer_sum.size() != query_width) {
                throw std::logic_error("KVMem query sum metadata has inconsistent layer widths");
            }
        }
    }

    const std::uint32_t block_count = runtime.store().block_count();
    bool first = true;
    std::uint32_t previous = 0;
    for (const std::uint32_t block_id : metadata.prior_resident_block_ids) {
        if (block_id >= block_count || (!first && block_id <= previous)) {
            throw std::logic_error("KVMem prior resident block ids are invalid or not ascending");
        }
        first = false;
        previous = block_id;
    }
}

kvmem::KvMemRuntime& KVMemConversation::runtime() {
    require_attached();
    return *runtime_;
}

const kvmem::KvMemRuntime& KVMemConversation::runtime() const {
    require_attached();
    return *runtime_;
}

kvmem::RawKvStore& KVMemConversation::raw() {
    require_attached();
    return *raw_;
}

const kvmem::RawKvStore& KVMemConversation::raw() const {
    require_attached();
    return *raw_;
}

kvmem::RawKvStore* KVMemConversation::follower_raw() {
    require_attached();
    return follower_raw_.get();
}

const kvmem::RawKvStore* KVMemConversation::follower_raw() const {
    require_attached();
    return follower_raw_.get();
}

KVMemConversation::SessionMetadata& KVMemConversation::metadata() {
    require_attached();
    return metadata_;
}

const KVMemConversation::SessionMetadata& KVMemConversation::metadata() const {
    require_attached();
    return metadata_;
}

std::uint32_t KVMemConversation::prefill_append_limit(
    std::uint32_t requested_tokens, std::uint32_t pool_tokens,
    bool selection_pinned) const {
    require_attached();
    const auto& store = runtime_->store();
    if (runtime_->pending() || requested_tokens == 0 || pool_tokens == 0) {
        throw std::invalid_argument("KVMem prefill batch needs a settled store and positive capacity");
    }
    const auto block_tokens = store.config().block_tokens;
    const auto tail = store.total_tokens() % block_tokens;
    if (selection_pinned && tail == 0) {
        return pinned_append_limit(requested_tokens, pool_tokens);
    }
    return preview_kvmem_prefill_append_tokens(store, requested_tokens, pool_tokens);
}

std::uint32_t KVMemConversation::pinned_append_limit(
    std::uint32_t requested_tokens, std::uint32_t pool_tokens) const {
    require_attached();
    const auto& store = runtime_->store();
    if (runtime_->pending() || requested_tokens == 0 || pool_tokens == 0) {
        throw std::invalid_argument("KVMem pinned append needs a settled store and positive capacity");
    }

    const std::uint32_t block_tokens = store.config().block_tokens;
    if (block_tokens == 0) {
        throw std::logic_error("KVMem pinned append store has zero native block capacity");
    }
    const std::uint32_t usable_pool_tokens = pool_tokens - pool_tokens % block_tokens;
    if (usable_pool_tokens == 0) {
        throw std::invalid_argument("KVMem pinned append pool cannot hold one native block");
    }

    const std::uint64_t native_pool_blocks = usable_pool_tokens / block_tokens;
    std::uint64_t resident_count = 0;
    // A GPU slot consumes one whole native block even when that block is partial.
    for (const auto& block : store.blocks()) {
        if (block.gpu_slot >= 0) { ++resident_count; }
    }
    if (resident_count > native_pool_blocks) {
        throw std::logic_error("KVMem resident blocks exceed the native pinned append pool");
    }

    const std::uint64_t free_slots = native_pool_blocks - resident_count;
    // The uint32 pool bounds this product and the partial-slot remainder.
    std::uint64_t available_tokens = free_slots * block_tokens;

    const std::uint32_t total_tokens = store.total_tokens();
    const std::uint32_t tail_tokens = total_tokens % block_tokens;
    if (tail_tokens != 0) {
        const auto& blocks = store.blocks();
        if (blocks.empty()) {
            throw std::logic_error("KVMem pinned append has no block for its partial tail");
        }
        const auto& tail = blocks.back();
        const std::uint64_t tail_orig_end =
            static_cast<std::uint64_t>(tail.orig_pos_start) + tail.n_tokens;
        if (tail.n_tokens != tail_tokens || tail_orig_end != total_tokens ||
            tail.gpu_slot < 0 || tail.tier != kvmem::KvTier::GPU || tail.in_flight) {
            throw std::logic_error("KVMem pinned append has no settled resident partial tail");
        }

        available_tokens += block_tokens - tail_tokens;
    }

    return static_cast<std::uint32_t>(
        std::min<std::uint64_t>(requested_tokens, available_tokens));
}

bool KVMemConversation::prepare_partial_tail_pressure(
    std::uint32_t n_tokens, std::uint32_t pool_tokens) {
    require_attached();
    auto& store = runtime_->store();
    const std::uint32_t block_tokens = store.config().block_tokens;
    const std::uint32_t tail_tokens = store.total_tokens() % block_tokens;
    if (runtime_->pending() || tail_tokens == 0 || n_tokens == 0 ||
        n_tokens > block_tokens - tail_tokens || pool_tokens < block_tokens ||
        store.blocks().empty()) {
        throw std::invalid_argument("KVMem tail pressure requires one settled partial append");
    }
    const auto& tail = store.blocks().back();
    if (tail.n_tokens != tail_tokens || tail.orig_pos_end() != store.total_tokens() ||
        tail.gpu_slot < 0 || tail.tier != kvmem::KvTier::GPU || tail.in_flight) {
        throw std::logic_error("KVMem tail pressure has no settled resident tail");
    }
    std::uint64_t resident_after_append = n_tokens;
    for (const auto& block : store.blocks()) {
        if (block.gpu_slot >= 0) { resident_after_append += block.n_tokens; }
    }
    if (resident_after_append + n_tokens > std::numeric_limits<std::uint32_t>::max()) {
        throw std::overflow_error("KVMem tail pressure token count exceeds uint32");
    }
    pool_tokens -= pool_tokens % block_tokens;
    // prepare_working_set counts an existing GPU tail after register_append.
    // Project that count without extending geometry used by the old pages.
    const bool pressure = runtime_->maybe_offload_during_prefill(
        n_tokens, static_cast<std::uint32_t>(resident_after_append), pool_tokens,
        {tail.block_id});
    if (pressure && (!tail.in_working_set || tail.in_flight || tail.gpu_slot < 0)) {
        throw std::logic_error("KVMem tail pressure did not retain its mandatory GPU block");
    }
    return pressure;
}

KVMemConversation::AppendPlan KVMemConversation::plan_prefill_append(
    std::uint32_t n_tokens, std::uint32_t pool_tokens, bool selection_pinned) {
    require_attached();
    const auto block_tokens = runtime_->store().config().block_tokens;
    if (runtime_->pending() || n_tokens == 0) {
        throw std::invalid_argument("KVMem prefill append exceeds its native batch admission bound");
    }
    if (selection_pinned &&
        n_tokens > pinned_append_limit(n_tokens, pool_tokens)) {
        throw std::invalid_argument("KVMem prefill append exceeds its native batch admission bound");
    }
    if (!selection_pinned &&
        (pool_tokens < block_tokens ||
         (n_tokens > block_tokens &&
          n_tokens > prefill_append_limit(n_tokens, pool_tokens)))) {
        throw std::invalid_argument("KVMem prefill append exceeds its native batch admission bound");
    }
    kvmem::KvMemStore& store = runtime_->store();
    pool_tokens -= pool_tokens % store.config().block_tokens;
    AppendPlan work;
    work.old_frontier = store.total_tokens();
    if (work.old_frontier > std::numeric_limits<std::uint32_t>::max() - n_tokens) {
        throw std::overflow_error("KVMem logical append frontier overflows uint32");
    }
    if (store.block_count() != 0) {
        const kvmem::KvMemBlock& tail = store.blocks().back();
        if (tail.n_tokens < store.config().block_tokens) {
            work.prior_tail_tokens = tail.n_tokens;
            if (tail.gpu_slot < 0 || tail.tier != kvmem::KvTier::GPU) {
                throw std::logic_error("KVMem partial append tail is not GPU resident");
            }
        }
    }

    runtime_->register_append(n_tokens);
    bool pressure_preparation_started = false;
    try {
        work.new_frontier = store.total_tokens();
        const std::int32_t first_incoming = store.block_id_containing(work.old_frontier);
        if (first_incoming < 0) {
            throw std::logic_error("KVMem native append has no block at its original frontier");
        }
        for (std::uint32_t id = static_cast<std::uint32_t>(first_incoming);
             id < store.block_count(); ++id) {
            const kvmem::KvMemBlock& block = store.blocks()[id];
            if (block.orig_pos_start >= work.new_frontier) { break; }
            work.incoming_blocks.push_back(id);
        }
        if (work.incoming_blocks.empty() || work.new_frontier - work.old_frontier != n_tokens) {
            throw std::logic_error("KVMem native append did not cover the planned token segment");
        }

        if (!selection_pinned) {
            std::uint64_t resident_tokens = 0;
            for (const kvmem::KvMemBlock& block : store.blocks()) {
                if (block.gpu_slot >= 0) { resident_tokens += block.n_tokens; }
            }
            if (resident_tokens > std::numeric_limits<std::uint32_t>::max()) {
                throw std::overflow_error("KVMem resident token count exceeds uint32");
            }
            const std::uint32_t resident_count = static_cast<std::uint32_t>(resident_tokens);
            pressure_preparation_started = store.prefill_needs_offload(
                resident_count, n_tokens, pool_tokens);
            work.pressure = runtime_->maybe_offload_during_prefill(
                n_tokens, resident_count, pool_tokens, work.incoming_blocks);
            if (work.pressure != pressure_preparation_started) {
                throw std::logic_error("KVMem prefill pressure decision changed during preparation");
            }
            if (work.pressure) {
                for (const std::uint32_t id : work.incoming_blocks) {
                    if (!store.blocks()[id].in_working_set) {
                        throw std::logic_error("KVMem prefill pressure dropped an incoming block");
                    }
                }
                return work;
            }
        }

        for (const std::uint32_t id : work.incoming_blocks) {
            const kvmem::KvMemBlock& block = store.blocks()[id];
            if (block.gpu_slot >= 0) { continue; }
            if (block.orig_pos_start < work.old_frontier) {
                throw std::logic_error("KVMem cannot replace an evicted partial append tail");
            }
            const std::int32_t slot = backend_->reserve_gpu_slot_for_append();
            store.set_block_gpu_slot(id, slot);
            store.set_block_tier(id, kvmem::KvTier::GPU, -1, block.nvme_slot);
        }
        return work;
    } catch (...) {
        if (runtime_->pending()) {
            std::throw_with_nested(std::runtime_error(
                "KVMem append failed with a pending pressure plan; conversation state is fail-stop"));
        }
        if (pressure_preparation_started) {
            std::throw_with_nested(std::runtime_error(
                "KVMem pressure selection failed before commit; conversation state is fail-stop"));
        }

        // In the no-pressure path, reserve_gpu_slot_for_append() reserves only
        // an unbound slot identity. truncate_to() drops the appended blocks and
        // releases every such slot still attached to them; no pages were handed
        // to Program and no stage-out plan was applied.
        try {
            runtime_->truncate_to(work.old_frontier);
        } catch (...) {
            std::throw_with_nested(std::runtime_error(
                "KVMem append rollback failed; conversation state is fail-stop"));
        }
        throw;
    }
}

void KVMemConversation::apply_prefill_pressure(
    std::uint32_t pre_append_frontier,
    const std::function<void()>& detach_execution_views,
    const FollowerTransition& follower) {
    require_attached();
    if (!runtime_->pending() || !detach_execution_views) {
        throw std::logic_error("KVMem prefill pressure requires a prepared plan and view detachment");
    }
    require_follower_transition(follower_raw_.get(), follower);
    backend_->begin_prefill_admission(runtime_->store(), runtime_->last_plan().stage_in,
                                      pre_append_frontier);
    try {
        if (follower_raw_ != nullptr) {
            follower_raw_->wait_writes();
            const auto& outgoing = runtime_->last_plan().stage_out;
            follower.before_target_spill(
                std::span<const std::uint32_t>{outgoing.data(), outgoing.size()},
                runtime_->store(), *follower_raw_);
            follower_raw_->wait_writes();
        }
        runtime_->spill_outgoing();
        detach_execution_views();
        runtime_->admit_incoming();
        backend_->finish_prefill_admission();
        if (follower_raw_ != nullptr) {
            follower.after_target_admit(runtime_->store(), *follower_raw_);
        }
    } catch (...) {
        backend_->abort_prefill_admission();
        throw;
    }
}

KVMemConversation::QuerySelectionPreview KVMemConversation::preview_query_selection(
    KVMemRetrievalGeometry geometry, std::uint32_t mandatory_begin,
    std::uint32_t mandatory_end, std::uint32_t replay_begin) {
    require_attached();
    auto& store = runtime_->store();
    if (runtime_->pending() || mandatory_begin >= mandatory_end ||
        replay_begin >= mandatory_end ||
        mandatory_end != store.total_tokens() ||
        metadata_.row_positions.size() != store.total_tokens() ||
        metadata_.q_sum.size() != raw_->config().n_layer ||
        metadata_.q_count.size() != raw_->config().n_layer) {
        throw std::logic_error("KVMem query selection needs a completed first pass");
    }
    raw_->wait_writes();
    std::vector<KVMemRetrievalQueryLayer> layers;
    layers.reserve(metadata_.q_sum.size());
    bool captured = false;
    for (std::size_t il = 0; il < metadata_.q_sum.size(); ++il) {
        layers.push_back({metadata_.q_sum[il], metadata_.q_count[il]});
        captured = captured || metadata_.q_count[il] != 0;
    }
    if (!captured) {
        throw std::logic_error("KVMem query selection has no captured Q rows");
    }
    store.set_retrieval_scores(score_kvmem_retrieval(
        *raw_, store.block_count(), geometry, layers));
    QuerySelectionPreview preview;
    preview.logical_rows = store.total_tokens();
    for (const kvmem::KvMemBlock& block : store.blocks()) {
        if (block.gpu_slot >= 0 && block.n_tokens != 0) {
            if (block.tier != kvmem::KvTier::GPU || block.in_flight) {
                throw std::logic_error("KVMem query preview has an unsettled resident block");
            }
            preview.resident_blocks.push_back(block.block_id);
        }
        if (block.orig_pos_end() > mandatory_begin &&
            block.orig_pos_start < mandatory_end) {
            preview.mandatory_blocks.push_back(block.block_id);
        }
        if (block.orig_pos_end() > replay_begin &&
            block.orig_pos_start < mandatory_end) {
            preview.replay_blocks.push_back(block.block_id);
        }
    }
    preview.selected_blocks = runtime_->preview_reselect(preview.mandatory_blocks);
    if (!std::is_sorted(preview.selected_blocks.begin(), preview.selected_blocks.end()) ||
        std::adjacent_find(preview.selected_blocks.begin(),
                           preview.selected_blocks.end()) != preview.selected_blocks.end()) {
        throw std::logic_error("KVMem query selection is not ordered by original block");
    }
    preview.replay_fits = std::includes(
        preview.selected_blocks.begin(), preview.selected_blocks.end(),
        preview.replay_blocks.begin(), preview.replay_blocks.end());
    std::uint64_t compact = 0;
    bool found_replay_begin = false;
    for (const std::uint32_t id : preview.selected_blocks) {
        if (id >= store.block_count()) {
            throw std::logic_error("KVMem query selection has an unknown block");
        }
        const kvmem::KvMemBlock& block = store.blocks()[id];
        if (block.orig_pos_start <= replay_begin &&
            replay_begin < block.orig_pos_end()) {
            const std::uint64_t begin = compact + replay_begin - block.orig_pos_start;
            if (begin > std::numeric_limits<std::uint32_t>::max()) {
                throw std::overflow_error("KVMem replay cache position exceeds uint32");
            }
            preview.replay_compact_begin = static_cast<std::uint32_t>(begin);
            found_replay_begin = true;
        }
        compact += block.n_tokens;
    }
    if (compact > std::numeric_limits<std::uint32_t>::max()) {
        throw std::overflow_error("KVMem selected cache position exceeds uint32");
    }
    preview.replay_compact_end = static_cast<std::uint32_t>(compact);
    preview.replay_fits = preview.replay_fits && found_replay_begin &&
                          preview.replay_compact_begin < preview.replay_compact_end;
    return preview;
}

std::optional<KVMemConversation::QuerySelectionPreview>
KVMemConversation::preview_cached_query_selection(
    KVMemRetrievalGeometry geometry, std::uint32_t observed_begin,
    std::uint32_t suffix_end, std::uint32_t generation_rows,
    std::uint32_t physical_pool_tokens, bool require_deferred_tail) {
    require_attached();
    const auto& config = runtime_->store().config();
    auto& store = runtime_->store();
    const std::uint32_t cached_frontier = store.total_tokens();
    if (runtime_->pending() || cached_frontier == 0 ||
        observed_begin > cached_frontier || suffix_end <= cached_frontier ||
        config.block_tokens == 0 || physical_pool_tokens == 0 ||
        physical_pool_tokens % config.block_tokens != 0 ||
        metadata_.row_positions.size() != cached_frontier) {
        return std::nullopt;
    }
    if (metadata_.q_sum.size() != raw_->config().n_layer ||
        metadata_.q_count.size() != raw_->config().n_layer) {
        return std::nullopt;
    }
    raw_->wait_writes();
    std::vector<KVMemRetrievalQueryLayer> layers;
    layers.reserve(metadata_.q_sum.size());
    bool captured = false;
    for (std::size_t il = 0; il < metadata_.q_sum.size(); ++il) {
        layers.push_back({metadata_.q_sum[il], metadata_.q_count[il]});
        captured = captured || metadata_.q_count[il] != 0;
    }
    if (!captured) { return std::nullopt; }
    store.set_retrieval_scores(score_kvmem_retrieval(
        *raw_, store.block_count(), geometry, layers));

    QuerySelectionPreview preview;
    preview.logical_rows = cached_frontier;
    for (const kvmem::KvMemBlock& block : store.blocks()) {
        if (block.gpu_slot >= 0 && block.n_tokens != 0) {
            if (block.tier != kvmem::KvTier::GPU || block.in_flight) {
                throw std::logic_error(
                    "KVMem cached-query preview has an unsettled resident block");
            }
            preview.resident_blocks.push_back(block.block_id);
        }
        if ((block.orig_pos_end() > observed_begin &&
             block.orig_pos_start < cached_frontier) ||
            ((require_deferred_tail || cached_frontier % config.block_tokens != 0) &&
             block.block_id + 1U == store.block_count())) {
            preview.mandatory_blocks.push_back(block.block_id);
        }
    }
    preview.selected_blocks = runtime_->preview_reselect(preview.mandatory_blocks);
    if (!std::is_sorted(preview.selected_blocks.begin(), preview.selected_blocks.end()) ||
        std::adjacent_find(preview.selected_blocks.begin(),
                           preview.selected_blocks.end()) !=
            preview.selected_blocks.end()) {
        throw std::logic_error("KVMem cached-query selection is not in original order");
    }
    if (preview.selected_blocks.empty() ||
        !std::includes(preview.selected_blocks.begin(), preview.selected_blocks.end(),
                       preview.mandatory_blocks.begin(), preview.mandatory_blocks.end())) {
        return std::nullopt;
    }

    // Mirror upstream selection_fits: old selected blocks plus every block
    // containing a future suffix/generation row must fit in the GPU slot pool.
    const std::uint64_t block_tokens = config.block_tokens;
    const std::uint64_t first_future = cached_frontier / block_tokens;
    const std::uint64_t final_blocks =
        (static_cast<std::uint64_t>(suffix_end) + generation_rows +
         block_tokens - 1U) / block_tokens;
    const std::uint64_t pool_blocks = physical_pool_tokens / block_tokens;
    if (final_blocks < first_future || final_blocks - first_future > pool_blocks ||
        final_blocks > std::numeric_limits<std::uint32_t>::max()) {
        return std::nullopt;
    }
    std::uint64_t slots = preview.selected_blocks.size();
    for (std::uint64_t id = first_future; id < final_blocks; ++id) {
        if (!std::binary_search(preview.selected_blocks.begin(),
                                preview.selected_blocks.end(),
                                static_cast<std::uint32_t>(id))) {
            ++slots;
        }
    }
    if (slots > pool_blocks) { return std::nullopt; }
    for (const std::uint32_t id : preview.selected_blocks) {
        const kvmem::KvMemBlock& block = store.blocks()[id];
        if (block.gpu_slot < 0 && block.cpu_slot < 0 && block.nvme_slot < 0) {
            throw std::logic_error(
                "KVMem cached-query selection has no archived block payload");
        }
    }
    return preview;
}

bool KVMemConversation::apply_query_selection(
    const QuerySelectionPreview& preview,
    const std::function<void()>& detach_execution_views,
    const FollowerTransition& follower, bool force_rebind) {
    require_attached();
    auto& store = runtime_->store();
    if (runtime_->pending() || !detach_execution_views ||
        preview.logical_rows != store.total_tokens()) {
        throw std::logic_error("KVMem query selection preview is stale");
    }
    std::vector<std::uint32_t> resident;
    for (const kvmem::KvMemBlock& block : store.blocks()) {
        if (block.gpu_slot >= 0 && block.n_tokens != 0) {
            if (block.tier != kvmem::KvTier::GPU || block.in_flight) {
                throw std::logic_error("KVMem query selection has an unsettled resident block");
            }
            resident.push_back(block.block_id);
        }
    }
    if (resident != preview.resident_blocks) {
        throw std::logic_error("KVMem resident view changed after query preview");
    }
    require_follower_transition(follower_raw_.get(), follower);
    for (const std::uint32_t id : preview.selected_blocks) {
        if (id >= store.block_count()) {
            throw std::logic_error("KVMem query selection has an unknown block");
        }
        const kvmem::KvMemBlock& block = store.blocks()[id];
        if (block.gpu_slot < 0 && block.cpu_slot < 0 && block.nvme_slot < 0) {
            // The NInfer page backend cannot regenerate full V from RawKvStore's
            // mean-only K fallback. Never admit an unbacked historical block.
            throw std::logic_error("KVMem query selection has no archived block payload");
        }
    }
    if (preview.selected_blocks == resident) {
        if (!runtime_->commit_resident_selection(preview.selected_blocks)) {
            throw std::logic_error("KVMem unchanged query view could not be committed");
        }
        if (!force_rebind) { return false; }
        // The selected native slots stay put, but the first-pass query was
        // evaluated across a prior pressure change. Preserve accepted follower
        // rows/pages before dropping its NInfer address, then rebuild the execution
        // prefix for query replay without inventing a native tier movement.
        if (follower_raw_ != nullptr) {
            follower_raw_->wait_writes();
            follower.before_target_spill({}, store, *follower_raw_);
            follower_raw_->wait_writes();
        }
        detach_execution_views();
        if (follower_raw_ != nullptr) {
            follower.after_target_admit(store, *follower_raw_);
        }
        return true;
    }
    (void)runtime_->prepare_selection(preview.selected_blocks);
    if (follower_raw_ != nullptr) {
        follower_raw_->wait_writes();
        const auto& outgoing = runtime_->last_plan().stage_out;
        follower.before_target_spill(
            std::span<const std::uint32_t>{outgoing.data(), outgoing.size()},
            runtime_->store(), *follower_raw_);
        follower_raw_->wait_writes();
    }
    runtime_->spill_outgoing();
    detach_execution_views();
    runtime_->admit_incoming();
    if (follower_raw_ != nullptr) {
        follower.after_target_admit(runtime_->store(), *follower_raw_);
    }
    return true;
}

void KVMemConversation::drain_resident_to_host(
    const std::function<void()>& detach_execution_views,
    const FollowerTransition& follower) {
    require_attached();
    if (runtime_->pending() || !detach_execution_views) {
        throw std::logic_error("KVMem resident drain requires no pending plan and view detachment");
    }
    if (metadata_.cold) {
        throw std::logic_error("KVMem active conversation cannot drain while marked cold");
    }
    require_metadata_transferable(metadata_, *runtime_);
    require_follower_transition(follower_raw_.get(), follower);

    const kvmem::KvMemStore& store = runtime_->store();
    std::vector<std::uint32_t> resident_block_ids;
    resident_block_ids.reserve(store.block_count());
    for (std::uint32_t id = 0; id < store.block_count(); ++id) {
        const kvmem::KvMemBlock& block = store.blocks()[id];
        if (block.in_flight) {
            throw std::logic_error("KVMem resident drain found an in-flight block");
        }
        const bool gpu_tier = block.tier == kvmem::KvTier::GPU;
        const bool has_gpu_slot = block.gpu_slot >= 0;
        if (gpu_tier != has_gpu_slot) {
            throw std::logic_error("KVMem resident drain found inconsistent GPU residency metadata");
        }
        if (gpu_tier) {
            if (block.n_tokens == 0) {
                throw std::logic_error("KVMem resident drain found an empty GPU block");
            }
            resident_block_ids.push_back(id);
        }
    }

    // Keep the pre-drain working set with the session so a later restore can
    // reconstruct the same resident IDs. Everything after this point may
    // mutate the runtime or detach Program-owned addresses and is fail-stop.
    metadata_.prior_resident_block_ids.swap(resident_block_ids);
    try {
        const std::vector<std::uint32_t> empty_selection;
        (void)runtime_->prepare_selection(empty_selection);
        if (runtime_->last_plan().stage_out != metadata_.prior_resident_block_ids) {
            throw std::logic_error("KVMem empty selection did not cover every prior resident block");
        }

        if (follower_raw_ != nullptr) {
            follower_raw_->wait_writes();
            const auto& outgoing = runtime_->last_plan().stage_out;
            follower.before_target_spill(
                std::span<const std::uint32_t>{outgoing.data(), outgoing.size()},
                runtime_->store(), *follower_raw_);
            follower_raw_->wait_writes();
        }

        runtime_->spill_outgoing();
        detach_execution_views();
        runtime_->admit_incoming();

        if (follower_raw_ != nullptr) {
            follower.after_target_admit(runtime_->store(), *follower_raw_);
        }
        raw_->wait_writes();
        if (follower_raw_ != nullptr) {
            follower_raw_->wait_writes();
        }

        require_transferable(*backend_, *runtime_);
        require_metadata_transferable(metadata_, *runtime_);
    } catch (const std::exception& error) {
        transition_failed_ = true;
        std::throw_with_nested(std::runtime_error(
            std::string("KVMem resident drain failed; conversation state is fail-stop: ") +
            error.what()));
    } catch (...) {
        transition_failed_ = true;
        std::throw_with_nested(std::runtime_error(
            "KVMem resident drain failed; conversation state is fail-stop"));
    }
}

KVMemConversation::Parked KVMemConversation::park() {
    require_attached();
    if (metadata_.cold) {
        throw std::logic_error("KVMem active conversation cannot be parked while marked cold");
    }
    require_transferable(*backend_, *runtime_);
    require_metadata_transferable(metadata_, *runtime_);
    raw_->wait_writes();
    if (follower_raw_ != nullptr) {
        follower_raw_->wait_writes();
    }
    require_transferable(*backend_, *runtime_);
    require_metadata_transferable(metadata_, *runtime_);

    Parked parked;
    parked.backend_ = backend_;
    parked.runtime_ = std::move(runtime_);
    parked.raw_ = std::move(raw_);
    parked.follower_raw_ = std::move(follower_raw_);
    parked.metadata_.swap(metadata_);
    return parked;
}

void KVMemConversation::restore(Parked&& parked) {
    if (runtime_ != nullptr || raw_ != nullptr || follower_raw_ != nullptr || !metadata_.empty()) {
        throw std::logic_error("KVMem conversation restore requires an empty destination");
    }
    if (backend_ == nullptr || parked.empty() || parked.backend_ != backend_ ||
        parked.runtime_ == nullptr || parked.raw_ == nullptr) {
        throw std::invalid_argument("parked KVMem conversation belongs to a different backend");
    }
    if (parked.metadata_.cold) {
        throw std::logic_error("KVMem cold conversation must be restored from its snapshot first");
    }
    require_transferable(*backend_, *parked.runtime_);
    require_metadata_transferable(parked.metadata_, *parked.runtime_);
    parked.raw_->wait_writes();
    if (parked.follower_raw_ != nullptr) {
        parked.follower_raw_->wait_writes();
    }
    require_transferable(*backend_, *parked.runtime_);
    require_metadata_transferable(parked.metadata_, *parked.runtime_);

    runtime_ = std::move(parked.runtime_);
    raw_ = std::move(parked.raw_);
    follower_raw_ = std::move(parked.follower_raw_);
    metadata_.swap(parked.metadata_);
    parked.backend_ = nullptr;
}

std::vector<std::uint32_t> KVMemConversation::restage_prior_resident() {
    require_attached();
    if (metadata_.cold) {
        throw std::logic_error("KVMem cold conversation cannot restage resident blocks");
    }
    require_transferable(*backend_, *runtime_);
    require_metadata_transferable(metadata_, *runtime_);

    const kvmem::KvMemStore& store = runtime_->store();
    const kvmem::KvMemStoreConfig& store_config = store.config();
    const kvmem::RawKvStoreConfig& raw_config = raw_->config();
    if (store_config.block_tokens == 0 || raw_config.n_layer == 0 ||
        raw_config.n_embd_k == 0 || raw_config.block_tokens != store_config.block_tokens ||
        (!metadata_.q_sum.empty() && metadata_.q_sum.size() != raw_config.n_layer) ||
        (!metadata_.q_count.empty() && metadata_.q_count.size() != raw_config.n_layer)) {
        throw std::logic_error("KVMem RawKvStore geometry does not match conversation metadata");
    }
    raw_->wait_writes();

    const std::uint32_t block_tokens = store_config.block_tokens;
    const std::uint32_t total_tokens = store.total_tokens();
    const std::uint64_t expected_block_count = total_tokens == 0
        ? 0
        : (static_cast<std::uint64_t>(total_tokens) + block_tokens - 1U) / block_tokens;
    if (expected_block_count != store.block_count()) {
        throw std::logic_error("KVMem Store block table does not cover its logical history");
    }

    for (std::uint32_t id = 0; id < store.block_count(); ++id) {
        const kvmem::KvMemBlock& block = store.blocks()[id];
        const std::uint64_t expected_begin = static_cast<std::uint64_t>(id) * block_tokens;
        const std::uint32_t expected_tokens = static_cast<std::uint32_t>(std::min<std::uint64_t>(
            block_tokens, static_cast<std::uint64_t>(total_tokens) - expected_begin));
        const std::uint32_t raw_tokens = raw_->n_tokens(id);
        const bool raw_has_block = raw_->has_block(id);
        if (block.block_id != id || block.orig_pos_start != expected_begin ||
            block.n_tokens != expected_tokens || block.gpu_slot != -1 ||
            block.cpu_slot < -1 || block.nvme_slot < -1 ||
            (block.tier != kvmem::KvTier::CPU && block.tier != kvmem::KvTier::SSD) ||
            raw_tokens > block.n_tokens ||
            raw_has_block != (raw_tokens != 0)) {
            throw std::logic_error("KVMem Store and RawKvStore block metadata disagree");
        }
    }

    std::vector<std::uint32_t> selected = metadata_.prior_resident_block_ids;
    kvmem::PinnedKvTier* cpu_tier = runtime_->cpu_tier();
    kvmem::NvmeKvTier* nvme_tier = runtime_->nvme_tier();
    for (const std::uint32_t id : selected) {
        const kvmem::KvMemBlock& block = store.blocks()[id];
        if (block.n_tokens == 0 || !raw_->has_block(id) ||
            raw_->n_tokens(id) != block.n_tokens) {
            throw std::logic_error("KVMem prior resident block lacks complete RawKvStore coverage");
        }

        if (block.tier == kvmem::KvTier::CPU) {
            if (block.cpu_slot < 0 || cpu_tier == nullptr || !cpu_tier->enabled() ||
                cpu_tier->block_slot(id) != block.cpu_slot) {
                throw std::logic_error("KVMem prior resident block has no matching CPU archive slot");
            }
        } else if (block.tier == kvmem::KvTier::SSD) {
            if (block.nvme_slot < 0 || !block.ssd_clean || nvme_tier == nullptr ||
                !nvme_tier->enabled() || nvme_tier->block_slot(id) != block.nvme_slot) {
                throw std::logic_error("KVMem prior resident block has no matching NVMe archive slot");
            }
        } else {
            throw std::logic_error("KVMem prior resident block has no host archive tier");
        }
    }

    try {
        const kvmem::KvMemPlan plan = runtime_->prepare_selection(selected);
        if (!plan.stage_out.empty() || plan.stage_in != selected) {
            throw std::logic_error("KVMem native restage plan differs from the saved resident IDs");
        }
        // Match the native adapter's apply-plan ordering. With no resident
        // outgoing blocks this also waits for any Runtime NVMe prefetch.
        runtime_->spill_outgoing();
        runtime_->admit_incoming();

        if (runtime_->pending()) {
            throw std::logic_error("KVMem native restage left a pending Runtime plan");
        }
        std::vector<std::uint32_t> resident;
        resident.reserve(selected.size());
        for (std::uint32_t id = 0; id < store.block_count(); ++id) {
            const kvmem::KvMemBlock& block = store.blocks()[id];
            const bool expected_resident = std::binary_search(selected.begin(), selected.end(), id);
            const bool gpu_tier = block.tier == kvmem::KvTier::GPU;
            const bool has_gpu_slot = block.gpu_slot >= 0;
            if (block.in_flight || block.gpu_slot < -1 || gpu_tier != has_gpu_slot ||
                block.in_working_set != expected_resident || gpu_tier != expected_resident) {
                throw std::logic_error("KVMem Runtime residency differs from the saved resident IDs");
            }
            if (gpu_tier) {
                (void)backend_->pages_for_slot(id, block.gpu_slot);
                resident.push_back(id);
            }
        }
        if (resident != selected || backend_->occupied_slots() != selected.size()) {
            throw std::logic_error("KVMem backend residency differs from the saved resident IDs");
        }
    } catch (...) {
        transition_failed_ = true;
        std::throw_with_nested(std::runtime_error(
            "KVMem resident restage failed; conversation state is fail-stop"));
    }

    return selected;
}

std::uint64_t KVMemConversation::snapshot_parked_size(
    Parked& archive, std::uint32_t query_width) {
    kvmem::SnapshotWriter sizing;
    stream_parked_snapshot(archive, query_width, sizing, true);
    return sizing.bytes();
}

void KVMemConversation::snapshot_parked_write(
    Parked& archive, std::uint32_t query_width, kvmem::SnapshotWriter& stream) {
    if (stream.bytes() != 0) {
        throw std::logic_error("native archive requires a fresh checksum writer");
    }
    stream_parked_snapshot(archive, query_width, stream, false);
}

std::vector<std::uint8_t> KVMemConversation::snapshot_parked(
    Parked& archive, std::uint32_t query_width) {
    const auto size = snapshot_parked_size(archive, query_width);
    std::vector<std::uint8_t> bytes;
    bytes.reserve(static_cast<std::size_t>(size));
    kvmem::SnapshotWriter out([&](const void* data, std::size_t count) {
        const auto* first = static_cast<const std::uint8_t*>(data);
        bytes.insert(bytes.end(), first, first + count);
    });
    snapshot_parked_write(archive, query_width, out);
    if (out.bytes() != size) {
        throw std::logic_error("KVMem parked snapshot changed after sizing");
    }
    return bytes;
}

void KVMemConversation::stream_parked_snapshot(
    Parked& archive, std::uint32_t query_width, kvmem::SnapshotWriter& out, bool sizing) {
    if (archive.cache_invalidated_) {
        throw std::logic_error("KVMem invalidated archive cannot be exported");
    }
    if (archive.frozen_raw_) {
        if (!archive.reusable() || !archive.raw_ ||
            query_width != archive.compact_query_width_) {
            throw std::logic_error("native frozen export has an invalid owner");
        }
        if (!archive.runtime_) {
            if (!archive.compact_file_ || archive.runtime_raw_insert_offset_ < 12) {
                throw std::logic_error("native frozen export lacks its Runtime record");
            }
            auto size = archive.compact_file_->payload_bytes();
            for (std::size_t owner = 0; owner < (archive.follower_raw_ ? 2U : 1U); ++owner) {
                size = kvmem_session_checked_add(size,
                    8 + archive.frozen_raw_->store_snapshot_bytes(owner));
            }
            if (size > kMaxParkedSnapshotBytes) {
                throw std::length_error("native portable snapshot exceeds its byte limit");
            }
            if (sizing) {
                out.write(nullptr, size);
                return;
            }
            archive.compact_file_->load([&](kvmem::SnapshotReader& stream) {
                ParkedSnapshotReader in(stream);
                const auto magic = in.read_bytes(kParkedSnapshotMagic.size());
                if (!std::equal(magic.begin(), magic.end(), kParkedSnapshotMagic.begin()) ||
                    in.u32() != kRuntimeSnapshotVersion) {
                    throw kvmem::SnapshotCorrupt("incompatible native Runtime export");
                }
                out.write(kParkedSnapshotMagic.data(), kParkedSnapshotMagic.size());
                out.scalar(kParkedSnapshotVersion);
                std::array<std::uint8_t, 64U * 1024U> scratch;
                const auto copy = [&](std::uint64_t count) {
                    while (count) {
                        const auto part = static_cast<std::size_t>(std::min<std::uint64_t>(count, scratch.size()));
                        in.read_into(scratch.data(), part);
                        out.write(scratch.data(), part);
                        count -= part;
                    }
                };
                copy(archive.runtime_raw_insert_offset_ - 12);
                for (std::size_t owner = 0; owner < (archive.follower_raw_ ? 2U : 1U); ++owner) {
                    out.scalar(archive.frozen_raw_->store_snapshot_bytes(owner));
                    archive.frozen_raw_->write_store(owner, out);
                }
                if (in.remaining() < 8) { throw kvmem::SnapshotCorrupt("truncated native Runtime export"); }
                copy(in.remaining() - 8);
                const auto saved_hash = in.trailer_u64();
                if (saved_hash != in.hash() || in.remaining()) {
                    throw kvmem::SnapshotCorrupt("invalid native Runtime export checksum");
                }
            });
            out.scalar(out.hash());
            if (out.bytes() != size) {
                throw std::logic_error("native Runtime export changed after sizing");
            }
            return;
        }
        // A partially parked Runtime still needs the public one-block GPU
        // traversal; frozen Raw bytes are streamed from their native manifest.
        write_parked_snapshot(archive, query_width, out, sizing);
        return;
    }
    if (archive.compacted()) {
        if (archive.transition_failed_ || archive.backend_ == nullptr ||
            archive.runtime_ != nullptr || archive.raw_ != nullptr ||
            archive.follower_raw_ != nullptr ||
            archive.compact_file_ != nullptr ||
            archive.compact_query_width_ != query_width) {
            throw std::logic_error("KVMem compact snapshot has invalid idle ownership");
        }
        out.write(sizing ? nullptr : archive.compact_snapshot_.data(),
                  archive.compact_snapshot_.size());
        return;
    }
    write_parked_snapshot(archive, query_width, out, sizing);
}

void KVMemConversation::write_parked_snapshot(
    Parked& archive, std::uint32_t query_width, kvmem::SnapshotWriter& stream, bool sizing,
    bool external_raw) {
    if (archive.cache_invalidated_ || archive.transition_failed_ || archive.backend_ == nullptr ||
        archive.runtime_ == nullptr || archive.raw_ == nullptr ||
        archive.runtime_->pending() || archive.backend_->occupied_slots() != 0) {
        throw std::logic_error("KVMem parked snapshot requires a healthy idle host archive"
            " (invalidated=" + std::to_string(archive.cache_invalidated_) +
            ", transition_failed=" + std::to_string(archive.transition_failed_) +
            ", runtime=" + std::to_string(archive.runtime_ != nullptr) +
            ", raw=" + std::to_string(archive.raw_ != nullptr) +
            ", pending=" + std::to_string(archive.runtime_ && archive.runtime_->pending()) +
            ", occupied_gpu_slots=" + std::to_string(
                archive.backend_ ? archive.backend_->occupied_slots() : 0) + ")");
    }
    KVMemPageBackend& backend = *archive.backend_;
    kvmem::KvMemRuntime& runtime = *archive.runtime_;
    kvmem::KvMemStore& store = runtime.store();
    const std::uint32_t logical_tokens = store.total_tokens();
    if (logical_tokens > kMaxParkedLogicalTokens) {
        throw std::length_error("KVMem parked snapshot exceeds the logical-token limit");
    }
    validate_raw_geometry(runtime.config(), archive.raw_->config(),
                          archive.follower_raw_ != nullptr
                              ? std::optional<kvmem::RawKvStoreConfig>(
                                    archive.follower_raw_->config())
                              : std::nullopt,
                          backend.block_bytes());
    if (query_width == 0) {
        throw std::invalid_argument("KVMem parked snapshot query width is zero");
    }
    require_transferable(backend, runtime);
    require_metadata_transferable(archive.metadata_, runtime);
    validate_host_backing(runtime, backend, logical_tokens);
    validate_metadata_shape(archive.metadata_, logical_tokens, store.block_count(),
                            archive.raw_->config(), query_width);
    if (runtime.config().store.estimated_gpu_block_capacity != 0 &&
        archive.metadata_.prior_resident_block_ids.size() >
            runtime.config().store.estimated_gpu_block_capacity) {
        throw std::invalid_argument("KVMem saved resident set exceeds its configured capacity");
    }

    const std::uint64_t expected_blocks = logical_tokens == 0 ? 0 :
        (static_cast<std::uint64_t>(logical_tokens) + kLogicalBlockTokens - 1U) /
            kLogicalBlockTokens;
    if (expected_blocks != store.block_count()) {
        throw std::invalid_argument("KVMem parked snapshot block count is inconsistent");
    }
    std::vector<std::uint32_t> block_tokens;
    block_tokens.reserve(store.block_count());
    for (const kvmem::KvMemBlock& block : store.blocks()) {
        block_tokens.push_back(block.n_tokens);
    }
    validate_raw_frontier(*archive.raw_, store.block_count(), block_tokens,
                          archive.frozen_raw_ != nullptr);
    if (!archive.frozen_raw_) {
        validate_prior_resident_raw(archive.metadata_, store, *archive.raw_);
    }
    if (archive.follower_raw_ != nullptr) {
        validate_raw_frontier(*archive.follower_raw_, store.block_count(), block_tokens,
                              archive.frozen_raw_ != nullptr);
    }

    archive.raw_->wait_writes();
    if (archive.follower_raw_ != nullptr) {
        archive.follower_raw_->wait_writes();
    }
    ParkedSnapshotWriter out(stream, sizing);
    out.put_bytes(kParkedSnapshotMagic);
    out.put_u32(external_raw ? kRuntimeSnapshotVersion : kParkedSnapshotVersion);
    out.put_u32(kLogicalBlockTokens);
    const std::vector<std::uint8_t> runtime_config =
        encode_runtime_config(runtime.config());
    const std::vector<std::uint8_t> raw_config = encode_raw_config(archive.raw_->config());
    out.put_blob(runtime_config);
    out.put_blob(raw_config);
    out.put_bool(archive.follower_raw_ != nullptr);
    if (archive.follower_raw_ != nullptr) {
        const std::vector<std::uint8_t> follower_config =
            encode_raw_config(archive.follower_raw_->config());
        out.put_blob(follower_config);
    }
    out.put_u32(logical_tokens);
    out.put_u32(store.block_count());
    out.put_u64(backend.block_bytes());
    out.put_u32(query_width);
    write_metadata(out, archive.metadata_);
    if (external_raw) { archive.runtime_raw_insert_offset_ = out.size(); }
    else if (archive.frozen_raw_) {
        const auto write_frozen = [&](std::size_t owner) {
            const auto bytes = archive.frozen_raw_->store_snapshot_bytes(owner);
            out.put_u64(bytes);
            if (sizing) { out.count_bytes(bytes); return; }
            kvmem::SnapshotWriter raw_out([&](const void* data, std::size_t count) {
                out.put_bytes({static_cast<const std::uint8_t*>(data), count});
            });
            archive.frozen_raw_->write_store(owner, raw_out);
        };
        write_frozen(0);
        if (archive.follower_raw_) { write_frozen(1); }
    } else {
        write_raw_store(out, *archive.raw_, sizing);
        if (archive.follower_raw_ != nullptr) { write_raw_store(out, *archive.follower_raw_, sizing); }
    }

    constexpr std::uint64_t kBlockRecordHeaderBytes = 60;
    const std::uint64_t record_bytes = kBlockRecordHeaderBytes + backend.block_bytes();
    if (out.size() > kMaxParkedSnapshotBytes - sizeof(std::uint64_t)) {
        throw KVMemSnapshotPreflightError("KVMem parked snapshot exceeds its byte limit");
    }
    if (store.block_count() != 0 &&
        record_bytes > (kMaxParkedSnapshotBytes - out.size() - sizeof(std::uint64_t)) /
                           store.block_count()) {
        throw KVMemSnapshotPreflightError("KVMem parked snapshot exceeds its byte limit");
    }
    out.reserve_additional(record_bytes * store.block_count() + sizeof(std::uint64_t));
    if (sizing) {
        out.count_bytes(record_bytes * store.block_count());
        out.put_trailer_u64(0);
        return;
    }
    std::vector<std::uint8_t> packed_payload(
        static_cast<std::size_t>(backend.block_bytes()));
    KVMemPageBackend::HostArchiveScope host_transfer(backend);

    bool physical_transition_started = false;
    std::uint32_t active_block = std::numeric_limits<std::uint32_t>::max();
    std::optional<kvmem::KvMemBlock> active_original;
    try {
        for (std::uint32_t id = 0; id < store.block_count(); ++id) {
            const kvmem::KvMemBlock original = store.blocks()[id];
            active_block = id;
            active_original = original;

            // set_selection writes baked_pos and the remap counters even when
            // this traversal is only exporting bytes. Temporarily present a
            // same-position GPU working block so the public plan marks its
            // remap as a no-op; restore the host tier and original bake before
            // stage-in. Counter equality is checked while the original owner
            // is still recoverable.
            store.set_block_baked_pos(id, 0);
            store.set_block_tier(id, kvmem::KvTier::GPU,
                                 original.cpu_slot, original.nvme_slot);
            store.set_block_cpu_copy(id, original.cpu_slot);
            store.set_block_ssd_backing(id, original.nvme_slot, original.ssd_clean);
            const std::vector<std::uint32_t> selected{id};
            const kvmem::KvMemPlan& plan = runtime.prepare_selection(selected);
            if (store.blocks()[id].remap_count != original.remap_count ||
                store.blocks()[id].remap_abs_delta != original.remap_abs_delta) {
                archive.transition_failed_ = true;
                throw std::logic_error(
                    "KVMem snapshot traversal could not preserve remap counters");
            }
            if (!plan.stage_out.empty() || plan.stage_in != selected ||
                plan.remaps.size() != 1 || plan.remaps.front().block_id != id ||
                !plan.remaps.front().skip) {
                throw std::logic_error("KVMem snapshot traversal plan is not counter-neutral");
            }
            restore_source_block_metadata(store, id, original);
            runtime.spill_outgoing();
            physical_transition_started = true;
            runtime.admit_incoming();

            const kvmem::KvMemBlock& resident = store.blocks()[id];
            if (runtime.pending() || backend.occupied_slots() != 1 ||
                resident.tier != kvmem::KvTier::GPU || resident.gpu_slot < 0 ||
                !resident.in_working_set || resident.in_flight) {
                throw std::logic_error("KVMem snapshot stage-in did not admit exactly one block");
            }
            backend.copy_block_to_host(id, resident.gpu_slot, packed_payload.data(),
                                       backend.block_bytes());
            store.set_block_baked_pos(id, original.baked_pos);

            const std::vector<std::uint32_t> empty_selection;
            const kvmem::KvMemPlan& offload = runtime.prepare_selection(empty_selection);
            if (offload.stage_out != selected || !offload.stage_in.empty()) {
                throw std::logic_error(
                    "KVMem snapshot did not plan the exact single-block stage-out");
            }
            runtime.spill_outgoing();
            runtime.admit_incoming();
            if (runtime.pending() || backend.occupied_slots() != 0 ||
                store.blocks()[id].in_working_set ||
                store.blocks()[id].gpu_slot >= 0 ||
                store.blocks()[id].tier == kvmem::KvTier::GPU ||
                store.blocks()[id].baked_pos != original.baked_pos ||
                store.blocks()[id].remap_count != original.remap_count ||
                store.blocks()[id].remap_abs_delta != original.remap_abs_delta) {
                throw std::logic_error(
                    "KVMem snapshot stage-out changed host residency or remap metadata");
            }
            // The host archive is again complete before the transport sees
            // this payload. An optional file I/O failure here is recoverable.
            physical_transition_started = false;
            active_block = std::numeric_limits<std::uint32_t>::max();
            active_original.reset();
            write_block_record(out, original, packed_payload);
        }
        validate_restored_cpu_backing(runtime, backend);
        require_transferable(backend, runtime);
        validate_metadata_shape(archive.metadata_, logical_tokens, store.block_count(),
                                archive.raw_->config(), query_width);
        out.put_trailer_u64(out.hash());
    } catch (...) {
        if (physical_transition_started) {
            archive.transition_failed_ = true;
        } else if (active_block != std::numeric_limits<std::uint32_t>::max()) {
            try {
                if (runtime.pending()) { runtime.discard_pending(); }
                restore_source_block_metadata(store, active_block,
                                              *active_original);
                store.clear_working_set();
            } catch (...) {
                archive.transition_failed_ = true;
                std::throw_with_nested(std::runtime_error(
                    "KVMem snapshot pre-transition recovery failed; archive is fail-stop"));
            }
        }
        throw;
    }
}

KVMemConversation::Parked KVMemConversation::restore_parked_snapshot(
    std::span<const std::uint8_t> bytes,
    kvmem::KvMemRuntimeConfig runtime_config,
    kvmem::RawKvStoreConfig raw_config,
    KVMemPageBackend& backend,
    std::optional<kvmem::RawKvStoreConfig> follower_config,
    std::uint32_t query_width,
    const std::function<void(std::uint32_t, const SessionMetadata&, std::uint64_t)>& prepare_destination) {
    std::size_t cursor = 0;
    const auto source = [&](void* destination, std::size_t count) {
        if (count > bytes.size() - cursor) {
            throw kvmem::SnapshotCorrupt("truncated KVMem parked snapshot");
        }
        std::memcpy(destination, bytes.data() + cursor, count);
        cursor += count;
    };
    kvmem::SnapshotReader validation(source, bytes.size());
    (void)read_parked_snapshot(validation, runtime_config, raw_config, backend,
                               follower_config, query_width, true, false, prepare_destination);
    cursor = 0;
    kvmem::SnapshotReader input(source, bytes.size());
    return read_parked_snapshot(input, std::move(runtime_config), std::move(raw_config),
                                 backend, std::move(follower_config), query_width, false);
}

KVMemConversation::Parked KVMemConversation::read_parked_snapshot(
    kvmem::SnapshotReader& stream,
    kvmem::KvMemRuntimeConfig runtime_config,
    kvmem::RawKvStoreConfig raw_config,
    KVMemPageBackend& backend,
    std::optional<kvmem::RawKvStoreConfig> follower_config,
    std::uint32_t query_width, bool validation_only, bool external_raw,
    const std::function<void(std::uint32_t, const SessionMetadata&, std::uint64_t)>& prepare_destination) {
    if (!validation_only && backend.occupied_slots() != 0) {
        throw std::logic_error("KVMem parked snapshot restore requires an empty backend");
    }
    if (stream.remaining() > kMaxParkedSnapshotBytes || stream.remaining() < 8U + 4U + 4U + 8U) {
        throw kvmem::SnapshotCorrupt("KVMem parked snapshot size is invalid");
    }
    validate_raw_geometry(runtime_config, raw_config, follower_config,
                          backend.block_bytes());
    if (query_width == 0) {
        throw std::invalid_argument("KVMem parked restore requires a query width");
    }

    ParkedSnapshotReader in(stream);
    const bool magic_matches = std::equal(
        kParkedSnapshotMagic.begin(), kParkedSnapshotMagic.end(),
        in.read_bytes(kParkedSnapshotMagic.size()).begin());
    const std::uint32_t snapshot_version = in.u32();
    if (!magic_matches || snapshot_version !=
            (external_raw ? kRuntimeSnapshotVersion : kParkedSnapshotVersion) ||
        in.u32() != kLogicalBlockTokens) {
        throw kvmem::SnapshotCorrupt("unsupported KVMem parked snapshot format/version");
    }
    const std::vector<std::uint8_t> expected_runtime_config =
        encode_runtime_config(runtime_config);
    const std::vector<std::uint8_t> expected_raw_config = encode_raw_config(raw_config);
    expect_config_blob(in, expected_runtime_config, "Runtime");
    expect_config_blob(in, expected_raw_config, "target RawKvStore");
    const bool has_follower = in.boolean();
    if (has_follower != follower_config.has_value()) {
        throw kvmem::SnapshotCorrupt("KVMem parked follower configuration presence differs");
    }
    if (follower_config) {
        const std::vector<std::uint8_t> expected_follower_config =
            encode_raw_config(*follower_config);
        expect_config_blob(in, expected_follower_config, "follower RawKvStore");
    }

    const std::uint32_t logical_tokens = in.u32();
    const std::uint32_t block_count = in.u32();
    const std::uint64_t block_bytes = in.u64();
    const std::uint32_t saved_query_width = in.u32();
    const std::uint64_t expected_blocks = logical_tokens == 0 ? 0 :
        (static_cast<std::uint64_t>(logical_tokens) + kLogicalBlockTokens - 1U) /
            kLogicalBlockTokens;
    if (logical_tokens > kMaxParkedLogicalTokens ||
        logical_tokens > static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max()) ||
        expected_blocks != block_count || block_bytes > kMaxParkedBlockBytes) {
        throw kvmem::SnapshotCorrupt(
            "KVMem parked snapshot frontier or block geometry is invalid");
    }
    if (block_bytes != backend.block_bytes() || saved_query_width != query_width) {
        throw kvmem::SnapshotCorrupt("KVMem parked snapshot frontier or block geometry is invalid");
    }

    SessionMetadata metadata = read_metadata(in, logical_tokens, block_count, raw_config,
                                             query_width);
    if (runtime_config.store.estimated_gpu_block_capacity != 0 &&
        metadata.prior_resident_block_ids.size() >
            runtime_config.store.estimated_gpu_block_capacity) {
        throw kvmem::SnapshotCorrupt("KVMem saved resident set exceeds its configured capacity");
    }
    auto raw = validation_only ? std::unique_ptr<kvmem::RawKvStore>{}
                               : std::make_unique<kvmem::RawKvStore>(raw_config);
    std::uint64_t raw_extra_bytes = 0;
    if (!external_raw) {
        raw_extra_bytes = read_raw_store(in, raw.get(), raw_config, logical_tokens, block_count,
                                         metadata.prior_resident_block_ids);
    }
    std::unique_ptr<kvmem::RawKvStore> follower_raw;
    if (follower_config && !validation_only) {
        follower_raw = std::make_unique<kvmem::RawKvStore>(*follower_config);
    }
    if (has_follower && !external_raw) {
        raw_extra_bytes = kvmem_session_checked_add(raw_extra_bytes,
            read_raw_store(in, follower_raw.get(), *follower_config, logical_tokens, block_count));
    }
    if (validation_only) {
        for (std::uint32_t id = 0; id < block_count; ++id) {
            (void)read_block_record(in, id, logical_tokens, block_bytes);
        }
        const auto saved_checksum = in.trailer_u64();
        if (in.remaining() != 0 || in.hash() != saved_checksum) {
            throw kvmem::SnapshotCorrupt("KVMem parked snapshot checksum or length is invalid");
        }
        if (prepare_destination) {
            // Empty storage is measured at startup. The NInfer backend adds
            // page-locked CPU slots on demand while reconstructing the archive.
            // Add measured Raw vectors and the same bounded parser/shape/score
            // scratch used by same-run restore, not the full serialized file.
            kvmem::KvMemStore shape(runtime_config.store);
            shape.register_append(logical_tokens);
            const auto shape_bytes = shape.allocated_bytes() - sizeof(shape);
            auto additional = kvmem_session_checked_add(raw_extra_bytes, metadata_ram_bytes(metadata));
            if (backend.has_dynamic_cpu_storage()) {
                additional = kvmem_session_checked_add(additional, expected_blocks * block_bytes);
            }
            additional = kvmem_session_checked_add(additional,
                kvmem_session_checked_add(shape_bytes, shape_bytes));
            additional = kvmem_session_checked_add(additional, block_bytes + 64U * 1024U);
            additional = kvmem_session_checked_add(additional,
                std::uint64_t(block_count) * (3 * sizeof(double) + 8 * sizeof(std::uint32_t)));
            prepare_destination(logical_tokens, metadata, additional);
        }
        return {};
    }

    std::vector<std::uint32_t> block_tokens;
    block_tokens.reserve(block_count);
    for (std::uint32_t id = 0; id < block_count; ++id) {
        block_tokens.push_back(std::min(kLogicalBlockTokens,
                                        logical_tokens - id * kLogicalBlockTokens));
    }
    if (!external_raw) {
        validate_raw_frontier(*raw, block_count, block_tokens, false, true);
    }
    kvmem::KvMemStore shape(runtime_config.store);
    shape.register_append(logical_tokens);
    if (!external_raw) { validate_prior_resident_raw(metadata, shape, *raw, true); }
    if (follower_raw != nullptr && !external_raw) {
        validate_raw_frontier(*follower_raw, block_count, block_tokens, false, true);
    }

    auto runtime = std::make_unique<kvmem::KvMemRuntime>(runtime_config, &backend);
    if (block_count != 0) {
        kvmem::PinnedKvTier* cpu = runtime->cpu_tier();
        if (cpu == nullptr || !cpu->enabled() ||
            cpu->config().slot_bytes != backend.block_bytes() ||
            cpu->slot_count() < block_count) {
            throw std::invalid_argument(
                "KVMem parked restore Runtime lacks full CPU block capacity");
        }
    }
    runtime->register_append(logical_tokens);
    if (runtime->store().block_count() != block_count) {
        throw std::logic_error("KVMem parked restore Runtime registered an unexpected block count");
    }

    std::vector<double> retrieval_scores(block_count);
    std::vector<double> profile_scores(block_count);
    std::vector<double> attn_scores(block_count);
    kvmem::KvMemStore& store = runtime->store();
    // KvMemStore has only a media-range setter, not a getter or snapshot API.
    // Program reconstructs the ranges from its structural VisionItem identity
    // before publishing the parked continuation.
    store.set_media_ranges({});
    // register_append uses GPU as the default tier for newly produced rows.
    // Import has not produced any GPU payload: mark every unread descriptor
    // cold before traversing one record at a time. Otherwise selecting the
    // first record also stages out all later, still-uninitialized blocks.
    // These placeholders are private to construction; complete CPU backing
    // and the whole-file checksum are verified before returning an owner.
    for (std::uint32_t id = 0; id < block_count; ++id) {
        store.set_block_tier(id, kvmem::KvTier::CPU, -1, -1);
    }

    // remap_count/remap_abs_delta have no public setters. Restored blocks use
    // fresh counters; immutable-source cold stage-in refreshes raw K, and the
    // non-immutable NInfer configuration does not use these counters.
    KVMemPageBackend::HostArchiveScope host_transfer(backend);
    std::uint32_t active_block = std::numeric_limits<std::uint32_t>::max();
    std::int32_t active_gpu_slot = -1;
    try {
        for (std::uint32_t id = 0; id < block_count; ++id) {
            active_block = id;
            const ParkedBlockRecord record = read_block_record(in, id, logical_tokens, block_bytes);
            retrieval_scores[id] = record.retrieval_score;
            profile_scores[id] = record.profile_score;
            attn_scores[id] = record.attn_score;
            store.set_block_baked_pos(id, 0);
            store.set_block_tier(id, kvmem::KvTier::GPU);
            const std::vector<std::uint32_t> selected{id};
            const kvmem::KvMemPlan& plan = runtime->prepare_selection(selected);
            if (!plan.stage_out.empty() || plan.stage_in != selected ||
                plan.remaps.size() != 1 || !plan.remaps.front().skip ||
                store.blocks()[id].remap_count != 0 ||
                store.blocks()[id].remap_abs_delta != 0) {
                throw std::logic_error(
                    "KVMem restore could not make a counter-neutral block plan");
            }
            store.set_block_tier(id, kvmem::KvTier::CPU, -1, -1);
            runtime->spill_outgoing();
            runtime->admit_incoming();
            const kvmem::KvMemBlock& resident = store.blocks()[id];
            if (runtime->pending() || backend.occupied_slots() != 1 ||
                resident.tier != kvmem::KvTier::GPU || resident.gpu_slot < 0 ||
                !resident.in_working_set || resident.in_flight) {
                throw std::logic_error(
                    "KVMem restore did not admit exactly one packed block");
            }
            active_gpu_slot = resident.gpu_slot;
            backend.copy_block_from_host(id, active_gpu_slot,
                                         record.packed_payload.data(), block_bytes);
            store.set_block_baked_pos(id, record.baked_pos);

            const std::vector<std::uint32_t> empty_selection;
            const kvmem::KvMemPlan& offload = runtime->prepare_selection(empty_selection);
            if (offload.stage_out != selected || !offload.stage_in.empty()) {
                throw std::logic_error(
                    "KVMem restore did not plan the exact single-block stage-out");
            }
            runtime->spill_outgoing();
            runtime->admit_incoming();
            active_gpu_slot = -1;
            if (runtime->pending() || backend.occupied_slots() != 0 ||
                store.blocks()[id].tier != kvmem::KvTier::CPU ||
                store.blocks()[id].gpu_slot >= 0 || store.blocks()[id].cpu_slot < 0 ||
                store.blocks()[id].baked_pos != record.baked_pos) {
                throw std::logic_error(
                    "KVMem restore failed to retain the imported block on CPU");
            }
            active_block = std::numeric_limits<std::uint32_t>::max();
        }
        const auto saved_checksum = in.trailer_u64();
        if (in.remaining() != 0 || in.hash() != saved_checksum) {
            throw kvmem::SnapshotCorrupt("KVMem parked snapshot checksum or length is invalid");
        }
        restore_scores(store, retrieval_scores, profile_scores, attn_scores);
    } catch (...) {
        const std::exception_ptr original_failure = std::current_exception();
        try {
            if (runtime->pending()) { runtime->discard_pending(); }
            if (active_gpu_slot < 0 && active_block < store.block_count()) {
                active_gpu_slot = store.blocks()[active_block].gpu_slot;
            }
            if (backend.occupied_slots() != 0) {
                if (backend.occupied_slots() != 1 || active_gpu_slot < 0) {
                    throw std::logic_error(
                        "KVMem restore cleanup cannot identify its sole GPU slot");
                }
                // The caller guaranteed exclusive idle ownership and this
                // restore allocated at most one slot at a time, so it has no
                // execution-address references and can be safely released
                // even if a copy or native stage operation threw.
                backend.free_gpu_slot(active_gpu_slot);
            }
            if (backend.occupied_slots() != 0 || runtime->pending()) {
                throw std::logic_error("KVMem restore cleanup left backend state occupied");
            }
        } catch (...) {
            std::throw_with_nested(std::runtime_error(
                "KVMem restore failed and its GPU-slot cleanup could not complete"));
        }
        std::rethrow_exception(original_failure);
    }

    validate_restored_cpu_backing(*runtime, backend);
    if (backend.occupied_slots() != 0 || runtime->pending()) {
        throw std::logic_error("KVMem parked restore did not finish host-only");
    }
    if (follower_raw != nullptr) { follower_raw->wait_writes(); }
    raw->wait_writes();

    Parked restored;
    restored.backend_ = &backend;
    restored.runtime_ = std::move(runtime);
    restored.raw_ = std::move(raw);
    restored.follower_raw_ = std::move(follower_raw);
    restored.metadata_ = std::move(metadata);
    return restored;
}

void KVMemConversation::release_empty_host_archive() {
    require_attached();
    if (backend_->occupied_slots() != 0 || runtime_->pending() ||
        runtime_->store().total_tokens() != 0 || !metadata_.empty()) {
        throw std::logic_error("KVMem empty destination still owns archive state");
    }
    raw_->wait_writes();
    if (follower_raw_ != nullptr) { follower_raw_->wait_writes(); }
    runtime_->truncate_to(0);
    raw_.reset();
    follower_raw_.reset();
    runtime_.reset();
}

void KVMemConversation::swap_host_archive_with(Parked& parked) {
    require_attached();
    if (parked.empty() || parked.backend_ != backend_ ||
        parked.runtime_ == nullptr || parked.raw_ == nullptr) {
        throw std::invalid_argument("parked KVMem conversation belongs to a different backend");
    }
    if (metadata_.cold || parked.metadata_.cold) {
        throw std::logic_error("KVMem cold conversation cannot participate in an owner swap");
    }

    require_transferable(*backend_, *runtime_);
    require_transferable(*backend_, *parked.runtime_);
    require_metadata_transferable(metadata_, *runtime_);
    require_metadata_transferable(parked.metadata_, *parked.runtime_);
    raw_->wait_writes();
    parked.raw_->wait_writes();
    if (follower_raw_ != nullptr) {
        follower_raw_->wait_writes();
    }
    if (parked.follower_raw_ != nullptr) {
        parked.follower_raw_->wait_writes();
    }
    require_transferable(*backend_, *runtime_);
    require_transferable(*backend_, *parked.runtime_);
    require_metadata_transferable(metadata_, *runtime_);
    require_metadata_transferable(parked.metadata_, *parked.runtime_);

    runtime_.swap(parked.runtime_);
    raw_.swap(parked.raw_);
    follower_raw_.swap(parked.follower_raw_);
    metadata_.swap(parked.metadata_);
}

} // namespace ninfer::models::qwen3_5::detail
