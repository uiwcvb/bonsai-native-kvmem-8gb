// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#include "models/qwen3_5/program/storage/kvmem_parked_file.h"

#include <kvmem-session-files.h>
#include <kvmem-session-transfer.h>

#include <limits>
#include <stdexcept>
#include <utility>

namespace ninfer::models::qwen3_5::detail {
namespace {
constexpr std::uint64_t kParkedFileMagic = 0x3130454c4946564bull; // KVFILE01
constexpr std::uint64_t kParkedFileHeaderBytes = 8 + 4 + 8 + 8;
} // namespace

struct KVMemParkedFileState::Impl {
    Impl(std::filesystem::path root, std::uint64_t byte_limit)
        : native(std::move(root), byte_limit),
          file_generation(std::filesystem::hash_value(native.directory())) {}

    kvmem_session_files native;
    const std::uint64_t file_generation;
    std::uint64_t next_id = 1;
};

KVMemParkedFileState::KVMemParkedFileState(
    std::filesystem::path root,
    std::uint64_t byte_limit)
    : impl_(std::make_unique<Impl>(std::move(root), byte_limit)) {}

KVMemParkedFileState::~KVMemParkedFileState() = default;

int KVMemParkedFileState::allocate_id() {
    if (!impl_ || impl_->next_id > static_cast<std::uint64_t>((std::numeric_limits<int>::max)())) {
        throw std::overflow_error("parked-file cache exhausted native snapshot ids");
    }
    return static_cast<int>(impl_->next_id++);
}

KVMemParkedFileState::PayloadIdentity KVMemParkedFileState::allocate_payload_identity() {
    const int id = allocate_id();
    // IDs are never reused, so the native opaque generation can identify the
    // private run. A counter restarting at one would accept a valid same-id
    // chunk accidentally substituted from another run.
    return {id, impl_->file_generation};
}

std::uint64_t KVMemParkedFileState::file_generation() const noexcept {
    return impl_ ? impl_->file_generation : 0;
}

std::uint64_t KVMemParkedFileState::bytes() const noexcept {
    return impl_ ? impl_->native.bytes() : 0;
}

std::uint64_t KVMemParkedFileState::limit() const noexcept {
    return impl_ ? impl_->native.limit() : 0;
}

std::uint64_t KVMemParkedFileState::available() const {
    if (!impl_) { throw std::logic_error("parked-file cache has no native owner"); }
    return impl_->native.available();
}

std::uint64_t KVMemParkedFileState::session_bytes(int id) const noexcept {
    if (!impl_) return 0;
    try { return impl_->native.session_bytes(id); }
    catch (...) { return 0; }
}

bool KVMemParkedFileState::erase_session(int id) noexcept {
    if (!impl_) return true;
    try { return impl_->native.erase(id); }
    catch (...) { return false; }
}

void KVMemParkedFileState::save_legacy(
    int id,
    std::uint64_t payload_bytes,
    const WriteCallback & write) {
    impl_->native.save(id, payload_bytes, write);
}

void KVMemParkedFileState::load_legacy(int id, const ReadCallback & read) const {
    impl_->native.load(id, read);
}

void KVMemParkedFileState::spill(kvmem_session_payload & payload, std::uint32_t index) {
    payload.spill(impl_->native, index);
}

void KVMemParkedFileState::restore(kvmem_session_payload & payload, std::uint32_t index) {
    payload.restore(impl_->native, index);
}

void KVMemParkedFileState::load_chunk(
    int id,
    std::uint32_t index,
    const ReadCallback & read) const {
    impl_->native.load_chunk(id, index, read);
}

bool KVMemParkedFileState::chunk_ready(int id, std::uint32_t index) const noexcept {
    if (!impl_) return false;
    try { return impl_->native.ready(id, index); }
    catch (...) { return false; }
}

bool KVMemParkedFileState::chunk_present(int id, std::uint32_t index) const noexcept {
    if (!impl_) return false;
    try { return impl_->native.contains_chunk(id, index); }
    catch (...) { return false; }
}

std::uint64_t KVMemParkedFileState::chunk_bytes(int id, std::uint32_t index) const noexcept {
    if (!impl_) return 0;
    try { return impl_->native.chunk_bytes(id, index); }
    catch (...) { return 0; }
}

std::filesystem::path KVMemParkedFileState::path(int id, std::uint32_t index) const {
    return impl_->native.path(id, index);
}

void KVMemParkedFileState::set_fault(
    std::function<void(const char *, int, std::uint32_t)> fault) {
    if (!impl_) { throw std::logic_error("cannot configure a moved-from parked-file cache"); }
    impl_->native.fault = std::move(fault);
}

KVMemParkedFileCache::KVMemParkedFileCache(
    std::filesystem::path root,
    std::uint64_t byte_limit) {
    if (byte_limit == 0) {
        throw std::invalid_argument("parked-file cache byte limit must be nonzero");
    }
    state_ = std::make_shared<KVMemParkedFileState>(std::move(root), byte_limit);
}

KVMemParkedFileCache::~KVMemParkedFileCache() = default;
KVMemParkedFileCache::KVMemParkedFileCache(KVMemParkedFileCache &&) noexcept = default;
KVMemParkedFileCache & KVMemParkedFileCache::operator=(KVMemParkedFileCache &&) noexcept = default;

std::unique_ptr<KVMemParkedSnapshotFile> KVMemParkedFileCache::write(
    std::uint64_t payload_bytes,
    const WriteCallback & write_callback) {
    if (!state_) {
        throw std::logic_error("cannot write through a moved-from parked-file cache");
    }
    if (payload_bytes > (std::numeric_limits<std::uint64_t>::max)() - kParkedFileHeaderBytes) {
        throw std::length_error("parked-file snapshot length overflow");
    }

    const int id = state_->allocate_id();

    // Own the id before native save can publish its file, so allocation failure
    // cannot leave a published record without an RAII owner.
    auto file = std::unique_ptr<KVMemParkedSnapshotFile>(
        new KVMemParkedSnapshotFile(state_, id, payload_bytes));
    // Adapt the pinned transfer header's trusted id/generation/length checks.
    // A checksum alone cannot reject a different, otherwise valid snapshot.
    state_->save_legacy(id, payload_bytes + kParkedFileHeaderBytes,
                       [&](kvmem::SnapshotWriter & writer) {
        writer.scalar(kParkedFileMagic);
        writer.scalar(static_cast<std::int32_t>(id));
        writer.scalar(state_->file_generation());
        writer.scalar(payload_bytes);
        // The file identity header belongs to the enclosing native checksum,
        // not the archive's checksum. Give its codec a fresh native scope;
        // forwarding retains the original complete-file byte/hash contract.
        kvmem::SnapshotWriter payload([&](const void* data, std::size_t count) {
            writer.write(data, count);
        });
        write_callback(payload);
        if (payload.bytes() != payload_bytes) {
            throw std::logic_error("parked-file payload differs from its planned length");
        }
    });
    return file;
}

std::uint64_t KVMemParkedFileCache::bytes() const noexcept {
    return state_ ? state_->bytes() : 0;
}

std::uint64_t KVMemParkedFileCache::limit() const noexcept {
    return state_ ? state_->limit() : 0;
}

std::uint64_t KVMemParkedFileCache::available() const {
    if (!state_) { throw std::logic_error("parked-file cache has no native owner"); }
    return state_->available();
}

std::uint64_t KVMemParkedFileCache::charged_bytes(std::uint64_t payload_bytes) {
    constexpr auto overhead = kParkedFileHeaderBytes + sizeof(std::uint64_t);
    if (payload_bytes > (std::numeric_limits<std::uint64_t>::max)() - overhead) {
        throw std::length_error("parked-file charged snapshot length overflow");
    }
    return payload_bytes + overhead;
}

void KVMemParkedFileCache::set_fault(
    std::function<void(const char*, int, std::uint32_t)> fault) {
    if (!state_) { throw std::logic_error("cannot configure a moved-from parked-file cache"); }
    state_->set_fault(std::move(fault));
}

KVMemParkedSnapshotFile::KVMemParkedSnapshotFile(
    std::shared_ptr<KVMemParkedFileState> state,
    int id,
    std::uint64_t payload_bytes) noexcept
    : state_(std::move(state)), id_(id), payload_bytes_(payload_bytes) {}

KVMemParkedSnapshotFile::~KVMemParkedSnapshotFile() noexcept {
    (void)erase();
}

std::uint64_t KVMemParkedSnapshotFile::charged_bytes() const noexcept {
    return state_ ? state_->session_bytes(id_) : 0;
}

bool KVMemParkedSnapshotFile::erase() noexcept {
    return !state_ || state_->erase_session(id_);
}

void KVMemParkedSnapshotFile::load(const ReadCallback & read_callback) const {
    state_->load_legacy(id_, [&](kvmem::SnapshotReader & reader) {
        reader.expect(kParkedFileMagic);
        reader.expect(static_cast<std::int32_t>(id_));
        reader.expect(state_->file_generation());
        reader.expect(payload_bytes_);
        if (reader.remaining() != payload_bytes_) {
            throw kvmem::SnapshotCorrupt("parked-file payload length changed");
        }
        // Header validation above consumes only the containing file scope.
        // The archive codec borrows a separate, fresh native payload scope.
        kvmem::SnapshotReader payload([&](void* data, std::size_t count) {
            reader.read(data, count);
        }, payload_bytes_);
        read_callback(payload);
        if (payload.remaining() != 0) {
            throw kvmem::SnapshotCorrupt("parked-file payload was not fully consumed");
        }
    });
}

std::filesystem::path KVMemParkedSnapshotFile::path() const {
    return state_->path(id_);
}

} // namespace ninfer::models::qwen3_5::detail
