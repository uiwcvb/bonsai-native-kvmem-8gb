// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#include "models/qwen3_5/program/storage/kvmem_frozen_raw.h"
#include "models/qwen3_5/program/storage/kvmem_query_checkpoint.h"

#include <kvmem-session-transfer.h>
#include <kvmem/raw_kv_store.hpp>
#include <kvmem/snapshot_buffer.hpp>

#include <algorithm>
#include <array>
#include <cstring>
#include <limits>
#include <optional>
#include <stdexcept>
#include <unordered_set>
#include <utility>
#include <vector>

namespace ninfer::models::qwen3_5::detail {
namespace {

constexpr std::uint32_t kRawSnapshotMagic = 0x31564b52;
constexpr std::uint64_t kNativeChunkHeaderBytes = 32;
constexpr std::size_t kDrainBytes = 64 * 1024;
constexpr std::array<std::uint64_t, 5> kRawVectorElementBytes{1, 2, 1, 1, 4};

std::uint64_t checked_add(std::uint64_t a, std::uint64_t b, const char * what) {
    if (b > (std::numeric_limits<std::uint64_t>::max)() - a) {
        throw std::length_error(what);
    }
    return a + b;
}

std::uint64_t checked_mul(std::uint64_t a, std::uint64_t b, const char * what) {
    if (a != 0 && b > (std::numeric_limits<std::uint64_t>::max)() / a) {
        throw std::length_error(what);
    }
    return a * b;
}

std::uint64_t checked_capacity_bytes(const kvmem::SnapshotBuffer & buffer) {
    if (!buffer.capacity || !buffer.object) {
        throw std::runtime_error("RawKvStore returned an invalid snapshot binding");
    }
    return buffer.ram_bytes();
}

struct TapeOp {
    enum class Kind : std::uint8_t { literal, buffer } kind = Kind::literal;
    std::vector<std::uint8_t> literal;
    std::size_t buffer_index = 0;
    std::uint64_t count = 0;
    std::uint64_t bytes = 0;
};

class RawSnapshotTapeCapture {
public:
    RawSnapshotTapeCapture(
        const kvmem::RawKvStoreConfig & config,
        const std::vector<kvmem::SnapshotBuffer> & bindings,
        std::size_t binding_base)
        : config_(config), bindings_(bindings), binding_base_(binding_base) {
        scalar_bytes_ = sizeof(std::uint32_t);
    }

    void consume(const void * data, std::size_t size) {
        auto * source = static_cast<const std::uint8_t *>(data);
        while (size != 0) {
            if (mode_ == Mode::done) {
                throw std::runtime_error("RawKvStore snapshot has trailing bytes");
            }
            if (mode_ == Mode::layer_fields) {
                const auto part = (std::min)(size, layer_fields_left_);
                append_literal(source, part);
                count_block_bytes(part);
                source += part;
                size -= part;
                layer_fields_left_ -= part;
                if (layer_fields_left_ == 0) begin_vector_count();
                continue;
            }
            if (mode_ == Mode::vector_data) {
                const auto part = static_cast<std::size_t>((std::min<std::uint64_t>)
                    (size, vector_data_left_));
                count_seen(part);
                count_block_bytes(part);
                source += part;
                size -= part;
                vector_data_left_ -= part;
                if (vector_data_left_ == 0) next_vector();
                continue;
            }

            const auto part = (std::min)(size, scalar_bytes_ - scalar_have_);
            if (mode_ == Mode::vector_count) count_seen(part);
            else append_literal(source, part);
            std::memcpy(scalar_.data() + scalar_have_, source, part);
            source += part;
            size -= part;
            scalar_have_ += part;
            if (scalar_have_ == scalar_bytes_) finish_scalar();
        }
    }

    void finish(std::uint64_t expected_bytes) {
        if (mode_ != Mode::done || scalar_have_ != 0 || seen_bytes_ != expected_bytes) {
            throw std::runtime_error("RawKvStore snapshot tape is incomplete");
        }
        while (binding_cursor_ < bindings_.size()) {
            const auto & binding = bindings_[binding_cursor_++];
            if (binding.count != 0 || binding.size != 0) {
                throw std::runtime_error("RawKvStore snapshot omitted a bound vector");
            }
        }
        flush_literal();
    }

    std::vector<TapeOp> take_ops() { return std::move(ops_); }
private:
    enum class Mode : std::uint8_t { header, block_size, layer_fields, vector_count, vector_data, done };

    std::uint64_t scalar_value() const {
        if (scalar_bytes_ == sizeof(std::uint32_t)) {
            std::uint32_t value = 0;
            std::memcpy(&value, scalar_.data(), sizeof(value));
            return value;
        }
        if (scalar_bytes_ == sizeof(std::uint64_t)) {
            std::uint64_t value = 0;
            std::memcpy(&value, scalar_.data(), sizeof(value));
            return value;
        }
        throw std::logic_error("invalid RawKvStore snapshot scalar width");
    }

    void count_seen(std::uint64_t bytes) {
        seen_bytes_ = checked_add(seen_bytes_, bytes, "RawKvStore snapshot byte count overflow");
    }

    void count_block_bytes(std::uint64_t bytes) {
        block_bytes_ = checked_add(block_bytes_, bytes, "RawKvStore block length overflow");
        if (block_bytes_ > declared_block_bytes_) {
            throw std::runtime_error("RawKvStore block length is shorter than its contents");
        }
    }

    void append_literal(const std::uint8_t * data, std::size_t size) {
        if (size == 0) return;
        count_seen(size);
        literal_bytes_ = checked_add(literal_bytes_, size, "RawKvStore metadata tape length overflow");
        if (size > pending_literal_.max_size() - pending_literal_.size()) {
            throw std::length_error("RawKvStore metadata tape is too large");
        }
        pending_literal_.insert(pending_literal_.end(), data, data + size);
    }

    void flush_literal() {
        if (pending_literal_.empty()) return;
        if (ops_.size() == ops_.max_size()) {
            throw std::length_error("RawKvStore metadata tape has too many records");
        }
        TapeOp op;
        op.kind = TapeOp::Kind::literal;
        op.literal = std::move(pending_literal_);
        ops_.push_back(std::move(op));
        pending_literal_.clear();
    }

    void append_count_literal() {
        literal_bytes_ = checked_add(literal_bytes_, scalar_bytes_, "RawKvStore metadata tape length overflow");
        if (scalar_bytes_ > pending_literal_.max_size() - pending_literal_.size()) {
            throw std::length_error("RawKvStore metadata tape is too large");
        }
        pending_literal_.insert(pending_literal_.end(), scalar_.begin(), scalar_.begin() + scalar_bytes_);
    }

    void append_buffer(std::size_t local_index, std::uint64_t count, std::uint64_t bytes) {
        flush_literal();
        if (local_index > (std::numeric_limits<std::size_t>::max)() - binding_base_) {
            throw std::length_error("RawKvStore binding index overflow");
        }
        if (ops_.size() == ops_.max_size()) {
            throw std::length_error("RawKvStore metadata tape has too many records");
        }
        TapeOp op;
        op.kind = TapeOp::Kind::buffer;
        op.buffer_index = binding_base_ + local_index;
        op.count = count;
        op.bytes = bytes;
        ops_.push_back(std::move(op));
    }

    void begin_header_scalar() {
        scalar_bytes_ = header_field_ < 5 ? sizeof(std::uint32_t) : sizeof(std::uint64_t);
        scalar_have_ = 0;
    }

    void begin_block_size() {
        mode_ = Mode::block_size;
        scalar_bytes_ = sizeof(std::uint64_t);
        scalar_have_ = 0;
    }

    void begin_layer_fields() {
        mode_ = Mode::layer_fields;
        layer_fields_left_ = 4 * sizeof(std::uint32_t) + 2 * sizeof(std::uint8_t);
    }

    void begin_vector_count() {
        mode_ = Mode::vector_count;
        scalar_bytes_ = sizeof(std::uint64_t);
        scalar_have_ = 0;
        vector_index_ = 0;
    }

    void finish_header_field(std::uint64_t value) {
        switch (header_field_) {
            case 0: if (value != kRawSnapshotMagic) throw std::runtime_error("unexpected RawKvStore snapshot magic"); break;
            case 1: if (value != config_.n_layer) throw std::runtime_error("RawKvStore layer count changed during freeze"); break;
            case 2: if (value != config_.n_embd_k) throw std::runtime_error("RawKvStore K width changed during freeze"); break;
            case 3: if (value != config_.n_embd_v) throw std::runtime_error("RawKvStore V width changed during freeze"); break;
            case 4: if (value != config_.block_tokens) throw std::runtime_error("RawKvStore block size changed during freeze"); break;
            case 5: if (value != config_.k_row_bytes) throw std::runtime_error("RawKvStore K row size changed during freeze"); break;
            case 6: if (value != config_.k_gpu_row_bytes) throw std::runtime_error("RawKvStore packed K row size changed during freeze"); break;
            case 7: if (value != config_.v_gpu_row_bytes) throw std::runtime_error("RawKvStore packed V row size changed during freeze"); break;
            case 8:
                if (value > std::uint64_t((std::numeric_limits<std::uint32_t>::max)()) + 1) {
                    throw std::runtime_error("RawKvStore snapshot block count is out of range");
                }
                blocks_left_ = value;
                if (header_field_ != 8) throw std::logic_error("invalid RawKvStore header state");
                if (blocks_left_ == 0) mode_ = Mode::done;
                else begin_block_size();
                return;
            default: throw std::logic_error("invalid RawKvStore snapshot header field");
        }
        ++header_field_;
        begin_header_scalar();
    }

    void finish_block_size(std::uint64_t value) {
        declared_block_bytes_ = value;
        block_bytes_ = 0;
        layer_index_ = 0;
        if (config_.n_layer == 0) finish_block();
        else begin_layer_fields();
    }

    void finish_vector_count(std::uint64_t count) {
        count_block_bytes(sizeof(std::uint64_t));
        const auto element_bytes = kRawVectorElementBytes[vector_index_];
        const auto bytes = checked_mul(count, element_bytes, "RawKvStore vector byte count overflow");
        if (count > (std::numeric_limits<std::size_t>::max)() / element_bytes) {
            throw std::length_error("RawKvStore vector count is out of range");
        }
        if (bytes > declared_block_bytes_ - block_bytes_) {
            throw std::runtime_error("RawKvStore vector exceeds its declared block length");
        }
        if (count != 0) {
            while (binding_cursor_ < bindings_.size() && bindings_[binding_cursor_].count == 0) {
                if (bindings_[binding_cursor_].size != 0) {
                    throw std::runtime_error("RawKvStore has an invalid empty snapshot binding");
                }
                ++binding_cursor_;
            }
            if (binding_cursor_ == bindings_.size()) {
                throw std::runtime_error("RawKvStore snapshot vector has no allocation binding");
            }
            const auto & binding = bindings_[binding_cursor_];
            if (binding.count != count || binding.size != bytes || !binding.write || !binding.read || !binding.clear) {
                throw std::runtime_error("RawKvStore snapshot vector disagrees with its allocation binding");
            }
            append_buffer(binding_cursor_, count, bytes);
            ++binding_cursor_;
        } else append_count_literal();
        vector_data_left_ = bytes;
        if (vector_data_left_ == 0) next_vector();
        else mode_ = Mode::vector_data;
    }

    void finish_scalar() {
        const auto value = scalar_value();
        scalar_have_ = 0;
        switch (mode_) {
            case Mode::header: finish_header_field(value); break;
            case Mode::block_size: finish_block_size(value); break;
            case Mode::vector_count: finish_vector_count(value); break;
            default: throw std::logic_error("unexpected RawKvStore snapshot scalar");
        }
    }

    void next_vector() {
        ++vector_index_;
        if (vector_index_ < kRawVectorElementBytes.size()) {
            mode_ = Mode::vector_count;
            scalar_bytes_ = sizeof(std::uint64_t);
            scalar_have_ = 0;
            return;
        }
        ++layer_index_;
        if (layer_index_ < config_.n_layer) begin_layer_fields();
        else finish_block();
    }

    void finish_block() {
        if (block_bytes_ != declared_block_bytes_) {
            throw std::runtime_error("RawKvStore declared block length disagrees with its contents");
        }
        if (blocks_left_ == 0) throw std::logic_error("RawKvStore block counter underflow");
        --blocks_left_;
        if (blocks_left_ == 0) mode_ = Mode::done;
        else begin_block_size();
    }

    const kvmem::RawKvStoreConfig & config_;
    const std::vector<kvmem::SnapshotBuffer> & bindings_;
    const std::size_t binding_base_;
    std::vector<TapeOp> ops_;
    std::vector<std::uint8_t> pending_literal_;
    std::array<std::uint8_t, sizeof(std::uint64_t)> scalar_{};
    Mode mode_ = Mode::header;
    std::size_t scalar_bytes_ = 0;
    std::size_t scalar_have_ = 0;
    std::size_t header_field_ = 0;
    std::size_t layer_fields_left_ = 0;
    std::size_t layer_index_ = 0;
    std::size_t vector_index_ = 0;
    std::size_t binding_cursor_ = 0;
    std::uint64_t blocks_left_ = 0;
    std::uint64_t declared_block_bytes_ = 0;
    std::uint64_t block_bytes_ = 0;
    std::uint64_t vector_data_left_ = 0;
    std::uint64_t seen_bytes_ = 0;
    std::uint64_t literal_bytes_ = 0;
};

void validate_group_arithmetic(
    const std::vector<kvmem::SnapshotBuffer> & buffers,
    std::uint64_t group_bytes) {
    std::uint64_t group_size = 0;
    std::uint64_t chunk_payload = 0;
    std::uint64_t total_disk = 0;
    std::uint64_t chunk_count = 0;
    for (const auto & buffer : buffers) {
        if (!buffer.write || !buffer.read || !buffer.clear || !buffer.object || !buffer.capacity) {
            throw std::runtime_error("RawKvStore returned an incomplete allocation binding");
        }
        if (buffer.size > (std::numeric_limits<std::uint64_t>::max)() - sizeof(std::uint64_t)) {
            throw std::length_error("RawKvStore buffer length overflow");
        }
        const bool split = chunk_count == 0 ||
            (group_size != 0 && (buffer.size >= group_bytes || group_size > group_bytes - buffer.size));
        if (split) {
            if (chunk_count != 0) {
                total_disk = checked_add(total_disk, chunk_payload, "RawKvStore disk length overflow");
                total_disk = checked_add(total_disk, sizeof(std::uint64_t), "RawKvStore disk length overflow");
            }
            if (chunk_count == (std::numeric_limits<std::uint32_t>::max)()) {
                throw std::length_error("RawKvStore has too many native chunks");
            }
            ++chunk_count;
            group_size = 0;
            chunk_payload = kNativeChunkHeaderBytes;
        }
        const auto entry = checked_add(sizeof(std::uint64_t), buffer.size, "RawKvStore chunk length overflow");
        group_size = checked_add(group_size, entry, "RawKvStore group length overflow");
        chunk_payload = checked_add(chunk_payload, entry, "RawKvStore chunk length overflow");
    }
    if (chunk_count != 0) {
        total_disk = checked_add(total_disk, chunk_payload, "RawKvStore disk length overflow");
        total_disk = checked_add(total_disk, sizeof(std::uint64_t), "RawKvStore disk length overflow");
    }
    (void) total_disk;
}

template<class Payload>
std::uint64_t expected_chunk_payload(const Payload & payload, std::uint32_t index) {
    const auto & chunk = payload.chunks.at(index);
    std::uint64_t total = kNativeChunkHeaderBytes;
    for (const auto & buffer : chunk.buffers) {
        total = checked_add(total, sizeof(std::uint64_t), "native chunk length overflow");
        total = checked_add(total, buffer.size, "native chunk length overflow");
    }
    return total;
}

template<class Payload>
void read_and_check_chunk_prefix(
    const Payload & payload,
    std::uint32_t index,
    kvmem::SnapshotReader & reader) {
    payload.check_header(reader, index);
    const auto & chunk = payload.chunks.at(index);
    std::uint64_t body_bytes = 0;
    for (const auto & buffer : chunk.buffers) {
        body_bytes = checked_add(body_bytes, sizeof(std::uint64_t), "native chunk body length overflow");
        body_bytes = checked_add(body_bytes, buffer.size, "native chunk body length overflow");
    }
    if (reader.remaining() != body_bytes) {
        throw kvmem::SnapshotCorrupt("native chunk length disagrees with its in-memory manifest");
    }
}

void drain_bytes(kvmem::SnapshotReader & reader, std::uint64_t bytes,
                 std::array<std::uint8_t, kDrainBytes> & scratch) {
    while (bytes != 0) {
        const auto part = static_cast<std::size_t>((std::min<std::uint64_t>)(bytes, scratch.size()));
        reader.read(scratch.data(), part);
        bytes -= part;
    }
}

} // namespace

struct KVMemFrozenRaw::Impl {
    struct ChunkRange {
        std::size_t first_buffer = 0;
        std::size_t buffer_count = 0;
    };

    struct StoreTape {
        std::vector<TapeOp> ops;
        std::uint64_t snapshot_bytes = 0;
    };

    struct CheckpointBuffers {
        std::shared_ptr<const KVMemQueryBoundaryCheckpoint> owner;
        std::size_t image = 0;
        std::optional<std::size_t> tail_mean;
    };

    Impl(std::shared_ptr<KVMemParkedFileState> file_state,
         std::span<kvmem::RawKvStore * const> input_stores,
         KVMemParkedFileState::PayloadIdentity payload_identity,
         std::uint64_t group_bytes,
         std::span<const std::shared_ptr<const KVMemQueryBoundaryCheckpoint>> input_checkpoints)
        : state(std::move(file_state)), id(payload_identity.id), generation(payload_identity.generation) {
        std::vector<kvmem::SnapshotBuffer> bindings;
        if (!state) throw std::invalid_argument("frozen Raw cache requires a live native file manager");
        if (input_stores.size() > owners.max_size()) {
            throw std::length_error("too many RawKvStore owners");
        }
        owners.reserve(input_stores.size());
        tapes.reserve(input_stores.size());
        std::unordered_set<kvmem::RawKvStore *> unique_stores;
        unique_stores.reserve(input_stores.size());

        std::uint64_t resident_bytes = 0;
        std::uint64_t restore_bytes_total = 0;
        for (auto * store : input_stores) {
            if (!store) throw std::invalid_argument("freeze_raw received a null RawKvStore");
            if (!unique_stores.insert(store).second) {
                throw std::invalid_argument("freeze_raw received the same RawKvStore more than once");
            }
            owners.push_back(store);

            std::vector<kvmem::SnapshotBuffer> local_bindings;
            store->snapshot_buffers(local_bindings);
            const auto binding_base = bindings.size();
            if (local_bindings.size() > (std::numeric_limits<std::size_t>::max)() - binding_base) {
                throw std::length_error("RawKvStore binding count overflow");
            }
            for (const auto & binding : local_bindings) {
                resident_bytes = checked_add(resident_bytes, checked_capacity_bytes(binding),
                                             "RawKvStore resident byte count overflow");
                restore_bytes_total = checked_add(restore_bytes_total, binding.size,
                                                  "RawKvStore restore byte count overflow");
            }

            RawSnapshotTapeCapture capture(store->config(), local_bindings, binding_base);
            kvmem::SnapshotWriter writer([&](const void * data, std::size_t size) {
                capture.consume(data, size);
            });
            store->snapshot_write(writer);
            capture.finish(writer.bytes());

            StoreTape tape;
            tape.snapshot_bytes = writer.bytes();
            tape.ops = capture.take_ops();
            tapes.push_back(std::move(tape));
            if (local_bindings.size() > bindings.max_size() - bindings.size()) {
                throw std::length_error("too many RawKvStore allocation bindings");
            }
            bindings.insert(bindings.end(), local_bindings.begin(), local_bindings.end());
        }
        checkpoints.reserve(input_checkpoints.size());
        for (const auto& checkpoint : input_checkpoints) {
            if (!checkpoint) { throw std::invalid_argument("freeze_raw received an empty checkpoint"); }
            if (std::any_of(checkpoints.begin(), checkpoints.end(), [&](const auto& old) {
                    return checkpoint->shares_storage_with(*old.owner);
                })) { continue; }
            const auto first = bindings.size();
            checkpoint->append_snapshot_buffers(bindings);
            const auto count = bindings.size() - first;
            if (count < 1U || count > 2U ||
                bindings[first].size != checkpoint->host_layout().image_bytes ||
                (count == 2U && bindings[first + 1U].count != checkpoint->tail_mean_size()) ||
                (count == 1U && checkpoint->tail_mean_size() != 0)) {
                throw std::logic_error("recurrent checkpoint bindings disagree with their geometry");
            }
            checkpoints.push_back({checkpoint, first,
                count == 2U ? std::optional<std::size_t>(first + 1U) : std::nullopt});
            for (auto i = first; i < bindings.size(); ++i) {
                resident_bytes = checked_add(resident_bytes, checked_capacity_bytes(bindings[i]),
                                             "checkpoint resident byte count overflow");
                restore_bytes_total = checked_add(restore_bytes_total, bindings[i].size,
                                                  "checkpoint restore byte count overflow");
            }
        }
        (void) resident_bytes;
        (void) restore_bytes_total;

        validate_group_arithmetic(bindings, group_bytes);
        payload = std::make_unique<kvmem_session_payload>(id, generation, bindings, group_bytes);
        if (payload->chunks.size() > (std::numeric_limits<std::uint32_t>::max)()) {
            throw std::length_error("RawKvStore has too many native chunks");
        }

        chunk_ranges.reserve(payload->chunks.size());
        std::size_t next_buffer = 0;
        for (std::size_t i = 0; i < payload->chunks.size(); ++i) {
            const auto count = payload->chunks[i].buffers.size();
            if (count > bindings.size() - next_buffer) {
                throw std::logic_error("native payload changed the RawKvStore binding order");
            }
            chunk_ranges.push_back({next_buffer, count});
            next_buffer += count;
        }
        if (next_buffer != bindings.size()) {
            throw std::logic_error("native payload lost a RawKvStore binding");
        }
    }

    std::shared_ptr<KVMemParkedFileState> state;
    const int id;
    const std::uint64_t generation;
    std::vector<kvmem::RawKvStore *> owners;
    std::vector<StoreTape> tapes;
    std::vector<CheckpointBuffers> checkpoints;
    std::vector<ChunkRange> chunk_ranges;
    std::unique_ptr<kvmem_session_payload> payload;
};

KVMemFrozenRaw::KVMemFrozenRaw(
    std::shared_ptr<KVMemParkedFileState> state,
    std::span<kvmem::RawKvStore * const> stores,
    KVMemParkedFileState::PayloadIdentity identity,
    std::uint64_t group_bytes,
    std::span<const std::shared_ptr<const KVMemQueryBoundaryCheckpoint>> checkpoints)
    : impl_(std::make_unique<Impl>(std::move(state), stores, identity, group_bytes, checkpoints)) {}

KVMemFrozenRaw::~KVMemFrozenRaw() noexcept {
    (void) erase();
}

std::unique_ptr<KVMemFrozenRaw> KVMemParkedFileCache::freeze_raw(
    std::span<kvmem::RawKvStore * const> stores,
    std::uint64_t group_bytes,
    std::span<const std::shared_ptr<const KVMemQueryBoundaryCheckpoint>> checkpoints) {
    if (!state_) throw std::logic_error("cannot freeze Raw stores through a moved-from file cache");
    const auto identity = state_->allocate_payload_identity();
    return std::unique_ptr<KVMemFrozenRaw>(
        new KVMemFrozenRaw(state_, stores, identity, group_bytes, checkpoints));
}

std::uint32_t KVMemFrozenRaw::chunk_count() const {
    return static_cast<std::uint32_t>(impl_->payload->chunks.size());
}

KVMemFrozenRaw::Chunk KVMemFrozenRaw::chunk(std::uint32_t index) const {
    const auto & native_chunk = impl_->payload->chunks.at(index);
    const bool present = impl_->state->chunk_present(impl_->id, index);
    const bool ready = impl_->state->chunk_ready(impl_->id, index);
    if (native_chunk.in_ram && present && !ready) {
        throw std::runtime_error("unfinished native chunk is attached to resident Raw allocations");
    }
    if (!native_chunk.in_ram && !ready) {
        throw kvmem::SnapshotCorrupt("missing or unfinished native chunk for frozen Raw allocations");
    }
    const auto charged = impl_->state->chunk_bytes(impl_->id, index);
    const auto spill = native_chunk.in_ram && !ready
        ? native_chunk.disk_bytes() : 0;
    return {
        native_chunk.in_ram,
        native_chunk.ram_bytes(),
        charged,
        spill,
        native_chunk.in_ram ? 0 : native_chunk.restore_bytes(),
    };
}

bool KVMemFrozenRaw::complete() const {
    return impl_->payload->complete();
}

bool KVMemFrozenRaw::valid() const noexcept {
    return impl_ && !impl_->payload->invalid;
}

void KVMemFrozenRaw::invalidate() noexcept {
    if (impl_) { impl_->payload->invalid = true; }
}

std::uint64_t KVMemFrozenRaw::ram_bytes() const {
    return impl_->payload->ram_bytes();
}

std::uint64_t KVMemFrozenRaw::restore_bytes() const {
    return impl_->payload->restore_bytes();
}

std::uint64_t KVMemFrozenRaw::disk_bytes() const noexcept {
    return impl_ ? impl_->state->session_bytes(impl_->id) : 0;
}

std::uint64_t KVMemFrozenRaw::metadata_bytes() const {
    std::uint64_t total = checked_add(sizeof(Impl), impl_->payload->metadata_bytes(),
                                      "frozen Raw metadata size overflow");
    auto add_capacity = [&](std::size_t count, std::size_t element_size) {
        const auto bytes = checked_mul(count, element_size, "frozen Raw metadata size overflow");
        total = checked_add(total, bytes, "frozen Raw metadata size overflow");
    };
    add_capacity(impl_->owners.capacity(), sizeof(kvmem::RawKvStore *));
    add_capacity(impl_->tapes.capacity(), sizeof(Impl::StoreTape));
    add_capacity(impl_->checkpoints.capacity(), sizeof(Impl::CheckpointBuffers));
    add_capacity(impl_->chunk_ranges.capacity(), sizeof(Impl::ChunkRange));
    for (const auto & tape : impl_->tapes) {
        add_capacity(tape.ops.capacity(), sizeof(TapeOp));
        for (const auto & op : tape.ops) {
            add_capacity(op.literal.capacity(), sizeof(std::uint8_t));
        }
    }
    return total;
}

std::uint64_t KVMemFrozenRaw::store_snapshot_bytes(std::size_t store_index) const {
    return impl_->tapes.at(store_index).snapshot_bytes;
}

bool KVMemFrozenRaw::prepare_transfer() {
    if (!valid()) { throw kvmem::SnapshotCorrupt("invalid frozen Raw transfer source"); }
    bool changed = false;
    for (std::size_t i = 0; i < impl_->payload->chunks.size(); ++i) {
        const auto index = static_cast<std::uint32_t>(i);
        const auto & native_chunk = impl_->payload->chunks[i];
        if (native_chunk.in_ram && impl_->state->chunk_present(impl_->id, index) &&
            !impl_->state->chunk_ready(impl_->id, index)) {
            restore(index);
            changed = true;
        }
    }
    return changed;
}

void KVMemFrozenRaw::spill(std::uint32_t index) {
    (void) impl_->payload->chunks.at(index);
    impl_->state->spill(*impl_->payload, index);
}

void KVMemFrozenRaw::restore(std::uint32_t index) {
    (void) impl_->payload->chunks.at(index);
    impl_->state->restore(*impl_->payload, index);
}

void KVMemFrozenRaw::validate() const {
    if (!valid()) { throw kvmem::SnapshotCorrupt("invalid frozen Raw manifest"); }
    std::array<std::uint8_t, kDrainBytes> scratch{};
    for (std::size_t i = 0; i < impl_->payload->chunks.size(); ++i) {
        const auto index = static_cast<std::uint32_t>(i);
        const auto & native_chunk = impl_->payload->chunks[i];
        if (native_chunk.in_ram) continue;
        if (!impl_->state->chunk_ready(impl_->id, index)) {
            throw kvmem::SnapshotCorrupt("missing or unfinished frozen Raw chunk");
        }
        const auto expected = expected_chunk_payload(*impl_->payload, index);
        const auto charged = checked_add(expected, sizeof(std::uint64_t), "native chunk charge overflow");
        if (impl_->state->chunk_bytes(impl_->id, index) != charged) {
            throw kvmem::SnapshotCorrupt("frozen Raw chunk charge disagrees with its manifest");
        }
        impl_->state->load_chunk(impl_->id, index, [&](kvmem::SnapshotReader & reader) {
            read_and_check_chunk_prefix(*impl_->payload, index, reader);
            for (const auto & buffer : native_chunk.buffers) {
                const auto count = reader.scalar<std::uint64_t>();
                if (count != buffer.count) throw kvmem::SnapshotCorrupt("frozen Raw buffer count mismatch");
                drain_bytes(reader, buffer.size, scratch);
            }
        });
    }
}

bool KVMemFrozenRaw::erase() noexcept {
    return !impl_ || impl_->state->erase_session(impl_->id);
}

std::filesystem::path KVMemFrozenRaw::path(std::uint32_t index) const {
    (void) impl_->payload->chunks.at(index);
    return impl_->state->path(impl_->id, index);
}

void KVMemFrozenRaw::write_store(
    std::size_t store_index,
    kvmem::SnapshotWriter & out) const {
    if (!valid()) { throw kvmem::SnapshotCorrupt("invalid frozen Raw export"); }
    const auto & tape = impl_->tapes.at(store_index);
    std::size_t op_index = 0;
    std::array<std::uint8_t, kDrainBytes> scratch{};

    auto write_literals = [&]() {
        while (op_index < tape.ops.size() && tape.ops[op_index].kind == TapeOp::Kind::literal) {
            const auto & bytes = tape.ops[op_index].literal;
            out.write(bytes.data(), bytes.size());
            ++op_index;
        }
    };
    auto check_pending_buffer = [&](std::size_t current_buffer) {
        if (op_index < tape.ops.size() && tape.ops[op_index].kind == TapeOp::Kind::buffer &&
            tape.ops[op_index].buffer_index < current_buffer) {
            throw std::logic_error("frozen Raw metadata tape lost buffer ordering");
        }
    };

    for (std::size_t ci = 0; ci < impl_->payload->chunks.size(); ++ci) {
        const auto index = static_cast<std::uint32_t>(ci);
        const auto & native_chunk = impl_->payload->chunks[ci];
        const auto range = impl_->chunk_ranges[ci];

        write_literals();
        check_pending_buffer(range.first_buffer);
        const auto range_end = range.first_buffer + range.buffer_count;
        if (op_index == tape.ops.size() || tape.ops[op_index].buffer_index >= range_end) {
            continue;
        }
        if (native_chunk.in_ram) {
            for (std::size_t j = 0; j < range.buffer_count; ++j) {
                const auto global_index = range.first_buffer + j;
                write_literals();
                check_pending_buffer(global_index);
                if (op_index < tape.ops.size() && tape.ops[op_index].kind == TapeOp::Kind::buffer &&
                    tape.ops[op_index].buffer_index == global_index) {
                    const auto & op = tape.ops[op_index];
                    const auto & binding = native_chunk.buffers[j];
                    if (op.count != binding.count || op.bytes != binding.size) {
                        throw std::logic_error("frozen Raw metadata tape disagrees with its binding");
                    }
                    binding.write(binding.object, out);
                    ++op_index;
                }
            }
            write_literals();
            check_pending_buffer(range_end);
            continue;
        }

        if (!impl_->state->chunk_ready(impl_->id, index)) {
            throw kvmem::SnapshotCorrupt("missing or unfinished frozen Raw chunk");
        }
        const auto expected = expected_chunk_payload(*impl_->payload, index);
        const auto charged = checked_add(expected, sizeof(std::uint64_t), "native chunk charge overflow");
        if (impl_->state->chunk_bytes(impl_->id, index) != charged) {
            throw kvmem::SnapshotCorrupt("frozen Raw chunk charge disagrees with its manifest");
        }
        impl_->state->load_chunk(impl_->id, index, [&](kvmem::SnapshotReader & reader) {
            read_and_check_chunk_prefix(*impl_->payload, index, reader);
            for (std::size_t j = 0; j < range.buffer_count; ++j) {
                const auto global_index = range.first_buffer + j;
                const auto & binding = native_chunk.buffers[j];
                const auto count = reader.scalar<std::uint64_t>();
                if (count != binding.count) throw kvmem::SnapshotCorrupt("frozen Raw buffer count mismatch");

                write_literals();
                check_pending_buffer(global_index);
                if (op_index < tape.ops.size() && tape.ops[op_index].kind == TapeOp::Kind::buffer &&
                    tape.ops[op_index].buffer_index == global_index) {
                    const auto & op = tape.ops[op_index];
                    if (op.count != count || op.bytes != binding.size) {
                        throw kvmem::SnapshotCorrupt("frozen Raw tape disagrees with native buffer");
                    }
                    out.scalar(count);
                    auto remaining = binding.size;
                    while (remaining != 0) {
                        const auto part = static_cast<std::size_t>((std::min<std::uint64_t>)(remaining, scratch.size()));
                        reader.read(scratch.data(), part);
                        out.write(scratch.data(), part);
                        remaining -= part;
                    }
                    ++op_index;
                } else {
                    drain_bytes(reader, binding.size, scratch);
                }
            }
            write_literals();
            check_pending_buffer(range_end);
        });
    }

    write_literals();
    if (op_index != tape.ops.size()) {
        throw std::logic_error("frozen Raw metadata tape has unconsumed buffers");
    }
}

bool KVMemFrozenRaw::owns_checkpoint(
    const KVMemQueryBoundaryCheckpoint& checkpoint) const noexcept {
    return std::any_of(impl_->checkpoints.begin(), impl_->checkpoints.end(), [&](const auto& item) {
        return checkpoint.shares_storage_with(*item.owner);
    });
}

void KVMemFrozenRaw::write_checkpoint_image(
    const KVMemQueryBoundaryCheckpoint& checkpoint,
    const kvmem::SnapshotWriter::Sink& sink) const {
    write_checkpoint_part(checkpoint, false, sink);
}

void KVMemFrozenRaw::write_checkpoint_tail_mean(
    const KVMemQueryBoundaryCheckpoint& checkpoint,
    const kvmem::SnapshotWriter::Sink& sink) const {
    write_checkpoint_part(checkpoint, true, sink);
}

void KVMemFrozenRaw::write_checkpoint_part(
    const KVMemQueryBoundaryCheckpoint& checkpoint, bool tail_mean,
    const kvmem::SnapshotWriter::Sink& sink) const {
    if (!valid()) { throw kvmem::SnapshotCorrupt("invalid frozen recurrent export"); }
    if (!sink) { throw std::invalid_argument("recurrent export requires a payload sink"); }
    const auto entry = std::find_if(impl_->checkpoints.begin(), impl_->checkpoints.end(),
        [&](const auto& item) { return checkpoint.shares_storage_with(*item.owner); });
    if (entry == impl_->checkpoints.end()) {
        throw std::logic_error("recurrent checkpoint has no frozen binding");
    }
    if (tail_mean && !entry->tail_mean) {
        if (checkpoint.tail_mean_size() != 0) {
            throw std::logic_error("frozen recurrent checkpoint lost its tail mean");
        }
        return;
    }
    const auto wanted = tail_mean ? *entry->tail_mean : entry->image;
    const auto expected_count = tail_mean ? checkpoint.tail_mean_size()
                                          : checkpoint.host_layout().image_bytes;
    const auto expected_bytes = checked_mul(expected_count, tail_mean ? sizeof(float) : 1U,
                                             "recurrent export byte count overflow");
    for (std::size_t ci = 0; ci < impl_->chunk_ranges.size(); ++ci) {
        const auto range = impl_->chunk_ranges[ci];
        if (wanted < range.first_buffer || wanted - range.first_buffer >= range.buffer_count) {
            continue;
        }
        const auto index = static_cast<std::uint32_t>(ci);
        const auto& native_chunk = impl_->payload->chunks[ci];
        const auto& binding = native_chunk.buffers[wanted - range.first_buffer];
        if (binding.count != expected_count || binding.size != expected_bytes) {
            throw std::logic_error("frozen recurrent buffer disagrees with its retained geometry");
        }
        if (native_chunk.in_ram) {
            const auto* bytes = tail_mean
                ? reinterpret_cast<const std::uint8_t*>(checkpoint.tail_mean().data())
                : reinterpret_cast<const std::uint8_t*>(checkpoint.host_view().data);
            for (std::uint64_t offset = 0; offset < expected_bytes;) {
                const auto count = static_cast<std::size_t>((std::min<std::uint64_t>)(
                    expected_bytes - offset, kDrainBytes));
                sink(bytes + static_cast<std::size_t>(offset), count);
                offset += count;
            }
            return;
        }
        if (!impl_->state->chunk_ready(impl_->id, index)) {
            throw kvmem::SnapshotCorrupt("missing or unfinished recurrent chunk");
        }
        const auto charged = checked_add(expected_chunk_payload(*impl_->payload, index),
                                           sizeof(std::uint64_t), "native chunk charge overflow");
        if (impl_->state->chunk_bytes(impl_->id, index) != charged) {
            throw kvmem::SnapshotCorrupt("recurrent chunk charge disagrees with its manifest");
        }
        std::array<std::uint8_t, kDrainBytes> scratch{};
        impl_->state->load_chunk(impl_->id, index, [&](kvmem::SnapshotReader& reader) {
            read_and_check_chunk_prefix(*impl_->payload, index, reader);
            for (std::size_t bi = 0; bi < range.buffer_count; ++bi) {
                const auto& current = native_chunk.buffers[bi];
                if (reader.scalar<std::uint64_t>() != current.count) {
                    throw kvmem::SnapshotCorrupt("recurrent chunk buffer count mismatch");
                }
                if (range.first_buffer + bi != wanted) {
                    drain_bytes(reader, current.size, scratch);
                    continue;
                }
                for (auto remaining = current.size; remaining != 0;) {
                    const auto count = static_cast<std::size_t>((std::min<std::uint64_t>)(
                        remaining, scratch.size()));
                    reader.read(scratch.data(), count);
                    sink(scratch.data(), count);
                    remaining -= count;
                }
            }
        });
        return;
    }
    throw std::logic_error("recurrent checkpoint binding lost its native chunk");
}

} // namespace ninfer::models::qwen3_5::detail
