// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#include "models/qwen3_5/program/storage/kvmem_follower_prefill_pressure.h"

#include "models/qwen3_5/program/storage/kv_store.h"
#include "models/qwen3_5/program/storage/kvmem_follower_page_backend.h"
#include "models/qwen3_5/program/storage/kvmem_follower_retained_pages.h"

#include <kvmem/kvmem_store.hpp>
#include <kvmem/raw_kv_store.hpp>

#include <cstdint>
#include <limits>
#include <stdexcept>
#include <vector>

namespace ninfer::models::qwen3_5::detail {
namespace {

constexpr std::uint32_t kPageTokens  = KVMemFollowerExecutionMap::kPageTokens;
constexpr std::uint32_t kBlockTokens = KVMemFollowerExecutionMap::kBlockTokens;

} // namespace

void preserve_kvmem_prefill_follower(
    const kvmem::KvMemStore& store,
    std::span<const KVMemFollowerExecutionRecord> execution,
    KVAddressSpaceStore& addresses, KVAddressSpaceHandle address,
    KVMemFollowerPageBackend& follower_backend, kvmem::RawKvStore& follower_raw,
    std::span<const std::uint32_t> outgoing_ids,
    std::uint32_t committed_original_frontier,
    std::uint32_t committed_execution_frontier,
    KVMemFollowerRetainedPages& retained) {
    const kvmem::RawKvStoreConfig& raw_config = follower_raw.config();
    if (store.config().block_tokens != kBlockTokens ||
        (execution.empty() && committed_execution_frontier != 0) ||
        raw_config.block_tokens != kBlockTokens || raw_config.n_layer != 1 ||
        raw_config.k_gpu_row_bytes != follower_backend.key_gpu_row_bytes() ||
        raw_config.v_gpu_row_bytes != follower_backend.value_gpu_row_bytes() ||
        !addresses.valid(address) || !addresses.active(address) ||
        addresses.committed_frontier(address) != committed_execution_frontier) {
        throw std::logic_error("native follower has invalid pressure geometry or address frontier");
    }

    // A first whole-batch pressure plan can select only incoming rows. Its
    // old follower is then a real zero-frontier writer, not a missing history
    // map. The frontier, resident-coverage and outgoing checks below still
    // reject any empty map that would lose committed rows.
    const std::size_t block_count = store.block_count();
    std::vector<std::uint8_t> covered(block_count, 0);
    std::uint64_t expected_execution = 0;
    for (std::size_t index = 0; index < execution.size(); ++index) {
        const KVMemFollowerExecutionRecord& location = execution[index];
        if (location.native_block_id >= block_count ||
            location.execution_begin != expected_execution ||
            location.original_position > committed_original_frontier ||
            location.committed_rows == 0 || location.committed_rows > kBlockTokens ||
            location.committed_rows > committed_original_frontier - location.original_position ||
            location.execution_begin % kBlockTokens != 0) {
            throw std::logic_error("native follower source map has a gap or future rows");
        }
        const auto& block = store.blocks()[location.native_block_id];
        if (block.block_id != location.native_block_id || block.gpu_slot < 0 ||
            block.orig_pos_start != location.original_position ||
            block.orig_pos_start > std::numeric_limits<std::uint32_t>::max() - block.n_tokens ||
            block.n_tokens < location.committed_rows || block.n_tokens > kBlockTokens ||
            covered[location.native_block_id]) {
            throw std::logic_error("native follower source map disagrees with target residency");
        }

        if (location.committed_rows == kBlockTokens) {
            if (block.n_tokens != kBlockTokens) {
                throw std::logic_error("native follower full source row count is not a full target block");
            }
        } else if (index + 1U != execution.size() ||
                   location.committed_rows != block.n_tokens ||
                   block.orig_pos_end() != committed_original_frontier ||
                   static_cast<std::size_t>(location.native_block_id) + 1U != block_count ||
                   !block.in_working_set) {
            throw std::logic_error("native follower partial tail is not the selected final target block");
        }

        covered[location.native_block_id] = 1;
        expected_execution += location.committed_rows;
        if (expected_execution > committed_execution_frontier) {
            throw std::logic_error("native follower source map exceeds its committed frontier");
        }
    }
    if (expected_execution != committed_execution_frontier) {
        throw std::logic_error("native follower source map misses committed rows");
    }
    for (const auto& block : store.blocks()) {
        if (block.gpu_slot >= 0 && block.orig_pos_start < committed_original_frontier &&
            block.orig_pos_end() <= committed_original_frontier && !covered[block.block_id]) {
            throw std::logic_error("native follower source map misses a resident target block");
        }
    }

    const std::vector<KVMemFollowerResolvedBlock> resolved =
        KVMemFollowerExecutionMap::resolve(execution, addresses, address);
    std::vector<std::uint8_t> outgoing(block_count, 0);
    for (const std::uint32_t id : outgoing_ids) {
        if (id >= outgoing.size() || !covered[id] || outgoing[id]) {
            throw std::logic_error("native pressure outgoing follower block is not resident");
        }
        outgoing[id] = 1;
    }

    // Validate the whole transfer/retention set before the first Raw write.
    for (const KVMemFollowerResolvedBlock& block : resolved) {
        const std::uint32_t id = block.record.native_block_id;
        if (outgoing[id]) {
            if (block.record.committed_rows != kBlockTokens ||
                block.record.execution_begin % kBlockTokens != 0) {
                throw std::logic_error("native pressure can spill only complete follower blocks");
            }
        } else {
            if (!store.blocks()[id].in_working_set) {
                throw std::logic_error("native pressure omitted an unselected follower spill");
            }
            if (retained.has(id)) {
                throw std::logic_error("native pressure already retains a selected follower block");
            }
        }
    }

    for (const KVMemFollowerResolvedBlock& block : resolved) {
        if (!outgoing[block.record.native_block_id]) { continue; }
        follower_backend.stage_out(block.record.original_position, block.mtp_pages,
                                   block.record.committed_rows, follower_raw);
        if (!follower_raw.has_k_gpu(block.record.native_block_id, 0,
                                    block.record.committed_rows) ||
            !follower_raw.has_v_gpu(block.record.native_block_id, 0,
                                    block.record.committed_rows)) {
            throw std::logic_error("native pressure did not preserve packed follower K/V");
        }
    }

    // Spills finish before deactivation; detached pages then become read-only
    // references carrying the exact committed prefix, including a short tail.
    addresses.deactivate(address);
    for (const KVMemFollowerResolvedBlock& block : resolved) {
        if (outgoing[block.record.native_block_id]) { continue; }
        const std::uint32_t first = block.record.execution_begin / kPageTokens;
        KVMemFollowerRetainedPages::PagePair pair{};
        pair[0] = addresses.logical_page(address, first);
        if (block.record.committed_rows > kPageTokens) {
            pair[1] = addresses.logical_page(address, first + 1U);
        }
        retained.retain_existing(block.record.native_block_id, pair,
                                 block.record.committed_rows);
    }
}

} // namespace ninfer::models::qwen3_5::detail
