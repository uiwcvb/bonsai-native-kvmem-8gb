// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#pragma once

#include "models/qwen3_5/program/round_buffers.h"
#include "models/qwen3_5/state/state_image.h"

#include <cuda_runtime_api.h>
#include <kvmem/raw_kv_store.hpp>
#include <kvmem/snapshot_buffer.hpp>

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <vector>

namespace ninfer::models::qwen3_5::detail {

struct KVMemQueryBoundaryState {
    std::uint32_t logical_frontier = 0;
    std::array<TokenId, kMtpDecodeMaximumDrafts> mtp_draft_tokens{};
    std::uint32_t mtp_draft_count = 0;
    bool tail_hidden_valid = false;
    bool follower_lags_one = false;
};

/**
 * A single query-boundary checkpoint for NInfer recurrent StateImage plus KVMem tail-mean
 * metadata. The copied layout and logical metadata are immutable and shared-owned; draft-carry
 * descriptors can differ without copying an unchanged StateImage or tail mean. Native snapshot
 * bindings may independently reclaim and restore the two owned payload vectors while leaving that
 * metadata and their expected sizes unchanged.
 *
 * Capture requires the caller to quiesce StateImage writers and flush any KVMem-side staged mean
 * work. `stream` must be the stream containing, or ordered after, all writes to the source slot.
 * The helper waits for RawKvStore writes and synchronizes that stream around the device/host
 * transfer. The captured RawKvStore may be destroyed after capture.
 *
 * Neither restore path removes attention KV rows, edits NInfer logical KV, changes page-table
 * views, nor rolls back KvMemRuntime. The caller owns those operations.
 *
 * A caller binding payloads to Native must quiesce readers and writers of the bound vectors, keep
 * the shared storage pinned and all surviving descriptors frozen for inference until all Native
 * chunks are restored. Metadata-only matching remains legal while cold; attachment waits for the
 * complete Native manifest.
 */
class KVMemQueryBoundaryCheckpoint final {
public:
    [[nodiscard]] static KVMemQueryBoundaryCheckpoint capture(
        StateImageDevicePool& device_images, std::int32_t active_device_slot,
        kvmem::RawKvStore& raw_store, KVMemQueryBoundaryState state,
        cudaStream_t stream = nullptr);
    static void validate_host_image(HostStateImageConstView source,
                                    const kvmem::RawKvStoreConfig& raw_config,
                                    KVMemQueryBoundaryState state,
                                    std::size_t tail_mean_count);
    [[nodiscard]] static KVMemQueryBoundaryCheckpoint from_host_image(
        HostStateImageConstView source, const kvmem::RawKvStoreConfig& raw_config,
        KVMemQueryBoundaryState state, std::vector<float> tail_mean);

    KVMemQueryBoundaryCheckpoint(const KVMemQueryBoundaryCheckpoint&) = delete;
    KVMemQueryBoundaryCheckpoint& operator=(const KVMemQueryBoundaryCheckpoint&) = delete;
    KVMemQueryBoundaryCheckpoint(KVMemQueryBoundaryCheckpoint&& other) noexcept;
    KVMemQueryBoundaryCheckpoint& operator=(KVMemQueryBoundaryCheckpoint&& other) noexcept;
    ~KVMemQueryBoundaryCheckpoint();

    [[nodiscard]] const KVMemQueryBoundaryState& state() const;
    // Metadata-only: remains available while the StateImage payload is cold.
    [[nodiscard]] const StateImageHostLayout& host_layout() const;
    // Physical residency only; independent from Native residency of the tail-mean vector.
    [[nodiscard]] bool image_resident() const noexcept;
    // Immutable expected element count from the logical frontier and captured Raw geometry.
    [[nodiscard]] std::size_t tail_mean_size() const;
    [[nodiscard]] HostStateImageConstView host_view() const;
    [[nodiscard]] std::size_t allocated_bytes() const noexcept;
    // Requires a resident tail-mean vector of tail_mean_size(); StateImage residency is independent.
    [[nodiscard]] const std::vector<float>& tail_mean() const;
    // Appends the image binding first, then a tail-mean binding when it has capacity. The caller
    // must satisfy the class-level Native freeze, pinning, quiescence, and full-restore contract.
    // Both payload lengths are checked before any binding is appended.
    void append_snapshot_buffers(std::vector<kvmem::SnapshotBuffer>& buffers) const;
    [[nodiscard]] bool shares_storage_with(const KVMemQueryBoundaryCheckpoint& other) const noexcept;

    // Only Host draft metadata changes. The caller must prove that no StateImage
    // or Raw mean writer has run since capture; the logical frontier/flags stay fixed.
    [[nodiscard]] KVMemQueryBoundaryCheckpoint with_draft_carry(
        std::array<TokenId, kMtpDecodeMaximumDrafts> tokens, std::uint32_t count) const;

    // Query replay restores recurrent state only (upstream truncate=false).
    // First-pass mean-K remains the retrieval statistic; replay must suppress
    // K/Q capture and invalidate packed query-suffix bytes separately.
    // The caller rebuilds writable attention pages for that suffix.
    void restore_for_query_replay(StateImageDevicePool& device_images,
                                  std::int32_t destination_device_slot,
                                  cudaStream_t stream = nullptr) const;

    // Failure rollback path: corresponds to `truncate=true` for this helper's state. The caller
    // must first truncate attention storage (including RawKvStore as applicable) and roll back
    // logical KV, page-table views, and KvMemRuntime. This then restores StateImage and the saved
    // RawKvStore tail mean; it never truncates attention KV itself.
    void restore_for_failure_rollback(StateImageDevicePool& device_images,
                                      std::int32_t destination_device_slot,
                                      kvmem::RawKvStore& raw_store,
                                      cudaStream_t stream = nullptr) const;

private:
    struct RawMeanGeometry {
        std::uint32_t n_layer = 0;
        std::uint32_t n_embd_k = 0;
        std::uint32_t block_tokens = 0;
    };

    struct Storage {
        StateImageHostLayout state_image_layout;
        mutable std::vector<std::uint8_t> state_image;
        RawMeanGeometry raw_mean_geometry;
        mutable std::vector<float> tail_mean;
    };

    KVMemQueryBoundaryCheckpoint(std::shared_ptr<const Storage> storage,
                                 KVMemQueryBoundaryState state) noexcept;

    void require_metadata_valid() const;
    void require_valid() const;
    void restore_state_image(StateImageDevicePool& device_images,
                             std::int32_t destination_device_slot,
                             cudaStream_t stream) const;

    std::shared_ptr<const Storage> storage_;
    KVMemQueryBoundaryState state_{};
};

} // namespace ninfer::models::qwen3_5::detail
