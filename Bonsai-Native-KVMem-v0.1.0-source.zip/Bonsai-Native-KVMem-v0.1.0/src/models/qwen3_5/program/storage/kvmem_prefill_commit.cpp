// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#include "models/qwen3_5/program/storage/kvmem_prefill_commit.h"

#include "models/qwen3_5/program/storage/kvmem_page_backend.h"

#include <kvmem/kvmem_store.hpp>

#include <algorithm>
#include <limits>
#include <optional>
#include <span>
#include <stdexcept>

namespace ninfer::models::qwen3_5::detail {
namespace {

constexpr std::uint32_t kNativeBlockTokens =
    2U * static_cast<std::uint32_t>(kPagedKVPageSize);

struct PublishableBlock {
    std::uint32_t id = 0;
    const kvmem::KvMemBlock* block = nullptr;
    std::uint32_t execution_begin = 0;
    bool partial_tail = false;
    bool replace_materialized_tail = false;
};

template <class Visitor>
void visit_publishable_blocks(const kvmem::KvMemStore& store,
                              KVMemPrefillCommitSpan span, Visitor&& visitor) {
    std::uint32_t covered = span.logical_begin;
    const auto& blocks = store.blocks();
    const std::int32_t first_block_id =
        store.block_id_containing(span.logical_begin);
    if (first_block_id < 0 ||
        static_cast<std::size_t>(first_block_id) >= blocks.size()) {
        throw std::logic_error("KVMem prefill store does not cover the accepted interval");
    }
    const std::size_t first_block_index = static_cast<std::size_t>(first_block_id);

    for (std::size_t index = first_block_index; index < blocks.size(); ++index) {
        const kvmem::KvMemBlock& block = blocks[index];
        if (block.orig_pos_start >= span.logical_end) { break; }
        if (block.n_tokens == 0 ||
            block.n_tokens > kNativeBlockTokens ||
            block.orig_pos_start > std::numeric_limits<std::uint32_t>::max() - block.n_tokens) {
            throw std::logic_error("KVMem prefill store has invalid block geometry");
        }
        const std::uint32_t block_end = block.orig_pos_end();
        if (block.block_id != index || block.orig_pos_start % kNativeBlockTokens != 0 ||
            block_end > store.total_tokens() || block_end <= span.logical_begin ||
            (index == first_block_index
                 ? block.orig_pos_start > span.logical_begin
                 : block.orig_pos_start != covered)) {
            throw std::logic_error("KVMem prefill store does not cover the accepted interval");
        }
        if (block.gpu_slot < 0 || block.tier != kvmem::KvTier::GPU || block.in_flight) {
            throw std::logic_error("KVMem accepted block has no settled GPU slot");
        }

        const std::uint32_t covered_end = std::min(block_end, span.logical_end);
        if (block_end <= span.logical_end && block.n_tokens == kNativeBlockTokens) {
            const std::uint32_t logical_delta = span.logical_end - block.orig_pos_start;
            if (logical_delta > span.execution_end) {
                throw std::logic_error("KVMem prefill execution start underflows");
            }
            const std::uint32_t execution_begin = span.execution_end - logical_delta;
            if (execution_begin % kNativeBlockTokens != 0 ||
                static_cast<std::uint64_t>(execution_begin) + block.n_tokens >
                    span.execution_end) {
                throw std::logic_error("KVMem complete block has invalid execution geometry");
            }
            visitor(PublishableBlock{
                .id = block.block_id,
                .block = &block,
                .execution_begin = execution_begin,
                .partial_tail = false,
                .replace_materialized_tail =
                    !span.replay && span.materialized_tail_tokens != 0 &&
                    block.block_id == static_cast<std::uint32_t>(first_block_id),
            });
        } else if (block_end == span.logical_end && block.n_tokens < kNativeBlockTokens &&
                   span.publish_partial_tail) {
            const std::uint32_t logical_delta = span.logical_end - block.orig_pos_start;
            if (logical_delta > span.execution_end) {
                throw std::logic_error("KVMem partial execution start underflows");
            }
            const std::uint32_t execution_begin = span.execution_end - logical_delta;
            if (execution_begin % kNativeBlockTokens != 0 ||
                static_cast<std::uint64_t>(execution_begin) + block.n_tokens !=
                    span.execution_end) {
                throw std::logic_error("KVMem partial block has invalid execution geometry");
            }
            visitor(PublishableBlock{
                .id = block.block_id,
                .block = &block,
                .execution_begin = execution_begin,
                .partial_tail = true,
                .replace_materialized_tail =
                    !span.replay && span.materialized_tail_tokens != 0 &&
                    block.block_id == static_cast<std::uint32_t>(first_block_id),
            });
        }
        covered = covered_end;
        if (covered == span.logical_end) { break; }
    }

    if (covered != span.logical_end) {
        throw std::logic_error("KVMem prefill store does not cover the accepted interval");
    }
}

KVMemFollowerExecutionRecord follower_record(
    const PublishableBlock& publish, KVMemPrefillCommitSpan span) {
    const std::uint32_t rows = publish.block->n_tokens -
        ((span.deferred_follower_last_row &&
          publish.block->orig_pos_end() == span.logical_end)
             ? 1U
             : 0U);
    return KVMemFollowerExecutionRecord{
        .native_block_id = publish.id,
        .original_position = publish.block->orig_pos_start,
        .execution_begin = publish.execution_begin,
        .committed_rows = rows,
    };
}

void validate_follower_record_order(
    const KVMemFollowerExecutionRecord& prior,
    const KVMemFollowerExecutionRecord& current) {
    const std::uint64_t prior_execution_end =
        static_cast<std::uint64_t>(prior.execution_begin) + prior.committed_rows;
    const std::uint64_t prior_logical_end =
        static_cast<std::uint64_t>(prior.original_position) + prior.committed_rows;
    if (prior.native_block_id >= current.native_block_id ||
        prior.original_position >= current.original_position ||
        prior_logical_end > current.original_position ||
        prior_execution_end > current.execution_begin) {
        throw std::logic_error("native MTP committed blocks are not logically ordered");
    }
}

} // namespace

std::uint32_t commit_kvmem_prefill_blocks(
    const kvmem::KvMemStore& store, KVMemPageBackend& backend,
    KVAddressSpaceStore& addresses, KVAddressSpaceHandle address,
    KVMemPrefillCommitSpan span, const KVMemPrefillFollowerCommit* follower) {
    if (store.config().block_tokens != kNativeBlockTokens ||
        span.logical_begin >= span.logical_end ||
        span.logical_end > store.total_tokens() ||
        span.execution_end < span.logical_end - span.logical_begin ||
        (!span.replay &&
         (span.materialized_tail_tokens >= kNativeBlockTokens ||
          span.materialized_tail_tokens > span.logical_begin % kNativeBlockTokens)) ||
        !addresses.valid(address) || addresses.active(address) ||
        addresses.committed_frontier(address) < span.execution_end) {
        throw std::invalid_argument("KVMem prefill commit span or inactive writer is invalid");
    }

    if (follower != nullptr) {
        if (follower->addresses == nullptr || follower->records == nullptr ||
            !follower->addresses->valid(follower->address)) {
            throw std::invalid_argument("native MTP commit requires a valid follower address");
        }
        if (follower->committed_frontier >
            follower->addresses->committed_frontier(follower->address)) {
            throw std::invalid_argument(
                "native MTP commit frontier exceeds its actual follower address");
        }
    }

    std::optional<KVMemFollowerExecutionRecord> prior_follower;
    bool may_update_follower_tail = false;
    if (follower != nullptr && !follower->records->empty()) {
        prior_follower = follower->records->back();
        may_update_follower_tail = true;
    }

    visit_publishable_blocks(store, span, [&](const PublishableBlock& publish) {
        const std::uint64_t block_execution_end =
            static_cast<std::uint64_t>(publish.execution_begin) + publish.block->n_tokens;
        const std::uint64_t required_pages =
            (block_execution_end + static_cast<std::uint32_t>(kPagedKVPageSize) - 1U) /
            static_cast<std::uint32_t>(kPagedKVPageSize);
        if (block_execution_end > addresses.committed_frontier(address) ||
            required_pages > addresses.mapped_pages(address)) {
            throw std::logic_error("KVMem target writer does not cover a completed block");
        }
        if (publish.replace_materialized_tail &&
            publish.block->n_tokens <= span.materialized_tail_tokens) {
            throw std::logic_error("KVMem materialized tail did not grow before publication");
        }

        if (follower == nullptr) { return; }
        const KVMemFollowerExecutionRecord location = follower_record(publish, span);
        if (location.committed_rows == 0) { return; }
        const std::uint64_t follower_end =
            static_cast<std::uint64_t>(location.execution_begin) + location.committed_rows;
        if (follower_end > follower->committed_frontier) {
            throw std::logic_error("native MTP block exceeds the committed follower frontier");
        }
        (void)KVMemFollowerExecutionMap::resolve(
            std::span<const KVMemFollowerExecutionRecord>{&location, 1U},
            *follower->addresses, follower->address);

        if (may_update_follower_tail && prior_follower &&
            prior_follower->native_block_id == location.native_block_id) {
            if (prior_follower->original_position != location.original_position ||
                prior_follower->execution_begin != location.execution_begin ||
                prior_follower->committed_rows > location.committed_rows) {
                throw std::logic_error("native MTP tail moved within its active writer");
            }
            may_update_follower_tail = false;
        } else if (prior_follower) {
            validate_follower_record_order(*prior_follower, location);
            may_update_follower_tail = false;
        }
        prior_follower = location;
    });

    std::uint32_t materialized_tail_tokens = span.materialized_tail_tokens;
    visit_publishable_blocks(store, span, [&](const PublishableBlock& publish) {
        if (span.replay) {
            backend.replace_replayed_block(publish.id, publish.block->gpu_slot,
                                           addresses, address,
                                           publish.execution_begin,
                                           publish.block->n_tokens);
        } else if (publish.replace_materialized_tail) {
            backend.replace_inactive_tail_address(
                publish.id, publish.block->gpu_slot, addresses, address,
                publish.execution_begin, span.materialized_tail_tokens,
                publish.block->n_tokens);
        } else {
            backend.adopt_inactive_prefill_address(
                publish.id, publish.block->gpu_slot, addresses, address,
                publish.execution_begin, publish.block->n_tokens);
        }

        if (!span.replay) {
            materialized_tail_tokens = publish.partial_tail ? publish.block->n_tokens : 0U;
        }

        if (follower == nullptr) { return; }
        const KVMemFollowerExecutionRecord location = follower_record(publish, span);
        if (location.committed_rows == 0) { return; }
        auto& records = *follower->records;
        if (!records.empty() && records.back().native_block_id == location.native_block_id) {
            records.back().committed_rows = location.committed_rows;
        } else {
            records.push_back(location);
        }
    });

    return materialized_tail_tokens;
}

} // namespace ninfer::models::qwen3_5::detail
