// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include "core/paged_kv_cache.h"

#include <array>
#include <cstdint>
#include <span>
#include <vector>

namespace kvmem {
class KvMemStore;
}

namespace ninfer::models::qwen3_5::detail {

class KVAddressSpaceHandle;
class KVAddressSpaceStore;

// Caller-supplied mapping from one native block to its exact MTP execution range.
// execution_begin belongs to the MTP address and is never inferred from either
// native_block_id or original_position.
struct KVMemFollowerExecutionRecord {
    std::uint32_t native_block_id = 0;
    std::uint32_t original_position = 0;
    std::uint32_t execution_begin = 0;
    std::uint32_t committed_rows = 0;
};

// The physical pages resolved from the supplied MTP address. The second handle
// remains invalid when committed_rows is at most one 64-token page.
struct KVMemFollowerResolvedBlock {
    KVMemFollowerExecutionRecord record;
    std::array<DeviceKVPageHandle, 2> mtp_pages{};
};

// Stateless construction, validation and page resolution. This does not enable MTP and
// does not equate MTP execution positions with target-side selected offsets.
class KVMemFollowerExecutionMap final {
public:
    static constexpr std::uint32_t kPageTokens = 64;
    static constexpr std::uint32_t kBlockTokens = 128;

    // Reconstruct compact execution order from the native resident blocks.
    // The follower may defer exactly the final logical row for its bridge;
    // a one-row native tail then has no follower record or physical page.
    [[nodiscard]] static std::vector<KVMemFollowerExecutionRecord> from_native_resident(
        const kvmem::KvMemStore& store, std::uint32_t target_frontier,
        std::uint32_t follower_frontier);

    // Records must be sorted by execution_begin and their execution ranges must
    // not overlap. Each native block id and original block start must be unique.
    [[nodiscard]] static std::vector<KVMemFollowerResolvedBlock> resolve(
        std::span<const KVMemFollowerExecutionRecord> records,
        const KVAddressSpaceStore& addresses, KVAddressSpaceHandle mtp_address);
};

} // namespace ninfer::models::qwen3_5::detail
