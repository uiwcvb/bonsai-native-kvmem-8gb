// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#include "models/qwen3_5/program/program_impl.h"
#include "models/qwen3_5/program/context_work.h"
#include "models/qwen3_5/program/context.h"
#include "models/qwen3_5/program/graph_execution.h"
#include "models/qwen3_5/program/speculative/ngram_policy.h"
#if defined(NINFER_WITH_KVMEM)
#include "models/qwen3_5/program/storage/kvmem_page_backend.h"
#endif
#include "core/nvtx.h"
#include "core/device.h"
#include "ninfer/ops/prepare_ragged_prefix.h"
#include "ninfer/ops/sampling.h"
#include "ninfer/ops/scatter.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

namespace ninfer::models::qwen3_5::execution {
namespace {

auto ordinary_batch_body(OrdinaryBatchContext& state, std::int32_t batch_size,
                         ops::CausalAttentionExecutionEnvelope envelope) {
    return [&state, batch_size, envelope] {
        if (batch_size <= 0 || batch_size > static_cast<std::int32_t>(kMaximumConcurrency)) {
            throw std::logic_error("ordinary decode batch state is incomplete");
        }

        qwen3_5::OrdinaryDecodeState& ordinary = state.frame;
        CUDA_CHECK(cudaMemcpyAsync(ordinary.ingress.data, &state.host_ingress,
                                   sizeof(qwen3_5::OrdinaryDecodeIngress), cudaMemcpyHostToDevice,
                                   state.execution.device.stream));

        TextContext card(state.execution.device, state.execution.parameters, state.execution.work,
                         {}, state.execution.linear_attention, state.execution.io,
                         state.execution.prefill_hidden, state.execution.prefill_chunk, 0, {},
                         &state.text_cache);
        card.set_attention_feature_capture(state.execution.attention_features);

        Tensor tokens             = ordinary.tokens.slice(0, 0, batch_size);
        Tensor cache_positions    = ordinary.cache_positions.slice(0, 0, batch_size);
        Tensor logical_positions  = ordinary.logical_positions.slice(0, 0, batch_size);
        Tensor rope_positions     = ordinary.rope_positions.slice(0, 0, batch_size);
        Tensor kv_rows            = ordinary.text_kv_table_rows.slice(0, 0, batch_size);
        Tensor state_sources      = ordinary.state_source_slots.slice(0, 0, batch_size);
        Tensor state_destinations = ordinary.state_destination_slots.slice(0, 0, batch_size);
        Tensor hidden             = ordinary.hidden.slice(1, 0, batch_size);
        Tensor logits             = ordinary.logits.slice(1, 0, batch_size);
        Tensor sampled            = ordinary.sampled_tokens.slice(0, 0, batch_size);

        card.ordinary_decode_batch(tokens, cache_positions, rope_positions, kv_rows, state_sources,
                                   state_destinations, envelope, hidden, logits);
        ops::scatter(hidden, state_destinations, state.continuation_hidden_store,
                     state.execution.device.stream);
        ops::sample(logits, sampled,
                    dimension(state.execution.parameters.model.resources().public_token_count),
                    ordinary.sampling, logical_positions, ops::kSamplePurposeDecode,
                    state.execution.work, state.execution.device.stream);
        CUDA_CHECK(cudaMemcpyAsync(&state.host_egress, ordinary.egress.data,
                                   sizeof(qwen3_5::OrdinaryDecodeEgress), cudaMemcpyDeviceToHost,
                                   state.execution.device.stream));
    };
}

} // namespace

void capture_ordinary_decode_batch(OrdinaryBatchContext& state, std::int32_t batch_size,
                                   ops::CausalAttentionExecutionEnvelope envelope,
                                   DecodeGraphDefinition& definition) {
    auto body = ordinary_batch_body(state, batch_size, envelope);
    capture_graph(state, definition, body);
}

void ordinary_decode_batch(OrdinaryBatchContext& state, std::int32_t batch_size,
                           ops::CausalAttentionExecutionEnvelope envelope,
                           DecodeGraphExecutable* executable) {
    auto body = ordinary_batch_body(state, batch_size, envelope);
    run_prepared(state, executable, body);
}

} // namespace ninfer::models::qwen3_5::execution

namespace ninfer::models::qwen3_5::detail {

namespace {

DecodeGraphProfile& select_graph_profile(DecodeGraphFamily& family, std::uint32_t batch_size,
                                         std::uint32_t frontier, const char* label);

DecodeGraphTopology& select_graph_topology(DecodeGraphFamily& family, std::uint32_t topology_class,
                                           const char* label);

DecodeGraphExecutable& install_graph_profile(DecodeGraphFamily& family, DecodeGraphProfile& profile,
                                             const char* label);

DecodeGraphProfile& select_graph_profile(DecodeGraphFamily& family, std::uint32_t batch_size,
                                         std::uint32_t frontier, const char* label) {
    const auto it = std::find_if(
        family.profiles.begin(), family.profiles.end(), [&](const DecodeGraphProfile& profile) {
            return profile.batch_size == batch_size && profile.min_execution_frontier <= frontier &&
                   frontier <= profile.max_execution_frontier;
        });
    if (it == family.profiles.end()) {
        throw std::logic_error(std::string(label) + " CUDA Graph coverage is incomplete");
    }
    return *it;
}

DecodeGraphTopology& select_graph_topology(DecodeGraphFamily& family, std::uint32_t topology_class,
                                           const char* label) {
    const auto it = std::find_if(family.topologies.begin(), family.topologies.end(),
                                 [topology_class](const DecodeGraphTopology& topology) {
                                     return topology.topology_class == topology_class;
                                 });
    if (it == family.topologies.end()) {
        throw std::logic_error(std::string(label) + " CUDA Graph topology is unavailable");
    }
    return *it;
}

DecodeGraphExecutable& install_graph_profile(DecodeGraphFamily& family, DecodeGraphProfile& profile,
                                             const char* label) {
    DecodeGraphTopology& topology   = select_graph_topology(family, profile.topology_class, label);
    const std::size_t profile_index = static_cast<std::size_t>(&profile - family.profiles.data());
    if (topology.installed_profile != profile_index) {
        topology.executable.update(profile.definition);
        topology.installed_profile = profile_index;
    }
    return topology.executable;
}

} // namespace

void ProgramImpl::install_sampling(SequenceState& sequence, RequestControl& request,
                                   const ops::SamplingConfig& config) {
    Tensor counts = token_counts.slice(1, static_cast<std::int32_t>(sequence.lane), 1)
                        .view({dimension(parameters.model.resources().public_token_count)});
    request.sampling_host     = config;
    // MTP rounds can verify up to V drafts, so acceptance is counted over the verify window.
    const std::uint32_t verified_positions =
        speculative_backend == SpeculativeBackend::Mtp ? verify_window : draft_window;
    request.speculative_stats = SpeculativeStats{
        .backend               = speculative_backend,
        .enabled               = speculative_backend != SpeculativeBackend::None,
        .draft_window          = draft_window,
        .accepted_per_position = std::vector<std::uint64_t>(verified_positions, 0),
        .verify_window         = speculative_backend == SpeculativeBackend::Mtp ? verify_window : 0U,
    };
    const bool penalties = request.sampling_host.presence_penalty != 0.0F ||
                           request.sampling_host.frequency_penalty != 0.0F;
    if (penalties) { CUDA_CHECK(cudaMemsetAsync(counts.data, 0, counts.bytes(), device.stream)); }
    request.sampling_host.token_counts =
        penalties ? static_cast<std::int32_t*>(counts.data) : nullptr;
    Tensor config_lane = sampling_config.slice(1, static_cast<std::int32_t>(sequence.lane), 1);
    CUDA_CHECK(cudaMemcpyAsync(config_lane.data, &request.sampling_host,
                               sizeof(request.sampling_host), cudaMemcpyHostToDevice,
                               device.stream));
}

void ProgramImpl::copy_tail(SequenceState& sequence, const Tensor& source) {
    if (source.dtype != DType::BF16 ||
        source.ne[0] != dimension(parameters.model.config().text.hidden_size) ||
        source.ne[1] != 1) {
        throw std::logic_error("target tail hidden has an invalid shape");
    }
    CUDA_CHECK(cudaMemcpyAsync(sequence.tail_hidden.data, source.data, sequence.tail_hidden.bytes(),
                               cudaMemcpyDeviceToDevice, device.stream));
    sequence.tail_hidden_valid = true;
}

void ProgramImpl::copy_round_token() {
    CUDA_CHECK(cudaMemcpyAsync(host_tokens, io.token.data, sizeof(TokenId), cudaMemcpyDeviceToHost,
                               device.stream));
}

void ProgramImpl::mark_workspace_usage(std::size_t phase_bytes) noexcept {
    workspace_logical_peak_bytes = std::max(workspace_logical_peak_bytes, phase_bytes);
}

void ProgramImpl::enqueue_dflash_context_append(std::span<const std::uint32_t> lanes,
                                                std::span<const std::uint32_t> starts,
                                                std::span<const std::uint32_t> counts) {
    if (!is_masked_draft_backend(speculative_backend) || !dflash || !io.dflash_decode ||
        lanes.empty() || lanes.size() > max_concurrency || starts.size() != lanes.size() ||
        counts.size() != lanes.size()) {
        throw std::logic_error("DFlash context append has invalid membership");
    }

    std::uint32_t minimum_count = draft_window + 1U;
    std::uint32_t maximum_count = 0;
    *dflash_host_ingress        = {};
    for (std::size_t row = 0; row < lanes.size(); ++row) {
        const std::uint32_t lane = lanes[row];
        if (lane >= max_concurrency || counts[row] == 0 || counts[row] > draft_window + 1U ||
            std::find(lanes.begin(), lanes.begin() + static_cast<std::ptrdiff_t>(row), lane) !=
                lanes.begin() + static_cast<std::ptrdiff_t>(row)) {
            throw std::logic_error("DFlash context append contains an invalid row");
        }
        SequenceState& sequence   = active_sequence(lane);
        const std::uint32_t start = starts[row];
        const std::uint64_t end64 = static_cast<std::uint64_t>(start) + counts[row];
        const std::uint32_t end   = static_cast<std::uint32_t>(end64);
        if (!sequence.kv || text_kv_addresses->bound_row(sequence.kv->text) < 0 ||
            (backend_kv_cache() && (!sequence.kv->backend ||
                                    backend_kv_addresses->bound_row(*sequence.kv->backend) < 0)) ||
            end64 > capacity) {
            throw std::logic_error("DFlash context append is outside retained target storage");
        }
        dflash_host_ingress->context_frontiers[row] =
            checked_i32(start, "DFlash append context frontier");
        dflash_host_ingress->execution_frontiers[row] =
            checked_i32(end, "DFlash append target frontier");
        dflash_host_ingress->dflash_kv_table_rows[row] =
            sequence.kv->backend ? backend_kv_addresses->bound_row(*sequence.kv->backend) : 0;
        dflash_host_ingress->active_lanes[row]            = static_cast<std::int32_t>(lane);
        const StateImageSelectors selectors               = state_selectors(sequence);
        dflash_host_ingress->state_source_slots[row]      = selectors.source;
        dflash_host_ingress->state_destination_slots[row] = selectors.destination;
        // Context append writes only the draft caches. Target execution owns Main KV
        // coverage, including any uncommitted suffix that survives until the round is settled.
        // DFlash2 has only fixed cyclic state; DFlash also grows its Full backend KV here.
        if (sequence.kv->backend) {
            backend_kv_addresses->ensure_mapped_to_tokens(*sequence.kv->backend, end,
                                                          device.stream);
        }
        minimum_count = std::min(minimum_count, counts[row]);
        maximum_count = std::max(maximum_count, counts[row]);
    }

    qwen3_5::DFlashDecodeState& frame = *io.dflash_decode;
    CUDA_CHECK(cudaMemcpyAsync(frame.ingress.data, dflash_host_ingress,
                               sizeof(qwen3_5::DFlashDecodeIngress), cudaMemcpyHostToDevice,
                               device.stream));
    const auto batch                = static_cast<std::int32_t>(lanes.size());
    Tensor active_lane_tensor       = frame.active_lanes.slice(0, 0, batch);
    Tensor state_destination_tensor = frame.state_destination_slots.slice(0, 0, batch);
    Tensor device_starts            = frame.context_frontiers.slice(0, 0, batch);
    Tensor device_ends              = frame.execution_frontiers.slice(0, 0, batch);
    Tensor table_rows               = frame.dflash_kv_table_rows.slice(0, 0, batch);
    Tensor positions                = frame.append_positions.slice(1, 0, batch);
    Tensor device_counts            = frame.append_counts.slice(0, 0, batch);

    work.reset();
    Tensor features =
        work.alloc(DType::BF16, {dimension(parameters.draft->feature_projection.weight.k),
                                 static_cast<std::int32_t>(draft_window + 1U), batch});
    ops::prepare_ragged_prefix(dflash->pending_features, active_lane_tensor, device_starts,
                               device_ends, features, positions, device_counts, device.stream);

    execution::DFlashAppendContext state{{device, parameters, work, state_images->linear(),
                                          replay_records ? &*replay_records : nullptr, io,
                                          prefill_hidden, prefill_chunk, proposal_head},
                                         *dflash};
    mark_workspace_usage(workspace_plan.dflash_context);
    execution::dflash_append_context(state, features, positions, device_counts,
                                     state_destination_tensor, table_rows,
                                     {minimum_count, maximum_count});
}

void ProgramImpl::validate_licensed_tokens(std::span<const TokenId> tokens) const {
    for (const TokenId token : tokens) {
        if (token < 0 || token >= dimension(parameters.model.resources().public_token_count)) {
            throw std::runtime_error("target returned a token outside the public token domain");
        }
    }
}

#if defined(NINFER_WITH_KVMEM)
void ProgramImpl::ensure_native_decode_writable_tail(SequenceState& sequence) {
    if (!kvmem.enabled || !native_kvmem_conversation || !native_kvmem_backend ||
        !sequence.kv ||
        (speculative_backend == SpeculativeBackend::None && sequence.kv->backend) ||
        (speculative_backend == SpeculativeBackend::Mtp && !sequence.kv->backend) ||
        (speculative_backend != SpeculativeBackend::None &&
         speculative_backend != SpeculativeBackend::Mtp)) {
        throw std::logic_error("native decode tail has no supported target owner");
    }
    const std::uint32_t logical = sequence.execution_frontier;
    const std::uint32_t compact = sequence.compact_kv_frontier.value_or(logical);
    const auto& store = native_kvmem_conversation->runtime().store();
    if (store.total_tokens() != logical ||
        text_kv_addresses->committed_frontier(sequence.kv->text) != compact) {
        throw std::logic_error("native decode tail has an inconsistent frontier");
    }
    constexpr std::uint32_t page_tokens = static_cast<std::uint32_t>(kPagedKVPageSize);
    if (compact % page_tokens == 0 ||
        text_kv_pages->writer_references(text_kv_addresses->logical_page(
            sequence.kv->text, compact / page_tokens)) != 0) {
        return;
    }
    // The accepted prompt tail is slot-owned and read-only. Fork it once;
    // later generated rows retain the private writable page until block close.
    device.synchronize();
    const KVAddressSpaceHandle old_writer = sequence.kv->text;
    if (!text_kv_addresses->can_release_after_deactivate(old_writer)) {
        throw std::logic_error("native decode cannot detach its shared prompt tail");
    }
    std::vector<std::uint32_t> selected;
    std::uint64_t selected_tokens = 0;
    for (const kvmem::KvMemBlock& block : store.blocks()) {
        // An all-resident prompt may have no selection flag at all, and new
        // generated blocks are not marked in_working_set until a reselect.
        // The current writer covers exactly its GPU-resident prefix; reject
        // any extra/missing resident rows with the compact-size check below.
        if (block.gpu_slot >= 0 && block.n_tokens != 0) {
            selected.push_back(block.block_id);
            selected_tokens += block.n_tokens;
        }
    }
    if (selected.empty() || selected_tokens != compact) {
        throw std::logic_error("native decode has no rebuildable selected prefix");
    }
    std::uint32_t execution_tokens = 0;
    for (const std::uint32_t id : selected) {
        const kvmem::KvMemBlock& block = store.blocks()[id];
        if (execution_tokens % kvmem.block_tokens != 0) {
            throw std::logic_error("native resident decode view lost block alignment");
        }
        const auto native_pages = native_kvmem_backend->pages_for_slot(id, block.gpu_slot);
        const std::uint32_t visible_pages =
            (block.n_tokens + page_tokens - 1U) / page_tokens;
        for (std::uint32_t page = 0; page < visible_pages; ++page) {
            if (text_kv_addresses->logical_page(
                    old_writer, execution_tokens / page_tokens + page) != native_pages[page]) {
                throw std::logic_error(
                    "native resident decode blocks do not match the execution view");
            }
        }
        execution_tokens += block.n_tokens;
    }
    if (!text_kv_addresses->release_after_deactivate(old_writer)) {
        throw std::logic_error("native decode could not release its shared execution view");
    }
    std::optional<KVAddressSpaceHandle> reader;
    std::optional<KVAddressSpaceHandle> writer;
    try {
        reader = text_kv_addresses->create_inactive();
        writer = text_kv_addresses->create_inactive();
        if (!reader || !writer) {
            throw std::runtime_error("native decode lacks address descriptors");
        }
        const auto offsets = native_kvmem_backend->install_selected_for_append(
            store, selected, *text_kv_addresses, *reader, *writer,
            kv_pages_for_frontier(compact + 1U),
            static_cast<std::int32_t>(sequence.lane), false);
        if (offsets.empty() ||
            offsets.back().execution_begin + offsets.back().tokens != compact ||
            !text_kv_addresses->release(*reader)) {
            throw std::logic_error("native decode selected prefix is incomplete");
        }
        reader.reset();
        sequence.kv->text = *writer;
        writer.reset();
        sequence.compact_kv_frontier = compact;
    } catch (...) {
        if (writer) { (void)text_kv_addresses->release_after_deactivate(*writer); }
        if (reader) { (void)text_kv_addresses->release_after_deactivate(*reader); }
        throw;
    }
}

void ProgramImpl::adopt_native_decode_tail(SequenceState& sequence) {
    if (!kvmem.enabled || !native_kvmem_conversation || !native_kvmem_backend ||
        !sequence.kv ||
        (speculative_backend == SpeculativeBackend::None && sequence.kv->backend) ||
        (speculative_backend == SpeculativeBackend::Mtp && !sequence.kv->backend) ||
        (speculative_backend != SpeculativeBackend::None &&
         speculative_backend != SpeculativeBackend::Mtp)) {
        throw std::logic_error("native decode tail has no supported target owner");
    }
    const auto& store = native_kvmem_conversation->runtime().store();
    if (store.total_tokens() == 0) { return; }
    const std::int32_t id = store.block_id_containing(store.total_tokens() - 1U);
    if (id < 0) { throw std::logic_error("native decode tail has no block identity"); }
    const auto& block = store.blocks()[static_cast<std::uint32_t>(id)];
    if (block.orig_pos_end() != store.total_tokens() || block.gpu_slot < 0 ||
        block.n_tokens == 0 || block.n_tokens > kvmem.block_tokens ||
        sequence.native_tail_materialized_tokens > block.n_tokens ||
        sequence.text_kv_valid < block.n_tokens) {
        throw std::logic_error("native decode tail is not an accepted GPU block");
    }
    if (sequence.native_tail_materialized_tokens == block.n_tokens) { return; }

    const std::uint32_t execution_begin = sequence.text_kv_valid - block.n_tokens;
    const KVAddressSpaceHandle writer = sequence.kv->text;
    if (execution_begin % kvmem.block_tokens != 0 ||
        text_kv_addresses->committed_frontier(writer) != sequence.text_kv_valid) {
        throw std::logic_error("native decode tail is not aligned with its compact writer");
    }
    const std::uint32_t entitlement = text_kv_addresses->entitlement(writer);
    text_kv_addresses->deactivate(writer);
    try {
        if (sequence.native_tail_materialized_tokens != 0) {
            native_kvmem_backend->replace_inactive_tail_address(
                static_cast<std::uint32_t>(id), block.gpu_slot, *text_kv_addresses,
                writer, execution_begin, sequence.native_tail_materialized_tokens,
                block.n_tokens);
        } else {
            native_kvmem_backend->adopt_inactive_prefill_address(
                static_cast<std::uint32_t>(id), block.gpu_slot, *text_kv_addresses,
                writer, execution_begin, block.n_tokens);
        }
        sequence.native_tail_materialized_tokens =
            block.n_tokens == kvmem.block_tokens ? 0U : block.n_tokens;
        text_kv_addresses->activate(writer, entitlement,
                                    static_cast<std::int32_t>(sequence.lane), device.stream);
    } catch (...) {
        native_kvmem_poisoned = true;
        throw;
    }
}
#endif

runtime::BatchedGeneratedRound
ProgramImpl::decode_ordinary_batch(std::span<const std::uint32_t> lanes,
                                   std::span<const runtime::RoundBudget> budgets,
                                   runtime::ExecutionTiming* failed_timing) {
    nvtx::ScopedRange round_range(nvtx::Name::DecodeOrdinaryRound, nvtx::Category::Decode,
                                  static_cast<std::uint64_t>(lanes.size()));
    runtime::ExecutionTimingRecorder timing(runtime::ExecutionTimingPhase::Submit, failed_timing);
    if (speculative_backend != SpeculativeBackend::None) {
        throw std::logic_error("ordinary batch execution requires the ordinary backend");
    }
    if (lanes.empty() || lanes.size() > max_concurrency || budgets.size() != lanes.size()) {
        throw std::invalid_argument("ordinary batch membership is invalid");
    }

    std::uint32_t maximum_frontier = 0;
    for (std::size_t row = 0; row < lanes.size(); ++row) {
        const std::uint32_t lane = lanes[row];
        if (lane >= max_concurrency ||
            std::find(lanes.begin(), lanes.begin() + static_cast<std::ptrdiff_t>(row), lane) !=
                lanes.begin() + static_cast<std::ptrdiff_t>(row)) {
            throw std::invalid_argument("ordinary batch contains an invalid or duplicate lane");
        }
        const SequenceState& sequence = active_sequence(lane);
        const RequestControl& request = requests[lane];
        const std::uint32_t cache_frontier =
            sequence.compact_kv_frontier.value_or(sequence.execution_frontier);
        if (request.lifecycle != Lifecycle::Active ||
            budgets[row].generated_tokens_remaining == 0 || !sequence.kv ||
            text_kv_addresses->bound_row(sequence.kv->text) < 0 ||
            sequence.execution_frontier >= capacity ||
            cache_frontier >= kv_capacity ||
            sequence.ledger_frontier != sequence.execution_frontier + 1 ||
            sequence.ledger.size() != sequence.ledger_frontier ||
            sequence.prefix_identity.size() != sequence.ledger_frontier ||
            sequence.prefix_digests.size() != sequence.ledger_frontier) {
            throw std::logic_error("ordinary batch row is not decode-ready");
        }
        maximum_frontier = std::max(maximum_frontier, cache_frontier);
    }

    const auto start = Clock::now();
    try {
#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled) {
            if (lanes.size() != 1 || !native_kvmem_conversation || !native_kvmem_backend ||
                !native_decode_features || !native_decode_capture || native_kvmem_poisoned ||
                !native_kvmem_owner || *native_kvmem_owner != active_continuations[lanes[0]]) {
                throw std::logic_error("native ordinary decode has no exclusive conversation owner");
            }
            SequenceState& sequence = active_sequence(lanes[0]);
            const std::uint32_t logical = sequence.execution_frontier;
            const std::uint32_t compact =
                sequence.compact_kv_frontier.value_or(logical);
            const auto& store = native_kvmem_conversation->runtime().store();
            if (store.total_tokens() != logical ||
                native_kvmem_conversation->runtime().pending() ||
                native_kvmem_conversation->metadata().row_positions.size() != logical ||
                native_decode_features->key_frontier() != logical ||
                !sequence.kv || sequence.kv->backend ||
                text_kv_addresses->committed_frontier(sequence.kv->text) != compact) {
                throw std::logic_error("native ordinary decode frontiers are inconsistent");
            }

            ensure_native_decode_writable_tail(sequence);
            const auto append = native_kvmem_conversation->plan_prefill_append(
                1U, kv_capacity, true);
            if (append.pressure || append.old_frontier != logical ||
                append.new_frontier != logical + 1U) {
                throw std::logic_error("native ordinary input append changed its frontier");
            }
            (void)native_decode_features->begin_decode_token(logical, device.stream);
        }
#endif
        std::optional<nvtx::ScopedRange> submit_range;
        submit_range.emplace(nvtx::Name::DecodeOrdinarySubmit, nvtx::Category::Decode,
                             static_cast<std::uint64_t>(lanes.size()));
        DecodeGraphExecutable* executable = nullptr;
        ops::CausalAttentionExecutionEnvelope envelope{maximum_frontier + 1, maximum_frontier + 1};
        if (use_cuda_graph) {
            DecodeGraphProfile& profile =
                select_graph_profile(ordinary_graphs, static_cast<std::uint32_t>(lanes.size()),
                                     maximum_frontier, "ordinary batch");
            executable = &install_graph_profile(ordinary_graphs, profile, "ordinary batch");
            envelope   = {profile.min_execution_frontier + 1, profile.max_execution_frontier + 1};
        }

        for (std::size_t row = 0; row < lanes.size(); ++row) {
            SequenceState& sequence            = active_sequence(lanes[row]);
            const RequestControl& request      = requests[lanes[row]];
            const std::uint32_t frontier       = sequence.execution_frontier;
            const std::uint32_t cache_frontier =
                sequence.compact_kv_frontier.value_or(frontier);
            ordinary_host_ingress->tokens[row] = sequence.ledger.back();
            ordinary_host_ingress->cache_positions[row] =
                checked_i32(cache_frontier, "ordinary batch cache position");
            ordinary_host_ingress->logical_positions[row] =
                checked_i32(sequence.ledger_frontier - 1U,
                            "ordinary batch logical sampling position");
            ordinary_host_ingress->rope_positions[row] =
                checked_i32(frontier, "ordinary batch RoPE position") + sequence.rope_delta;
            ordinary_host_ingress->text_kv_table_rows[row] =
                text_kv_addresses->bound_row(sequence.kv->text);
            const StateImageSelectors selectors                 = state_selectors(sequence);
            ordinary_host_ingress->state_source_slots[row]      = selectors.source;
            ordinary_host_ingress->state_destination_slots[row] = selectors.destination;
            ordinary_host_ingress->sampling[row]                = request.sampling_host;
            ensure_sequence_kv_mapped(sequence, cache_frontier + 1, 0);
        }

        execution::OrdinaryBatchContext schedule_state{
            {device, parameters, work, state_images->linear(),
             replay_records ? &*replay_records : nullptr, io, prefill_hidden, prefill_chunk,
             proposal_head},
            decoder->text_kv,
            *io.ordinary,
            *ordinary_host_ingress,
            *ordinary_host_egress,
            state_images->continuation_hidden_store()};
#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled) {
            schedule_state.execution.attention_features = &*native_decode_capture;
        }
#endif

        mark_workspace_usage(workspace_plan.ordinary_round);
        execution::ordinary_decode_batch(schedule_state, static_cast<std::int32_t>(lanes.size()),
                                         envelope, executable);
        submit_range.reset();
        timing.begin_wait();
        {
            nvtx::ScopedRange wait_range(nvtx::Name::DecodeOrdinaryWait, nvtx::Category::Control,
                                         static_cast<std::uint64_t>(lanes.size()));
            device.synchronize();
        }
        timing.end_wait();

#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled) {
            SequenceState& sequence = active_sequence(lanes[0]);
            const std::uint32_t logical = sequence.execution_frontier;
            native_decode_features->accept_decode_token(logical);
            auto& rows = native_kvmem_conversation->metadata().row_positions;
            if (rows.size() != logical) {
                throw std::logic_error("native ordinary row metadata is not contiguous");
            }
            const std::int32_t rope =
                checked_i32(logical, "native ordinary RoPE position") + sequence.rope_delta;
            rows.push_back(KVMemConversation::RowPosition{
                .pos = {rope, rope, rope, rope},
                .token = sequence.ledger.back(),
                .spatial = true,
            });
        }
#endif

        const double seconds = std::chrono::duration<double>(Clock::now() - start).count();
        for (std::size_t row = 0; row < lanes.size(); ++row) {
            SequenceState& sequence    = active_sequence(lanes[row]);
            RequestControl& request    = requests[lanes[row]];
            const std::uint32_t base_E = sequence.execution_frontier;
            const std::uint32_t cache_frontier =
                sequence.compact_kv_frontier.value_or(base_E);
            const std::uint32_t base_S = sequence.ledger_frontier;
            const TokenId token        = ordinary_host_egress->sampled_tokens[row];
            validate_licensed_tokens(std::span<const TokenId>(&token, 1));
            sequence.text_kv_valid = cache_frontier + 1;
            commit_sequence_kv(sequence, sequence.text_kv_valid, 0);
#if defined(NINFER_WITH_KVMEM)
            if (kvmem.enabled && (base_E + 1U) % kvmem.block_tokens == 0) {
                adopt_native_decode_tail(sequence);
            }
#endif
            sequence.tail_hidden_valid = true;
            sequence.ledger.push_back(token);
            sequence.prefix_identity.append_generated(1, sequence.rope_delta);
            sequence.prefix_digests.append_generated(std::span<const TokenId>(&token, 1),
                                                     sequence.rope_delta);
            request.pending   = PendingCandidate{.kind          = PendingKind::Ordinary,
                                                 .base_E        = base_E,
                                                 .base_S        = base_S,
                                                 .prompt_tokens = 0,
                                                 .produced      = 1};
            request.lifecycle = Lifecycle::Pending;
            request.timings.decode_seconds += seconds;
        }
        return runtime::BatchedGeneratedRound{
            .tokens =
                std::span<const TokenId>(ordinary_host_egress->sampled_tokens.data(), lanes.size()),
            .timing = timing.finish(),
        };
    } catch (...) {
#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled) { native_kvmem_poisoned = true; }
#endif
        timing.begin_wait();
        try {
            nvtx::ScopedRange wait_range(nvtx::Name::DecodeOrdinaryWait, nvtx::Category::Control,
                                         static_cast<std::uint64_t>(lanes.size()));
            device.synchronize();
        } catch (...) {}
        timing.end_wait();
        clear_execution_failure_lanes(lanes);
        throw;
    }
}

runtime::BatchedGeneratedRound
ProgramImpl::decode_mtp_batch(std::span<const std::uint32_t> lanes,
                              std::span<const runtime::RoundBudget> budgets,
                              runtime::ExecutionTiming* failed_timing) {
    nvtx::ScopedRange round_range(nvtx::Name::DecodeMtpRound, nvtx::Category::Mtp,
                                  static_cast<std::uint64_t>(lanes.size()));
    runtime::ExecutionTimingRecorder timing(runtime::ExecutionTimingPhase::Submit, failed_timing);
    if (speculative_backend != SpeculativeBackend::Mtp || !io.mtp_decode ||
        decoder->mtp_cache() == nullptr) {
        throw std::logic_error("MTP batch execution requires the MTP backend");
    }
    if (lanes.empty() || lanes.size() > max_concurrency || budgets.size() != lanes.size()) {
        throw std::invalid_argument("MTP batch membership is invalid");
    }
    const std::uint32_t cache_context_capacity = std::min(capacity, kv_capacity);

    std::uint32_t maximum_cache_frontier = 0;
    for (std::size_t row = 0; row < lanes.size(); ++row) {
        const std::uint32_t lane = lanes[row];
        if (lane >= max_concurrency ||
            std::find(lanes.begin(), lanes.begin() + static_cast<std::ptrdiff_t>(row), lane) !=
                lanes.begin() + static_cast<std::ptrdiff_t>(row)) {
            throw std::invalid_argument("MTP batch contains an invalid or duplicate lane");
        }
        const SequenceState& sequence = active_sequence(lane);
        const RequestControl& request = requests[lane];
        const std::uint32_t cache_frontier =
            sequence.compact_kv_frontier.value_or(sequence.execution_frontier);
        if (request.lifecycle != Lifecycle::Active ||
            budgets[row].generated_tokens_remaining == 0 || !sequence.kv || !sequence.kv->backend ||
            text_kv_addresses->bound_row(sequence.kv->text) < 0 ||
            backend_kv_addresses->bound_row(*sequence.kv->backend) < 0 ||
            sequence.execution_frontier >= capacity ||
            cache_frontier >= cache_context_capacity ||
            sequence.text_kv_valid != cache_frontier ||
            sequence.mtp_kv_valid != cache_frontier ||
            sequence.ledger_frontier != sequence.execution_frontier + 1 ||
            sequence.ledger.size() != sequence.ledger_frontier ||
            sequence.prefix_identity.size() != sequence.ledger_frontier ||
            sequence.prefix_digests.size() != sequence.ledger_frontier ||
            sequence.mtp_draft_count > draft_window) {
            throw std::logic_error("MTP batch row is not decode-ready");
        }
        maximum_cache_frontier = std::max(maximum_cache_frontier, cache_frontier);
    }

    std::uint32_t native_append_tokens = capacity;
#if defined(NINFER_WITH_KVMEM)
    if (kvmem.enabled) {
        if (lanes.size() != 1 || !native_kvmem_conversation ||
            !native_kvmem_backend || !native_mtp_accepted_keys ||
            !native_kvmem_follower_backend || native_kvmem_poisoned ||
            !native_kvmem_owner ||
            *native_kvmem_owner != active_continuations[lanes[0]]) {
            throw std::logic_error("native MTP decode has no exclusive conversation owner");
        }
        const SequenceState& sequence = active_sequence(lanes[0]);
        const std::uint32_t logical = sequence.execution_frontier;
        const std::uint32_t compact = sequence.compact_kv_frontier.value_or(logical);
        const auto& store = native_kvmem_conversation->runtime().store();
        if (store.total_tokens() != logical ||
            native_kvmem_conversation->runtime().pending() ||
            native_kvmem_conversation->metadata().row_positions.size() != logical ||
            native_mtp_accepted_keys->key_frontier() != logical ||
            text_kv_addresses->committed_frontier(sequence.kv->text) != compact ||
            backend_kv_addresses->committed_frontier(*sequence.kv->backend) != compact) {
            throw std::logic_error("native MTP decode frontiers are inconsistent");
        }
        // One verify can finish the existing native slot and enter the next.
        // Admit the actual input span before COW/register/forward; only whole
        // free slots plus the resident tail's remaining rows are available.
        native_append_tokens = native_kvmem_conversation->pinned_append_limit(
            verify_window + 1U, kv_capacity);
        if (native_append_tokens == 0) {
            throw std::logic_error("native MTP generation pool is exhausted");
        }
    }
#endif

    // Row drafts: the MTP proposal, extended from the n-gram pool when enabled. The round verifies
    // the full window V only when some row's usable draft pays for it; otherwise it keeps the MTP
    // width K+1 and its graph set.
    std::array<TokenId, kMaximumConcurrency * kMtpVerifyMaximumDrafts> row_drafts{};
    std::array<std::uint32_t, kMaximumConcurrency> usable_drafts{};
    std::array<std::uint32_t, kMaximumConcurrency> proposal_drafts{};
    for (std::size_t row = 0; row < lanes.size(); ++row) {
        SequenceState& sequence = active_sequence(lanes[row]);
        proposal_drafts[row]    = sequence.mtp_draft_count;
        const std::span<const TokenId> proposal(sequence.mtp_drafts.data(),
                                                sequence.mtp_draft_count);
        const std::span<TokenId> drafts(row_drafts.data() + row * kMtpVerifyMaximumDrafts,
                                        verify_window);
        std::size_t count = proposal.size();
        if (ngram_pool) {
            ngram_pool->observe(sequence.ledger, sequence.ngram_observed);
            sequence.ngram_observed = sequence.ledger.size();
            std::array<TokenId, NgramDraftPool::kMaximumMatchTokens + kMtpDecodeMaximumDrafts>
                context{};
            count = chain_ngram_drafts(*ngram_pool, sequence.ledger, proposal, ngram.min_drafts,
                                       context, drafts);
        } else {
            std::copy(proposal.begin(), proposal.end(), drafts.begin());
        }
        const std::uint32_t max_by_budget = budgets[row].generated_tokens_remaining > 1
                                                ? budgets[row].generated_tokens_remaining - 1
                                                : 0;
        const std::uint32_t cache_frontier =
            sequence.compact_kv_frontier.value_or(sequence.execution_frontier);
        const std::uint32_t max_by_cache = cache_context_capacity - cache_frontier - 1U;
        usable_drafts[row] = std::min({static_cast<std::uint32_t>(count), max_by_budget,
                                       capacity - sequence.execution_frontier - 1U, max_by_cache,
                                       native_append_tokens - 1U});
    }
    const std::uint32_t verify_drafts =
        ngram_pool ? ngram_round_verify_drafts(
                         std::span<const std::uint32_t>(usable_drafts.data(), lanes.size()),
                         draft_window, verify_window)
                   : draft_window;
    const std::uint32_t width     = verify_drafts + 1;
    const bool wide_round         = verify_drafts != draft_window;
    DecodeGraphFamily& mtp_family = wide_round ? mtp_wide_graphs : mtp_graphs;

    const auto started = Clock::now();
    try {
#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled) {
            SequenceState& sequence = active_sequence(lanes[0]);
            const std::uint32_t logical = sequence.execution_frontier;
            ensure_native_decode_writable_tail(sequence);
            const auto append = native_kvmem_conversation->plan_prefill_append(
                std::min(usable_drafts[0], verify_drafts) + 1U, kv_capacity, true);
            if (append.pressure || append.old_frontier != logical ||
                append.new_frontier != logical +
                                           std::min(usable_drafts[0], verify_drafts) + 1U) {
                throw std::logic_error("native MTP target append changed its frontier");
            }
        }
#endif
        std::optional<nvtx::ScopedRange> submit_range;
        submit_range.emplace(nvtx::Name::DecodeMtpSubmit, nvtx::Category::Mtp,
                             static_cast<std::uint64_t>(lanes.size()));
        DecodeGraphExecutable* executable = nullptr;
        execution::MtpCausalAttentionEnvelopes envelopes =
            mtp_causal_attention_envelopes(maximum_cache_frontier, verify_drafts, draft_window,
                                           cache_context_capacity);
        if (use_cuda_graph) {
            DecodeGraphProfile& profile =
                select_graph_profile(mtp_family, static_cast<std::uint32_t>(lanes.size()),
                                     maximum_cache_frontier, "MTP batch");
            executable = &install_graph_profile(mtp_family, profile, "MTP batch");
            envelopes  = mtp_causal_attention_envelopes(profile.max_execution_frontier,
                                                        verify_drafts, draft_window,
                                                        cache_context_capacity);
        }

        for (std::size_t row = 0; row < lanes.size(); ++row) {
            SequenceState& sequence           = active_sequence(lanes[row]);
            const RequestControl& request     = requests[lanes[row]];
            const std::uint32_t frontier      = sequence.execution_frontier;
            const std::uint32_t cache_frontier =
                sequence.compact_kv_frontier.value_or(frontier);
            const std::uint32_t extent        = std::min(usable_drafts[row], verify_drafts);
            mtp_host_ingress->anchors[row]        = sequence.ledger.back();
            mtp_host_ingress->base_frontiers[row] = checked_i32(frontier, "MTP batch frontier");
            mtp_host_ingress->cache_base_frontiers[row] =
                checked_i32(cache_frontier, "MTP batch cache frontier");
            // The MTP op uses this only to size the next draft extent. Clamp that proposal budget
            // to the physical slots available after this row's cache base; target licensing still
            // uses the original frontend budget and is independently bounded by usable_drafts.
            const std::uint32_t cache_remaining = cache_context_capacity - cache_frontier;
            mtp_host_ingress->remaining_budgets[row] = checked_i32(
                std::min(budgets[row].generated_tokens_remaining, cache_remaining),
                "MTP batch remaining cache budget");
            mtp_host_ingress->current_extents[row]      = static_cast<std::int32_t>(extent);
            mtp_host_ingress->target_valid_columns[row] = static_cast<std::int32_t>(extent + 1);
            for (std::uint32_t j = 0; j < verify_drafts; ++j) {
                mtp_host_ingress->current_drafts[row * verify_drafts + j] =
                    j < extent ? row_drafts[row * kMtpVerifyMaximumDrafts + j]
                               : sequence.ledger.back();
            }
            for (std::uint32_t j = 0; j < width; ++j) {
                const std::uint32_t position = frontier + std::min(j, extent);
                mtp_host_ingress->target_rope_positions[row * width + j] =
                    checked_i32(position, "MTP batch RoPE position") + sequence.rope_delta;
            }
            mtp_host_ingress->text_kv_table_rows[row] =
                text_kv_addresses->bound_row(sequence.kv->text);
            mtp_host_ingress->mtp_kv_table_rows[row] =
                backend_kv_addresses->bound_row(*sequence.kv->backend);
            const StateImageSelectors selectors            = state_selectors(sequence);
            mtp_host_ingress->state_source_slots[row]      = selectors.source;
            mtp_host_ingress->state_destination_slots[row] = selectors.destination;
            mtp_host_ingress->rope_deltas[row]             = sequence.rope_delta;
            mtp_host_ingress->sampling[row]                = request.sampling_host;
            // Text KV covers the verified columns; MTP KV also covers the K-1 AR steps that
            // follow the accepted prefix, so its end depends on the depth K, not on W.
            const std::uint64_t text_end = static_cast<std::uint64_t>(cache_frontier) + extent + 1U;
            const std::uint64_t mtp_end = static_cast<std::uint64_t>(cache_frontier) + extent +
                                          draft_window;
            if (text_end > cache_context_capacity) {
                throw std::logic_error("MTP verification mapping exceeds physical KV capacity");
            }
            ensure_sequence_kv_mapped(
                sequence, static_cast<std::uint32_t>(text_end),
                static_cast<std::uint32_t>(std::min<std::uint64_t>(mtp_end,
                                                                   cache_context_capacity)));
        }

        execution::MtpBatchContext schedule_state{{device, parameters, work, state_images->linear(),
                                                   round_replay_records(width), io,
                                                   prefill_hidden, prefill_chunk, proposal_head},
                                                  decoder->text_kv,
                                                  *decoder->mtp_cache(),
                                                  *io.mtp_decode,
                                                  *mtp_host_ingress,
                                                  *mtp_host_egress,
                                                  state_images->continuation_hidden_store(),
                                                  capacity};

        mark_workspace_usage(workspace_plan.mtp_round);
        mtp_round_width = width;
#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled) {
            const Tensor committed_hidden = state_images->continuation_hidden_slot(
                state_selectors(active_sequence(lanes[0])).source);
            auto& cancel_hidden = requests[lanes[0]].native_cancel_tail_hidden;
            cancel_hidden.resize(committed_hidden.bytes());
            CUDA_CHECK(cudaMemcpyAsync(cancel_hidden.data(), committed_hidden.data,
                                       committed_hidden.bytes(), cudaMemcpyDeviceToHost,
                                       device.stream));
            (void)native_mtp_accepted_keys->begin_verify(
                static_cast<std::int32_t>(width), 1, device.stream);
            schedule_state.execution.attention_features =
                &native_mtp_accepted_keys->capture_view();
        }
#endif
        execution::mtp_decode_batch(schedule_state, static_cast<std::int32_t>(lanes.size()), width,
                                    draft_window, envelopes, executable);
        submit_range.reset();
        timing.begin_wait();
        {
            nvtx::ScopedRange wait_range(nvtx::Name::DecodeMtpWait, nvtx::Category::Control,
                                         static_cast<std::uint64_t>(lanes.size()));
            device.synchronize();
        }
        timing.end_wait();

        const double seconds = std::chrono::duration<double>(Clock::now() - started).count();
        for (std::size_t row = 0; row < lanes.size(); ++row) {
            SequenceState& sequence       = active_sequence(lanes[row]);
            RequestControl& request       = requests[lanes[row]];
            const std::uint32_t base_E    = sequence.execution_frontier;
            const std::uint32_t base_S    = sequence.ledger_frontier;
            const std::int32_t count_i    = mtp_host_egress->licensed_counts[row];
            const std::int32_t accepted_i = mtp_host_egress->accepted_drafts[row];
            const std::int32_t next_i     = mtp_host_egress->next_extents[row];
            const std::int32_t pcur_i = mtp_host_ingress->current_extents[row];
            if (count_i <= 0 || count_i > static_cast<std::int32_t>(width) || accepted_i < 0 ||
                pcur_i < 0 || accepted_i > pcur_i ||
                accepted_i + 1 != count_i || next_i < 0 ||
                next_i > static_cast<std::int32_t>(draft_window) ||
                static_cast<std::uint32_t>(count_i) > budgets[row].generated_tokens_remaining ||
                static_cast<std::uint64_t>(base_E) + static_cast<std::uint32_t>(count_i) >
                    capacity ||
                static_cast<std::uint64_t>(mtp_host_ingress->cache_base_frontiers[row]) +
                        static_cast<std::uint32_t>(count_i) >
                    cache_context_capacity) {
                throw std::runtime_error("MTP batch returned invalid row metadata");
            }
            const std::span<const TokenId> row_tokens(mtp_host_egress->licensed_tokens.data() +
                                                          row * width,
                                                      static_cast<std::size_t>(count_i));
            validate_licensed_tokens(row_tokens);
            const std::uint32_t pcur = static_cast<std::uint32_t>(pcur_i);
            if (wide_round) { request.speculative_stats.wide_rounds += 1; }
            if (pcur == 0) {
                request.speculative_stats.fallback_steps += 1;
            } else {
                request.speculative_stats.rounds += 1;
                request.speculative_stats.drafted_tokens += pcur;
                request.speculative_stats.accepted_tokens += static_cast<std::uint32_t>(accepted_i);
                for (std::int32_t i = 0; i < accepted_i; ++i) {
                    request.speculative_stats.accepted_per_position[static_cast<std::size_t>(i)] +=
                        1;
                }
                const DraftSourceCounts sources = draft_source_counts(
                    pcur, proposal_drafts[row], static_cast<std::uint32_t>(accepted_i));
                request.speculative_stats.ngram_drafted_tokens += sources.ngram_drafted;
                request.speculative_stats.ngram_accepted_tokens += sources.ngram_accepted;
            }
            request.pending = PendingCandidate{
                .kind          = PendingKind::Speculative,
                .base_E        = base_E,
                .base_S        = base_S,
                .prompt_tokens = 0,
                .produced      = static_cast<std::uint32_t>(count_i),
            };
            request.lifecycle = Lifecycle::Pending;
            request.timings.decode_seconds += seconds;
        }
        return runtime::BatchedGeneratedRound{
            .tokens     = std::span<const TokenId>(mtp_host_egress->licensed_tokens.data(),
                                                   lanes.size() * width),
            .row_counts = std::span<const std::int32_t>(mtp_host_egress->licensed_counts.data(),
                                                        lanes.size()),
            .row_stride = width,
            .timing     = timing.finish(),
        };
    } catch (...) {
#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled) { native_kvmem_poisoned = true; }
#endif
        timing.begin_wait();
        try {
            nvtx::ScopedRange wait_range(nvtx::Name::DecodeMtpWait, nvtx::Category::Control,
                                         static_cast<std::uint64_t>(lanes.size()));
            device.synchronize();
        } catch (...) {}
        timing.end_wait();
#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled && native_mtp_accepted_keys &&
            native_mtp_accepted_keys->verify_in_flight()) {
            try { native_mtp_accepted_keys->discard_verify(); } catch (...) {}
        }
#endif
        clear_execution_failure_lanes(lanes);
        throw;
    }
}

runtime::BatchedGeneratedRound
ProgramImpl::decode_dflash_batch(std::span<const std::uint32_t> lanes,
                                 std::span<const runtime::RoundBudget> budgets,
                                 runtime::ExecutionTiming* failed_timing) {
    nvtx::ScopedRange round_range(nvtx::Name::DecodeDFlashRound, nvtx::Category::DFlash,
                                  static_cast<std::uint64_t>(lanes.size()));
    runtime::ExecutionTimingRecorder timing(runtime::ExecutionTimingPhase::Submit, failed_timing);
    if (!is_masked_draft_backend(speculative_backend) || !io.dflash_decode || !dflash) {
        throw std::logic_error("DFlash batch execution requires the DFlash backend");
    }
    if (lanes.empty() || lanes.size() > max_concurrency || budgets.size() != lanes.size()) {
        throw std::invalid_argument("DFlash batch membership is invalid");
    }

    const std::uint32_t width           = draft_window + 1U;
    std::uint32_t maximum_frontier      = 0;
    std::uint32_t maximum_target_tokens = 1;
    for (std::size_t row = 0; row < lanes.size(); ++row) {
        const std::uint32_t lane = lanes[row];
        if (lane >= max_concurrency ||
            std::find(lanes.begin(), lanes.begin() + static_cast<std::ptrdiff_t>(row), lane) !=
                lanes.begin() + static_cast<std::ptrdiff_t>(row)) {
            throw std::invalid_argument("DFlash batch contains an invalid or duplicate lane");
        }
        const SequenceState& sequence = active_sequence(lane);
        const RequestControl& request = requests[lane];
        if (request.lifecycle != Lifecycle::Active ||
            budgets[row].generated_tokens_remaining == 0 || !sequence.kv ||
            text_kv_addresses->bound_row(sequence.kv->text) < 0 ||
            (backend_kv_cache() && (!sequence.kv->backend ||
                                    backend_kv_addresses->bound_row(*sequence.kv->backend) < 0)) ||
            sequence.execution_frontier >= capacity ||
            sequence.text_kv_valid != sequence.execution_frontier ||
            sequence.dflash_context_frontier > sequence.execution_frontier ||
            sequence.execution_frontier - sequence.dflash_context_frontier > width ||
            sequence.ledger_frontier != sequence.execution_frontier + 1 ||
            sequence.ledger.size() != sequence.ledger_frontier ||
            sequence.prefix_identity.size() != sequence.ledger_frontier ||
            sequence.prefix_digests.size() != sequence.ledger_frontier) {
            throw std::logic_error("DFlash batch row is not decode-ready");
        }
        const std::uint32_t max_by_budget = budgets[row].generated_tokens_remaining > 1
                                                ? budgets[row].generated_tokens_remaining - 1U
                                                : 0U;
        const std::uint32_t extent =
            std::min({draft_window, max_by_budget, capacity - sequence.execution_frontier - 1U});
        maximum_frontier = std::max(maximum_frontier, sequence.execution_frontier);
        maximum_target_tokens =
            std::max(maximum_target_tokens, sequence.execution_frontier + extent + 1U);
    }

    const auto started = Clock::now();
    try {
        std::optional<nvtx::ScopedRange> submit_range;
        submit_range.emplace(nvtx::Name::DecodeDFlashSubmit, nvtx::Category::DFlash,
                             static_cast<std::uint64_t>(lanes.size()));
        DecodeGraphExecutable* executable    = nullptr;
        execution::DFlashEnvelopes envelopes = dflash_envelopes(0, maximum_frontier, draft_window);
        ops::CausalAttentionExecutionEnvelope target_envelope{1, maximum_target_tokens};
        if (use_cuda_graph) {
            DecodeGraphProfile& profile =
                select_graph_profile(dflash_graphs, static_cast<std::uint32_t>(lanes.size()),
                                     maximum_frontier, "DFlash batch");
            executable      = &install_graph_profile(dflash_graphs, profile, "DFlash batch");
            envelopes       = dflash_envelopes(profile.min_execution_frontier,
                                               profile.max_execution_frontier, draft_window);
            target_envelope = {
                1, static_cast<std::uint32_t>(std::min<std::uint64_t>(
                       capacity, static_cast<std::uint64_t>(profile.max_execution_frontier) +
                                     draft_window + 1ULL))};
        }

        for (std::size_t row = 0; row < lanes.size(); ++row) {
            SequenceState& sequence           = active_sequence(lanes[row]);
            const RequestControl& request     = requests[lanes[row]];
            const std::uint32_t frontier      = sequence.execution_frontier;
            const std::uint32_t max_by_budget = budgets[row].generated_tokens_remaining > 1
                                                    ? budgets[row].generated_tokens_remaining - 1U
                                                    : 0U;
            const std::uint32_t extent =
                std::min({draft_window, max_by_budget, capacity - frontier - 1U});
            dflash_host_ingress->anchors[row] = sequence.ledger.back();
            dflash_host_ingress->execution_frontiers[row] =
                checked_i32(frontier, "DFlash batch frontier");
            dflash_host_ingress->context_frontiers[row] =
                checked_i32(sequence.dflash_context_frontier, "DFlash context frontier");
            dflash_host_ingress->proposal_valid_columns[row] = static_cast<std::int32_t>(width);
            dflash_host_ingress->proposal_extents[row]       = static_cast<std::int32_t>(extent);
            dflash_host_ingress->target_valid_columns[row] = static_cast<std::int32_t>(extent + 1U);
            for (std::uint32_t column = 0; column < width; ++column) {
                const std::uint32_t position = frontier + std::min(column, extent);
                dflash_host_ingress->target_rope_positions[row * width + column] =
                    checked_i32(position, "DFlash target RoPE position") + sequence.rope_delta;
            }
            dflash_host_ingress->text_kv_table_rows[row] =
                text_kv_addresses->bound_row(sequence.kv->text);
            dflash_host_ingress->dflash_kv_table_rows[row] =
                sequence.kv->backend ? backend_kv_addresses->bound_row(*sequence.kv->backend) : 0;
            dflash_host_ingress->active_lanes[row]       = static_cast<std::int32_t>(sequence.lane);
            const StateImageSelectors selectors          = state_selectors(sequence);
            dflash_host_ingress->state_source_slots[row] = selectors.source;
            dflash_host_ingress->state_destination_slots[row] = selectors.destination;
            dflash_host_ingress->sampling[row]                = request.sampling_host;
            ensure_sequence_kv_mapped(sequence, frontier + extent + 1U,
                                      backend_kv_cache() ? frontier : 0U);
        }

        execution::DFlashBatchContext schedule_state{
            {device, parameters, work, state_images->linear(),
             replay_records ? &*replay_records : nullptr, io, prefill_hidden, prefill_chunk,
             proposal_head},
            decoder->text_kv,
            *dflash,
            *io.dflash_decode,
            *dflash_host_ingress,
            *dflash_host_egress,
            state_images->continuation_hidden_store()};

        mark_workspace_usage(workspace_plan.dflash_round);
        execution::dflash_decode_batch(schedule_state, static_cast<std::int32_t>(lanes.size()),
                                       draft_window, envelopes, target_envelope, executable);
        submit_range.reset();
        timing.begin_wait();
        {
            nvtx::ScopedRange wait_range(nvtx::Name::DecodeDFlashWait, nvtx::Category::Control,
                                         static_cast<std::uint64_t>(lanes.size()));
            device.synchronize();
        }
        timing.end_wait();

        const double seconds = std::chrono::duration<double>(Clock::now() - started).count();
        for (std::size_t row = 0; row < lanes.size(); ++row) {
            SequenceState& sequence       = active_sequence(lanes[row]);
            RequestControl& request       = requests[lanes[row]];
            const std::uint32_t base_E    = sequence.execution_frontier;
            const std::uint32_t base_S    = sequence.ledger_frontier;
            const std::int32_t count_i    = dflash_host_egress->licensed_counts[row];
            const std::int32_t accepted_i = dflash_host_egress->accepted_drafts[row];
            const std::uint32_t extent =
                static_cast<std::uint32_t>(dflash_host_ingress->proposal_extents[row]);
            if (count_i <= 0 || count_i > static_cast<std::int32_t>(width) || accepted_i < 0 ||
                accepted_i + 1 != count_i || accepted_i > static_cast<std::int32_t>(extent) ||
                static_cast<std::uint32_t>(count_i) > budgets[row].generated_tokens_remaining ||
                static_cast<std::uint64_t>(base_E) + static_cast<std::uint32_t>(count_i) >
                    capacity) {
                throw std::runtime_error("DFlash batch returned invalid row metadata");
            }
            const std::span<const TokenId> row_tokens(dflash_host_egress->licensed_tokens.data() +
                                                          row * width,
                                                      static_cast<std::size_t>(count_i));
            validate_licensed_tokens(row_tokens);
            if (extent == 0) {
                request.speculative_stats.fallback_steps += 1;
            } else {
                request.speculative_stats.rounds += 1;
                request.speculative_stats.drafted_tokens += extent;
                request.speculative_stats.accepted_tokens += static_cast<std::uint32_t>(accepted_i);
                for (std::int32_t i = 0; i < accepted_i; ++i) {
                    request.speculative_stats.accepted_per_position[static_cast<std::size_t>(i)] +=
                        1;
                }
            }
            sequence.dflash_context_frontier = base_E;
            request.pending                  = PendingCandidate{
                                 .kind          = PendingKind::Speculative,
                                 .base_E        = base_E,
                                 .base_S        = base_S,
                                 .prompt_tokens = 0,
                                 .produced      = static_cast<std::uint32_t>(count_i),
            };
            request.lifecycle = Lifecycle::Pending;
            request.timings.decode_seconds += seconds;
        }
        return runtime::BatchedGeneratedRound{
            .tokens     = std::span<const TokenId>(dflash_host_egress->licensed_tokens.data(),
                                                   lanes.size() * width),
            .row_counts = std::span<const std::int32_t>(dflash_host_egress->licensed_counts.data(),
                                                        lanes.size()),
            .row_stride = width,
            .timing     = timing.finish(),
        };
    } catch (...) {
        timing.begin_wait();
        try {
            nvtx::ScopedRange wait_range(nvtx::Name::DecodeDFlashWait, nvtx::Category::Control,
                                         static_cast<std::uint64_t>(lanes.size()));
            device.synchronize();
        } catch (...) {}
        timing.end_wait();
        clear_execution_failure_lanes(lanes);
        throw;
    }
}

runtime::BatchedGeneratedRound
ProgramImpl::decode_raw(std::span<const std::uint32_t> lanes,
                        std::span<const runtime::RoundBudget> budgets,
                        runtime::ExecutionTiming* failed_timing) {
    if (kvmem.enabled && speculative_backend != SpeculativeBackend::None &&
        speculative_backend != SpeculativeBackend::Mtp) {
        // DFlash has no native follower/accepted-prefix transaction. MTP has
        // a separate single-lane, block-bounded candidate in decode_mtp_batch.
        throw std::logic_error("native KVMem draft backend has no accepted-token transaction");
    }
    if (speculative_backend == SpeculativeBackend::None) {
        return decode_ordinary_batch(lanes, budgets, failed_timing);
    }
    if (speculative_backend == SpeculativeBackend::Mtp) {
        return decode_mtp_batch(lanes, budgets, failed_timing);
    }
    return decode_dflash_batch(lanes, budgets, failed_timing);
}

runtime::ExecutionTiming ProgramImpl::resolve_non_speculative_pending(
    SequenceState& sequence, RequestControl& request, std::uint32_t accepted_tokens, bool terminal,
    std::optional<std::uint32_t> prefix_execution_split_after,
    runtime::ExecutionTiming* failed_timing) {
    runtime::ExecutionTimingRecorder timing(runtime::ExecutionTimingPhase::Post, failed_timing);
    if (request.lifecycle != Lifecycle::Pending) {
        throw std::logic_error("pending resolution requires a pending generated round");
    }
    if ((request.pending.kind != PendingKind::Begin &&
         request.pending.kind != PendingKind::Ordinary) ||
        request.pending.produced != 1 || accepted_tokens != 1) {
        throw std::logic_error("non-speculative pending round must commit its single token");
    }

    const std::uint32_t base_ledger_frontier = request.pending.kind == PendingKind::Begin
                                                   ? request.pending.prompt_tokens
                                                   : request.pending.base_S;
    commit_generated_prefix_identity(
        sequence, base_ledger_frontier,
        std::span<const TokenId>(sequence.ledger).subspan(base_ledger_frontier, accepted_tokens),
        prefix_execution_split_after);

    switch (request.pending.kind) {
    case PendingKind::Begin:
        sequence.execution_frontier = request.pending.prompt_tokens;
        sequence.ledger_frontier    = request.pending.prompt_tokens + 1;
        break;
    case PendingKind::Ordinary:
        advance_rebuild_work(sequence, request.pending.base_E + request.pending.produced,
                             prefill_chunk);
        if (sequence.compact_kv_frontier) {
            *sequence.compact_kv_frontier += request.pending.produced;
        }
        sequence.execution_frontier = request.pending.base_E + request.pending.produced;
        sequence.ledger_frontier    = request.pending.base_S + request.pending.produced;
        break;
    case PendingKind::Speculative:
    case PendingKind::None:
        throw std::logic_error("non-speculative pending round has an invalid kind");
    }
    if (sequence.ledger_frontier != sequence.execution_frontier + 1 ||
        sequence.ledger.size() != sequence.ledger_frontier ||
        sequence.prefix_identity.size() != sequence.ledger_frontier ||
        sequence.prefix_digests.size() != sequence.ledger_frontier) {
        throw std::logic_error("resolved round did not establish a valid frontier");
    }
    // Begin publishes a sampled token but does not execute it through the target. An exact-hit
    // Fork therefore still names an immutable read source and an unwritten destination here; the
    // first state-mutating decode commit closes it. A suffix prefill already closed its Fork at
    // the committed prefill frontier.
    if (request.pending.kind == PendingKind::Begin && terminal && sequence.state.fork_pending) {
        const StateImageSelectors selectors = state_selectors(sequence);
        timing.resume_submit();
        state_images->copy_slot(selectors.source, selectors.destination, device.stream);
        timing.begin_wait();
        device.synchronize();
        timing.end_wait();
        settle_state_fork(sequence);
    } else if (request.pending.kind == PendingKind::Ordinary) {
        settle_state_fork(sequence);
    }
    trim_sequence_kv(sequence, sequence.text_kv_valid, backend_kv_valid(sequence));
#if defined(NINFER_WITH_KVMEM)
    if (terminal && kvmem.enabled) {
        // The sampled terminal token was never a model input. Publish only
        // the already-executed tail before this continuation can be reused.
        if (!native_decode_features) {
            throw std::logic_error("native decode K accumulation is unavailable");
        }
        native_decode_features->flush_decode_tail();
        // Prefill and ordinary decode already publish completed blocks. The
        // partial-tail marker is zero after that publication, not proof that
        // the final full block is still unbound. Only a partial executed tail
        // needs a final adoption here; adopting a full block twice poisons its
        // physical owner (including a terminal Begin on aligned prefill).
        if (sequence.execution_frontier % kvmem.block_tokens != 0) {
            adopt_native_decode_tail(sequence);
        }
    }
#endif
    if (terminal) { sequence.mtp_draft_count = 0; }
    request.lifecycle = terminal ? Lifecycle::Finishable : Lifecycle::Active;
    request.pending   = {};
    return timing.finish();
}


} // namespace ninfer::models::qwen3_5::detail
