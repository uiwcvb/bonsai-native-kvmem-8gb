// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#pragma once

#include "models/qwen3_5/frontend/prepared_prompt.h"
#include "runtime/contract/request.h"

#include <cstddef>
#include <cstdint>
#include <span>

namespace ninfer::models::qwen3_5::detail {

struct CaptureGroup;

// Admission reserves a service-work upper bound, including one possible native
// query replay. Execution still charges only the units that actually run.
std::uint64_t projected_request_service_work(
    const runtime::RequestPlanSummary& summary, const PreparedPromptData& prompt,
    std::uint32_t reuse_base, std::uint32_t prefill_chunk, std::size_t prefill_splits,
    std::span<const CaptureGroup> captures, const KVMemOptions& kvmem);

} // namespace ninfer::models::qwen3_5::detail
