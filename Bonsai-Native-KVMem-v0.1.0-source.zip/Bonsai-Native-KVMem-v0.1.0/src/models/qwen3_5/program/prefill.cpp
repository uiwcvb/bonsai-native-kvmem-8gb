// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#include "models/qwen3_5/program/program_impl.h"
#include "models/qwen3_5/program/context_work.h"
#include "models/qwen3_5/program/context.h"
#if defined(NINFER_WITH_KVMEM)
#include "models/qwen3_5/program/storage/kvmem_follower_replay_prefix.h"
#include "models/qwen3_5/program/storage/kvmem_page_backend.h"
#include "models/qwen3_5/program/storage/kvmem_prefill_commit.h"
#endif
#include "models/qwen3_5/execution/linear.h"
#include "core/device.h"
#include "ninfer/ops/gdn_replay.h"
#include "ninfer/ops/sampling.h"
#include "ninfer/ops/scalar.h"
#include "ninfer/ops/scatter.h"
#include "ninfer/ops/speculative_round.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <span>
#include <stdexcept>
#include <utility>
#include <vector>

namespace ninfer::models::qwen3_5::execution {
namespace {

DFlashFeatureSink make_dflash_prefill_sink(PrefillContext& state) {
    if (!state.execution.io.dflash_decode || state.dflash_host_ingress == nullptr) {
        throw std::logic_error("DFlash prefill controls are unavailable");
    }
    return dflash_feature_sink(
        state, [&state](const Tensor& features, const Tensor& positions, bool rewrite_checkpoint) {
            auto& frame  = *state.execution.io.dflash_decode;
            Tensor count = frame.append_counts.slice(0, 0, 1);
            Tensor lane  = frame.state_destination_slots.slice(0, 0, 1);
            Tensor row   = frame.dflash_kv_table_rows.slice(0, 0, 1);
            ops::set_i32_scalar(count, features.ne[1], state.execution.device.stream);
            const auto exact = static_cast<std::uint32_t>(features.ne[1]);
            dflash_append_context(state, features, positions, count, lane, row, {exact, exact});
            (void)rewrite_checkpoint;
        });
}

} // namespace

void configure_text_card(TextContext& card, const ExecutionCore& execution,
                         const ops::SamplingConfig* sampling, std::int32_t state_source_slot,
                         std::int32_t state_destination_slot, std::uint32_t mtp_proposal_extent) {
    card.set_sampling(sampling);
    card.set_attention_feature_capture(execution.attention_features);
    card.set_linear_state_slots(state_source_slot, state_destination_slot);
    card.set_gdn_state_action(GdnStateAction::UpdateInPlace, nullptr);
    card.set_mtp_proposal_extent(mtp_proposal_extent);
    if (execution.proposal_head == ProposalHead::Full) {
        card.set_proposal_head(nullptr, nullptr, 0);
        return;
    }
    if (card.proposal_head() == nullptr || card.proposal_head_n() <= 0) {
        throw std::runtime_error("optimized proposal head is unavailable");
    }
}

PrefillChunkResult prefill_text_chunk(PrefillContext& state, std::span<const TokenId> ids,
                                      std::uint32_t nominal_length,
                                      std::optional<std::uint32_t> split_frontier,
                                      bool finalize_at_end) {
    TextContext card(state.execution.device, state.execution.parameters, state.execution.work,
                     state.text_kv, state.execution.linear_attention, state.execution.io,
                     state.execution.prefill_hidden, state.execution.prefill_chunk,
                     state.cache_kv_base.value_or(state.text_kv_base), state.mtp_kv,
                     &state.text_cache, state.mtp_cache);
    configure_text_card(card, state.execution, state.sampling, state.state_source_slot,
                        state.state_destination_slot, state.mtp_proposal_extent);
    card.set_rewrite_checkpoint_hidden_output(state.rewrite_checkpoint_hidden);
    card.set_prefill_split_frontier(split_frontier ? static_cast<std::int64_t>(*split_frontier)
                                                   : -1);
    const std::span<const int> prompt(ids.data(), ids.size());
    if (state.dflash != nullptr) {
        DFlashFeatureSink sink = make_dflash_prefill_sink(state);
        return card.prefill_chunk(prompt, state.text_kv_base, nominal_length, finalize_at_end,
                                  sink);
    }
    return card.prefill_chunk(prompt, state.text_kv_base, nominal_length, finalize_at_end);
}

PrefillChunkResult prefill_multimodal_chunk(PrefillContext& state, const PreparedPromptData& prompt,
                                            VisionPrefillSession& vision,
                                            std::uint32_t nominal_length,
                                            std::optional<std::uint32_t> split_frontier,
                                            bool finalize_at_end) {
    TextContext card(state.execution.device, state.execution.parameters, state.execution.work,
                     state.text_kv, state.execution.linear_attention, state.execution.io,
                     state.execution.prefill_hidden, state.execution.prefill_chunk,
                     state.cache_kv_base.value_or(state.text_kv_base), state.mtp_kv,
                     &state.text_cache, state.mtp_cache);
    configure_text_card(card, state.execution, state.sampling, state.state_source_slot,
                        state.state_destination_slot, state.mtp_proposal_extent);
    card.set_rewrite_checkpoint_hidden_output(state.rewrite_checkpoint_hidden);
    card.set_prefill_split_frontier(split_frontier ? static_cast<std::int64_t>(*split_frontier)
                                                   : -1);
    if (state.dflash != nullptr) {
        DFlashFeatureSink sink = make_dflash_prefill_sink(state);
        return card.prefill_chunk(prompt, state.text_kv_base, nominal_length, vision,
                                  finalize_at_end, sink);
    }
    return card.prefill_chunk(prompt, state.text_kv_base, nominal_length, vision, finalize_at_end);
}

void mtp_bridge_multimodal(PrefillContext& state, const PreparedPromptData& prompt,
                           VisionPrefillSession& vision, const MtpBridgeInput& bridge) {
    if (!state.mtp_kv.valid() || bridge.previous_hidden == nullptr || state.text_kv_base == 0 ||
        bridge.position < 0 ||
        static_cast<std::uint32_t>(bridge.position) + 1 !=
            state.cache_kv_base.value_or(state.text_kv_base)) {
        throw std::logic_error("multimodal MTP bridge does not match the reusable frontier");
    }

    Tensor bridge_token = state.execution.io.mtp->target_input_ids.slice(0, 0, 1);
    const TokenId token = prompt.token_ids[state.text_kv_base];
    CUDA_CHECK(cudaMemcpyAsync(bridge_token.data, &token, sizeof(token), cudaMemcpyHostToDevice,
                               state.execution.device.stream));

    Tensor visual_embedding;
    const Tensor* composed_embedding = nullptr;
    if (prompt.token_types[state.text_kv_base] != 0) {
        const VisionChunk chunk = vision.prepare_chunk(state.text_kv_base, 1);
        if (chunk.control == nullptr) {
            throw std::logic_error("visual MTP bridge has no encoded Vision item");
        }
        const auto& scatter = chunk.control->scatter_indices;
        const auto column   = std::lower_bound(scatter.begin(), scatter.end(),
                                               static_cast<std::int32_t>(state.text_kv_base));
        if (column == scatter.end() || *column != static_cast<std::int32_t>(state.text_kv_base) ||
            static_cast<std::uint8_t>(chunk.control->modality) !=
                prompt.token_types[state.text_kv_base]) {
            throw std::logic_error("visual MTP bridge does not match Vision scatter metadata");
        }
        visual_embedding =
            chunk.embeddings.slice(1, static_cast<std::int32_t>(column - scatter.begin()), 1);
        composed_embedding = &visual_embedding;
    }

    mtp_bridge_and_propose(state, bridge_token, *bridge.previous_hidden, bridge.position,
                           bridge.rope_position, false, composed_embedding);
}

void sample_from_hidden(PrefillContext& state, const Tensor& hidden, std::int32_t absolute_position,
                        std::int32_t purpose) {
    if (hidden.dtype != DType::BF16 ||
        hidden.ne[0] != dimension(state.execution.parameters.model.config().text.hidden_size) ||
        hidden.ne[1] != 1 || hidden.ne[2] != 1 || hidden.ne[3] != 1 || hidden.data == nullptr) {
        throw std::invalid_argument("sample_from_hidden requires BF16 [hidden,1]");
    }
    state.execution.work.reset();
    Tensor logits = state.execution.io.logits.slice(1, 0, 1);
    project(hidden, state.execution.parameters.text.output_head, logits,
                 state.execution.work, state.execution.device.stream);
    CUDA_CHECK(cudaMemcpyAsync(state.execution.io.pos.data, &absolute_position,
                               sizeof(absolute_position), cudaMemcpyHostToDevice,
                               state.execution.device.stream));
    ops::sample(logits, state.execution.io.token,
                dimension(state.execution.parameters.model.resources().public_token_count),
                state.sampling, state.execution.io.pos, purpose, state.execution.work,
                state.execution.device.stream);
    state.execution.work.reset();
}

} // namespace ninfer::models::qwen3_5::execution

namespace ninfer::models::qwen3_5::detail {

namespace {

std::array<std::int32_t, 3> prompt_rope_position(const PreparedPromptData& prompt,
                                                 std::uint32_t token);

#if defined(NINFER_WITH_KVMEM)
KVMemTurnSpans plan_native_turn_spans(const PreparedPromptData& prompt, std::uint32_t base,
                                     std::uint32_t eval_end, std::uint32_t query_max_tokens,
                                     const KVMemConversation::SessionMetadata& metadata) {
    const std::uint32_t replay_begin =
        native_query_replay_begin(prompt, base, eval_end, query_max_tokens);
    KVMemTurnSpans out;
    out.query_begin = eval_end;
    out.eval_end = eval_end;
    out.capture_begin = eval_end;
    out.capture_end = eval_end;
    out.mandatory_begin = eval_end;
    out.mandatory_end = eval_end;
    out.replay_begin = eval_end;

    const auto& source_query = prompt.retrieval_query_span;
    // Native clamp_query_span applies the cap even to exact user ranges.
    // Preserve the full user's origin for identity, but use the capped suffix
    // for Q capture, mandatory protection and recurrent replay. Canonical
    // input/history is not truncated.
    const auto query = source_query
                           ? std::optional<RetrievalQuerySpan>(
                                 clamp_native_query_span(*source_query, query_max_tokens))
                           : std::nullopt;
    out.query_begin = replay_begin;
    out.mandatory_begin = replay_begin;
    out.replay_begin = replay_begin;
    out.retrieve = replay_begin < eval_end;
    // The pinned multimodal server makes observations after a cached user
    // query mandatory during its same-query path. Keep the same evidence
    // range, using persisted exact-user Q when its identity still matches.
    // Only do this when the exact last-user boundary is still in the cached
    // prefix. The native preview determines whether the full observed tail
    // fits; otherwise a fresh suffix probe replaces the cached Q.
    if (metadata.matches_exact_query(prompt, base, query_max_tokens) && replay_begin < eval_end) {
        out.mandatory_begin = query->end;
    }
    // user_begin certifies exact last-user provenance; query->begin is the
    // native Q start after any media payload in that user message.
    out.capture_exact_user = query && query->user_begin && query->begin >= base &&
                             query->end > query->begin;
    if (out.capture_exact_user) {
        out.capture_begin = query->begin;
        out.capture_end = query->end;
    } else {
        out.capture_begin =
            std::max(replay_begin, eval_end - std::min(query_max_tokens, eval_end));
        out.capture_end = eval_end;
    }
    return out;
}

bool can_reuse_exact_query(const PreparedPromptData& prompt,
                           const KVMemConversation::SessionMetadata& metadata,
                           const KVMemTurnSpans& turn, std::uint32_t base,
                           std::uint32_t query_max_tokens) {
    return turn.mandatory_begin <= turn.replay_begin &&
           metadata.matches_exact_query(prompt, base, query_max_tokens);
}

void record_native_query(KVMemConversation::SessionMetadata& metadata,
                         const PreparedPromptData& prompt,
                         const KVMemTurnSpans& turn,
                         std::span<const KVMemRetrievalQueryLayer> layers) {
    metadata.q_sum.clear();
    metadata.q_count.clear();
    metadata.exact_query_valid = false;
    metadata.exact_query_user_begin = 0;
    metadata.exact_query_begin = 0;
    metadata.exact_query_end = 0;
    metadata.exact_query_media.clear();
    metadata.q_sum.reserve(layers.size());
    metadata.q_count.reserve(layers.size());
    std::uint32_t captured = 0;
    for (const KVMemRetrievalQueryLayer& layer : layers) {
        metadata.q_sum.emplace_back(layer.pre_rope_sum.begin(), layer.pre_rope_sum.end());
        metadata.q_count.push_back(layer.count);
        captured = std::max(captured, layer.count);
    }
    if (turn.capture_exact_user && prompt.retrieval_query_span &&
        prompt.retrieval_query_span->user_begin &&
        captured == turn.capture_end - turn.capture_begin) {
        metadata.exact_query_media = prompt.vision_items;
        metadata.exact_query_user_begin = *prompt.retrieval_query_span->user_begin;
        metadata.exact_query_valid = true;
        metadata.exact_query_begin = turn.capture_begin;
        metadata.exact_query_end = turn.capture_end;
    }
}
#endif

std::array<std::int32_t, 3> prompt_rope_position(const PreparedPromptData& prompt,
                                                 std::uint32_t token) {
    const std::size_t tokens = prompt.token_ids.size();
    if (token >= tokens || prompt.positions.size() != 3 * tokens) {
        throw std::invalid_argument("MTP bridge position is outside prepared prompt metadata");
    }
    return {prompt.positions[token], prompt.positions[tokens + token],
            prompt.positions[2 * tokens + token]};
}

} // namespace

void ProgramImpl::start_sequence(std::uint32_t lane, SequenceState& sequence,
                                 MaterializationTransaction& transaction) {
    if (lane >= max_concurrency) { throw std::out_of_range("request lane is out of range"); }
    RequestControl& request = requests[lane];
    if (!transaction.plan || transaction.plan->impl_ == nullptr || !transaction.prepared ||
        !request.prefill) {
        throw std::invalid_argument("materialization staging is incomplete");
    }
    AdmissionCandidateImpl& request_plan = *transaction.plan->impl_;
    if (request.lifecycle == Lifecycle::Prefilling || request.lifecycle == Lifecycle::Active ||
        request.lifecycle == Lifecycle::Pending) {
        throw std::logic_error("staged prefill requires a free request lane");
    }
    auto& staged                           = *request.prefill;
    const auto started                     = Clock::now();
    const std::uint32_t prompt_tokens      = staged.prompt_tokens;
    const std::uint32_t base               = staged.base;
    // An exact native cached turn retains its full logical history in Store,
    // but the resident execution view has a separate compact KV coordinate.
    const std::uint32_t kv_base =
        request_plan.native_physical_reuse_base.value_or(base);
    const std::uint32_t initial_mtp_extent = staged.initial_mtp_extent;
    request.lifecycle                      = Lifecycle::Empty;
    try {
#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled) {
            const auto* first = continuation_states.data();
            const auto* last = first + continuation_capacity;
            if (&sequence < first || &sequence >= last || native_kvmem_poisoned ||
                (native_kvmem_owner &&
                 *native_kvmem_owner != static_cast<std::uint32_t>(&sequence - first))) {
                throw std::logic_error(
                    "native KVMem conversation is not attached to this continuation");
            }
            if (!native_kvmem_conversation || !native_kvmem_backend ||
                native_kvmem_conversation->runtime().store().total_tokens() != base) {
                throw std::logic_error(
                    "native KVMem conversation does not match the materialized prefix");
            }
            staged.native_turn_spans = plan_native_turn_spans(
                staged.prompt, base, prompt_tokens, kvmem.query_max_tokens,
                native_kvmem_conversation->metadata());
            if (request_plan.native_physical_reuse_base && !sequence.compact_kv_frontier) {
                // Canonicalize the unchanged dense endpoint before the first
                // native append; short conversations have not selected yet.
                sequence.compact_kv_frontier = sequence.text_kv_valid;
            }
            // The pinned multimodal server supplies every media run to the
            // native Store with one boundary token on each side. This lets
            // constrain_media keep an image/video run as a unit during both
            // prefill pressure and query-conditioned selection.
            std::vector<std::pair<std::uint32_t, std::uint32_t>> media_ranges;
            for (const VisionItem& item : staged.prompt.vision_items) {
                for (const TokenSpan span : item.token_spans) {
                    if (span.count == 0 || span.begin > prompt_tokens ||
                        span.count > prompt_tokens - span.begin) {
                        throw std::invalid_argument("native media range exceeds the prompt");
                    }
                    const auto begin = static_cast<std::uint32_t>(span.begin);
                    const auto end = static_cast<std::uint32_t>(span.begin + span.count);
                    media_ranges.emplace_back(begin == 0 ? 0 : begin - 1U,
                                              std::min(prompt_tokens, end + 1U));
                }
            }
            std::sort(media_ranges.begin(), media_ranges.end());
            native_kvmem_conversation->runtime().store().set_media_ranges(
                std::move(media_ranges));
            const KVMemTurnSpans& turn = *staged.native_turn_spans;
            if (!native_prefill_features) {
                throw std::logic_error("native prefill capture storage is unavailable");
            }
            // Single-concurrency admission starts only after the prior owner
            // has drained. Stable views now come from the startup resource plan.
            native_prefill_features->bind_raw(native_kvmem_conversation->raw(), base, true);
            staged.native_features = native_prefill_features.get();
            staged.native_features->begin_query(
                checked_i32(turn.capture_begin, "native query capture begin"),
                checked_i32(turn.capture_end - turn.capture_begin,
                            "native query capture length"));
            staged.native_materialized_tail_tokens = base % kvmem.block_tokens;
        }
#endif
        const std::uint32_t state_slots = request_plan.demand.active_entitlement.device.state_slots;
        const bool preserving_source =
            (transaction.has_source || transaction.has_shared_source) &&
            transaction.source_mode == runtime::PrivateSourceMode::Retain;
        const bool text_prefix_fork    = request_plan.text_prefix_fork_required;
        const bool backend_prefix_fork = request_plan.backend_prefix_fork_required;
        if (request_plan.reuse == ReusePath::Root) {
            if (transaction.reserved_state_count != state_slots || state_slots == 0 ||
                !transaction.root_text_address || !transaction.text_activation ||
                transaction.root_backend_address.has_value() !=
                    (request_plan.backend_kv_page_entitlement != 0) ||
                transaction.backend_activation.has_value() !=
                    (request_plan.backend_kv_page_entitlement != 0)) {
                throw std::logic_error("root materialization reservations are incomplete");
            }
            release_sequence_kv(sequence);
            release_sequence_state(sequence);
            sequence.state = ActiveStateBinding{.read  = transaction.reserved_states[0],
                                                .write = transaction.reserved_states[0]};
            transaction.reserved_states[0] = {};
            if (state_slots == 2) {
                sequence.reserved_state        = transaction.reserved_states[1];
                transaction.reserved_states[1] = {};
            }
            transaction.reserved_state_count = 0;

            SequenceKVBundle bundle{.text = *transaction.root_text_address};
            transaction.root_text_address.reset();
            if (transaction.root_backend_address) {
                bundle.backend = *transaction.root_backend_address;
                transaction.root_backend_address.reset();
            }
            sequence.kv.emplace(bundle);
        } else if (preserving_source) {
            const bool private_source_ready = transaction.has_source &&
                                              transaction.source_index < continuation_capacity &&
                                              continuation_slots[transaction.source_index].role ==
                                                  ContinuationSlotRole::Catalogued;
            const bool shared_source_ready =
                transaction.has_shared_source &&
                transaction.shared_source_index < shared_prefix_capacity &&
                shared_prefix_slots[transaction.shared_source_index].role ==
                    SharedPrefixSlotRole::Catalogued;
            if (private_source_ready == shared_source_ready ||
                transaction.reserved_state_count != state_slots || state_slots == 0 ||
                !transaction.root_text_address || !transaction.text_prefix_fork ||
                !transaction.prefix_forks_ready ||
                transaction.root_backend_address.has_value() !=
                    (request_plan.backend_kv_page_entitlement != 0)) {
                throw std::logic_error("retained materialization is incomplete");
            }
            const StateImageHandle selected =
                private_source_ready
                    ? selected_state(continuation_states[transaction.source_index],
                                     request_plan.reuse, request_plan.selected_checkpoint)
                    : shared_prefix_states[transaction.shared_source_index].state;
            const StateImageHandle current = transaction.reserved_states[0];
            if (state_store->residency(selected) == StateReplicaResidency::HostOnly) {
                if (state_store->role(current) != StateImageRole::ActiveMutable) {
                    throw std::logic_error("Host retained Fork destination was not published");
                }
                sequence.state = ActiveStateBinding{.read = current, .write = current};
            } else if (transaction.split_state_identity) {
                if (!private_source_ready ||
                    state_store->residency(selected) != StateReplicaResidency::Both) {
                    throw std::logic_error("StateImage identity split source changed");
                }
                state_store->split_device_replica_identity(selected, current);
                sequence.state = ActiveStateBinding{.read = current, .write = current};
            } else {
                const StateImageSelectors selectors = state_store->begin_fork(selected, current);
                if (is_masked_draft_backend(speculative_backend)) {
                    state_images->copy_dflash_local(selectors.source, selectors.destination,
                                                    device.stream);
                }
                sequence.state = ActiveStateBinding{
                    .read           = selected,
                    .write          = current,
                    .fork_pending   = true,
                    .read_ownership = StateReadOwnership::ExternalOwner,
                };
            }
            transaction.reserved_states[0]   = {};
            transaction.split_state_identity = false;
            if (state_slots == 2) {
                sequence.reserved_state        = transaction.reserved_states[1];
                transaction.reserved_states[1] = {};
            }
            transaction.reserved_state_count = 0;
            sequence.rewrite_state.reset();
            sequence.rewrite_checkpoint = {};

            SequenceKVBundle bundle{.text = *transaction.root_text_address};
            transaction.root_text_address.reset();
            if (transaction.root_backend_address) {
                bundle.backend = *transaction.root_backend_address;
                transaction.root_backend_address.reset();
            }
            sequence.kv.emplace(bundle);
        } else {
            if (request_plan.state_fork_required !=
                transaction.state_fork_destination.has_value()) {
                throw std::logic_error("private materialization StateImage Fork is incomplete");
            }
            if (transaction.reserved_state_count > 1 ||
                (transaction.reserved_state_count != 0 && sequence.reserved_state)) {
                throw std::logic_error("private materialization StateImage reservation is invalid");
            }
            if (transaction.reserved_state_count == 1) {
                sequence.reserved_state          = transaction.reserved_states[0];
                transaction.reserved_states[0]   = {};
                transaction.reserved_state_count = 0;
            }
        }

        if (!preserving_source) {
            std::array<HostKVPageReplicaRelease, 2> stale_tail_replicas{};
            std::size_t stale_tail_count           = 0;
            const auto preflight_inactive_truncate = [&](KVAddressSpaceStore& addresses,
                                                         LogicalKVPageStore& pages,
                                                         KVAddressSpaceHandle address,
                                                         std::optional<std::uint32_t> frontier) {
                if (!frontier ||
                    (addresses.committed_frontier(address) == *frontier &&
                     addresses.mapped_pages(address) == kv_pages_for_frontier(*frontier))) {
                    return;
                }
                bool releases_tail               = false;
                const std::uint32_t target_pages = kv_pages_for_frontier(*frontier);
                if (target_pages != 0) {
                    const LogicalKVPageHandle tail =
                        addresses.logical_page(address, target_pages - 1U);
                    const std::uint32_t columns =
                        *frontier -
                        (target_pages - 1U) * static_cast<std::uint32_t>(kPagedKVPageSize);
                    if (columns != pages.committed_columns(tail) && pages.host_resident(tail)) {
                        if (host_kv_extents == nullptr ||
                            stale_tail_count == stale_tail_replicas.size()) {
                            throw std::logic_error("stale Host KV tail replica is not releasable");
                        }
                        stale_tail_replicas[stale_tail_count++] =
                            HostKVPageReplicaRelease{.pages = &pages, .page = tail};
                        releases_tail = true;
                    }
                }
                if (!addresses.can_destructive_truncate_inactive(address, *frontier,
                                                                 releases_tail)) {
                    throw std::logic_error(
                        "selected private KV frontier is not destructively materializable");
                }
            };
            if (!sequence.kv) {
                throw std::logic_error("materialization destination has no KV address space");
            }
            if (!text_prefix_fork) {
                preflight_inactive_truncate(*text_kv_addresses, *text_kv_pages, sequence.kv->text,
                                            transaction.text_activation_frontier);
            }
            if (sequence.kv->backend && !backend_prefix_fork) {
                preflight_inactive_truncate(*backend_kv_addresses, *backend_kv_pages,
                                            *sequence.kv->backend,
                                            transaction.backend_activation_frontier);
            }
            if (stale_tail_count != 0) {
                const std::span<const HostKVPageReplicaRelease> releases(stale_tail_replicas.data(),
                                                                         stale_tail_count);
                if (!host_kv_extents->release_page_replicas(releases)) {
                    throw std::logic_error(
                        "stale Host KV tail replicas cannot be released atomically");
                }
            }
            if (!text_prefix_fork && transaction.text_activation_frontier &&
                (text_kv_addresses->committed_frontier(sequence.kv->text) !=
                     *transaction.text_activation_frontier ||
                 text_kv_addresses->mapped_pages(sequence.kv->text) !=
                     kv_pages_for_frontier(*transaction.text_activation_frontier))) {
                text_kv_addresses->destructive_truncate_inactive(
                    sequence.kv->text, *transaction.text_activation_frontier);
            }
            if (!backend_prefix_fork && transaction.backend_activation_frontier &&
                sequence.kv->backend &&
                (backend_kv_addresses->committed_frontier(*sequence.kv->backend) !=
                     *transaction.backend_activation_frontier ||
                 backend_kv_addresses->mapped_pages(*sequence.kv->backend) !=
                     kv_pages_for_frontier(*transaction.backend_activation_frontier))) {
                backend_kv_addresses->destructive_truncate_inactive(
                    *sequence.kv->backend, *transaction.backend_activation_frontier);
            }
            if (host_kv_extents) { (void)host_kv_extents->release_unreferenced(); }
        }
        if ((text_prefix_fork || backend_prefix_fork) && !transaction.prefix_forks_ready) {
            throw std::logic_error("materialization prefix forks are incomplete");
        }
        if (text_prefix_fork) {
            text_kv_addresses->commit_prefix_fork(std::move(*transaction.text_prefix_fork),
                                                  device.stream);
            transaction.text_prefix_fork.reset();
            if (!preserving_source) {
                const KVAddressSpaceHandle source_address = sequence.kv->text;
                sequence.kv->text                         = *transaction.root_text_address;
                transaction.root_text_address.reset();
                if (!text_kv_addresses->release(source_address)) {
                    throw std::logic_error("consumed Text KV source remained pinned after COW");
                }
            }
        } else {
            text_kv_addresses->commit_activation(std::move(*transaction.text_activation),
                                                 device.stream);
            transaction.text_activation.reset();
        }
        if (backend_prefix_fork) {
            backend_kv_addresses->commit_prefix_fork(std::move(*transaction.backend_prefix_fork),
                                                     device.stream);
            transaction.backend_prefix_fork.reset();
            if (!preserving_source) {
                const KVAddressSpaceHandle source_address = *sequence.kv->backend;
                sequence.kv->backend                      = *transaction.root_backend_address;
                transaction.root_backend_address.reset();
                if (!backend_kv_addresses->release(source_address)) {
                    throw std::logic_error("consumed Backend KV source remained pinned after COW");
                }
            }
        } else if (transaction.backend_activation) {
            backend_kv_addresses->commit_activation(std::move(*transaction.backend_activation),
                                                    device.stream);
            transaction.backend_activation.reset();
        }
        transaction.prefix_forks_ready = false;
        transaction.text_activation_frontier.reset();
        transaction.backend_activation_frontier.reset();
        transaction.prepared = false;

        const bool preserve_rewrite =
            request_plan.rewrite_disposition == RewriteCheckpointDisposition::RetainExisting;
        const auto activate_consumed_state = [&](StateImageHandle selected) {
            if (!request_plan.state_fork_required) {
                if (transaction.state_fork_destination ||
                    state_store->checkpoint_references(selected) != 0) {
                    throw std::logic_error("planned StateImage Move is no longer valid");
                }
                state_store->move_checkpoint_to_active(selected);
                sequence.state = ActiveStateBinding{.read = selected, .write = selected};
                return;
            }
            if (!transaction.state_fork_destination ||
                state_store->checkpoint_references(selected) == 0) {
                throw std::logic_error("planned StateImage Fork is no longer valid");
            }
            const StateImageHandle destination = *transaction.state_fork_destination;
            if (transaction.state_restored) {
                if (state_store->role(destination) != StateImageRole::ActiveMutable) {
                    throw std::logic_error("restored StateImage Fork destination is unavailable");
                }
                sequence.state = ActiveStateBinding{.read = destination, .write = destination};
            } else {
                const std::uint32_t references = state_store->checkpoint_references(selected);
                const std::uint32_t lineage_references =
                    owned_checkpoint_references(sequence, selected);
                if (lineage_references > references) {
                    throw std::logic_error("consumed StateImage Fork ownership is inconsistent");
                }
                const StateReadOwnership read_ownership =
                    lineage_references == references ? StateReadOwnership::LineageCheckpoint
                                                     : StateReadOwnership::ExternalOwner;
                const StateImageSelectors selectors =
                    state_store->begin_fork(selected, destination);
                if (is_masked_draft_backend(speculative_backend)) {
                    state_images->copy_dflash_local(selectors.source, selectors.destination,
                                                    device.stream);
                }
                sequence.state = ActiveStateBinding{
                    .read           = selected,
                    .write          = destination,
                    .fork_pending   = true,
                    .read_ownership = read_ownership,
                };
            }
            transaction.state_fork_destination.reset();
        };
        if (request_plan.reuse == ReusePath::Root) {
            sequence.rewrite_checkpoint = {};
            ordered_reset(sequence);
            sequence.ledger.clear();
            sequence.prefix_digests.clear();
            sequence.text_kv_valid = 0;
            sequence.mtp_kv_valid  = 0;
        } else if (preserving_source) {
            const SequenceState* private_source =
                transaction.has_source ? &continuation_states[transaction.source_index] : nullptr;
            SharedPrefixState* shared_source =
                transaction.has_shared_source
                    ? &shared_prefix_states[transaction.shared_source_index]
                    : nullptr;
            const std::uint32_t source_text_frontier =
                private_source != nullptr ? private_source->text_kv_valid : shared_source->frontier;
            if (!sequence.kv || source_text_frontier < base) {
                throw std::logic_error("retained prefix has incomplete Text KV");
            }
            sequence.text_kv_valid = base;
            if (speculative_backend == SpeculativeBackend::Mtp) {
                const std::uint32_t mtp_base       = base == 0 ? 0 : base - 1U;
                const std::uint32_t source_backend = private_source != nullptr
                                                         ? private_source->mtp_kv_valid
                                                         : shared_source->backend_frontier;
                if (!request_plan.prepare_mtp || source_backend < mtp_base) {
                    throw std::logic_error("retained prefix has incomplete MTP KV");
                }
                sequence.mtp_kv_valid = mtp_base;
            } else if (is_masked_draft_backend(speculative_backend)) {
                const std::uint32_t source_backend = private_source != nullptr
                                                         ? private_source->dflash_context_frontier
                                                         : shared_source->frontier;
                if (source_backend < base) {
                    throw std::logic_error("retained prefix has incomplete DFlash KV");
                }
                sequence.dflash_context_frontier = base;
            }
            sequence.tail_hidden_valid =
                base == prompt_tokens &&
                (private_source != nullptr ? private_source->tail_hidden_valid
                                           : shared_source->tail_hidden_valid);
            if (shared_source != nullptr) {
                if (shared_source->active_references == std::numeric_limits<std::uint32_t>::max()) {
                    throw std::overflow_error("shared-prefix active reference overflow");
                }
                ++shared_source->active_references;
                sequence.shared_prefix_references.push_back(transaction.shared_source_index);
            }
            refresh_state_views(sequence);
            bind_sequence_kv(sequence);
        } else if (request_plan.reuse == ReusePath::PrivateEndpoint) {
            if (!state_store->valid(sequence.state.read) ||
                sequence.state.read != sequence.state.write || sequence.state.fork_pending ||
                state_store->role(sequence.state.read) != StateImageRole::CheckpointImmutable) {
                throw std::logic_error("resident endpoint StateImage is not movable");
            }
            if (!preserve_rewrite && sequence.rewrite_state) {
                const StateImageHandle dropped = *sequence.rewrite_state;
                state_store->release_checkpoint_reference(dropped);
                sequence.rewrite_state.reset();
                sequence.rewrite_checkpoint = {};
                if (dropped != sequence.state.read &&
                    state_store->checkpoint_references(dropped) == 0 &&
                    !state_store->release(dropped)) {
                    throw std::logic_error("dropped rewrite StateImage could not be released");
                }
            }
            activate_consumed_state(sequence.state.read);
            if (!sequence.kv) {
                throw std::logic_error("resident prefix has no KV allocation bundle");
            }
            if (sequence.text_kv_valid < kv_base ||
                (request_plan.native_physical_reuse_base &&
                 (!sequence.compact_kv_frontier ||
                  *sequence.compact_kv_frontier != kv_base))) {
                throw std::logic_error("resident Text KV is shorter than the append frontier");
            }
            if (speculative_backend == SpeculativeBackend::Mtp) {
                const std::uint32_t mtp_base = kv_base == 0 ? 0 : kv_base - 1;
                if (!request_plan.prepare_mtp || sequence.mtp_kv_valid < mtp_base) {
                    throw std::logic_error("resident MTP KV is shorter than the bridge frontier");
                }
                sequence.mtp_kv_valid = mtp_base;
            } else if (is_masked_draft_backend(speculative_backend) &&
                       sequence.dflash_context_frontier != base) {
                throw std::logic_error("resident DFlash context is not at the append frontier");
            }
            bind_sequence_kv(sequence);
            trim_sequence_kv(sequence, kv_base, backend_kv_valid(sequence));
            resize_sequence_kv_entitlement(sequence, request_plan.text_kv_page_entitlement,
                                           request_plan.backend_kv_page_entitlement);
            sequence.text_kv_valid = kv_base;
#if defined(NINFER_WITH_KVMEM)
            if (kvmem.enabled && speculative_backend == SpeculativeBackend::Mtp) {
                // PrivateEndpoint always defers its last follower row for the
                // current suffix/sample bridge. The map must follow that trim,
                // including a restored checkpoint whose follower was synchronous.
                refresh_native_follower_execution(sequence);
            }
#endif
            sequence.ledger.resize(base);
            sequence.prefix_digests.truncate(base);
            reserve_state_entitlement(sequence, state_slots);
            refresh_state_views(sequence);
        } else if (is_rewrite_checkpoint_restore(request_plan.reuse)) {
            if (!sequence.kv || sequence.text_kv_valid < base) {
                throw std::logic_error("resident rewrite checkpoint has no complete KV allocation");
            }
            if (!sequence.rewrite_state || !state_store->valid(*sequence.rewrite_state) ||
                state_store->role(*sequence.rewrite_state) != StateImageRole::CheckpointImmutable ||
                (sequence.endpoint_valid &&
                 (!state_store->valid(sequence.state.read) ||
                  sequence.state.read != sequence.state.write || sequence.state.fork_pending ||
                  state_store->role(sequence.state.read) != StateImageRole::CheckpointImmutable))) {
                throw std::logic_error("resident rewrite StateImage is not movable");
            }
            const StateImageHandle checkpoint = *sequence.rewrite_state;
            if (sequence.endpoint_valid && sequence.state.read == checkpoint) {
                throw std::logic_error("resident endpoint aliases its rewrite StateImage");
            }
            if (sequence.endpoint_valid && !state_store->release(sequence.state.read)) {
                throw std::logic_error("superseded endpoint StateImage could not be released");
            }
            if (!preserve_rewrite) {
                state_store->release_checkpoint_reference(checkpoint);
                sequence.rewrite_state.reset();
                sequence.rewrite_checkpoint = {};
            }
            activate_consumed_state(checkpoint);
            sequence.text_kv_valid = base;
            if (speculative_backend == SpeculativeBackend::Mtp) {
                const std::uint32_t mtp_base = base == 0 ? 0 : base - 1;
                if (!request_plan.prepare_mtp || sequence.mtp_kv_valid < mtp_base) {
                    throw std::logic_error(
                        "rewrite-checkpoint MTP KV is shorter than the bridge frontier");
                }
                sequence.mtp_kv_valid = mtp_base;
            } else if (is_masked_draft_backend(speculative_backend)) {
                if (!dflash || (backend_kv_cache() && !sequence.kv->backend) ||
                    sequence.dflash_context_frontier < base) {
                    throw std::logic_error("planned DFlash rewrite checkpoint is unavailable");
                }
                sequence.dflash_context_frontier = base;
            }
            bind_sequence_kv(sequence);
            trim_sequence_kv(sequence, base, backend_kv_valid(sequence));
            resize_sequence_kv_entitlement(sequence, request_plan.text_kv_page_entitlement,
                                           request_plan.backend_kv_page_entitlement);
            sequence.tail_hidden_valid = base == prompt_tokens;
            sequence.ledger.resize(base);
            sequence.prefix_digests.truncate(base);
            reserve_state_entitlement(sequence, state_slots);
            refresh_state_views(sequence);
        } else {
            throw std::logic_error("request plan has an invalid prefix reuse path");
        }

        sequence.endpoint_valid = false;
        if (!preserving_source) {
            trim_sequence_kv(sequence, kv_base, backend_kv_valid(sequence));
        }
        bind_sequence_kv(sequence);
        const std::uint32_t backend_materialized =
            speculative_backend == SpeculativeBackend::Mtp
                ? std::min(capacity,
                           prompt_tokens + (initial_mtp_extent == 0 ? 0U : initial_mtp_extent - 1U))
            : speculative_backend == SpeculativeBackend::DFlash ? prompt_tokens
                                                                : 0U;
        // Native KVMem admits exact block-bounded microbatches before forward.
        // Do not materialize the complete logical prompt in the writer address
        // at request start: that would consume the physical pool before a
        // selected execution view can replace old blocks. The per-chunk path
        // below grows the dense writer only as far as the next actual chunk;
        // sparse view installation remains a separate required step.
        const std::uint32_t initial_backend_materialized =
            !kvmem.enabled ||
                    (base == prompt_tokens && !request_plan.native_physical_reuse_base)
                ? backend_materialized
                : std::min(backend_materialized,
                           kv_base + (initial_mtp_extent == 0 ? 0U : initial_mtp_extent - 1U));
        if (kvmem.enabled) {
            // An active NInfer address reserves every page in its entitlement,
            // even before ensure_mapped_to_tokens materializes them. Keep only
            // the current writer extent reserved; the native backend needs the
            // remaining pool capacity for resident and stage-in block slots.
            const std::uint32_t main_pages = std::max(
                {1U, kv_pages_for_frontier(kv_base),
                 text_kv_addresses->mapped_pages(sequence.kv->text)});
            const std::uint32_t backend_pages = sequence.kv->backend
                ? std::max({1U, kv_pages_for_frontier(initial_backend_materialized),
                            backend_kv_addresses->mapped_pages(*sequence.kv->backend)})
                : 0U;
            resize_sequence_kv_entitlement(sequence, main_pages, backend_pages);
        }
        ensure_sequence_kv_mapped(sequence, kvmem.enabled ? kv_base : prompt_tokens,
                                  initial_backend_materialized);
        install_sampling(sequence, request, request_plan.sampling);
        sequence.rope_delta = staged.prompt.rope_delta;
        set_device_i32(io.rope_delta, sequence.rope_delta);

        request.timings              = {};
        request.pending              = {};
        request.publish_continuation = request_plan.summary.publish_continuation;
#if defined(NINFER_WITH_KVMEM)
        request.native_evaluation_frontier = 0;
#endif
        sequence.mtp_draft_count     = 0;
        sequence.tail_hidden_valid   = base == prompt_tokens && sequence.tail_hidden_valid;
        sequence.ledger.swap(materialization_ledger_);
        // Every reuse path rebinds the ledger here; the first round reports the whole prompt,
        // which also makes this request's own history the pool's latest continuations.
        sequence.ngram_observed = 0;
        sequence.prefix_identity.swap(materialization_identity_);
        sequence.prefix_digests.swap(materialization_prefix_digests_);
        sequence.rebuild_work       = request_plan.root_rebuild_work;
        sequence.rebuild_tail_begin = request_plan.root_rebuild_tail_begin;

        if (is_masked_draft_backend(speculative_backend)) {
            if (!dflash || !io.dflash_decode || (backend_kv_cache() && !sequence.kv->backend)) {
                throw std::logic_error("DFlash prefill state is incomplete");
            }
            *dflash_host_ingress                       = {};
            dflash_host_ingress->active_lanes[0]       = static_cast<std::int32_t>(sequence.lane);
            const StateImageSelectors selectors        = state_selectors(sequence);
            dflash_host_ingress->state_source_slots[0] = selectors.source;
            dflash_host_ingress->state_destination_slots[0] = selectors.destination;
            dflash_host_ingress->dflash_kv_table_rows[0] =
                sequence.kv->backend ? backend_kv_addresses->bound_row(*sequence.kv->backend) : 0;
            CUDA_CHECK(cudaMemcpyAsync(io.dflash_decode->ingress.data, dflash_host_ingress,
                                       sizeof(qwen3_5::DFlashDecodeIngress), cudaMemcpyHostToDevice,
                                       device.stream));
        }

        staged.elapsed_seconds += std::chrono::duration<double>(Clock::now() - started).count();
        request.lifecycle = Lifecycle::Prefilling;
#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled) {
            native_kvmem_owner = static_cast<std::uint32_t>(
                &sequence - continuation_states.data());
        }
#endif
    } catch (...) {
        try {
            device.synchronize();
        } catch (...) {}
        clear_lane_best_effort(sequence, request);
        throw;
    }
}

runtime::PrefillStepResult
ProgramImpl::advance_prefill_raw(std::uint32_t lane, runtime::ExecutionTiming* failed_timing) {
    if (lane >= max_concurrency) { throw std::out_of_range("request lane is out of range"); }
    return advance_prefill(active_sequence(lane), requests[lane], failed_timing);
}

runtime::ExecutionTiming ProgramImpl::resolve_prefill_raw(std::uint32_t lane, bool terminal,
                                                          runtime::ExecutionTiming* failed_timing) {
    if (lane >= max_concurrency) { throw std::out_of_range("request lane is out of range"); }
    if (requests[lane].pending.kind != PendingKind::Begin) {
        throw std::logic_error("prefill resolution requires a pending prefill token");
    }
    return resolve_non_speculative_pending(active_sequence(lane), requests[lane], 1, terminal,
                                           std::nullopt, failed_timing);
}

runtime::ExecutionTiming ProgramImpl::resolve_pending_raw(
    std::span<const std::uint32_t> lanes, std::span<const std::uint32_t> accepted_tokens,
    std::span<const std::uint8_t> terminal, std::span<const std::uint8_t> cancelled,
    std::span<const std::optional<std::uint32_t>> prefix_execution_splits,
    runtime::ExecutionTiming* failed_timing) {
    runtime::ExecutionTimingRecorder timing(runtime::ExecutionTimingPhase::Post, failed_timing);
    if (lanes.empty() || lanes.size() > max_concurrency || accepted_tokens.size() != lanes.size() ||
        terminal.size() != lanes.size() || cancelled.size() != lanes.size() ||
        prefix_execution_splits.size() != lanes.size()) {
        throw std::invalid_argument("pending batch resolution has inconsistent membership");
    }

    if (lanes.size() == 1 && lanes.front() < max_concurrency &&
        requests[lanes.front()].pending.kind == PendingKind::Begin) {
        const std::uint32_t lane = lanes.front();
        if (requests[lane].lifecycle != Lifecycle::Pending) {
            throw std::logic_error("prefill pending token no longer matches Program state");
        }
        if (cancelled.front()) {
            if (accepted_tokens.front() != 0 || !terminal.front()) {
                throw std::logic_error("cancelled prefill pending decision is invalid");
            }
            if (kvmem.enabled) {
                requests[lane].pending = {};
                requests[lane].lifecycle = Lifecycle::Finishable;
            } else if (!clear_lane_strict(active_sequence(lane), requests[lane])) {
                throw std::logic_error("cancelled prefill lane is not strictly releasable");
            }
        } else {
            timing.pause();
            timing.include(resolve_non_speculative_pending(
                active_sequence(lane), requests[lane], accepted_tokens.front(),
                terminal.front() != 0, prefix_execution_splits.front(), failed_timing));
            timing.resume_post();
        }
        return timing.finish();
    }

    if (speculative_backend == SpeculativeBackend::None) {
        for (std::size_t row = 0; row < lanes.size(); ++row) {
            const std::uint32_t lane = lanes[row];
            if (lane >= max_concurrency || requests[lane].lifecycle != Lifecycle::Pending ||
                requests[lane].pending.kind != PendingKind::Ordinary) {
                throw std::logic_error("ordinary pending batch no longer matches Program state");
            }
            if (cancelled[row]) {
                if (!clear_lane_strict(active_sequence(lane), requests[lane])) {
                    throw std::logic_error("cancelled decode lane is not strictly releasable");
                }
            } else {
                timing.pause();
                timing.include(resolve_non_speculative_pending(
                    active_sequence(lane), requests[lane], accepted_tokens[row], terminal[row] != 0,
                    prefix_execution_splits[row], failed_timing));
                timing.resume_post();
            }
        }
        return timing.finish();
    }

    // The fold reads the records through the view of the round's width.
    const ops::GdnReplayFoldPlan& fold = round_replay_fold(
        speculative_backend == SpeculativeBackend::Mtp ? mtp_round_width : draft_window + 1U);

    std::array<ops::GdnReplayFoldRow, kMaximumConcurrency> fold_rows{};
    std::array<std::int32_t, kMaximumConcurrency> hidden_selectors{};
    bool needs_hidden_correction = false;
    for (std::size_t row = 0; row < lanes.size(); ++row) {
        const std::uint32_t lane = lanes[row];
        if (lane >= max_concurrency || requests[lane].lifecycle != Lifecycle::Pending ||
            requests[lane].pending.kind != PendingKind::Speculative) {
            throw std::logic_error("speculative pending batch no longer matches Program state");
        }
        const PendingCandidate& pending = requests[lane].pending;
        const SequenceState& sequence   = active_sequence(lane);
        const std::uint32_t expected_cache_base =
            speculative_backend == SpeculativeBackend::Mtp
                ? sequence.compact_kv_frontier.value_or(pending.base_E)
                : pending.base_E;
        if (sequence.execution_frontier != pending.base_E ||
            sequence.ledger_frontier != pending.base_S ||
            sequence.ledger.size() != pending.base_S ||
            sequence.prefix_identity.size() != pending.base_S ||
            sequence.prefix_digests.size() != pending.base_S ||
            sequence.text_kv_valid != expected_cache_base ||
            (speculative_backend == SpeculativeBackend::Mtp &&
             sequence.mtp_kv_valid != expected_cache_base) ||
            (is_masked_draft_backend(speculative_backend) &&
             sequence.dflash_context_frontier != pending.base_E)) {
            throw std::logic_error("speculative pending row is not at its recorded base");
        }
        const std::uint32_t committed = cancelled[row] ? 0U : accepted_tokens[row];
        if ((cancelled[row] && accepted_tokens[row] != 0) ||
            (!cancelled[row] && (committed == 0 || committed > pending.produced ||
                                 (!terminal[row] && committed != pending.produced)))) {
            throw std::logic_error("speculative pending row has an invalid committed prefix");
        }
        if (speculative_backend == SpeculativeBackend::Mtp &&
            (expected_cache_base > kv_capacity ||
             committed > kv_capacity - expected_cache_base)) {
            throw std::logic_error("MTP accepted prefix exceeds the physical KV pool");
        }
        const StateImageSelectors selectors = state_selectors(sequence);
        fold_rows[row] =
            ops::GdnReplayFoldRow{.source_state_slot      = selectors.source,
                                  .destination_state_slot = selectors.destination,
                                  .commit_columns         = static_cast<std::int32_t>(committed)};
        const bool partial_terminal =
            !cancelled[row] && terminal[row] && committed < pending.produced;
        hidden_selectors[row] =
            static_cast<std::int32_t>(partial_terminal ? committed - 1U : pending.produced - 1U);
        needs_hidden_correction = needs_hidden_correction || partial_terminal;
    }

    const auto tail_started = Clock::now();
    try {
        timing.resume_submit();
        fold.execute(std::span<const ops::GdnReplayFoldRow>(fold_rows.data(), lanes.size()),
                     device.stream);

        // Sparse acceptance reads counts. Publish only the prefix licensed by the Frontend.
        if (speculative_backend == SpeculativeBackend::DFlash2) {
            for (std::size_t row = 0; row < lanes.size(); ++row) {
                if (cancelled[row] || !requests[lanes[row]].sampling_host.token_counts) {
                    continue;
                }
                const auto count = static_cast<std::int32_t>(accepted_tokens[row]);
                Tensor ids =
                    io.dflash_decode->licensed_tokens.slice(1, static_cast<std::int32_t>(row), 1)
                        .slice(0, 0, count)
                        .view({count});
                Tensor counts =
                    token_counts.slice(1, static_cast<std::int32_t>(lanes[row]), 1)
                        .view({dimension(parameters.model.resources().public_token_count)});
                ops::increment_token_counts(ids, counts, device.stream);
            }
        }

        if (needs_hidden_correction) {
            const auto batch = static_cast<std::int32_t>(lanes.size());
            Tensor selector_tensor;
            Tensor hidden;
            Tensor selected;
            Tensor destinations;
            if (speculative_backend == SpeculativeBackend::Mtp && io.mtp_decode) {
                qwen3_5::MtpDecodeState& frame = *io.mtp_decode;
                selector_tensor                = frame.current_extents.slice(0, 0, batch);
                hidden                         = frame.target_hidden.slice(2, 0, batch);
                selected     = frame.target_continuation_hidden.slice(1, 0, batch);
                destinations = frame.state_destination_slots.slice(0, 0, batch);
            } else if (is_masked_draft_backend(speculative_backend) && io.dflash_decode) {
                qwen3_5::DFlashDecodeState& frame = *io.dflash_decode;
                selector_tensor                   = frame.proposal_extents.slice(0, 0, batch);
                hidden                            = frame.target_hidden.slice(2, 0, batch);
                selected     = frame.target_continuation_hidden.slice(1, 0, batch);
                destinations = frame.state_destination_slots.slice(0, 0, batch);
            } else {
                throw std::logic_error("partial speculative commit has no target frame");
            }
            CUDA_CHECK(cudaMemcpyAsync(selector_tensor.data, hidden_selectors.data(),
                                       lanes.size() * sizeof(std::int32_t), cudaMemcpyHostToDevice,
                                       device.stream));
            ops::speculative_select_accepted_hidden(hidden, selector_tensor, selected,
                                                    device.stream);
            ops::scatter(selected, destinations, state_images->continuation_hidden_store(),
                         device.stream);
        }

        if (is_masked_draft_backend(speculative_backend)) {
            std::array<std::uint32_t, kMaximumConcurrency> append_lanes{};
            std::array<std::uint32_t, kMaximumConcurrency> append_starts{};
            std::array<std::uint32_t, kMaximumConcurrency> append_counts{};
            std::size_t append_size = 0;
            for (std::size_t row = 0; row < lanes.size(); ++row) {
                if (!cancelled[row] && terminal[row]) {
                    append_lanes[append_size]  = lanes[row];
                    append_starts[append_size] = requests[lanes[row]].pending.base_E;
                    append_counts[append_size] = accepted_tokens[row];
                    ++append_size;
                }
            }
            if (append_size != 0) {
                enqueue_dflash_context_append(
                    std::span<const std::uint32_t>(append_lanes.data(), append_size),
                    std::span<const std::uint32_t>(append_starts.data(), append_size),
                    std::span<const std::uint32_t>(append_counts.data(), append_size));
            }
        }

        timing.begin_wait();
        device.synchronize();
        timing.end_wait();
        work.reset();
    } catch (...) {
        try {
            device.synchronize();
        } catch (...) {}
#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled && speculative_backend == SpeculativeBackend::Mtp &&
            native_mtp_accepted_keys && native_mtp_accepted_keys->verify_in_flight()) {
            try { native_mtp_accepted_keys->discard_verify(); } catch (...) {}
        }
        if (kvmem.enabled) { native_kvmem_poisoned = true; }
#endif
        work.reset();
        clear_execution_failure_lanes(lanes);
        throw;
    }

    const double tail_seconds = std::chrono::duration<double>(Clock::now() - tail_started).count();
    // MTP rounds choose their width per round; DFlash rounds always verify K+1 columns.
    const std::uint32_t width =
        speculative_backend == SpeculativeBackend::Mtp ? mtp_round_width : draft_window + 1U;
    try {
        for (std::size_t row = 0; row < lanes.size(); ++row) {
            SequenceState& sequence = active_sequence(lanes[row]);
            RequestControl& request = requests[lanes[row]];
            if (cancelled[row]) {
#if defined(NINFER_WITH_KVMEM)
                if (kvmem.enabled && speculative_backend == SpeculativeBackend::Mtp &&
                    native_mtp_accepted_keys && native_mtp_accepted_keys->verify_in_flight()) {
                    native_mtp_accepted_keys->discard_verify();
                    // The fold licensed zero columns. Remove only provisional
                    // native rows and keep the previously committed endpoint.
                    const auto frontier = request.pending.base_E;
                    native_kvmem_conversation->raw().truncate_to(frontier);
                    if (auto* follower = native_kvmem_conversation->follower_raw()) {
                        follower->truncate_to(frontier);
                    }
                    (void)native_kvmem_conversation->runtime().truncate_to(frontier);
                    const Tensor committed_hidden = state_images->continuation_hidden_slot(
                        state_selectors(sequence).destination);
                    if (request.native_cancel_tail_hidden.size() != committed_hidden.bytes()) {
                        throw std::logic_error("native cancellation has no committed hidden row");
                    }
                    CUDA_CHECK(cudaMemcpyAsync(committed_hidden.data,
                                               request.native_cancel_tail_hidden.data(),
                                               committed_hidden.bytes(), cudaMemcpyHostToDevice,
                                               device.stream));
                    device.synchronize();
                    request.pending = {};
                    request.lifecycle = Lifecycle::Finishable;
                    continue;
                }
#endif
                if (!clear_lane_strict(sequence, request)) {
                    throw std::logic_error("cancelled speculative lane is not strictly releasable");
                }
                continue;
            }

            const PendingCandidate pending = request.pending;
            const std::uint32_t committed  = accepted_tokens[row];
#if defined(NINFER_WITH_KVMEM)
            if (kvmem.enabled && speculative_backend == SpeculativeBackend::Mtp) {
                if (lanes.size() != 1 || !native_kvmem_conversation ||
                    !native_mtp_accepted_keys || !native_decode_features || !native_kvmem_owner ||
                    *native_kvmem_owner != active_continuations[lanes[row]] ||
                    native_mtp_accepted_keys->key_frontier() != pending.base_E ||
                    !native_mtp_accepted_keys->verify_in_flight()) {
                    throw std::logic_error("native MTP acceptance has no matching verify capture");
                }
                auto& native = *native_kvmem_conversation;
                auto& rows = native.metadata().row_positions;
                const std::uint32_t actual_columns =
                    static_cast<std::uint32_t>(mtp_host_ingress->current_extents[row]) + 1U;
                if (rows.size() != pending.base_E ||
                    native.runtime().pending() ||
                    native.runtime().store().total_tokens() !=
                        pending.base_E + actual_columns ||
                    committed > actual_columns || committed > width) {
                    throw std::logic_error("native MTP accepted prefix disagrees with registered rows");
                }
                const std::uint32_t accepted_end = pending.base_E + committed;
                native.raw().truncate_to(accepted_end);
                if (auto* follower = native.follower_raw()) {
                    follower->truncate_to(accepted_end);
                }
                (void)native.runtime().truncate_to(accepted_end);
                native_mtp_accepted_keys->commit_accepted_prefix(pending.base_E,
                                                                  static_cast<std::int32_t>(committed));
                // MTP owns the row writes, but the common known/control
                // consumer also validates this workspace's committed frontier.
                // Rebase bookkeeping only; never publish accepted keys twice.
                native_decode_features->reset_key_frontier(accepted_end);
                const std::uint32_t drafts_per_row = width - 1U;
                for (std::uint32_t column = 0; column < committed; ++column) {
                    const TokenId input = column == 0
                        ? mtp_host_ingress->anchors[row]
                        : mtp_host_ingress->current_drafts[
                              row * drafts_per_row + column - 1U];
                    const std::int32_t rope =
                        checked_i32(pending.base_E + column,
                                    "native MTP accepted RoPE position") + sequence.rope_delta;
                    rows.push_back(KVMemConversation::RowPosition{
                        .pos = {rope, rope, rope, rope},
                        .token = input,
                        .spatial = true,
                    });
                }
            }
#endif
            settle_state_fork(sequence);
            const TokenId* token_base =
                speculative_backend == SpeculativeBackend::Mtp
                    ? mtp_host_egress->licensed_tokens.data() + row * width
                    : dflash_host_egress->licensed_tokens.data() + row * width;
            sequence.ledger.insert(sequence.ledger.end(), token_base, token_base + committed);
            commit_generated_prefix_identity(sequence, pending.base_S,
                                             std::span<const TokenId>(token_base, committed),
                                             prefix_execution_splits[row]);
            advance_rebuild_work(sequence, pending.base_E + committed, prefill_chunk);
            sequence.execution_frontier = pending.base_E + committed;
            sequence.ledger_frontier    = pending.base_S + committed;
            sequence.tail_hidden_valid  = true;

            if (speculative_backend == SpeculativeBackend::Mtp) {
                const std::uint32_t cache_end =
                    sequence.compact_kv_frontier.value_or(pending.base_E) + committed;
                if (sequence.compact_kv_frontier) {
                    *sequence.compact_kv_frontier = cache_end;
                }
                sequence.text_kv_valid = cache_end;
                sequence.mtp_kv_valid = cache_end;
                if (terminal[row]) {
                    sequence.mtp_draft_count = 0;
                } else {
                    const std::int32_t next  = mtp_host_egress->next_extents[row];
                    sequence.mtp_draft_count = static_cast<std::uint32_t>(next);
                    for (std::uint32_t step = 0; step < sequence.mtp_draft_count; ++step) {
                        sequence.mtp_drafts[step] =
                            mtp_host_egress->next_drafts[step * max_concurrency + row];
                    }
                }
            } else {
                sequence.text_kv_valid = sequence.execution_frontier;
                sequence.dflash_context_frontier =
                    terminal[row] ? sequence.execution_frontier : pending.base_E;
            }

            commit_sequence_kv(sequence, sequence.text_kv_valid, backend_kv_valid(sequence));
            trim_sequence_kv(sequence, sequence.text_kv_valid, backend_kv_valid(sequence));
#if defined(NINFER_WITH_KVMEM)
            if (kvmem.enabled && speculative_backend == SpeculativeBackend::Mtp) {
                // Rejected columns have already been truncated from native
                // Store/Raw and both writers. Publish every completed accepted
                // block, including a former partial head of a cross-slot verify.
                const KVAddressSpaceHandle writer = sequence.kv->text;
                const auto entitlement = text_kv_addresses->entitlement(writer);
                text_kv_addresses->deactivate(writer);
                sequence.native_tail_materialized_tokens = commit_kvmem_prefill_blocks(
                    native_kvmem_conversation->runtime().store(), *native_kvmem_backend,
                    *text_kv_addresses, writer,
                    KVMemPrefillCommitSpan{
                        .logical_begin = pending.base_E,
                        .logical_end = sequence.execution_frontier,
                        .execution_end = sequence.text_kv_valid,
                        .materialized_tail_tokens = sequence.native_tail_materialized_tokens,
                        .publish_partial_tail = terminal[row] != 0,
                    });
                text_kv_addresses->activate(writer, entitlement,
                                            static_cast<std::int32_t>(sequence.lane), device.stream);
                refresh_native_follower_execution(sequence);
            }
#endif
            if (terminal[row]) {
                request.lifecycle = Lifecycle::Finishable;
            } else {
                request.lifecycle = Lifecycle::Active;
            }
            request.pending = {};
            request.timings.decode_seconds += tail_seconds;
        }
    } catch (...) {
#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled) { native_kvmem_poisoned = true; }
#endif
        clear_execution_failure_lanes(lanes);
        throw;
    }
    return timing.finish();
}

runtime::PrefillStepResult ProgramImpl::advance_prefill(SequenceState& sequence,
                                                        RequestControl& request,
                                                        runtime::ExecutionTiming* failed_timing) {
    runtime::ExecutionTimingRecorder timing(runtime::ExecutionTimingPhase::Submit, failed_timing);
    if (request.lifecycle != Lifecycle::Prefilling || !request.prefill) {
        throw std::logic_error("staged prefill step requires an active concurrent request");
    }

    RequestControl::Prefill& staged = *request.prefill;
    if (staged.pending_capture_offer != 0) {
        throw std::logic_error("prefill cannot advance while a capture offer is pending");
    }
    const runtime::BeginSummary summary{.prompt_tokens        = staged.prompt_tokens,
                                        .reused_prompt_tokens = staged.base,
                                        .prefix_reuse_path    = staged.reuse};
    std::uint32_t processed_prompt_tokens = 0;
    const auto started                    = Clock::now();
    try {
        if (staged.next_capture < staged.capture_groups.size() &&
            staged.capture_groups[staged.next_capture].frontier == staged.cursor) {
            if (staged.cursor != staged.base ||
                !staged.capture_groups[staged.next_capture].shared ||
                staged.capture_groups[staged.next_capture].rewrite ||
                staged.capture_groups[staged.next_capture].long_anchor) {
                throw std::logic_error("zero-prefill capture is not a shared base promotion");
            }
            if (++next_capture_offer_id_ == 0) { ++next_capture_offer_id_; }
            staged.pending_capture_offer = next_capture_offer_id_;
            return runtime::PrefillStepResult{
                .summary = summary,
                .timing  = timing.finish(),
            };
        }
        StateImageSelectors selectors = state_selectors(sequence);
        Tensor rewrite_capture_hidden;
        Tensor* rewrite_capture_hidden_ptr = nullptr;
        if (staged.next_capture < staged.capture_groups.size()) {
            rewrite_capture_hidden = state_images->continuation_hidden_slot(selectors.destination);
            rewrite_capture_hidden_ptr = &rewrite_capture_hidden;
        }
        execution::PrefillContext schedule_state{
            {device, parameters, work, state_images->linear(),
             replay_records ? &*replay_records : nullptr, io, prefill_hidden, prefill_chunk,
             proposal_head},
            text_kv_view(sequence),
            mtp_kv_view(sequence),
            decoder->text_kv,
            decoder->mtp_cache(),
            dflash ? &*dflash : nullptr,
            staged.cursor,
            static_cast<const ops::SamplingConfig*>(
                sampling_config.slice(1, static_cast<std::int32_t>(sequence.lane), 1).data),
            rewrite_capture_hidden_ptr,
            selectors.source,
            selectors.destination,
            staged.initial_mtp_extent,
            dflash_host_ingress};
        schedule_state.cache_kv_base = sequence.compact_kv_frontier;

#if defined(NINFER_WITH_KVMEM)
        const auto install_native_selected_writer =
            [&](std::span<const std::uint32_t> selected_ids,
                std::uint32_t append_reserve_tokens,
                KVMemFollowerRetainedPages* retained,
                std::optional<std::uint32_t> follower_logical_frontier) {
                if (!kvmem.enabled || sequence.kv || !native_kvmem_conversation ||
                    !native_kvmem_backend) {
                    throw std::logic_error("native selected writer has no detached source view");
                }
                const auto& store = native_kvmem_conversation->runtime().store();
                std::uint64_t visible = 0;
                for (const std::uint32_t id : selected_ids) {
                    if (id >= store.block_count()) {
                        throw std::logic_error("native selected writer has an unknown block");
                    }
                    visible += store.blocks()[id].n_tokens;
                }
                if (visible > kv_capacity ||
                    append_reserve_tokens > kv_capacity - visible) {
                    throw std::logic_error("native selected writer exceeds its physical KV pool");
                }
                const std::uint32_t selected_tokens = static_cast<std::uint32_t>(visible);
                std::optional<KVAddressSpaceHandle> reader;
                std::optional<KVAddressSpaceHandle> writer;
                std::optional<KVMemFollowerInstalledView> follower_view;
                try {
                    if (selected_ids.empty()) {
                        // Native pressure may keep only the incoming batch.
                        // No historical pages exist to fork; reserve an empty
                        // active writer and publish its new rows after forward.
                        writer = text_kv_addresses->create_active(
                            kv_pages_for_frontier(append_reserve_tokens),
                            static_cast<std::int32_t>(sequence.lane));
                        if (!writer) {
                            throw std::logic_error("native empty writer lacks an address descriptor");
                        }
                    } else {
                        reader = text_kv_addresses->create_inactive();
                        writer = text_kv_addresses->create_inactive();
                        if (!reader || !writer) {
                            throw std::logic_error("native selected writer lacks address descriptors");
                        }
                        const auto offsets = native_kvmem_backend->install_selected_for_append(
                            store, selected_ids, *text_kv_addresses, *reader, *writer,
                            kv_pages_for_frontier(selected_tokens + append_reserve_tokens),
                            static_cast<std::int32_t>(sequence.lane));
                        if (offsets.empty() ||
                            offsets.back().execution_begin + offsets.back().tokens !=
                                selected_tokens ||
                            !text_kv_addresses->release(*reader)) {
                            throw std::logic_error("native selected writer has incomplete coverage");
                        }
                        reader.reset();
                    }
                    if (speculative_backend == SpeculativeBackend::Mtp) {
                        const kvmem::RawKvStore* follower_raw =
                            native_kvmem_conversation->follower_raw();
                        if (follower_raw == nullptr) {
                            throw std::logic_error("native selected writer has no MTP mirror");
                        }
                        std::uint32_t follower_missing_rows = 0;
                        if (follower_logical_frontier) {
                            if (*follower_logical_frontier > store.total_tokens() ||
                                store.total_tokens() - *follower_logical_frontier > 1U) {
                                throw std::logic_error(
                                    "native selected MTP prefix has an invalid committed frontier");
                            }
                            follower_missing_rows =
                                store.total_tokens() - *follower_logical_frontier;
                            KVMemFollowerReplayPrefix prefix =
                                install_kvmem_follower_replay_prefix(
                                    store, selected_ids,
                                    *follower_logical_frontier,
                                    device, *backend_kv_pages, *backend_kv_addresses,
                                    *native_kvmem_follower_backend, *follower_raw,
                                    kv_pages_for_frontier(
                                        selected_tokens + append_reserve_tokens),
                                    sequence.lane, retained);
                            follower_view = KVMemFollowerInstalledView{
                                .address = prefix.address,
                                .execution = std::move(prefix.execution),
                                .visible_tokens = prefix.compact_frontier,
                            };
                        } else {
                            follower_view = install_native_follower_selected(
                                store, selected_ids, append_reserve_tokens,
                                sequence.lane, *follower_raw, retained);
                        }
                        if (follower_view->visible_tokens + follower_missing_rows !=
                            selected_tokens) {
                            throw std::logic_error(
                                "native selected writer and follower disagree on execution size");
                        }
                    }
                    sequence.kv.emplace(SequenceKVBundle{
                        .text = *writer,
                        .backend = follower_view
                                       ? std::optional<KVAddressSpaceHandle>{follower_view->address}
                                       : std::nullopt,
                    });
                    writer.reset();
                    sequence.compact_kv_frontier = selected_tokens;
                    sequence.text_kv_valid = selected_tokens;
                    if (follower_view) {
                        sequence.native_follower_execution =
                            std::move(follower_view->execution);
                        sequence.mtp_kv_valid = follower_view->visible_tokens;
                        follower_view.reset();
                        schedule_state.mtp_kv = mtp_kv_view(sequence);
                        set_device_i32(io.backend_kv_table_row,
                                       backend_kv_addresses->bound_row(*sequence.kv->backend));
                    }
                    schedule_state.text_kv = text_kv_view(sequence);
                    schedule_state.cache_kv_base = selected_tokens;
                    set_device_i32(io.text_kv_table_row,
                                   text_kv_addresses->bound_row(sequence.kv->text));
                } catch (...) {
                    if (sequence.kv) { release_sequence_kv(sequence); }
                    if (follower_view) {
                        (void)backend_kv_addresses->release_after_deactivate(
                            follower_view->address);
                    }
                    if (writer) {
                        (void)text_kv_addresses->release_after_deactivate(*writer);
                    }
                    if (reader) {
                        (void)text_kv_addresses->release_after_deactivate(*reader);
                    }
                    throw;
                }
            };

        const auto install_native_replay_writer =
            [&](const KVMemConversation::QuerySelectionPreview& selection,
                std::uint32_t replay_logical_begin) {
                if (!kvmem.enabled || sequence.kv || !native_kvmem_conversation ||
                    !native_kvmem_backend || !selection.replay_fits ||
                    selection.replay_compact_end > kv_capacity) {
                    throw std::logic_error("native query replay has no selected source view");
                }
                std::optional<KVAddressSpaceHandle> reader;
                std::optional<KVAddressSpaceHandle> writer;
                try {
                    reader = text_kv_addresses->create_inactive();
                    writer = text_kv_addresses->create_inactive();
                    if (!reader || !writer) {
                        throw std::logic_error("native replay lacks address descriptors");
                    }
                    const std::uint32_t replay_cache_begin =
                        native_kvmem_backend->install_selected_for_replay(
                            native_kvmem_conversation->runtime().store(),
                            selection.selected_blocks, replay_logical_begin,
                            *text_kv_addresses, *reader, *writer,
                            std::max(1U, kv_pages_for_frontier(
                                             selection.replay_compact_begin)),
                            static_cast<std::int32_t>(sequence.lane));
                    if (replay_cache_begin != selection.replay_compact_begin ||
                        !text_kv_addresses->release(*reader)) {
                        throw std::logic_error("native replay prefix has a wrong cache frontier");
                    }
                    reader.reset();
                    sequence.kv.emplace(SequenceKVBundle{.text = *writer});
                    writer.reset();
                    sequence.compact_kv_frontier = replay_cache_begin;
                    sequence.text_kv_valid = replay_cache_begin;
                    schedule_state.text_kv = text_kv_view(sequence);
                    schedule_state.cache_kv_base = replay_cache_begin;
                    set_device_i32(io.text_kv_table_row,
                                   text_kv_addresses->bound_row(sequence.kv->text));
                } catch (...) {
                    if (writer) {
                        (void)text_kv_addresses->release_after_deactivate(*writer);
                    }
                    if (reader) {
                        (void)text_kv_addresses->release_after_deactivate(*reader);
                    }
                    throw;
                }
            };

        const auto install_native_follower_replay_prefix =
            [&](const KVMemConversation::QuerySelectionPreview& selection,
                std::uint32_t replay_logical_begin,
                KVMemFollowerRetainedPages* retained) {
                if (!kvmem.enabled || speculative_backend != SpeculativeBackend::Mtp ||
                    !sequence.kv || sequence.kv->backend || !backend_kv_pages ||
                    !backend_kv_addresses || !native_kvmem_follower_backend ||
                    !native_kvmem_conversation || !selection.replay_fits) {
                    throw std::logic_error("native MTP replay has no detached follower view");
                }
                const kvmem::RawKvStore* raw =
                    native_kvmem_conversation->follower_raw();
                if (raw == nullptr) {
                    throw std::logic_error("native MTP replay lost its packed Raw mirror");
                }
                KVMemFollowerReplayPrefix follower =
                    install_kvmem_follower_replay_prefix(
                        native_kvmem_conversation->runtime().store(),
                        selection.selected_blocks, replay_logical_begin,
                        device, *backend_kv_pages, *backend_kv_addresses,
                        *native_kvmem_follower_backend, *raw,
                        std::max(1U, kv_pages_for_frontier(
                                         selection.replay_compact_begin)),
                        sequence.lane, retained);
                if (follower.compact_frontier != selection.replay_compact_begin ||
                    follower.compact_frontier != sequence.text_kv_valid) {
                    (void)backend_kv_addresses->release_after_deactivate(follower.address);
                    throw std::logic_error("native MTP replay prefix differs from target selection");
                }
                sequence.kv->backend = follower.address;
                try {
                    sequence.native_follower_execution = std::move(follower.execution);
                    sequence.mtp_kv_valid = follower.compact_frontier;
                    schedule_state.mtp_kv = mtp_kv_view(sequence);
                    set_device_i32(io.backend_kv_table_row,
                                   backend_kv_addresses->bound_row(*sequence.kv->backend));
                } catch (...) {
                    release_sequence_kv(sequence);
                    throw;
                }
            };
#endif

#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled && staged.cursor == staged.base && staged.base != 0 &&
            (speculative_backend == SpeculativeBackend::None ||
             speculative_backend == SpeculativeBackend::Mtp) &&
            staged.reuse == ReusePath::PrivateEndpoint &&
            staged.native_turn_spans && staged.native_turn_spans->retrieve &&
            !staged.native_cached_preselected &&
            !staged.native_cached_query_fallback && native_kvmem_conversation &&
            can_reuse_exact_query(staged.prompt,
                                  native_kvmem_conversation->metadata(),
                                  *staged.native_turn_spans, staged.base,
                                  kvmem.query_max_tokens)) {
            // Match the pinned server's cached-Q decision before evaluating
            // the new suffix. Keeping a complete current view costs no tier
            // movement; otherwise the upstream Store scores/reselects with
            // old Q and all already-observed tool rows mandatory.
            const auto& store = native_kvmem_conversation->runtime().store();
            const std::uint32_t block_tokens = kvmem.block_tokens;
            if (store.total_tokens() != staged.base || block_tokens == 0 ||
                !sequence.kv || !sequence.compact_kv_frontier ||
                *sequence.compact_kv_frontier != sequence.text_kv_valid ||
                text_kv_addresses->committed_frontier(sequence.kv->text) !=
                    sequence.text_kv_valid ||
                native_kvmem_conversation->runtime().pending()) {
                throw std::logic_error("native cached Q has no stable prefix view");
            }
            std::vector<std::uint32_t> resident;
            std::uint64_t resident_rows = 0;
            bool observations_resident = true;
            for (const kvmem::KvMemBlock& block : store.blocks()) {
                if (block.orig_pos_end() >
                        staged.native_turn_spans->mandatory_begin &&
                    block.orig_pos_start < staged.base && block.gpu_slot < 0) {
                    observations_resident = false;
                }
                if (block.gpu_slot < 0) { continue; }
                if (block.tier != kvmem::KvTier::GPU || block.in_flight ||
                    block.n_tokens == 0) {
                    throw std::logic_error("native cached Q has unsettled resident KV");
                }
                resident.push_back(block.block_id);
                resident_rows += block.n_tokens;
            }
            if (staged.base % block_tokens != 0 &&
                (store.blocks().empty() ||
                 store.blocks().back().gpu_slot < 0)) {
                observations_resident = false;
            }
            if (resident_rows != sequence.text_kv_valid) {
                throw std::logic_error("native cached Q execution view has missing rows");
            }
            if (speculative_backend == SpeculativeBackend::Mtp) {
                if (staged.mtp_bridge != MtpBridgeMode::BeforeSuffix ||
                    store.blocks().empty() || store.blocks().back().gpu_slot < 0 ||
                    !sequence.kv->backend ||
                    sequence.mtp_kv_valid + 1U != sequence.text_kv_valid ||
                    backend_kv_addresses->committed_frontier(
                        *sequence.kv->backend) != sequence.mtp_kv_valid) {
                    throw std::logic_error("native cached Q has no deferred follower row");
                }
                std::size_t record_index = 0;
                std::uint32_t execution = 0;
                for (const std::uint32_t id : resident) {
                    const auto& block = store.blocks()[id];
                    const std::uint32_t rows = block.n_tokens -
                        (block.orig_pos_end() == staged.base ? 1U : 0U);
                    if (rows == 0) { continue; }
                    if (record_index >= sequence.native_follower_execution.size()) {
                        throw std::logic_error("native cached Q follower map misses a block");
                    }
                    const auto& record =
                        sequence.native_follower_execution[record_index++];
                    if (record.native_block_id != id ||
                        record.original_position != block.orig_pos_start ||
                        record.execution_begin != execution ||
                        record.committed_rows != rows) {
                        throw std::logic_error("native cached Q follower map is stale");
                    }
                    execution += rows;
                }
                if (record_index != sequence.native_follower_execution.size() ||
                    execution != sequence.mtp_kv_valid) {
                    throw std::logic_error("native cached Q follower map has extra rows");
                }
                (void)KVMemFollowerExecutionMap::resolve(
                    sequence.native_follower_execution, *backend_kv_addresses,
                    *sequence.kv->backend);
            } else if (speculative_backend != SpeculativeBackend::None ||
                       sequence.kv->backend) {
                throw std::logic_error("native cached Q has an unsupported draft backend");
            }
            const std::uint64_t first_future = staged.base / block_tokens;
            const std::uint64_t final_blocks =
                (static_cast<std::uint64_t>(staged.prompt_tokens) +
                 kvmem.generation_reserve_tokens + block_tokens - 1U) /
                block_tokens;
            const std::uint64_t pool_blocks = kv_capacity / block_tokens;
            std::uint64_t needed_blocks = resident.size();
            for (std::uint64_t id = first_future; id < final_blocks; ++id) {
                if (id >= store.block_count() ||
                    store.blocks()[static_cast<std::size_t>(id)].gpu_slot < 0) {
                    ++needed_blocks;
                }
            }
            const bool can_keep = observations_resident &&
                                  final_blocks >= first_future &&
                                  final_blocks - first_future <= pool_blocks &&
                                  needed_blocks <= pool_blocks;
            if (can_keep) {
                if (!native_kvmem_conversation->runtime()
                         .commit_resident_selection(resident)) {
                    throw std::logic_error("native cached Q could not keep its resident view");
                }
                staged.native_cached_preselected = true;
            } else {
                const auto& attention = *parameters.model.config().text.attention;
                auto preview =
                    native_kvmem_conversation->preview_cached_query_selection(
                        KVMemRetrievalGeometry{
                            .head_dim = attention.head_dim,
                            .query_heads = attention.num_attention_heads,
                            .kv_heads = attention.num_key_value_heads,
                        }, staged.native_turn_spans->mandatory_begin,
                        staged.prompt_tokens, kvmem.generation_reserve_tokens,
                        kv_capacity, speculative_backend == SpeculativeBackend::Mtp);
                if (!preview) {
                    // The pinned server falls back to a fresh suffix Q when
                    // the old observations plus output would lose any
                    // mandatory block or exceed GPU slots.
                    staged.native_cached_query_fallback = true;
                    staged.native_turn_spans->mandatory_begin =
                        staged.native_turn_spans->replay_begin;
                } else {
                    if (preview->resident_blocks != resident) {
                        throw std::logic_error(
                            "native cached preview changed its resident identity");
                    }
                    KVMemConversation::FollowerTransition follower_transition;
                    std::optional<KVMemFollowerRetainedPages> follower_retained;
                    if (speculative_backend == SpeculativeBackend::Mtp) {
                        if (!backend_kv_pages) {
                            throw std::logic_error("native cached query has no follower page owner");
                        }
                        follower_retained.emplace(*backend_kv_pages,
                            native_kvmem_conversation->runtime().store().block_count());
                        follower_transition.before_target_spill =
                            [&](std::span<const std::uint32_t>,
                                const kvmem::KvMemStore& source,
                                kvmem::RawKvStore& raw) {
                                harvest_native_follower_for_query(
                                    sequence, source, raw, staged.base,
                                    preview->selected_blocks, staged.base - 1U,
                                    *follower_retained);
                                raw.invalidate_packed_from(staged.base - 1U);
                            };
                        follower_transition.after_target_admit =
                            [](const kvmem::KvMemStore&, kvmem::RawKvStore&) {};
                    }
                    if (preview->selected_blocks != resident) {
                        device.synchronize();
                        if (!text_kv_addresses->can_release_after_deactivate(
                                sequence.kv->text) ||
                            (sequence.kv->backend &&
                             !backend_kv_addresses->can_release_after_deactivate(
                                 *sequence.kv->backend))) {
                            throw std::logic_error(
                                "native cached reselect cannot detach its old view");
                        }
                    }
                    const bool changed = native_kvmem_conversation->apply_query_selection(
                        *preview, [&] {
                            if (sequence.kv->backend) {
                                const KVAddressSpaceHandle old = *sequence.kv->backend;
                                if (!backend_kv_addresses->release_after_deactivate(old)) {
                                    throw std::logic_error(
                                        "native cached reselect could not detach follower");
                                }
                                sequence.kv->backend.reset();
                                sequence.native_follower_execution.clear();
                            }
                            const KVAddressSpaceHandle old = sequence.kv->text;
                            if (!text_kv_addresses->release_after_deactivate(old)) {
                                throw std::logic_error(
                                    "native cached reselect could not detach target");
                            }
                            sequence.kv.reset();
                        }, follower_transition);
                    if (changed) {
                        const std::uint32_t append_reserve =
                            std::min(block_tokens, staged.prompt_tokens - staged.base);
                        const std::optional<std::uint32_t> deferred_follower_row =
                            speculative_backend == SpeculativeBackend::Mtp
                                ? std::optional<std::uint32_t>{staged.base - 1U}
                                : std::nullopt;
                        install_native_selected_writer(preview->selected_blocks,
                                                       append_reserve,
                                                       follower_retained ? &*follower_retained
                                                                         : nullptr,
                                                       deferred_follower_row);
                    }
                    staged.native_cached_preselected = true;
                }
            }
            if (staged.native_cached_preselected) {
                // Native freezes Q only after keep/reselect proves both the
                // observed band and the complete future append. The retained
                // SessionMetadata remains the query source; this bounded
                // capture workspace is now K-only, for short and sparse turns.
                staged.native_features->begin_query(
                    checked_i32(staged.native_turn_spans->capture_begin,
                                "native frozen query begin"), 0);
            }
        }
#endif

        if (staged.mtp_bridge == MtpBridgeMode::BeforeSuffix) {
            if (staged.cursor != staged.base || staged.base == 0 ||
                staged.cursor >= staged.prompt_tokens) {
                throw std::logic_error("staged MTP bridge is outside the reusable suffix");
            }
            mark_workspace_usage(workspace_plan.mtp_prefill);
            const Tensor& previous_hidden = sequence.tail_hidden;
            const execution::MtpBridgeInput bridge{
                .previous_hidden = &previous_hidden,
                .position        = checked_i32(sequence.mtp_kv_valid,
                                               "MTP bridge cache position"),
                .rope_position   = prompt_rope_position(staged.prompt, staged.base - 1),
            };
            if (staged.vision) {
                execution::mtp_bridge_multimodal(schedule_state, staged.prompt, *staged.vision,
                                                 bridge);
            } else {
                Tensor bridge_token = io.mtp->target_input_ids.slice(0, 0, 1);
                const TokenId token = staged.prompt.token_ids[staged.base];
                CUDA_CHECK(cudaMemcpyAsync(bridge_token.data, &token, sizeof(token),
                                           cudaMemcpyHostToDevice, device.stream));
                execution::mtp_bridge_and_propose(schedule_state, bridge_token, previous_hidden,
                                                  bridge.position, bridge.rope_position, false);
            }
            sequence.mtp_kv_valid = sequence.text_kv_valid;
            commit_sequence_kv(sequence, sequence.text_kv_valid, sequence.mtp_kv_valid);
#if defined(NINFER_WITH_KVMEM)
            if (kvmem.enabled && sequence.compact_kv_frontier) {
                refresh_native_follower_execution(sequence);
            }
#endif
            staged.mtp_bridge = MtpBridgeMode::None;
        }

        if (staged.cursor < staged.prompt_tokens) {
            // A sparse native request cannot sample until the completed user
            // query has been considered by the Store. The MTP final follower
            // column needs that sampled token too, so it is bridged afterward.
            const bool native_defer_target_sample =
                kvmem.enabled &&
                (speculative_backend == SpeculativeBackend::None ||
                 (speculative_backend == SpeculativeBackend::Mtp &&
                  staged.prompt_tokens > kvmem.history_budget_tokens));
            if (kvmem.enabled && speculative_backend != SpeculativeBackend::None &&
                speculative_backend != SpeculativeBackend::Mtp &&
                staged.prompt_tokens > kvmem.history_budget_tokens) {
                throw std::logic_error("native draft backend has no selected history view");
            }
            const std::uint32_t nominal =
                std::min(prefill_chunk, staged.prompt_tokens - staged.cursor);
            mark_workspace_usage(staged.prepare_mtp ? workspace_plan.mtp_prefill
                                                    : workspace_plan.text_prefill);
            if (is_masked_draft_backend(speculative_backend)) {
                mark_workspace_usage(workspace_plan.dflash_context);
            }
            std::uint32_t remaining          = nominal;
            std::uint32_t final_chunk_tokens = 0;
            bool finalized                   = false;
            while (remaining != 0) {
                schedule_state.text_kv_base           = staged.cursor;
                schedule_state.cache_kv_base          = sequence.compact_kv_frontier;
                selectors                             = state_selectors(sequence);
#if defined(NINFER_WITH_KVMEM)
                const bool native_media_checkpoint = kvmem.enabled &&
                    next_native_media_checkpoint(staged.prompt, staged.cursor,
                                                 speculative_backend, true) == staged.cursor;
                const bool native_query_checkpoint = staged.native_turn_spans &&
                    staged.cursor == staged.native_turn_spans->replay_begin &&
                    !staged.native_query_checkpoint;
                if (kvmem.enabled && !staged.native_replaying &&
                    (native_media_checkpoint || native_query_checkpoint)) {
                    if ((speculative_backend != SpeculativeBackend::None &&
                         speculative_backend != SpeculativeBackend::Mtp) ||
                        (staged.reuse != ReusePath::Root &&
                         (staged.reuse != ReusePath::PrivateEndpoint ||
                          !sequence.compact_kv_frontier)) ||
                        selectors.source != selectors.destination ||
                        !native_kvmem_conversation ||
                        native_kvmem_conversation->runtime().store().total_tokens() !=
                            staged.cursor) {
                        throw std::logic_error(
                            "native media/query boundary has no consistent recurrent checkpoint source");
                    }
                    if (native_media_checkpoint && staged.native_query_checkpoint &&
                        staged.native_query_checkpoint->state().logical_frontier == staged.cursor) {
                        // No forward occurred since the query capture at this boundary.
                        remember_native_checkpoint(sequence, staged.native_query_checkpoint, true);
                    } else {
                        auto checkpoint = capture_native_checkpoint(
                            sequence, staged.cursor, native_media_checkpoint);
                        if (native_query_checkpoint) {
                            staged.native_query_checkpoint = std::move(checkpoint);
                            staged.native_query_view_changed = false;
                        }
                    }
                }
#endif
                schedule_state.state_source_slot      = selectors.source;
                schedule_state.state_destination_slot = selectors.destination;
                if (staged.next_capture < staged.capture_groups.size()) {
                    rewrite_capture_hidden =
                        state_images->continuation_hidden_slot(selectors.destination);
                    schedule_state.rewrite_checkpoint_hidden = &rewrite_capture_hidden;
                } else {
                    schedule_state.rewrite_checkpoint_hidden = nullptr;
                }

                const bool final_candidate = staged.cursor + remaining == staged.prompt_tokens;
                const std::optional<std::uint32_t> capture_frontier =
                    staged.next_capture < staged.capture_groups.size()
                        ? std::optional<std::uint32_t>(
                              staged.capture_groups[staged.next_capture].frontier)
                        : std::nullopt;
                std::optional<std::uint32_t> split_frontier = capture_frontier;
                const auto rewrite_split                    = std::upper_bound(
                    staged.prompt.identity.rewrite_execution_frontiers.begin(),
                    staged.prompt.identity.rewrite_execution_frontiers.end(), staged.cursor);
                if (rewrite_split != staged.prompt.identity.rewrite_execution_frontiers.end() &&
                    (!split_frontier || *rewrite_split < *split_frontier)) {
                    split_frontier = *rewrite_split;
                }
                if (kvmem.enabled) {
                    // Native storage keeps 128-token blocks, but an aligned
                    // admitted forward may span several of them. Logical
                    // query/replay/capture boundaries remain exact.
                    const auto split_at = [&](std::uint32_t frontier) {
                        if (frontier > staged.cursor && frontier <= staged.prompt_tokens &&
                            (!split_frontier || frontier < *split_frontier)) {
                            split_frontier = frontier;
                        }
                    };
#if defined(NINFER_WITH_KVMEM)
                    if (!staged.native_turn_spans) {
                        throw std::logic_error("native KVMem prefill lost its turn boundaries");
                    }
                    const KVMemTurnSpans& turn = *staged.native_turn_spans;
                    split_at(turn.capture_begin);
                    split_at(turn.capture_end);
                    split_at(turn.mandatory_begin);
                    split_at(turn.mandatory_end);
                    split_at(turn.replay_begin);
                    if (const auto media = next_native_media_checkpoint(
                            staged.prompt, staged.cursor, speculative_backend)) {
                        split_at(*media);
                    }
#endif
                }
                std::uint32_t native_append_tokens = 0;
#if defined(NINFER_WITH_KVMEM)
                std::optional<KVMemConversation::AppendPlan> native_append;
                std::optional<execution::AttentionFeatureCapture> native_capture;
                bool native_partial_pressure = false;
#endif
                if (kvmem.enabled) {
                    // Native register_append must run before forward with the
                    // *actual* microbatch length. Vision may cap the chunk at
                    // the next media boundary after the generic split logic.
                    // Keep this preview adjacent to the forward call so its
                    // eventual admission transaction cannot reserve a longer
                    // block than TextContext will actually write.
                    native_append_tokens =
                        std::min({remaining, prefill_chunk, capacity, kv_capacity});
                    if (split_frontier && *split_frontier > staged.cursor) {
                        native_append_tokens =
                            std::min(native_append_tokens, *split_frontier - staged.cursor);
                    }
                    if (staged.vision) {
                        native_append_tokens =
                            staged.vision->chunk_length(staged.cursor, native_append_tokens);
                    }
                    if (native_append_tokens == 0) {
                        throw std::logic_error("native prefill has an empty append segment");
                    }
#if defined(NINFER_WITH_KVMEM)
                    if (!staged.native_features || !staged.native_turn_spans ||
                        !native_kvmem_conversation || !native_kvmem_backend ||
                        native_kvmem_conversation->runtime().store().total_tokens() !=
                            (staged.native_replaying ? staged.prompt_tokens : staged.cursor)) {
                        throw std::logic_error("native prefill lost its conversation frontier");
                    }
                    // Replay already owns a proved contiguous mandatory
                    // suffix and does not append Store rows or capture Q/K
                    // again. Batch it within the existing forward/media/state
                    // boundaries, not the native storage block size. Cached-Q
                    // suffix inputs use the same pinned whole-slot admission
                    // as generation, without another prefill pressure policy.
                    const auto append_limit = staged.native_replaying
                        ? native_append_tokens
                        : native_kvmem_conversation->prefill_append_limit(
                              native_append_tokens, kv_capacity,
                              staged.native_cached_preselected);
                    native_append_tokens = std::min(native_append_tokens, append_limit);
                    if (native_append_tokens == 0) {
                        throw std::logic_error("native prefill has no physical append headroom");
                    }
#endif
                    const std::uint32_t chunk_end = staged.cursor + native_append_tokens;
                    // TextContext must execute precisely the admitted rows,
                    // including physical-capacity and media bounds, not merely
                    // the nominal configured prefill chunk.
                    if (!split_frontier || chunk_end < *split_frontier) {
                        split_frontier = chunk_end;
                    }
#if defined(NINFER_WITH_KVMEM)
                    if (staged.native_replaying) {
                        if (!staged.native_query_selection ||
                            !staged.native_query_selection->replay_fits ||
                            native_kvmem_conversation->runtime().pending() ||
                            (speculative_backend != SpeculativeBackend::None &&
                             speculative_backend != SpeculativeBackend::Mtp)) {
                            throw std::logic_error("native query replay has no settled selection");
                        }
                    } else {
                        // An existing GPU tail can grow without a new slot, but
                        // it must still honor native prefill pressure unless the
                        // query selection is pinned. Prepare pressure against
                        // its OLD accepted geometry, reinstall that prefix,
                        // then register the new rows. Extending metadata first
                        // would make the old slot/follower appear to contain
                        // rows that forward has not produced yet.
                        const std::uint32_t tail_tokens =
                            staged.cursor % kvmem.block_tokens;
                        const auto& native_store =
                            native_kvmem_conversation->runtime().store();
                        const bool resident_tail =
                            tail_tokens != 0 && !native_store.blocks().empty() &&
                            native_store.blocks().back().orig_pos_end() == staged.cursor &&
                            native_store.blocks().back().gpu_slot >= 0;
                        const bool materialized_tail =
                            staged.native_materialized_tail_tokens != 0 &&
                            staged.native_materialized_tail_tokens <= tail_tokens;
                        const bool current_request_tail =
                            staged.native_materialized_tail_tokens == 0 &&
                            staged.cursor > staged.base &&
                            resident_tail &&
                            native_store.blocks().back().orig_pos_start >= staged.base;
                        const bool committed_writers =
                            sequence.kv &&
                            text_kv_addresses->committed_frontier(sequence.kv->text) ==
                                sequence.text_kv_valid &&
                            (speculative_backend != SpeculativeBackend::Mtp ||
                             (sequence.kv->backend &&
                              backend_kv_addresses->committed_frontier(
                                  *sequence.kv->backend) == sequence.mtp_kv_valid &&
                              sequence.mtp_kv_valid == sequence.text_kv_valid));
                        if (tail_tokens != 0) {
                            if (!resident_tail || !committed_writers ||
                                (!materialized_tail && !current_request_tail) ||
                                native_append_tokens > kvmem.block_tokens - tail_tokens) {
                                throw std::logic_error(
                                    "native partial append has no committed current tail view");
                            }
                            if (!staged.native_cached_preselected) {
                                native_partial_pressure =
                                    native_kvmem_conversation->prepare_partial_tail_pressure(
                                        native_append_tokens, kv_capacity);
                            }
                            if (!native_partial_pressure &&
                                (sequence.text_kv_valid > kv_capacity ||
                                 native_append_tokens > kv_capacity - sequence.text_kv_valid)) {
                                throw std::logic_error(
                                    "native partial append exceeds its pinned execution view");
                            }
                        }
                        if (!native_partial_pressure) {
                            native_append = native_kvmem_conversation->plan_prefill_append(
                                native_append_tokens, kv_capacity,
                                tail_tokens != 0 || staged.native_cached_preselected);
                        }
                        if (tail_tokens != 0 && native_append &&
                            (native_append->pressure ||
                             native_append->prior_tail_tokens != tail_tokens ||
                             native_append->incoming_blocks.size() != 1U)) {
                            throw std::logic_error(
                                "native pinned tail append escaped its existing GPU block");
                        }
                    }
                    if (native_partial_pressure || (native_append && native_append->pressure)) {
                        // The pinned adapter spills before dropping its live KV
                        // cells, then admits the chosen blocks. NInfer must
                        // release its address references in the middle of that
                        // transaction or the slot pages cannot be freed.
                        if ((speculative_backend != SpeculativeBackend::None &&
                             speculative_backend != SpeculativeBackend::Mtp) ||
                            (staged.reuse != ReusePath::Root &&
                             (staged.reuse != ReusePath::PrivateEndpoint ||
                              !sequence.compact_kv_frontier)) ||
                            !sequence.kv ||
                            (speculative_backend == SpeculativeBackend::None &&
                             sequence.kv->backend) ||
                            (speculative_backend == SpeculativeBackend::Mtp &&
                             (!sequence.kv->backend ||
                              (sequence.native_follower_execution.empty() &&
                               sequence.mtp_kv_valid != 0))) ||
                            (!native_partial_pressure &&
                             (staged.cursor % kvmem.block_tokens != 0 ||
                              !native_append || native_append->prior_tail_tokens != 0 ||
                              staged.native_materialized_tail_tokens != 0)) ||
                            (native_partial_pressure &&
                             (staged.cursor % kvmem.block_tokens == 0 || native_append))) {
                            throw std::logic_error(
                                "native prefill pressure has no committed compatible writer");
                        }
                        device.synchronize();
                        const KVAddressSpaceHandle old_writer = sequence.kv->text;
                        const std::optional<KVAddressSpaceHandle> old_follower =
                            sequence.kv->backend;
                        if (!text_kv_addresses->can_release_after_deactivate(old_writer)) {
                            throw std::logic_error(
                                "native pressure cannot detach its current execution view");
                        }
                        if (old_follower &&
                            !backend_kv_addresses->can_release_after_deactivate(*old_follower)) {
                            throw std::logic_error(
                                "native pressure cannot detach its MTP execution view");
                        }
                        if (native_partial_pressure) {
                            const auto& tail = native_kvmem_conversation->runtime().store().blocks().back();
                            if (staged.native_materialized_tail_tokens < tail.n_tokens) {
                                std::optional<KVMemPrefillFollowerCommit> follower;
                                if (old_follower) {
                                    follower = KVMemPrefillFollowerCommit{
                                        .addresses = backend_kv_addresses.get(),
                                        .address = *old_follower,
                                        .committed_frontier = sequence.mtp_kv_valid,
                                        .records = &sequence.native_follower_execution,
                                    };
                                }
                                text_kv_addresses->deactivate(old_writer);
                                staged.native_materialized_tail_tokens = commit_kvmem_prefill_blocks(
                                    native_kvmem_conversation->runtime().store(),
                                    *native_kvmem_backend, *text_kv_addresses, old_writer,
                                    KVMemPrefillCommitSpan{
                                        .logical_begin = tail.orig_pos_start +
                                            staged.native_materialized_tail_tokens,
                                        .logical_end = staged.cursor,
                                        .execution_end = sequence.text_kv_valid,
                                        .materialized_tail_tokens = staged.native_materialized_tail_tokens,
                                        .publish_partial_tail = true,
                                    }, follower ? &*follower : nullptr);
                            }
                        }
                        KVMemConversation::FollowerTransition follower_transition;
                        std::optional<KVMemFollowerRetainedPages> follower_retained;
                        if (old_follower) {
                            if (!backend_kv_pages) {
                                throw std::logic_error("native pressure has no follower page owner");
                            }
                            follower_retained.emplace(
                                *backend_kv_pages,
                                native_kvmem_conversation->runtime().store().block_count());
                            follower_transition.before_target_spill =
                                [&](std::span<const std::uint32_t> outgoing,
                                    const kvmem::KvMemStore& store,
                                    kvmem::RawKvStore& raw) {
                                    // Spill only evicted follower blocks. Kept
                                    // full/partial prefixes retain their actual
                                    // row coverage before address detachment.
                                    harvest_native_follower(sequence, store, raw,
                                                            outgoing, staged.cursor,
                                                            *follower_retained);
                                };
                            follower_transition.after_target_admit =
                                [&](const kvmem::KvMemStore& store,
                                    kvmem::RawKvStore& raw) {
                                    // The new MTP writer is built immediately
                                    // after this native transaction settles.
                                    for (const auto& block : store.blocks()) {
                                        if (!block.in_working_set ||
                                            block.orig_pos_start >= staged.cursor) { continue; }
                                        const bool partial_tail = native_partial_pressure &&
                                            block.n_tokens < kvmem.block_tokens &&
                                            block.orig_pos_end() == staged.cursor;
                                        const bool retained_rows =
                                            follower_retained->has(block.block_id) &&
                                            follower_retained->committed_rows(block.block_id) >=
                                                block.n_tokens;
                                        if ((block.n_tokens != kvmem.block_tokens && !partial_tail) ||
                                            (!retained_rows &&
                                             (!raw.has_k_gpu(block.block_id, 0,
                                                             block.n_tokens) ||
                                              !raw.has_v_gpu(block.block_id, 0,
                                                             block.n_tokens)))) {
                                            throw std::logic_error(
                                                "native pressure selected history without resident or packed MTP rows");
                                        }
                                    }
                                };
                        }
                        native_kvmem_conversation->apply_prefill_pressure(
                            staged.cursor, [&] {
                                if (old_follower) {
                                    if (!backend_kv_addresses->release_after_deactivate(
                                            *old_follower)) {
                                        throw std::logic_error(
                                            "native pressure could not detach its MTP view");
                                    }
                                    sequence.kv->backend.reset();
                                    sequence.native_follower_execution.clear();
                                }
                                if (!text_kv_addresses->release_after_deactivate(old_writer)) {
                                    throw std::logic_error(
                                        "native pressure could not detach its old execution view");
                                }
                                sequence.kv.reset();
                            }, follower_transition);
                        const auto& pressure_plan =
                            native_kvmem_conversation->runtime().last_plan();
                        if (staged.native_query_checkpoint &&
                            (!pressure_plan.stage_in.empty() ||
                             !pressure_plan.stage_out.empty())) {
                            staged.native_query_view_changed = true;
                        }

                        const auto& selected_store =
                            native_kvmem_conversation->runtime().store();
                        std::vector<std::uint32_t> selected_history;
                        for (const kvmem::KvMemBlock& block : selected_store.blocks()) {
                            if (!block.in_working_set ||
                                block.orig_pos_start >= staged.cursor) { continue; }
                            const bool partial_tail = native_partial_pressure &&
                                block.n_tokens < kvmem.block_tokens &&
                                block.orig_pos_end() == staged.cursor;
                            if (block.orig_pos_end() > staged.cursor ||
                                (block.n_tokens != kvmem.block_tokens && !partial_tail) ||
                                block.gpu_slot < 0) {
                                throw std::logic_error(
                                    "native pressure selected an unmaterialized history block");
                            }
                            selected_history.push_back(block.block_id);
                        }
                        install_native_selected_writer(
                            selected_history, native_append_tokens,
                            follower_retained ? &*follower_retained : nullptr,
                            native_partial_pressure && old_follower
                                ? std::optional<std::uint32_t>{staged.cursor} : std::nullopt);
                        if (native_partial_pressure) {
                            native_append = native_kvmem_conversation->plan_prefill_append(
                                native_append_tokens, kv_capacity, true);
                            if (native_append->pressure ||
                                native_append->prior_tail_tokens != staged.cursor % kvmem.block_tokens ||
                                native_append->incoming_blocks.size() != 1U) {
                                throw std::logic_error(
                                    "native tail append changed its settled pressure view");
                            }
                        }
                    }
                    const KVMemTurnSpans& turn = *staged.native_turn_spans;
                    if (!staged.native_replaying) {
                        // Pinned KVMem replays attention K/V but leaves the
                        // first-pass mean-K and query scores untouched.
                        const std::uint32_t query_first =
                            std::max(staged.cursor, turn.capture_begin);
                        const std::uint32_t query_end =
                            std::min(chunk_end, turn.capture_end);
                        native_capture = staged.native_features->begin_segment(
                            KVMemFeatureSegment{
                                .logical_frontier = checked_i32(chunk_end, "native feature frontier"),
                                .key_first = checked_i32(staged.cursor, "native key begin"),
                                .key_count = checked_i32(native_append_tokens, "native key length"),
                                .query_first = checked_i32(std::min(query_first, chunk_end),
                                                           "native query begin"),
                                .query_count = checked_i32(
                                    !staged.native_cached_preselected && query_end > query_first
                                        ? query_end - query_first : 0U,
                                    "native query length"),
                            }, device.stream);
                        schedule_state.execution.attention_features = &*native_capture;
                    }
#endif
                    const std::uint32_t cache_end =
                        sequence.compact_kv_frontier.value_or(staged.cursor) +
                        native_append_tokens;
                    // MTP attention follows the physical execution view, not the
                    // original RoPE/token coordinate after native selection.
                    const std::uint32_t backend_end =
                        speculative_backend == SpeculativeBackend::Mtp
                            ? std::min(capacity,
                                       cache_end + (chunk_end == staged.prompt_tokens &&
                                                            staged.initial_mtp_extent != 0
                                                        ? staged.initial_mtp_extent - 1U
                                                        : 0U))
                            : speculative_backend == SpeculativeBackend::DFlash ? chunk_end : 0U;
                    ensure_sequence_kv_mapped(sequence, cache_end, backend_end);
                }
                execution::PrefillChunkResult result;
                timing.pause();
                if (staged.vision) {
                    if (!workspace_plan.vision) {
                        throw std::logic_error("active Vision prefill lost its workspace plan");
                    }
                    mark_workspace_usage(workspace_plan.vision->capacity_bytes);
                    result = execution::prefill_multimodal_chunk(schedule_state, staged.prompt,
                                                                 *staged.vision, remaining,
                                                                 split_frontier,
                                                                 final_candidate && !native_defer_target_sample);
                } else {
                    result = execution::prefill_text_chunk(
                        schedule_state, std::span<const TokenId>(staged.prompt.token_ids),
                        remaining, split_frontier,
                        final_candidate && !native_defer_target_sample);
                }
#if defined(NINFER_WITH_KVMEM)
                schedule_state.execution.attention_features = nullptr;
#endif
                timing.include(result.timing);
                timing.resume_post();
                if (result.processed_tokens == 0 || result.processed_tokens > remaining) {
                    throw std::logic_error("ordinary prefill chunk made invalid progress");
                }
                if (kvmem.enabled && result.processed_tokens != native_append_tokens) {
                    throw std::logic_error("native prefill changed its previewed append length");
                }
#if defined(NINFER_WITH_KVMEM)
                if (native_append) {
                    // The capture kernels use the same stream as the accepted
                    // forward. Do not publish a partial Q/K sum or row map.
                    CUDA_CHECK(cudaStreamSynchronize(device.stream));
                    staged.native_features->copy_sums_to_host();
                    staged.native_features->commit_accepted_segment(
                        checked_i32(staged.cursor, "native accepted key begin"),
                        checked_i32(result.processed_tokens, "native accepted key length"));
                    auto& rows = native_kvmem_conversation->metadata().row_positions;
                    const std::size_t prompt_size = staged.prompt.token_ids.size();
                    if (rows.size() != staged.cursor ||
                        staged.prompt.positions.size() != 3U * prompt_size ||
                        staged.prompt.token_types.size() != prompt_size) {
                        throw std::logic_error("native row-position metadata is incomplete");
                    }
                    rows.reserve(native_append->new_frontier);
                    for (std::uint32_t pos = staged.cursor;
                         pos < native_append->new_frontier; ++pos) {
                        const auto axis0 = staged.prompt.positions[pos];
                        rows.push_back(KVMemConversation::RowPosition{
                            .pos = {axis0, staged.prompt.positions[prompt_size + pos],
                                    staged.prompt.positions[2U * prompt_size + pos], axis0},
                            // Embedding-only rows have no upstream token pointer.
                            .token = staged.prompt.token_types[pos] == 0
                                         ? staged.prompt.token_ids[pos] : -1,
                            .spatial = true,
                        });
                    }
                }
#endif
                if (staged.vision) { staged.vision->release_encoded_media_payloads(); }
                staged.cursor += result.processed_tokens;
#if defined(NINFER_WITH_KVMEM)
                if (!staged.native_replaying) {
                    processed_prompt_tokens += result.processed_tokens;
                }
#else
                processed_prompt_tokens += result.processed_tokens;
#endif
                remaining -= result.processed_tokens;
                final_chunk_tokens     = result.processed_tokens;
#if defined(NINFER_WITH_KVMEM)
                if (native_append && staged.native_turn_spans &&
                    staged.cursor == staged.native_turn_spans->capture_end) {
                    auto& metadata = native_kvmem_conversation->metadata();
                    if (staged.native_cached_query_fallback ||
                        !can_reuse_exact_query(staged.prompt, metadata,
                                               *staged.native_turn_spans, staged.base,
                                               kvmem.query_max_tokens)) {
                        record_native_query(metadata, staged.prompt, *staged.native_turn_spans,
                                            staged.native_features->host_query_layers());
                    }
                }
#endif
                const std::uint32_t accepted_cache_end =
                    sequence.compact_kv_frontier
                        ? *sequence.compact_kv_frontier + result.processed_tokens
                        : staged.cursor;
                const bool native_deferred_mtp_last_row =
                    native_defer_target_sample && staged.prepare_mtp &&
                    staged.cursor == staged.prompt_tokens;
                if (sequence.compact_kv_frontier) {
                    *sequence.compact_kv_frontier = accepted_cache_end;
                }
                sequence.text_kv_valid = accepted_cache_end;
                if (staged.prepare_mtp) {
                    if (native_deferred_mtp_last_row && accepted_cache_end == 0) {
                        throw std::logic_error("native MTP deferred row has no predecessor");
                    }
                    sequence.mtp_kv_valid =
                        accepted_cache_end - (native_deferred_mtp_last_row ? 1U : 0U);
                }
                if (is_masked_draft_backend(speculative_backend)) {
                    sequence.dflash_context_frontier = staged.cursor;
                }
                commit_sequence_kv(sequence, sequence.text_kv_valid, backend_kv_valid(sequence));

#if defined(NINFER_WITH_KVMEM)
                if ((native_append || staged.native_replaying) &&
                    (staged.cursor / kvmem.block_tokens >
                         (staged.cursor - result.processed_tokens) / kvmem.block_tokens ||
                     staged.cursor == staged.prompt_tokens)) {
                    const auto& store = native_kvmem_conversation->runtime().store();
                    std::optional<KVMemPrefillFollowerCommit> follower;
                    if (staged.prepare_mtp &&
                        speculative_backend == SpeculativeBackend::Mtp &&
                        (staged.reuse == ReusePath::Root ||
                         (staged.reuse == ReusePath::PrivateEndpoint &&
                          sequence.compact_kv_frontier))) {
                        if (!sequence.kv->backend || !backend_kv_addresses) {
                            throw std::logic_error(
                                "native MTP block has no committed follower address");
                        }
                        follower = KVMemPrefillFollowerCommit{
                            .addresses = backend_kv_addresses.get(),
                            .address = *sequence.kv->backend,
                            .committed_frontier = sequence.mtp_kv_valid,
                            .records = &sequence.native_follower_execution,
                        };
                    }
                    const auto address = sequence.kv->text;
                    const std::uint32_t entitlement = text_kv_addresses->entitlement(address);
                    text_kv_addresses->deactivate(address);
                    staged.native_materialized_tail_tokens = commit_kvmem_prefill_blocks(
                        store, *native_kvmem_backend, *text_kv_addresses, address,
                        KVMemPrefillCommitSpan{
                            .logical_begin = staged.cursor - result.processed_tokens,
                            .logical_end = staged.cursor,
                            .execution_end = sequence.text_kv_valid,
                            .materialized_tail_tokens = staged.native_materialized_tail_tokens,
                            .replay = staged.native_replaying,
                            .publish_partial_tail = staged.cursor == staged.prompt_tokens,
                            .deferred_follower_last_row = native_deferred_mtp_last_row,
                        }, follower ? &*follower : nullptr);
                    text_kv_addresses->activate(address, entitlement,
                                                static_cast<std::int32_t>(sequence.lane),
                                                device.stream);
                }
#endif

                if (native_defer_target_sample && staged.cursor == staged.prompt_tokens) {
                    // A long prompt must finish its first query pass before
                    // the native Store can rank archived blocks. Keep the
                    // first token behind selection and replay, not merely
                    // behind the physical prefill frontier.
#if defined(NINFER_WITH_KVMEM)
                    if (staged.prompt_tokens > kvmem.history_budget_tokens &&
                        !staged.native_replaying) {
                        if (!staged.native_turn_spans ||
                            !staged.native_turn_spans->retrieve ||
                            !staged.native_query_checkpoint ||
                            !native_kvmem_conversation ||
                            staged.native_query_checkpoint->state().logical_frontier !=
                                staged.native_turn_spans->replay_begin) {
                            throw std::logic_error(
                                "native long query has no complete replay boundary");
                        }
                        // The pinned multimodal server's same-query can_append
                        // path keeps its selected view when every subsequent
                        // observation is already visible and the generation
                        // reserve fits. Do the same after this first pass;
                        // unlike the upstream early precheck, this conservative
                        // proof never changes selection before prefill.
                        const auto keep_cached_query = [&] {
                            const KVMemTurnSpans& turn = *staged.native_turn_spans;
                            const auto& conversation = *native_kvmem_conversation;
                            if (!can_reuse_exact_query(staged.prompt,
                                                       conversation.metadata(), turn,
                                                       staged.base, kvmem.query_max_tokens) ||
                                staged.native_query_view_changed || !sequence.kv ||
                                !sequence.compact_kv_frontier ||
                                *sequence.compact_kv_frontier != sequence.text_kv_valid ||
                                text_kv_addresses->committed_frontier(sequence.kv->text) !=
                                    sequence.text_kv_valid) {
                                return false;
                            }
                            const auto& store = conversation.runtime().store();
                            if (store.total_tokens() != staged.prompt_tokens ||
                                conversation.runtime().pending()) {
                                return false;
                            }
                            std::vector<std::uint32_t> resident;
                            std::uint64_t visible_rows = 0;
                            for (const kvmem::KvMemBlock& block : store.blocks()) {
                                const bool observed =
                                    block.orig_pos_end() > turn.mandatory_begin &&
                                    block.orig_pos_start < staged.prompt_tokens;
                                if (observed && block.gpu_slot < 0) { return false; }
                                if (block.gpu_slot < 0) { continue; }
                                if (block.tier != kvmem::KvTier::GPU ||
                                    block.in_flight || block.n_tokens == 0) {
                                    return false;
                                }
                                resident.push_back(block.block_id);
                                visible_rows += block.n_tokens;
                            }
                            const std::uint64_t final_rows =
                                visible_rows + kvmem.generation_reserve_tokens;
                            if (visible_rows != sequence.text_kv_valid ||
                                final_rows > kv_capacity ||
                                (final_rows + kvmem.block_tokens - 1U) /
                                        kvmem.block_tokens >
                                    kv_capacity / kvmem.block_tokens) {
                                return false;
                            }
                            if (speculative_backend == SpeculativeBackend::Mtp) {
                                if (!sequence.kv->backend ||
                                    sequence.mtp_kv_valid + 1U != sequence.text_kv_valid ||
                                    backend_kv_addresses->committed_frontier(
                                        *sequence.kv->backend) != sequence.mtp_kv_valid) {
                                    return false;
                                }
                                const auto& follower = sequence.native_follower_execution;
                                std::size_t follower_index = 0;
                                std::uint32_t execution = 0;
                                for (const std::uint32_t id : resident) {
                                    const auto& block = store.blocks()[id];
                                    const std::uint32_t rows =
                                        block.n_tokens -
                                        (block.orig_pos_end() == staged.prompt_tokens ? 1U : 0U);
                                    if (rows == 0) { continue; }
                                    if (follower_index >= follower.size() ||
                                        follower[follower_index].native_block_id != id ||
                                        follower[follower_index].original_position !=
                                            block.orig_pos_start ||
                                        follower[follower_index].execution_begin != execution ||
                                        follower[follower_index].committed_rows != rows) {
                                        return false;
                                    }
                                    execution += rows;
                                    ++follower_index;
                                }
                                if (follower_index != follower.size() ||
                                    execution != sequence.mtp_kv_valid) {
                                    return false;
                                }
                                (void)KVMemFollowerExecutionMap::resolve(
                                    follower, *backend_kv_addresses, *sequence.kv->backend);
                            } else if (sequence.kv->backend) {
                                return false;
                            }
                            if (!native_kvmem_conversation->runtime()
                                     .commit_resident_selection(resident)) {
                                throw std::logic_error(
                                    "native cached query could not pin its proven resident view");
                            }
                            return true;
                        }();
                        if (!keep_cached_query) {
                            const auto& attention = *parameters.model.config().text.attention;
                            staged.native_query_selection =
                                native_kvmem_conversation->preview_query_selection(
                                    KVMemRetrievalGeometry{
                                        .head_dim    = attention.head_dim,
                                        .query_heads = attention.num_attention_heads,
                                        .kv_heads    = attention.num_key_value_heads,
                                    },
                                    staged.native_turn_spans->mandatory_begin,
                                    staged.native_turn_spans->mandatory_end,
                                    staged.native_turn_spans->replay_begin);
                            if (staged.native_turn_spans->mandatory_begin <
                                    staged.native_turn_spans->replay_begin &&
                                !std::includes(
                                    staged.native_query_selection->selected_blocks.begin(),
                                    staged.native_query_selection->selected_blocks.end(),
                                    staged.native_query_selection->mandatory_blocks.begin(),
                                    staged.native_query_selection->mandatory_blocks.end())) {
                                // A media group or sink may consume more than the
                                // conservative observed-tail estimate. Re-plan
                                // with the already captured fresh suffix Q, as
                                // the pinned server does when the old observation
                                // band cannot fit; never label a partial band
                                // mandatory and silently drop a tool result.
                                staged.native_turn_spans->mandatory_begin =
                                    staged.native_turn_spans->replay_begin;
                                record_native_query(native_kvmem_conversation->metadata(),
                                                    staged.prompt,
                                                    *staged.native_turn_spans,
                                                    staged.native_features->host_query_layers());
                                staged.native_query_selection =
                                    native_kvmem_conversation->preview_query_selection(
                                        KVMemRetrievalGeometry{
                                            .head_dim    = attention.head_dim,
                                            .query_heads = attention.num_attention_heads,
                                            .kv_heads    = attention.num_key_value_heads,
                                        },
                                        staged.native_turn_spans->mandatory_begin,
                                        staged.native_turn_spans->mandatory_end,
                                        staged.native_turn_spans->replay_begin);
                            }
                            const auto& selected = staged.native_query_selection->selected_blocks;
                            staged.native_query_replay_fits =
                                staged.native_query_selection->replay_fits;
                            const bool force_rebind_same_selection =
                                staged.native_query_view_changed &&
                                staged.native_query_replay_fits &&
                                selected == staged.native_query_selection->resident_blocks;
                            if (speculative_backend == SpeculativeBackend::Mtp) {
                                KVMemConversation::FollowerTransition follower_transition;
                                if (selected == staged.native_query_selection->resident_blocks &&
                                    !force_rebind_same_selection) {
                                    follower_transition.before_target_spill =
                                        [](std::span<const std::uint32_t>, const kvmem::KvMemStore&,
                                           kvmem::RawKvStore&) {
                                            throw std::logic_error(
                                                "unchanged MTP query unexpectedly spilled follower "
                                                "blocks");
                                        };
                                    follower_transition.after_target_admit =
                                        [](const kvmem::KvMemStore&, kvmem::RawKvStore&) {
                                            throw std::logic_error(
                                                "unchanged MTP query unexpectedly admitted "
                                                "follower blocks");
                                        };
                                    if (native_kvmem_conversation->apply_query_selection(
                                            *staged.native_query_selection,
                                            [] {
                                                throw std::logic_error(
                                                    "unchanged MTP query unexpectedly detached its "
                                                    "view");
                                            },
                                            follower_transition)) {
                                        throw std::logic_error(
                                            "native MTP unchanged query moved its attention view");
                                    }
                                } else {
                                    // Match the pinned server: an oversized query
                                    // keeps its first-pass recurrent state and only
                                    // changes the selected attention view.
                                    device.synchronize();
                                    if (!sequence.kv || !sequence.kv->backend ||
                                        !text_kv_addresses->can_release_after_deactivate(
                                            sequence.kv->text) ||
                                        !backend_kv_addresses->can_release_after_deactivate(
                                            *sequence.kv->backend)) {
                                        throw std::logic_error(
                                            "native MTP query cannot detach its first-pass views");
                                    }
                                    const KVAddressSpaceHandle old_writer   = sequence.kv->text;
                                    const KVAddressSpaceHandle old_follower = *sequence.kv->backend;
                                    if (!backend_kv_pages) {
                                        throw std::logic_error(
                                            "native MTP query has no follower page owner");
                                    }
                                    KVMemFollowerRetainedPages follower_retained(
                                        *backend_kv_pages,
                                        native_kvmem_conversation->runtime().store().block_count());
                                    const std::uint32_t required_follower_frontier =
                                        staged.native_query_replay_fits
                                            ? staged.native_turn_spans->replay_begin
                                            : staged.prompt_tokens - 1U;
                                    follower_transition.before_target_spill =
                                        [&](std::span<const std::uint32_t>,
                                            const kvmem::KvMemStore& store,
                                            kvmem::RawKvStore& raw) {
                                            harvest_native_follower_for_query(
                                                sequence, store, raw, staged.prompt_tokens,
                                                selected, required_follower_frontier,
                                                follower_retained);
                                        };
                                    follower_transition.after_target_admit =
                                        [&](const kvmem::KvMemStore& store, kvmem::RawKvStore&) {
                                            for (const std::uint32_t id : selected) {
                                                if (id >= store.block_count() ||
                                                    store.blocks()[id].gpu_slot < 0) {
                                                    throw std::logic_error(
                                                        "native MTP query selected a nonresident "
                                                        "block");
                                                }
                                            }
                                        };
                                    const bool changed =
                                        native_kvmem_conversation->apply_query_selection(
                                            *staged.native_query_selection,
                                            [&] {
                                                if (!backend_kv_addresses->release_after_deactivate(
                                                        old_follower)) {
                                                    throw std::logic_error("native MTP query could "
                                                                           "not detach follower");
                                                }
                                                sequence.kv->backend.reset();
                                                sequence.native_follower_execution.clear();
                                                if (!text_kv_addresses->release_after_deactivate(
                                                        old_writer)) {
                                                    throw std::logic_error(
                                                        "native MTP query could not detach target");
                                                }
                                                sequence.kv.reset();
                                            },
                                            follower_transition, force_rebind_same_selection);
                                    if (!changed) {
                                        throw std::logic_error(
                                            "native MTP changed query did not move its view");
                                    }
                                    if (!staged.native_query_replay_fits) {
                                        install_native_selected_writer(
                                            selected, 1U, &follower_retained,
                                            staged.prompt_tokens - 1U);
                                    } else {
                                        install_native_replay_writer(
                                            *staged.native_query_selection,
                                            staged.native_turn_spans->replay_begin);
                                        install_native_follower_replay_prefix(
                                            *staged.native_query_selection,
                                            staged.native_turn_spans->replay_begin,
                                            &follower_retained);
                                        const StateImageSelectors replay_selectors =
                                            state_selectors(sequence);
                                        if (replay_selectors.source !=
                                            replay_selectors.destination) {
                                            throw std::logic_error(
                                                "native MTP replay cannot overwrite forked "
                                                "recurrent state");
                                        }
                                        staged.native_query_checkpoint->restore_for_query_replay(
                                            *state_images, replay_selectors.destination,
                                            device.stream);
                                        const KVMemQueryBoundaryState& checkpoint =
                                            staged.native_query_checkpoint->state();
                                        sequence.mtp_drafts        = checkpoint.mtp_draft_tokens;
                                        sequence.mtp_draft_count   = checkpoint.mtp_draft_count;
                                        sequence.tail_hidden_valid = checkpoint.tail_hidden_valid;
                                        native_kvmem_conversation->raw().invalidate_packed_from(
                                            staged.native_turn_spans->replay_begin);
                                        kvmem::RawKvStore* follower_raw =
                                            native_kvmem_conversation->follower_raw();
                                        if (follower_raw == nullptr) {
                                            throw std::logic_error(
                                                "native MTP replay lost its follower Raw mirror");
                                        }
                                        follower_raw->invalidate_packed_from(
                                            staged.native_turn_spans->replay_begin);
                                        staged.native_replaying = true;
                                        staged.cursor = staged.native_turn_spans->replay_begin;
                                        sequence.tail_hidden_valid = false;
                                        staged.elapsed_seconds +=
                                            std::chrono::duration<double>(Clock::now() - started)
                                                .count();
                                        return runtime::PrefillStepResult{
                                            .summary                 = summary,
                                            .processed_prompt_tokens = processed_prompt_tokens,
                                            .timing                  = timing.finish(),
                                        };
                                    }
                                }
                            } else {
                                device.synchronize();
                                if (!sequence.kv || sequence.kv->backend ||
                                    !text_kv_addresses->can_release_after_deactivate(
                                        sequence.kv->text)) {
                                    throw std::logic_error(
                                        "native query selection cannot detach the first-pass view");
                                }
                                const KVAddressSpaceHandle old_writer = sequence.kv->text;
                                const bool changed =
                                    native_kvmem_conversation->apply_query_selection(
                                        *staged.native_query_selection,
                                        [&] {
                                            if (!text_kv_addresses->release_after_deactivate(
                                                    old_writer)) {
                                                throw std::logic_error(
                                                    "native query selection could not detach its "
                                                    "old view");
                                            }
                                            sequence.kv.reset();
                                        },
                                        {}, force_rebind_same_selection);
                                if (changed && !staged.native_query_replay_fits) {
                                    // Match the pinned adapter's no-replay branch: keep
                                    // the first-pass recurrent state, but let future
                                    // attention read the newly selected history.
                                    install_native_selected_writer(
                                        selected, 1U, nullptr, std::nullopt);
                                } else if (changed) {
                                    install_native_replay_writer(
                                        *staged.native_query_selection,
                                        staged.native_turn_spans->replay_begin);
                                    const StateImageSelectors replay_selectors =
                                        state_selectors(sequence);
                                    if (replay_selectors.source != replay_selectors.destination) {
                                        throw std::logic_error(
                                            "native query replay cannot overwrite a forked "
                                            "recurrent state");
                                    }
                                    staged.native_query_checkpoint->restore_for_query_replay(
                                        *state_images, replay_selectors.destination, device.stream);
                                    native_kvmem_conversation->raw().invalidate_packed_from(
                                        staged.native_turn_spans->replay_begin);
                                    staged.native_replaying = true;
                                    staged.cursor = staged.native_turn_spans->replay_begin;
                                    sequence.tail_hidden_valid = false;
                                    staged.elapsed_seconds +=
                                        std::chrono::duration<double>(Clock::now() - started)
                                            .count();
                                    return runtime::PrefillStepResult{
                                        .summary                 = summary,
                                        .processed_prompt_tokens = processed_prompt_tokens,
                                        .timing                  = timing.finish(),
                                    };
                                }
                            }
                        }
                    }
                    if (staged.prompt_tokens > kvmem.history_budget_tokens &&
                        staged.native_replaying &&
                        (!staged.native_query_selection ||
                         sequence.compact_kv_frontier !=
                             staged.native_query_selection->replay_compact_end)) {
                        throw std::logic_error("native replay did not rebuild the selected query suffix");
                    }
                    if (staged.native_replaying &&
                        speculative_backend == SpeculativeBackend::Mtp &&
                        (!sequence.kv || !sequence.kv->backend ||
                         sequence.mtp_kv_valid + 1U != sequence.text_kv_valid)) {
                        throw std::logic_error(
                            "native MTP replay did not leave exactly one deferred follower row");
                    }
#endif
                    if (result.finalized || final_chunk_tokens == 0) {
                        throw std::logic_error("native target prefill finalized inside its final tile");
                    }
                    const Tensor last_hidden = prefill_hidden.slice(
                        1, static_cast<std::int32_t>(final_chunk_tokens) - 1, 1);
                    execution::sample_from_hidden(
                        schedule_state, last_hidden,
                        checked_i32(staged.prompt_tokens, "native prefill sample position"),
                        ops::kSamplePurposePrefill);
                    set_device_i32(io.rope_pos,
                                   checked_i32(staged.prompt_tokens,
                                               "native prefill rope position") +
                                       sequence.rope_delta);
                    if (native_deferred_mtp_last_row) {
                        if (!sequence.kv || !sequence.kv->backend ||
                            sequence.mtp_kv_valid + 1U != sequence.text_kv_valid) {
                            throw std::logic_error(
                                "native MTP final bridge has no one-row follower gap");
                        }
                        copy_tail(sequence, last_hidden);
                        mark_workspace_usage(workspace_plan.mtp_prefill);
                        schedule_state.mtp_kv = mtp_kv_view(sequence);
                        const auto bridge_rope = prompt_rope_position(
                            staged.prompt, staged.prompt_tokens - 1U);
                        execution::mtp_bridge_and_propose(
                            schedule_state, io.token, sequence.tail_hidden,
                            checked_i32(sequence.mtp_kv_valid, "native MTP bridge cache position"),
                            bridge_rope, staged.initial_mtp_extent != 0, nullptr,
                            checked_i32(staged.prompt_tokens + 1U,
                                        "native MTP first draft RoPE position") +
                                sequence.rope_delta);
                        sequence.mtp_kv_valid = sequence.text_kv_valid;
                        commit_sequence_kv(sequence, sequence.text_kv_valid,
                                           sequence.mtp_kv_valid);
#if defined(NINFER_WITH_KVMEM)
                        refresh_native_follower_execution(sequence);
#endif
                    }
                    result.finalized = true;
                }

                // Prompt transitions are canonical immediately. If this was the first write after
                // an immutable source, close the Fork before potentially freezing a new rewrite.
                settle_state_fork(sequence);
#if defined(NINFER_WITH_KVMEM)
                if (kvmem.enabled && !staged.native_replaying && !result.finalized) {
                    const bool media_boundary =
                        next_native_media_checkpoint(staged.prompt, staged.cursor,
                                                     speculative_backend, true) == staged.cursor;
                    const bool query_boundary = staged.native_turn_spans &&
                        staged.cursor == staged.native_turn_spans->replay_begin &&
                        !staged.native_query_checkpoint;
                    if (media_boundary || query_boundary) {
                        copy_tail(sequence, prefill_hidden.slice(
                            1, static_cast<std::int32_t>(final_chunk_tokens) - 1, 1));
                        sequence.tail_hidden_valid = true;
                        // Media is captured on entry to the next forward;
                        // first retain this chunk's last hidden as its tail.
                        if (query_boundary) {
                            staged.native_query_checkpoint = capture_native_checkpoint(
                                sequence, staged.cursor, media_boundary);
                            staged.native_query_view_changed = false;
                        }
                    }
                }
#endif
                const bool reached_capture = capture_frontier && staged.cursor == *capture_frontier;
                if (reached_capture) {
                    if (result.finalized) {
                        // The prompt-frontier state becomes publishable only after the generated
                        // Begin token is committed. commit() emits the offer for this group.
                    } else {
                        staged.elapsed_seconds +=
                            std::chrono::duration<double>(Clock::now() - started).count();
                        if (++next_capture_offer_id_ == 0) { ++next_capture_offer_id_; }
                        staged.pending_capture_offer = next_capture_offer_id_;
                        return runtime::PrefillStepResult{
                            .summary                 = summary,
                            .processed_prompt_tokens = processed_prompt_tokens,
                            .timing                  = timing.finish(),
                        };
                    }
                }

                finalized = result.finalized;
                if (finalized || remaining == 0) { break; }
            }

            if (!finalized) {
                if (staged.cursor == staged.prompt_tokens) {
                    throw std::logic_error("staged prefill reached the prompt without sampling");
                }
                staged.elapsed_seconds +=
                    std::chrono::duration<double>(Clock::now() - started).count();
                return runtime::PrefillStepResult{
                    .summary                 = summary,
                    .processed_prompt_tokens = processed_prompt_tokens,
                    .timing                  = timing.finish(),
                };
            }
            if (staged.cursor != staged.prompt_tokens) {
                throw std::logic_error("staged prefill sampled before the prompt frontier");
            }
            timing.resume_submit();
            if (!(kvmem.enabled && speculative_backend == SpeculativeBackend::Mtp &&
                  staged.prompt_tokens > kvmem.history_budget_tokens)) {
                copy_tail(sequence, prefill_hidden.slice(
                                        1, static_cast<std::int32_t>(final_chunk_tokens) - 1, 1));
            }
        } else {
            mark_workspace_usage(workspace_plan.ordinary_round);
            if (!sequence.tail_hidden_valid) {
                throw std::logic_error("zero-suffix reuse has no target tail hidden");
            }
            execution::sample_from_hidden(schedule_state, sequence.tail_hidden,
                                          checked_i32(staged.prompt_tokens, "sample position"),
                                          ops::kSamplePurposePrefill);
            set_device_i32(io.rope_pos, checked_i32(staged.prompt_tokens, "rope position") +
                                            sequence.rope_delta);
            if (staged.prepare_mtp) {
                if (staged.mtp_bridge != MtpBridgeMode::AfterExactHit) {
                    throw std::logic_error("zero-suffix MTP reuse has no exact-hit bridge");
                }
                mark_workspace_usage(workspace_plan.mtp_prefill);
                const auto bridge_rope =
                    prompt_rope_position(staged.prompt, staged.prompt_tokens - 1);
                execution::mtp_bridge_and_propose(
                    schedule_state, io.token, sequence.tail_hidden,
                    checked_i32(sequence.mtp_kv_valid, "MTP full-prefix bridge cache position"),
                    bridge_rope, staged.initial_mtp_extent != 0, nullptr,
                    checked_i32(staged.prompt_tokens + 1U,
                                "MTP full-prefix first draft RoPE position") +
                        sequence.rope_delta);
                sequence.mtp_kv_valid =
                    sequence.compact_kv_frontier.value_or(staged.prompt_tokens);
                commit_sequence_kv(sequence, sequence.text_kv_valid, sequence.mtp_kv_valid);
#if defined(NINFER_WITH_KVMEM)
                if (kvmem.enabled) { refresh_native_follower_execution(sequence); }
#endif
                staged.mtp_bridge = MtpBridgeMode::None;
            }
        }

        copy_round_token();
        std::array<TokenId, qwen3_5::kMtpDecodeMaximumDrafts> initial_drafts{};
        if (staged.prepare_mtp && staged.initial_mtp_extent != 0) {
            CUDA_CHECK(cudaMemcpyAsync(initial_drafts.data(), io.mtp->draft_tokens.data,
                                       staged.initial_mtp_extent * sizeof(TokenId),
                                       cudaMemcpyDeviceToHost, device.stream));
        }
        timing.begin_wait();
        device.synchronize();
        timing.end_wait();
        staged.elapsed_seconds += std::chrono::duration<double>(Clock::now() - started).count();
        const double vision_seconds       = staged.vision ? staged.vision->elapsed_seconds() : 0.0;
        const std::uint32_t prompt_tokens = staged.prompt_tokens;

        validate_licensed_tokens(std::span<const TokenId>(host_tokens, 1));
        if (sequence.ledger.size() != prompt_tokens) {
            throw std::logic_error("candidate token ledger does not match prompt length");
        }
        sequence.ledger.push_back(host_tokens[0]);
        sequence.prefix_identity.append_generated(1, sequence.rope_delta);
        sequence.prefix_digests.append_generated(std::span<const TokenId>(host_tokens, 1),
                                                 sequence.rope_delta);
        sequence.text_kv_valid =
            sequence.compact_kv_frontier.value_or(prompt_tokens);
#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled) {
            sequence.native_tail_materialized_tokens =
                staged.native_materialized_tail_tokens;
            if (!native_decode_features || !native_kvmem_conversation) {
                throw std::logic_error("native accepted target capture is unavailable");
            }
            native_decode_features->bind_raw(native_kvmem_conversation->raw(),
                                             prompt_tokens);
        }
#endif
        if (staged.prepare_mtp) {
            if (sequence.mtp_kv_valid !=
                sequence.compact_kv_frontier.value_or(prompt_tokens)) {
                throw std::logic_error("staged MTP prefill did not reach the prompt frontier");
            }
#if defined(NINFER_WITH_KVMEM)
            if (kvmem.enabled) {
                if (!native_mtp_accepted_keys) {
                    throw std::logic_error("native MTP accepted-key capture is unavailable");
                }
                native_mtp_accepted_keys->reset_key_frontier(prompt_tokens);
            }
#endif
            sequence.mtp_draft_count = staged.initial_mtp_extent;
            std::copy_n(initial_drafts.begin(), staged.initial_mtp_extent,
                        sequence.mtp_drafts.begin());
        } else if (is_masked_draft_backend(speculative_backend) &&
                   sequence.dflash_context_frontier != prompt_tokens) {
            throw std::logic_error("staged DFlash prefill did not reach the prompt frontier");
        }
        sequence.tail_hidden_valid      = true;
#if defined(NINFER_WITH_KVMEM)
        if (kvmem.enabled) {
            (void)capture_native_checkpoint(sequence, prompt_tokens);
            request.native_evaluation_frontier = prompt_tokens;
        }
#endif
        request.timings.vision_seconds  = vision_seconds;
        request.timings.prefill_seconds = std::max(0.0, staged.elapsed_seconds - vision_seconds);
        staged.prompt.release_all_media_payloads();
        if (staged.vision) { staged.vision->retire_handoff(); }

        const bool prompt_frontier_capture =
            staged.next_capture < staged.capture_groups.size() &&
            staged.capture_groups[staged.next_capture].frontier == prompt_tokens;
        if (!prompt_frontier_capture) { request.prefill.reset(); }
        request.pending   = PendingCandidate{.kind          = PendingKind::Begin,
                                             .base_E        = 0,
                                             .base_S        = 0,
                                             .prompt_tokens = prompt_tokens,
                                             .produced      = 1};
        request.lifecycle = Lifecycle::Pending;
        return runtime::PrefillStepResult{
            .summary = summary,
            .round   = runtime::GeneratedRound{.tokens = std::span<const TokenId>(host_tokens, 1)},
            .processed_prompt_tokens = processed_prompt_tokens,
            .complete                = true,
            .timing                  = timing.finish(),
        };
    } catch (...) {
#if defined(NINFER_WITH_KVMEM)
        // register_append precedes forward and may leave a prepared native
        // pressure plan or a partially published RawKvStore segment. The
        // ordinary lane cleanup below resets the owner when it can; if a
        // context transaction prevents that cleanup, reject later reuse.
        if (kvmem.enabled) { native_kvmem_poisoned = true; }
#endif
        timing.begin_wait();
        try {
            device.synchronize();
        } catch (...) {}
        timing.end_wait();
        const std::uint32_t lane = sequence.lane;
        clear_execution_failure_lanes(std::span<const std::uint32_t>(&lane, 1));
        throw;
    }
}


} // namespace ninfer::models::qwen3_5::detail
