// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#pragma once

#include "models/qwen3_5/program/internal.h"

#include "core/arena.h"
#include "core/device.h"
#include "core/tensor.h"
#include "core/weight.h"
#include "models/qwen3_5/program/vision_control.h"
#include "models/qwen3_5/program/planning/startup.h"
#include "models/qwen3_5/program/vision_prefill.h"

#include <array>
#include <cstddef>
#include <cstdint>
#include <list>
#include <optional>
#include <span>
#include <vector>

namespace ninfer::models::qwen3_5::execution {

using detail::VisionWorkspacePlan;
using detail::VisionPrefillPlan;
using detail::VisionUseSpan;

struct VisionItemView {
    std::span<const std::uint16_t> patches;
    const qwen3_5::VisionItemControl* control = nullptr;
};

struct VisionFeatureCacheKey {
    std::array<std::uint8_t, 32> content_digest{};
    PromptModality modality = PromptModality::Image;
    VisionGrid grid;
    std::size_t patch_count = 0;
    DType output_dtype = DType::BF16;
    std::array<std::int32_t, 4> output_shape{};
    std::size_t output_bytes = 0;

    [[nodiscard]] bool operator==(const VisionFeatureCacheKey& other) const noexcept {
        return content_digest == other.content_digest && modality == other.modality &&
               grid.temporal == other.grid.temporal && grid.height == other.grid.height &&
               grid.width == other.grid.width && patch_count == other.patch_count &&
               output_dtype == other.output_dtype && output_shape == other.output_shape &&
               output_bytes == other.output_bytes;
    }
};

// Program-owned IMAGE outputs only, in ordinary CPU storage like the native
// embedding cache. Copies finish before publication/reuse; CUDA failures follow
// the existing CUDA_CHECK fail-fast path, never a cache-miss fallback.
class VisionFeatureCache {
public:
    static constexpr std::size_t kCapacityBytes = 64U * 1024U * 1024U;

    [[nodiscard]] bool try_copy_to_device(const VisionFeatureCacheKey& key, Tensor& output,
                                          cudaStream_t stream) noexcept;
    void remember(const VisionFeatureCacheKey& key, const Tensor& output,
                  cudaStream_t stream) noexcept;

private:
    struct Entry {
        VisionFeatureCacheKey key;
        std::vector<std::byte> features;
        std::size_t bytes;
    };

    std::list<Entry> entries_; // Most recently used first.
    std::size_t bytes_ = 0;
};

class VisionContext {
public:
    VisionContext(DeviceContext& device, const execution::Parameters& parameters);

    [[nodiscard]] static std::size_t workspace_bytes(const VisionConfig& config,
                                                     const VisionParameters& parameters,
                                                     std::size_t patches, std::size_t merged_tokens,
                                                     const VisionWorkspacePlan& plan);
    [[nodiscard]] static VisionWorkspacePlan plan_workspace(const VisionConfig& config,
                                                            const VisionParameters& parameters,
                                                            std::uint32_t max_merged_tokens,
                                                            std::size_t general_capacity_bytes);

    [[nodiscard]] const VisionConfig& config() const noexcept { return config_; }

    [[nodiscard]] static Tensor bind_output(DeviceSpan backing, const VisionWorkspacePlan& plan,
                                            std::size_t merged_tokens);
    void encode(const VisionItemView& item, Tensor& output, DeviceSpan backing,
                const VisionWorkspacePlan& plan) const;

private:
    DeviceContext& ctx_;
    const VisionConfig& config_;
    const VisionParameters& parameters_;
};

struct VisionChunk {
    std::int32_t length                       = 0;
    const qwen3_5::VisionItemControl* control = nullptr;
    Tensor embeddings;
};

class VisionPrefillSession {
public:
    VisionPrefillSession(DeviceContext& device, const execution::Parameters& parameters,
                         DeviceSpan workspace, const VisionWorkspacePlan& workspace_plan,
                         qwen3_5::PreparedPromptData& prompt, const VisionPrefillPlan& plan,
                         std::size_t& handoff_peak_bytes, VisionFeatureCache& feature_cache);

    [[nodiscard]] VisionChunk prepare_chunk(std::uint32_t begin, std::uint32_t nominal_length);
    // Returns the current session's exact chunk length without encoding or advancing state.
    [[nodiscard]] std::uint32_t chunk_length(std::uint32_t begin,
                                             std::uint32_t nominal_length) const;
    void release_encoded_media_payloads() noexcept;
    void retire_handoff() noexcept;
    [[nodiscard]] double elapsed_seconds() const;

    [[nodiscard]] std::size_t active_handoff_bytes() const noexcept {
        return active_handoff_bytes_;
    }

private:
    struct ChunkSelection {
        std::uint32_t length = 0;
        std::size_t next_use = 0;
        const VisionUseSpan* active = nullptr;
    };

    [[nodiscard]] ChunkSelection select_chunk(std::uint32_t begin,
                                              std::uint32_t nominal_length) const;

    DeviceContext& device_;
    DeviceSpan workspace_;
    const VisionWorkspacePlan& workspace_plan_;
    qwen3_5::PreparedPromptData& prompt_;
    const VisionPrefillPlan& plan_;
    std::size_t& handoff_peak_bytes_;
    VisionContext context_;
    VisionFeatureCache& feature_cache_;
    std::size_t next_use_ = 0;
    std::optional<std::uint32_t> active_item_;
    std::size_t active_handoff_bytes_ = 0;
    std::vector<std::uint32_t> encoded_payloads_pending_release_;
    std::vector<CudaEventTimer> timers_;
};

} // namespace ninfer::models::qwen3_5::execution
