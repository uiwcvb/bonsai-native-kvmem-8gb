// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#include "models/qwen3_5/execution/attention_features.h"

#include "core/device.h"
#include "ninfer/ops/attention_feature_sum.h"

#include <algorithm>
#include <limits>
#include <stdexcept>
#include <utility>

namespace ninfer::models::qwen3_5::execution {

void AttentionFeatureCapture::capture_layer(std::int32_t compact_layer, const Tensor& query,
                                            const Tensor& key, std::int32_t logical_first,
                                            cudaStream_t stream) const {
    if (compact_layer < 0) throw std::invalid_argument("negative attention feature layer");
    if (logical_first < 0 || key.ne[2] < 0 ||
        key.ne[2] > std::numeric_limits<std::int32_t>::max() - logical_first ||
        query.ne[2] != key.ne[2]) {
        throw std::invalid_argument("attention feature logical tile is invalid");
    }
    const auto tile_end = logical_first + static_cast<std::int32_t>(key.ne[2]);
    const auto intersect = [&](std::int32_t first, std::int32_t count) {
        if (first < 0 || count < 0 || count > std::numeric_limits<std::int32_t>::max() - first)
            throw std::invalid_argument("attention feature capture interval is invalid");
        const auto begin = std::max(first, logical_first);
        const auto end = std::min(first + count, tile_end);
        return std::pair{begin - logical_first, std::max(0, end - begin)};
    };
    const auto accumulate = [&](const Tensor& input, Tensor target,
                                std::int32_t first, std::int32_t count,
                                std::int32_t block_tokens) {
        const auto [tile_first, tile_count] = intersect(first, count);
        if (block_tokens < 0) {
            throw std::invalid_argument("negative attention feature block size");
        }
        if (block_tokens == 0) {
            if (tile_count != 0) {
                ops::attention_feature_sum(input, tile_first, tile_count, target, stream);
            }
            return;
        }
        const std::int64_t block_count = count == 0 ? 0 :
            1 + (static_cast<std::int64_t>(first % block_tokens) + count - 1) /
                    block_tokens;
        if (target.dtype != DType::FP32 || target.ne[0] != input.ne[0] ||
            target.ne[1] != input.ne[1] || target.ne[2] < block_count ||
            target.ne[3] != 1 || !target.is_contiguous()) {
            throw std::invalid_argument("attention feature block-sum capacity mismatch");
        }
        std::int32_t offset = tile_first;
        std::int32_t remaining = tile_count;
        while (remaining != 0) {
            const auto logical = logical_first + offset;
            const auto plane = logical / block_tokens - first / block_tokens;
            const auto take = std::min(remaining, block_tokens - logical % block_tokens);
            Tensor sum = target.slice(2, plane, 1);
            ops::attention_feature_sum(input, offset, take, sum, stream);
            offset += take;
            remaining -= take;
        }
    };
    const auto index = static_cast<std::size_t>(compact_layer);
    if (!staged_keys.empty()) {
        if (index >= staged_keys.size())
            throw std::invalid_argument("attention key capture layer is outside supplied views");
        const auto& target = staged_keys[index];
        if (target.data != nullptr) {
            if (key.dtype != DType::BF16 || target.dtype != DType::BF16 ||
                key.ne[3] != 1 || target.ne[3] != 1 || !key.is_contiguous() ||
                !target.is_contiguous() || key.data == nullptr ||
                key.ne[0] != target.ne[0] || key.ne[1] != target.ne[1] ||
                key.ne[2] > target.ne[2])
                throw std::invalid_argument("attention key capture shape/capacity mismatch");
            // Identical contiguous BF16 coordinates: this is a raw transfer, not a cast,
            // reduction, historical commit, or KV re-encoding operation.
            CUDA_CHECK(cudaMemcpyAsync(target.data, key.data, key.bytes(),
                                       cudaMemcpyDeviceToDevice, stream));
        }
    }
    if (!key_sums.empty()) {
        if (index >= key_sums.size())
            throw std::invalid_argument("attention key-sum layer is outside supplied views");
        auto target = key_sums[index];
        if (target.data != nullptr) {
            accumulate(key, target, key_first, key_count, key_block_tokens);
        }
    }
    if (!query_sums.empty()) {
        if (index >= query_sums.size())
            throw std::invalid_argument("attention query capture layer is outside supplied views");
        auto target = query_sums[index];
        if (target.data != nullptr) {
            accumulate(query, target, query_first, query_count, 0);
        }
    }
}

} // namespace ninfer::models::qwen3_5::execution
