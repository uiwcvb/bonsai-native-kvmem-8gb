// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#pragma once

#include "core/tensor.h"

#include <cuda_runtime.h>
#include <cstdint>
#include <span>

namespace ninfer::models::qwen3_5::execution {

// NInfer binding for the author's normalized, pre-RoPE Q/K capture points:
// third_party/kvmem/patches/llama-kvmem-current.patch (Qwen3.5 graph additions).
// Program owns all buffers and their lifetime; these are non-owning execution views.
struct AttentionFeatureCapture {
    // Indexed by compact main-attention layer, not the 64-layer hybrid index.
    // A null tensor skips that layer. Keys are BF16 [D,Hkv,capacity_columns].
    // Copying provisional keys here does NOT publish them into historical mean-K.
    // Program must reduce only accepted columns from the accepted block-prefix sum,
    // splitting at logical block boundaries;
    // rejected speculative tails must never enter RawKvStore.
    std::span<const Tensor> staged_keys;
    // Optional F32 [D,Hkv,S] ordered pre-RoPE K accumulators. With
    // key_block_tokens > 0, plane s continues the accepted prefix of logical block
    // key_first/key_block_tokens + s. Program commits each accepted block to
    // RawKvStore only after the entire execution segment succeeds.
    // Unlike staged_keys, this does not retain per-token K rows.
    std::span<const Tensor> key_sums;
    // Capture intervals use original logical token positions, not positions
    // relative to each TextContext internal prefill tile.
    std::int32_t key_first = 0;
    std::int32_t key_count = 0;
    // Zero keeps the single-accumulator [D,Hkv] decode/verify binding.
    std::int32_t key_block_tokens = 0;
    // Optional F32 [D,Hq] accumulators for query-capture layers. Program seeds
    // these from the accepted canonical query sum; token order continues across
    // block and execution-segment boundaries without independent subtotals.
    std::span<const Tensor> query_sums;
    std::int32_t query_first = 0;
    std::int32_t query_count = 0;

    // Columns follow the current execution's flattened [width,batch] order. Program
    // must bind per-sequence views/ranges; a query must not straddle different lanes.
    // Graph capture requires the same pointers/ranges for that graph's lifetime.
    // No host readback, allocation, or synchronization is performed here.
    void capture_layer(std::int32_t compact_layer, const Tensor& query, const Tensor& key,
                       std::int32_t logical_first, cudaStream_t stream) const;
};

} // namespace ninfer::models::qwen3_5::execution
