// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#pragma once

#include "core/tensor.h"

#include <cuda_runtime.h>

namespace ninfer::ops {

/**
 * Op: mtp_prepare_next_round
 *
 * Math / indexing:
 *   The round verified T=V+1 columns (V verify drafts); the MTP head proposes K drafts. For each
 *   row b with A=accepted[b], L=licensed_counts[b]:
 *     alignment_ids[j,b] = verify_ids[j+1,b]  for 0<=j<A
 *                          next_anchors[b]     otherwise;
 *     remaining_after = max(remaining_budgets[b]-L,0);
 *     cache_after     = cache_base_frontiers[b]+L;
 *     logical_room    = max(max_logical_context-updated_frontiers[b]-1,0);
 *     cache_room      = max(max_cache_context-cache_after-1,0);
 *     next_extents[b] = min(K,max(remaining_after-1,0),logical_room,cache_room);
 *     For S=max(K-1,1) and 0<=s<S:
 *       ar_positions[b,s]      = cache_after+s;
 *       ar_rope_positions[b,s] = updated_frontiers[b]+s+rope_deltas[b];
 *       ar_valid_columns[b,s]  = (s+1 < next_extents[b]).
 *
 * Logical shapes / effects:
 *   verify_ids/alignment_ids are distinct contiguous I32 [T,B]. ar_positions,
 *   ar_rope_positions, and ar_valid_columns are I32 [B,max(K-1,1)] with contiguous rows and one
 *   shared step stride at least B; this permits an exact-B prefix of a fixed-capacity frame. All
 *   other tensors are contiguous I32 [B]. B>=1, 1<=K<=5, K+1<=T<=16, 0<=accepted[b]<=T-1,
 *   licensed_counts[b]=accepted[b]+1, updated_frontiers and remaining_budgets are non-negative,
 *   and both context capacities are positive. The Op writes every output slot, including safe invalid-tail
 *   values. Inputs remain unchanged. No workspace or other state is used.
 */
void mtp_prepare_next_round(const Tensor& verify_ids, const Tensor& next_anchors,
                            const Tensor& accepted, const Tensor& updated_frontiers,
                            const Tensor& cache_base_frontiers,
                            const Tensor& remaining_budgets, const Tensor& licensed_counts,
                            const Tensor& rope_deltas, Tensor& alignment_ids, Tensor& next_extents,
                            Tensor& ar_positions, Tensor& ar_rope_positions,
                            Tensor& ar_valid_columns, std::int32_t proposal_depth,
                            std::int32_t max_logical_context,
                            std::int32_t max_cache_context, cudaStream_t stream);

} // namespace ninfer::ops
