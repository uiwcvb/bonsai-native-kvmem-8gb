// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#pragma once

#include "core/tensor.h"

#include <cuda_runtime.h>

#include <cstdint>

namespace ninfer::ops {

/**
 * Op: in-place attention feature sum over a token interval
 *
 * Math / indexing:
 *   For each (d,h), start with s = sum[d,h] and, in increasing i = 0..count-1,
 *   update s = FP32(s + FP32(input[d,h,first+i])); then store s in sum[d,h].
 *   This ordered FP32 recurrence preserves KVMem meank_add_bf16 semantics: the old
 *   accumulator participates in every token addition, not just a final reduced sum.
 *   Contiguous element offsets are input[(t*H+h)*D+d] and sum[h*D+d].
 *
 * Logical shapes / supported domain:
 *   input: contiguous BF16 [D,H,T,1]; sum: contiguous F32 [D,H,1,1]. D,H,T > 0,
 *   D*H <= INT32_MAX, 0 <= first <= T, and 0 <= count <= T-first.
 *   Views may have caller-selected base offsets, including contiguous Tensor::slice
 *   results. Storage must be device-accessible, non-null and element-aligned.
 *   No F16/F32 input or noncontiguous layouts are supported.
 *
 * Numeric:
 *   BF16 values are promoted to FP32 before each addition; there is no BF16 sum,
 *   normalization, mean division, tree reduction, or token reordering. Non-finite
 *   values follow CUDA FP32 addition; NaN payloads are not specified for count > 0.
 *
 * Effects:
 *   Only sum is updated. Input and sum storage must not overlap. Input outside the
 *   selected interval is not read. count == 0 preserves every sum bit without a
 *   kernel launch; view/range validation still applies. Invalid arguments do not
 *   enqueue work. The caller owns initialization, lifetime and ordering of sum.
 *
 * Workspace / execution:
 *   None. Asynchronous on the supplied stream, CUDA Graph capture/replay compatible.
 *   No allocation, synchronization, global accumulator, or retained pointers. Captured
 *   first/count are host constants; tensor contents may change between replays.
 */
void attention_feature_sum(const Tensor& input, std::int32_t first, std::int32_t count,
                           Tensor& sum, cudaStream_t stream);

} // namespace ninfer::ops
