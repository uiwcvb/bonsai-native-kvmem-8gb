<!-- Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md. -->
# NInfer CLI

`build/apps/ninfer` runs one request against one v3 `.ninfer` artifact. Build NInfer and
download an artifact using the [project README](../README.md) before following this guide.

The examples use Qwen3.8-27B NVFP4 with FP8 KV storage.

## Text input

```bash
./build/apps/ninfer models/qwen3_8_27b_nvfp4.ninfer \
  --prompt "Summarize the difference between prefill and decode." \
  --max-context 32768 \
  --max-new 8192 \
  --kv-dtype fp8 \
  --spec mtp --draft-tokens 3 \
  --lm-head-draft
```

Exactly one of `--prompt` and `--messages` is required. The CLI normally omits `--kv-capacity`, so
the shared Main Text KV pool follows the example's 32,768-token `--max-context`.

Answer content is streamed to stdout. Human-readable startup milestones and runtime errors are
written to stderr without service timestamps. Reasoning and the CLI result report (timings,
throughput, GPU memory, token IDs when requested, and speculative-decoding statistics) also use
stderr as unprefixed product output, so stdout can be redirected independently. On a terminal,
weight materialization is one transient progress line followed by a compact Engine-ready summary.
Redirected stderr contains persistent readable progress for long loads and no carriage returns or
ANSI escapes. `--log-level debug` exposes every startup phase. Option and local prompt/message input
failures remain direct command diagnostics:

```bash
./build/apps/ninfer models/qwen3_8_27b_nvfp4.ninfer \
  --prompt "Return one sentence." \
  --max-context 4096 \
  --max-new 64 \
  --kv-dtype fp8 \
  > answer.txt 2> run.log
```

`--chat-template FILE` overrides the artifact's built-in template with a local Jinja file.
Changes to the file take effect after restarting NInfer:

```bash
./build/apps/ninfer models/qwen3_8_27b.ninfer \
  --chat-template tools/chat_templates/qwen3_8.jinja --prompt "Hello"
```

Omitted thinking and effort options use the selected template's defaults. `--no-thinking` or
`--reasoning-effort none` requests disabled thinking; other effort values cannot be combined with
`--no-thinking`. The template interprets the selected effort. `--greedy` selects exact argmax
decoding independently.

`--thinking-budget N` places a positive upper bound on accepted model-origin tokens while the
new-turn Qwen thinking block remains open. If the model has not emitted `</think>` at that exact
boundary, Engine appends [Qwen's canonical early-close guidance](https://github.com/QwenLM/Qwen3/blob/main/docs/source/getting_started/thinking_budget.md)
and `</think>` to the same resident sequence without sampling, publishes the guidance through the
reasoning stream, then resumes ordinary generation from the updated context. A natural thinking
close, stop condition, cancellation, or total output/context limit at the boundary takes priority
and suppresses this insertion. The option cannot be combined with `--no-thinking`, but it can be
combined with `--reasoning-effort`.

`--max-new` counts every committed generated token, including internally inserted control tokens.
When the effective output capacity extends beyond the thinking budget, it must have room for the
complete tokenizer-derived control suffix plus one post-close model token; an undersized request is
rejected rather than truncating the suffix. Normal output sends the inserted guidance to stderr as
reasoning. `--print-token-ids` includes the inserted IDs, while `--raw-output` preserves the raw
control representation.

For example, this allows at most 512 model-origin thinking tokens while retaining enough total
output capacity for the inserted suffix and the answer:

```bash
./build/apps/ninfer models/qwen3_8_27b_nvfp4.ninfer \
  --prompt "Explain speculative decoding, then give a concise conclusion." \
  --max-context 4096 \
  --max-new 1024 \
  --thinking-budget 512 \
  --kv-dtype fp8 \
  --spec mtp --draft-tokens 3 \
  --lm-head-draft
```

## Startup memory profile

GPU residency is frozen when the Engine starts:

- no `--spec` omits MTP/DFlash/DFlash2 weights and state and the optimized proposal head;
- `--spec mtp`, `--spec dflash` (35B-A3B), and `--spec dflash2` (Qwen3.8-27B) load only
  the selected speculative backend;
- a speculative backend with the full proposal head omits the optimized proposal head;
- Vision is disabled by default, omitting its weights and Vision-specific unified-workspace extent;
- `--vision` loads the weights, expands the one Program workspace for Vision encode/handoff, and
  enables image/video input.
- the one-request CLI uses root-only context mode, so it does not reserve an extra Device
  checkpoint StateImage or capture a continuation that no later request could consume.

The complete `.ninfer` inventory is still validated. These choices are not lazy loading: an Engine
started without Vision rejects media and cannot enable Vision later. DFlash/DFlash2 and Vision may
be enabled together; these backends apply to generated-text decode after multimodal prefill and does not
accelerate Vision encode. The default speculative and Vision settings produce the smallest resident
profile.

## Structured messages

`--messages` accepts either a non-empty JSON message array or an object containing `messages`
and an optional `tools` array.

```json
[
  {
    "role": "system",
    "content": "Answer concisely."
  },
  {
    "role": "user",
    "content": [
      {
        "type": "image",
        "image": "examples/cli/media/visual_chart.png"
      },
      {
        "type": "text",
        "text": "Describe the chart."
      }
    ]
  }
]
```

Run message files from the repository root when they contain repository-relative media paths:

```bash
./build/apps/ninfer models/qwen3_8_27b_nvfp4.ninfer \
  --messages examples/cli/messages/image_chart.json \
  --max-context 8192 \
  --max-new 128 \
  --kv-dtype fp8 \
  --vision \
  --spec mtp --draft-tokens 3 \
  --lm-head-draft
```

Supported roles are `system`, `developer`, `user`, `assistant`, and `tool`.
The selected template formats these roles. The maintained Qwen templates keep system/developer
messages at their input positions.

Message content may be a string or an ordered array containing:

| Content type | Source field | Accepted source |
|---|---|---|
| text | `text` | string |
| image / image_url | `image` or `image_url` | local path, HTTP(S) URL, or base64 data URI |
| video / video_url | `video` or `video_url` | local path, HTTP(S) URL, or base64 data URI |

`image_url` and `video_url` may be strings or objects containing a string `url`. Assistant
history may include `reasoning_content` and `tool_calls`; a tool result uses role `tool` and
`tool_call_id`.

See [`examples/cli/`](../examples/cli/) for committed text, image, video, mixed-media, thinking,
long-decode, and long-context inputs.

## Speculative decoding

Speculative decoding is disabled by default. Select MTP with one to five draft positions, or the
35B-A3B DFlash or Qwen3.8-27B DFlash2 backend with one to fifteen. Both masked-draft backends
may be combined with `--vision`.
`--lm-head-draft` selects the optimized proposal head and requires a selected backend:

```bash
./build/apps/ninfer models/qwen3_6_35b_a3b.ninfer \
  --prompt "Write a short explanation of speculative decoding." \
  --max-context 16384 \
  --max-new 512 \
  --kv-dtype fp8 \
  --spec mtp --draft-tokens 3 \
  --lm-head-draft
```

With MTP, `--ngram chain` extends each round's MTP proposal with host n-gram drafts in the style
of llama.cpp `ngram-mod`: a shared pool maps the hash of the last `--ngram-n` tokens (default 8) to
the token that last followed them, and the proposal continues from it for up to `--ngram-max`
drafts in total (default 15, range `draft-tokens + 3 .. 15`). Extensions shorter than
`--ngram-min` (default 1) are dropped; `--ngram-pool-mib` (default 16) sizes the pool. A round
verifies the wide window only when some row's draft reaches `draft-tokens + 3`; otherwise it keeps
the MTP width and its CUDA Graphs. Greedy verification keeps the output of the non-speculative route
up to floating-point ties. The summary reports the pool's drafted and accepted tokens and the wide
rounds:

```bash
./build/apps/ninfer models/qwen3_6_35b_a3b.ninfer   --prompt "Rewrite this file with one change: ..."   --spec mtp --draft-tokens 3 --lm-head-draft   --ngram chain --ngram-max 15
```

For DFlash:

```bash
./build/apps/ninfer models/qwen3_6_35b_a3b.ninfer \
  --prompt "Write a short explanation of speculative decoding." \
  --max-context 16384 --max-new 512 \
  --kv-dtype fp8 \
  --spec dflash --draft-tokens 7 --lm-head-draft
```

For Qwen3.8-27B artifacts containing the DFlash2 companion weights, select
`--spec dflash2 --draft-tokens 7`, optionally with `--lm-head-draft` and `--vision`.
DFlash2 accepts every draft count from 1 through 15; seven is the checkpoint recommendation.
Both `groupwise-int` and `nvfp4` artifacts use the same Engine route, including CUDA Graph,
concurrent requests, sampling penalties, and prefix reuse. An artifact without the companion
weights reports a missing DFlash2 component when selected. Vision, MTP and DFlash follow the same
rule: their weights are required only when that component is enabled at startup.

Only one speculative backend can be enabled per Engine. The published [performance results](performance.md)
use MTP with three draft tokens and DFlash with seven draft tokens (block length eight), both with
the optimized proposal head. DFlash accepts one to fifteen draft tokens; seven forms the measured
block length eight, while fifteen uses the maximum supported block length sixteen.

## Common options

The table lists executable defaults without KVMem. The examples above select FP8 KV and MTP3.
KVMem's separate logical/physical defaults are in
[KVMem logical and physical capacity](#kvmem-logical-and-physical-capacity).

| Option | Meaning | Default |
|---|---|---:|
| `--max-context N` | per-sequence logical context ceiling | `2048` |
| `--kv-capacity N\|auto` | explicit shared Main Text KV capacity, or maximize it from remaining GPU memory; omitted means `--max-context` | `2048` |
| `--prefill-chunk N` | positive text-prefill chunk, in multiples of 128 | `1024` |
| `--max-new N` | requested output-token limit | `128` |
| `--device N` | CUDA device index | `0` |
| `--kv-dtype bf16\|int8\|fp8\|nvfp4\|k8v4\|rk8v4\|rk4v4\|rk4v4-e8\|rk2v4-e8` | KV-cache storage; rotated and E8-lattice modes trade key/value precision for capacity; `nvfp4` and `k8v4` are upstream sm_120a modes, not available on the RTX 4090 | `bf16` |
| `--spec mtp\|dflash\|dflash2` | speculative backend | off |
| `--draft-tokens N` | MTP `1..5`; DFlash/DFlash2 `1..15` | unset |
| `--lm-head-draft` | optimized proposal head | off |
| `--vision` | enable image/video input and load Vision GPU allocations | off |
| `--no-cuda-graph` | disable CUDA Graph decode | graphs on |
| `--chat-template FILE` | use a local Jinja template | artifact template |
| `--no-thinking` | disable thinking | template default |
| `--thinking-budget N` | positive model-origin thinking-token cap; omitted means unlimited | unset |
| `--reasoning-effort none\|minimal\|low\|medium\|high\|xhigh\|max` | pass an effort value to the selected template | template default |
| `--greedy` | exact argmax decoding | off |
| `--temperature F` | sampling temperature override | registered model/mode default |
| `--top-p F` | nucleus-threshold override | registered model/mode default |
| `--top-k N` | top-k-threshold override (`0..20`; zero selects the top-20 cap) | registered model/mode default |
| `--min-p F` | min-p-threshold override | registered model/mode default |
| `--presence-penalty F` | presence-penalty override | registered model/mode default |
| `--frequency-penalty F` | frequency-penalty override | registered model/mode default (`0`) |
| `--seed N` | sampling seed | `0` |

When a sampling flag is omitted, Engine selects the general-task preset for the loaded architecture
and rendered prompt mode. The current official models use:

| Model | Prompt mode | Temperature | Top-p | Top-k | Min-p | Presence penalty |
|---|---|---:|---:|---:|---:|---:|
| Qwen3.6-27B | thinking | `1.0` | `0.95` | `20` | `0` | `0` |
| Qwen3.6-27B | non-thinking | `0.7` | `0.80` | `20` | `0` | `1.5` |
| Qwen3.8-27B | thinking | `1.0` | `0.95` | `20` | `0` | `0` |
| Qwen3.8-27B | non-thinking | `0.7` | `0.80` | `20` | `0` | `1.5` |
| Qwen3.6-35B-A3B | thinking | `1.0` | `0.95` | `20` | `0` | `1.5` |
| Qwen3.6-35B-A3B | non-thinking | `0.7` | `0.80` | `20` | `0` | `1.5` |

Frequency penalty is `0` in every registered preset. Task-specific profiles such as Qwen's
precise-coding profile use explicit sampling overrides.

Repeat `--stop-token-id`, `--stop`, or `--reasoning-stop` to add stop conditions. Use
`--raw-output` to expose the frontend's raw output stream and `--print-token-ids` to include
generated token IDs in diagnostics.

Run `./build/apps/ninfer --help` for the exact option contract.

## Context and memory

The official artifacts have a native context limit of 262,144 tokens. The practical allocation
on one RTX 4090 depends on the selected artifact, media workload, output budget, and KV-cache
type. The artifact describes its model configuration and weight representations; `--kv-dtype`
independently selects runtime KV storage.
Use `--kv-dtype int8` for the maximum-precision profile. `--kv-dtype fp8` selects row-scaled
E4M3 D256 KV storage. The compressed modes store Hadamard-rotated keys and 4-bit values:

- `rk8v4` keeps 8-bit keys.
- `rk4v4` packs keys to 4 bits.
- `rk4v4-e8` selects 4-bit key codes on the E8 Conway-Sloane lattice. This is the
  recommended long-context mode on the RTX 4090 and fits the full native 262,144
  context. The measured quality gates are in [the fork comparison](udp-fork-comparison.md).
- `rk2v4-e8` packs keys to 2 bits with a 240-root E8 codebook, for maximum capacity.

None of these modes is byte-equivalent to INT8. At depth, `rk4v4-e8` measured no loss in
MTP acceptance or retrieval. Artifact identity selects the weight profile; `--kv-dtype`
selects runtime KV storage. The prepared prompt must fit
`--max-context`; generation stops at the remaining context capacity when necessary.
`--kv-capacity N` controls the shared physical Main Text KV pool independently and is rounded up to
the 64-token page size. `--kv-capacity auto` loads the selected weights, measures the remaining GPU
memory, and directly chooses the largest legal page capacity for the complete enabled runtime
layout. This includes the selected speculative backend, fixed sequence state, unified workspace,
and CUDA Graph allowance, while leaving the default 1 GiB automatic headroom
unallocated. It does not probe allocations or resize the pool at request time. The single-request
CLI normally leaves the option omitted so it follows
`--max-context` without KVMem; the distinction matters primarily to a concurrent Engine or server.

### KVMem logical and physical capacity

`--kvmem` is opt-in and currently requires one concurrent sequence with speculation disabled
or the MTP backend. When `--max-context` is omitted, CLI and server reserve 131,072 input tokens
plus `--kvmem-generation-reserve` for output: the default logical total is 147,456 tokens.
Prompt-template and control tokens count toward input. An explicit `--max-context` remains a
total input-plus-output limit and can be smaller for bounded diagnostics.

The default history budget is 32,768 tokens and generation reserve is 16,384 tokens. Both are
rounded up independently to whole native 128-token blocks (two NInfer 64-token pages), matching
Program admission. Omitted or `auto` KV capacity uses their sum: 49,152 physical tokens by
default, not the logical total. An explicit capacity cannot be smaller than that aligned sum.
This capacity policy does not change model/KV precision, sampling, or establish 128K quality
or throughput acceptance.

KVMem's native archive supports exact session endpoints only. Engine normalizes optional shared
prefix and long-anchor capacities to zero, and Program does not publish template rewrite,
shared-prefix or long-anchor captures in this mode. The server's automatic long-anchor count
therefore resolves to zero. Prompt/template tokens, execution boundaries, native query/replay
checkpoints and exact-endpoint caching are preserved; these optional checkpoint hints cannot
turn an otherwise supported endpoint into an archive that owner exchange cannot park.

### KVMem session RAM and disk parking

`--kvmem-session-cache-dir ROOT` and positive `--kvmem-session-disk-gb N` require `--kvmem` and
must be provided together; `N` is a fractional GiB budget. `--kvmem-session-ram-gb N` sets a
fractional GiB soft limit on measured native-session host RAM. Omit it or pass `0` for unlimited;
a positive value requires `--kvmem` and the complete cache-directory/disk-budget pair.

With a positive session RAM limit, ResourceManager deterministically selects the least-recently
used idle native sessions for optional cold parking, while protecting the selected/active session.
Disk configuration does not write every parked session: snapshots may be written when the soft RAM
limit is reached or when a restore encounters actual host-RAM headroom pressure. I/O or quota
failures retain the owned archive, including any already completed RAM/disk chunks, and do not
trigger generic eviction to work around the failed write.

The budget counts native archive and query/row metadata allocations, not fixed Engine/Program
arenas, prefix bookkeeping, weights or workspaces. A target's restored disk file is credited in
final capacity planning. Only final disk-capacity pressure may evict idle LRU entries, after a
complete temporary RAM/disk schedule has been proved. A temporary-space or deletion failure is
not an eviction request. Target and follower Raw allocations use the unchanged native frozen
chunk manifest and can alternate writes/reads within one session. Lengths, formats and ownership
remain trusted in RAM; only a fully restored manifest can resume inference. The private native
CPU arena remains one indivisible Runtime record and cannot be split. A failed deletion retains
both validated RAM and the charged file; retry removes the duplicate without reloading it.

A missing, truncated, checksum-invalid or identity-mismatched cold target follows the pinned
server's cache-miss rule: invalidate it before deleting its tracked files, release its existing
catalog entry only after cleanup succeeds, and recompute the same request normally. Temporary
read errors, allocation pressure and failed deletion do not discard a valid archive or silently
become a cache miss. Failed cleanup keeps the invalid owner and remaining disk charge for cleanup.

The root is passed to native `kvmem_session_files`, not NInfer's own file manager. Upstream creates
a private same-run `run-*` subdirectory and tracks only the files it creates there. Graceful
shutdown removes that run directory automatically. Abrupt termination may leave orphan `run-*`
directories; they are same-run only and must be manually removed with the server stopped. Do not
remove the cache root. This is not durable restart recovery. The native block-NVMe path is not used.
`--kvmem-compact-parked` remains a RAM-only standalone option; when a session cache is configured,
the native disk policy takes precedence. These settings do not establish full-model or 128K
retrieval acceptance or a TPS result.

At Engine startup NInfer reserves model weights, persistent sequence state, one phase-reused
Program workspace, and a separate CUDA Graph driver allowance. With Vision enabled, that one
workspace contains a general execution prefix and a fixed item-output handoff region. Vision encode
may reuse the full backing before producing the output; Text/MTP/decode work remains inside the
general prefix while the handoff is live. The capacity is therefore the maximum legal simultaneous
extent, not the sum of Text, Vision scratch, and Vision output allocations. Text prefill uses
`min(--prefill-chunk,--max-context)`; Vision keeps the existing 32,768-token aggregate prompt and
16,384-token single-item upper bounds, with a separate 1,024-token limit for a single image.
Each complete media item must fit the configured Vision workspace; distinct items reuse that
workspace sequentially. Engine passes the loaded model's normalized item capacity to preprocessing,
so its admission limit matches workspace planning. Whole-prompt Host/live-byte admission applies
independently. Item output
and its complete scatter control survive the Text/MTP subchunks that consume them. Requests
perform no project-owned device allocation or growth. Context-cache capacity controls are intentionally absent
from this one-request interface; the persistent Engine and server routes own cross-request reuse and
optional Host backing.

All weight, sequence, workspace, and graph allocations are released when the Engine is destroyed.
