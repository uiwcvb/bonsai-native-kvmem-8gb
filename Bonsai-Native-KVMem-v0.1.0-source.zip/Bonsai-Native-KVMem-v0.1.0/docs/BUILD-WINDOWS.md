# Windows 源码构建与手动运行

本页描述源码版，不是完整离线环境安装器。需要 Windows x64、NVIDIA GPU、合适的驱动、CMake 3.28+、Ninja、支持的 MSVC 和 CUDA，以及 FFmpeg / libcurl 等 vcpkg 依赖。

本机原工作树的已知构建组合为 MSVC 14.41.34120、CUDA 12.8.93、SM89、Release。其他工具链组合未由这次发布验证。请使用相应的 x64 Native Tools Command Prompt，并确认 `cl`、`cmake`、`ninja` 可用。

## SM89 构建

先把下面两个占位路径换成自己的安装位置。vcpkg 的 manifest 安装可能需要联网；本仓库不携带 CUDA、Visual Studio、vcpkg 安装目录或这些运行库的离线副本。

```cmd
set "VCPKG_ROOT=X:\path\to\vcpkg"
set "BONSAI_CUDA_ROOT=X:\path\to\cuda-12.8"
cmake -S . -B build -G Ninja ^
  -DCMAKE_BUILD_TYPE=Release ^
  -DCMAKE_CUDA_ARCHITECTURES=89 ^
  -DCMAKE_CUDA_COMPILER="%BONSAI_CUDA_ROOT%\bin\nvcc.exe" ^
  -DCUDAToolkit_ROOT="%BONSAI_CUDA_ROOT%" ^
  -DCMAKE_TOOLCHAIN_FILE="%VCPKG_ROOT%\scripts\buildsystems\vcpkg.cmake" ^
  -DVCPKG_TARGET_TRIPLET=x64-windows ^
  -DNINFER_ENABLE_KVMEM=ON ^
  -DNINFER_BUILD_APPS=ON ^
  -DBUILD_TESTING=OFF ^
  -DNINFER_BUILD_BENCHMARKS=OFF
cmake --build build --target ninfer-serve --parallel 1
build\apps\ninfer-serve.exe --help
```

选择单任务编译是为了降低 RAM/提交额度压力，并非性能调优。CUDA attention 模板可能编译很久；构建进度不表示模型正在推理。

## SM120 / RTX 5060

代码提供 `CMAKE_CUDA_ARCHITECTURES=120` 和 `NINFER_TARGET_SM_COUNT` 的独立构建入口。SM-count 是调度参数，不等于 CUDA 计算能力。必须按真实 GPU 和工具链选择，不能用它伪装另一种架构。

SM120 与 SM89 应放在不同构建目录，不得覆盖彼此的可执行文件。首版不附 SM120 二进制，也不把先前编译成功解释成已通过 5060 推理、GDN、KV codec 或会话切换验收。

## 手动启动标准档

自行准备兼容 v3 `.ninfer` 权重，并先检查显存、物理 RAM、提交额度和磁盘空间。标准档曾要求至少 7400 MiB 空闲显存、温度低于 80°C。**以下命令会实际加载模型；发布准备和只看源码时不要执行。**

```cmd
build\apps\ninfer-serve.exe "X:\models\model.ninfer" ^
  --host 127.0.0.1 --port 18097 --model-id bonsai-native ^
  --kvmem --max-context 147456 --kv-capacity 49152 ^
  --kvmem-history-budget 32768 --kvmem-generation-reserve 16384 ^
  --spec mtp --draft-tokens 1 ^
  --max-concurrency 1 --device-state-slots 0 --host-state-slots 2 ^
  --host-kv-mib 8192 --kv-dtype rk4v4-e8 --mapped-embedding ^
  --kvmem-session-cache-dir ".\session-cache" ^
  --kvmem-session-disk-gb 6 --kvmem-session-ram-gb 1 ^
  --prefill-chunk 512 --default-max-tokens 16384 ^
  --default-thinking-budget 2048 --log-stats-interval-ms 10000
```

此完整档示例明确选择 MTP1，并保留默认开启的 CUDA Graph；模型必须实际提供兼容 MTP 组件。它不是推理验收记录。只有权重确实含兼容 Vision 组件时，才增加 `--vision --mapped-vision --vision-max-tokens 1024`；部署三包使用保留这些组件的 artifact。

三个离线包共用 [distribution/profiles.json](../distribution/profiles.json)。[Build-ThreePackages.ps1](../distribution/Build-ThreePackages.ps1) 用已保留的干净离线模板、两个架构引擎和两套权重创建独立分卷 ZIP，并流式验证每个条目。模板和编译依赖不是源码仓库中的个人运行目录副本；脚本不会重编引擎、启动 GPU 测试或删除聊天。构建者需要显式提供这些输入路径，不能用复制另一种架构 EXE 的方式代替编译。

DSH 或其他 OpenAI 兼容客户端的 Base URL 为 `http://127.0.0.1:18097/v1`，模型 ID 为 `bonsai-native`。只监听本机；没有配置认证和网络安全措施时不要直接暴露公网。

换权重前明确停止旧服务，使用独立会话缓存目录，不混用不同权重的 KV。不要同时启动多个服务去争用相同端口或显存。本仓库不自动关闭任何其他应用，也不修改全局页面文件/显示/驱动设置。
