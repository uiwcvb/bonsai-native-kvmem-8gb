<!-- Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md. -->
# NInfer 资源调度与上下文缓存

本文定义 NInfer 在有限 Device/Host 资源下选择、验证并提交上下文状态的规则。它是 admission
materialization、prefix reuse、cache retention 和 pressure planning 的维护者权威。

本文解决的问题是：

> Scheduler 已经选择一个等待请求后，应从哪个可恢复位置开始，保留或降级哪些 inactive context，
> 才能以最低预测代价得到一个物理可执行且不会破坏 active request 完成保证的终态？

顶层请求顺序和生命周期由 [Engine 架构](engine-architecture.md)定义。KV page、address space、
replica 和 consumer view 的物理合同由 [Paged KV Context Store](paged-kv-cache.md)定义。

---

## 1. 术语与边界

本文使用以下术语：

| 术语 | 含义 |
|---|---|
| owner | 一个 active sequence、private continuation 或 shared prefix |
| checkpoint | owner 内某个可恢复 frontier 的不可变完整状态 |
| candidate | incoming request 可以采用的一个 root 或 exact checkpoint source |
| planning target | candidate 与全部受影响 inactive owners 的完整逻辑终态 |
| reservation | 已从全局可用容量中扣除、为未来物化或事务目的保留的容量 |
| resource plan | Program 针对一个 target seal 的有序物理 transition |
| placement | 一个完整 StateImage 或一个 KV logical page 的 Device/Host replica 状态 |

本文后续简称 planning target 为 `target`，表示一次资源决策的终态。

Prefix reuse 是 admission 的一种来源选择。它复用具有完整身份和状态覆盖的已计算前缀，减少重复
prefill，保持模型语义和请求顺序。不同 prefill 分块或数值路径之间不要求 logits 或生成 token 完全相同。

当前产品条件为单 GPU、单 resident model、固定 `max_concurrency=1..8` 和非抢占 active requests。
由此得到两个基本规则：

1. Scheduler 先确定本次尝试的 request，资源层只优化该 request 的 materialization；
2. 一个 request 发布为 Active 后，其最大合法执行范围已经获得完整资源保证，inactive cache policy
   不能再借用这部分容量。

---

## 2. 决策所有权

### 2.1 Scheduler

Scheduler 选择：

- 当前 FIFO head 或已经证明安全的 backfill request；
- admission 尝试时机；
- prefill、control 和 decode 的执行顺序。

Scheduler 不读取 checkpoint placement、victim、page 或 allocator facts。

### 2.2 ResourceManager

ResourceManager 拥有逻辑缓存策略：

- private/shared catalog 与 SessionIndex；
- candidate shortlist 和 logical claim；
- retention class、命中历史与 publication order；
- 跨 candidates 的 target 搜索和成本比较；
- Program 终态结果的逻辑采用。

ResourceManager 可以知道“某个 checkpoint 可从 Device、Host 或 root 恢复”的 Program summary，
但不保存物理 occupancy、refcount、free page 或 Host arena 几何的副本。

ResourceManager 对 active request 的逻辑保护保存为 owner edge，而不是 catalog capability 或引用计数镜像。
Capability generation 是 planning/transaction 的瞬时结构快照；owner edge 是持续到 active request terminal
settlement 的逻辑 lease。另一个 reader 改变同一 owner 的 Device/Host residency 时可以推进 generation，但不
使已有 owner edge stale。所有 active logical reference counts 都从这些 edges 派生。

### 2.3 Program

Program 是唯一物理 authority，拥有：

- State 与 KV 的真实 objects、references 和 replicas；
- Device pools、Host stores、allocators 和 reservations；
- continuation completeness 与 exact prefix identity；
- Move、Fork、COW、transfer 和 last-reference release；
- 完整 post-state、每个 transition stage 的物理可行性；
- 与当前资源状态绑定的 `ResourcePlan`。

调用关系为：

```text
Scheduler selects one request
        │
        ▼
ResourceManager enumerates candidates and compares targets
        │
        ▼
Program projects each complete target from real physical state
        │
        ▼
Program seals and executes one ResourcePlan
        │
        ▼
ResourceManager adopts one stable ResourceResult
```

逻辑策略与物理事实通过 candidate assessment、opaque target handle、`ResourcePlan` 和
`ResourceResult` 交互，不通过一份跨层共享的物理账本交互。

---

## 3. 资源模型

### 3.1 容量轴

Program 在启动时建立一个固定容量向量：

```text
PhysicalCapacity = {
    Device StateImage slots,
    Host StateImage slots,
    Device page groups for each typed KV pool,
    Host KV arena bytes and allocator geometry,
}
```

容量依据加载后的模型配置、实际权重绑定、启用组件及启动选项推导。权重的物理表示影响执行
workspace 和可用预算；KV/GDN 的数学状态、具体存储和容量由模型实现与 Program 分别负责。

这些轴相互独立。一个资源轴的余量不能补偿另一个轴的缺口。Host KV 的总空闲字节也不能替代
allocator 对具体 extent 几何的可分配性判断。

Engine 另有固定的逻辑容量：

- active lanes；
- private continuation catalog slots；
- shared prefix catalog slots；
- 每个 continuation 的 checkpoint/anchor 上限。

Lane 和 catalog slot 不计入物理 bytes，但 target 只有同时满足逻辑容量和物理容量才可发布。

### 3.2 唯一物理占用

对任一物理资源维度 \(r\)，状态 \(S\) 的占用为：

\[
Used_r(S)=
\sum_{x\in UniqueAllocations(S)} size_r(x)
+
\sum_{y\in ConcreteReservations(S)} size_r(y)
\]

`UniqueAllocations` 包括：

- Device/Host StateImage replicas；
- Device KV page replicas；
- Host KV extents。

`ConcreteReservations` 包括：

- active request 尚未 materialize 的未来增长；
- partial-tail COW destination；
- resource transition 的 copy destination 和 replacement capacity。

同一个物理 allocation 被多个 checkpoints 或 address spaces 引用时只计一次。已经物化的容量计
allocation，尚未物化但被保护的容量计 reservation；同一容量单位不能同时计入两项。

全局物理占用与 owner-exclusive resources 是两个不同视图。前者直接来自 State/KV stores 的 unique
allocations 与 concrete reservations；后者只表示单独移除一个 owner 时能够结算的资源。一个同时被
private checkpoint 与 shared prefix 引用的 allocation 在全局占用中计一次，但在任一 owner 的 exclusive
resources 中都不计。Owner-exclusive resources 可用于 eviction effect、ownership transfer 和 active
entitlement 校验，不能用于判断一个 checkpoint 是否具有 resident replica；后者只能查询对应 physical
store。

每个稳定状态和 transition 中间状态都必须满足：

\[
Used_r(S)\le Capacity_r
\]

### 3.3 完整 post-state 与联合回收

资源回收由最终剩余引用决定。对一组 logical actions \(V\)：

\[
Reclaim_r(S,V)=
Used_r(S)-Used_r(PostState(S,V))
\]

`PostState` 必须同时应用：

- selected source 的 retain 或 consume；
- 所有 victim owner/checkpoint outcomes；
- 所有 surviving Device/Host placements；
- active destination references 和 reservations；
- 零引用 objects 的 release。

因此通常有：

\[
Reclaim(S,A\cup B)\ne Reclaim(S,A)+Reclaim(S,B)
\]

删除一个 alias 可能不释放任何 allocation；两个 owners 一起删除最后一批 references 时，同一 allocation
只释放一次。ResourceManager 不计算或相加 per-owner reclaim credit。

Move、Fork、partial-tail COW 和 source placement 也由完整 post-state 决定。一个 source 在初始状态中
存在多个引用，并不意味着最终一定 Fork；反之，保留任一 checkpoint 所需的引用后也不能把它当作 Move。

### 3.4 有序阶段峰值

一个物理 plan 是稳定状态之间的有序阶段：

\[
S_0\rightarrow S_1\rightarrow\cdots\rightarrow S_n
\]

它可执行当且仅当：

\[
\forall r,\qquad
\max_{0\le i\le n} Used_r(S_i)\le Capacity_r
\]

阶段顺序必须表达真实 dependency：

```text
reserve destination
  -> copy
  -> verify and publish replacement
  -> release old replica
```

State restore、KV H2D/D2H、D2D fork、partial-tail COW 和 Host extent replacement 都遵循这一规则。
最终净占用不能掩盖 copy-before-release 的瞬时峰值。

### 3.5 Resource revision

Program 暴露单调 `resource_revision`，使只读 assessment 和 sealed plan 与一个稳定物理状态绑定。
以下变化会推进 revision：

- owner/reference topology 改变；
- inactive Device/Host placement 改变；
- global free/reserved capacity 改变；
- 会改变后续 allocator feasibility 的几何状态改变。

Active request 在自己的 reservation 内进行 mapped/reserved 转换、推进 committed frontier 或更新
state 内容时，不改变全局可用容量，因此不推进 revision。

一个 open resource transition 的中间阶段不向外发布 revision。它到达稳定 commit/abort 状态后，
若全局物理事实发生变化，只推进一次。Handle 的 owner/generation validation 独立阻止 slot reuse
产生的 stale capability。

---

## 4. Continuation 与 checkpoint

### 4.1 完整恢复条件

当前 Qwen3.5 模型同时包含可分页 Full Attention KV 和不能从任意较晚状态无损回退的 recurrent state。
因此某个 frontier 可以复用，当且仅当 Program 能证明：

1. 存在该 frontier 的完整 StateImage；
2. Main KV 满足 target 定义的 typed coverage；
3. selected backend 的 KV 与 fixed state 满足同一 continuation；
4. token、position、Vision 和 mode identity 与 incoming prompt 精确一致。

只有 token match、KV bytes 或 page match 时，缺少的是完整 continuation，不是一次部分 cache hit。

### 4.2 Continuation 组织

Private continuation 表示一条可继续演化的会话历史：

```text
PrivateContinuation
├── exact target/token history
├── Main KV address space
├── optional backend KV address space
└── one or more immutable checkpoints
```

Shared prefix 是不可变的复用来源，可以被多个 private branches Fork。一个 continuation 内的多个
checkpoints 可以引用相同 address space 的不同 prefix，但每个 checkpoint 都有自己的完整 StateImage
identity。

### 4.3 Checkpoint 种类

| Kind | 语义 |
|---|---|
| `SessionEndpoint` | 已完成请求的最新可继续状态 |
| `TurnClosure` | 当前 turn 中可替换 assistant suffix 之前的稳定状态 |
| `ResponseReplay` | generation opener 之前、可重新生成 response 的稳定状态 |
| `LongAnchor` | retention policy 选择的较早长上下文恢复点 |
| `SharedStablePrefix` | 多条历史共同使用的不可变稳定前缀 |

`TurnClosure` 和 `ResponseReplay` 的 frontier 必须位于下一请求可能替换的 assistant suffix 之前。
这样对话系统追加新的 user message 或改写生成尾部时，仍能复用稳定历史，而不会把可变 suffix 错当成
prefix identity 的一部分。

Checkpoint 发布后：

- identity、frontier 和 required coverage 不变；
- StateImage 与受保护的 KV prefix 不再原地修改；
- Device/Host placement 可以由 resource transition 改变。

### 4.4 Valid 与 Device-ready

Checkpoint \(c\) 有效，当且仅当：

- StateImage 至少有一个完整 Device 或 Host replica；
- 每个 required KV logical page 至少有一个 content epoch 一致且 coverage 足够的 Device 或 Host replica。

\[
\forall p\in RequiredPages(c),\qquad ValidDevice(p,c)\lor ValidHost(p,c)
\]

有效 checkpoint 可能需要 H2D restore。只有全部 execution requirements 已在 Device，且 active future
reservation 可以取得时，它才是 Device-ready。

### 4.5 Exact identity

Program 的 exact verification 可以使用：

- token IDs 和 token types；
- position/MRoPE axes 与 RoPE delta；
- Vision spans 和 media digest；
- template/runtime mode；
- checkpoint frontier。

Session key、marker、hash 和 prefix index 只缩小 candidate 集合，不证明命中。

`rewrite_execution_frontiers` 也是 exact identity 的一部分。它记录 replay/root prefill 必须分段的 exact
token frontiers，使重建路径采用与原生成路径一致的 execution decomposition；不能为了采用 endpoint 而忽略。
当 NInfer 自己生成的 accepted output 形成可由历史 renderer 精确重建的边界时，所有权链固定为：

```text
Frontend detects the model-output reconstruction boundary
  -> Engine transports relative accepted-prefix metadata
  -> Program atomically commits resident identity and shortlist digest
```

Frontend 只在 canonical boundary 恰好结束于 token frontier 时发布 metadata，并让 preview rollback、stop
truncation 和 speculative partial accept 服从同一个 accepted-prefix transaction。Program 把相对位置转换为
resident absolute frontier，并与 token ledger、State/KV 和 backend state 一起提交；它不扫描输出文本。
ResourceManager 不推断或放宽这个事实。这样未经客户端改写的 NInfer 输出可以继续采用 exact endpoint；客户端
重排 tool JSON、补默认值或改写历史仍是不同的 rendered identity，只能匹配更早的合法 checkpoint。

### 4.6 Request cache participation

每个请求在进入 Engine 前固定一种语义：

- `ReadWrite`：允许读取 exact candidates、capture checkpoints，并在 finish 时发布 continuation；
- `Disabled`：只允许 root materialization，结束时释放全部 active context resources。

`Disabled` 请求仍获得正常 active completion guarantee，但不会留下 private/shared catalog entry、
SessionIndex binding 或 Device/Host checkpoint replica。Serve warmup 使用这一语义。

---

## 5. State 与 KV 的 placement 语义

### 5.1 StateImage

StateImage 是完整迁移单位。设最大 active concurrency 为 \(C\)，额外 Device checkpoint slots 为 \(H\)，
则：

\[
Capacity_{DeviceState}=C+H
\]

前 \(C\) 份容量形成 active guarantee，全部 slots 仍由同一个 Program pool 管理，不与 lane 固定配对。
Host State 以完整 image 和独立 slot 容量计费。

State transition 的语义只有：

| 操作 | 条件与结果 |
|---|---|
| InPlace | 唯一 active writer 在自己的 destination 上推进 |
| Move | private source 被 consume，原 StateImage 成为 active destination |
| Fork | immutable 或仍需保留的 source 写入新的 private destination |
| Freeze | committed active StateImage 转为 immutable checkpoint |
| Snapshot/Restore | 完整 StateImage 在 Device 与 Host 之间复制 |

Program 根据完整 post-state 选择 Move 或 Fork。Fork source 在 destination 首次 state-writing commit 完成前
保持 pin；该结算属于 active model transaction，不能与新的 global resource transition 重叠。

Active State binding 同时记录 read source 的生命周期归属。Root、Move、Restore 和 active-capture Fork
的初始 read 由当前 sequence 提供；从 retained source 或仍有 surviving checkpoint reference 的 consumed
source 建立 Fork 时，read 由 surviving owner/reference graph 保留，active primary binding 只拥有
write destination。这个 borrowed read 参与全局物理占用并由 source pin 保护，但不能通过 primary binding
再次计费，也不能仅凭 primary binding 在 abort/release 时释放；若 surviving checkpoint 本身是 active
lineage 独占的 optional checkpoint，它只通过该 checkpoint ownership 计入 entitlement，并在该 ownership
结算后决定 source 是否可释放。Fork settlement 后 read/write 都切换到 destination，生命周期重新归属
active sequence。

### 5.2 Typed KV

每个 continuation 对 Main KV 及 selected backend KV 分别持有 typed address space。各 pool 的 frontier、
capacity 和 placement 独立。

资源规划只使用以下语义：

- required logical pages 与 committed coverage；
- 每页可用的 Device/Host replica；
- immutable references 和唯一 writer；
- partial-tail COW requirement；
- restore、demote 或 release 对 capacity 与 machine work 的影响。

具体 page geometry、Host packed extent、COW 和 block-table publication 由
[Paged KV Context Store](paged-kv-cache.md)定义。

Prefix Fork 后的 active address 可以按以下顺序同时包含共享与私有页：

```text
immutable full pages | unique mutable full pages | optional unique mutable tail
```

Active capture 对不可变整页只增加引用，对唯一可写整页原地 Freeze；非对齐尾页保留给 checkpoint，并只
复制一页作为新的 active writer。对齐 frontier 不发生 KV copy，后续增长再物化新的 writer page。
Program 的 capture assessment、reservation 和 commit 使用同一个 snapshot-shape 分析，因此资源信用、
transfer cost 与实际可提交的页所有权条件一致。

State 与 KV 可以独立 placement，例如 State 在 Device、Main KV 部分在 Device、其余 Main KV 在 Host，
backend KV 采用另一种 coverage。Checkpoint 只有在全部 required components 至少保留一份有效 replica
时才继续存在。

---

## 6. Active completion guarantee

### 6.1 Admission reservation

一个 candidate 发布为 Active 前，Program 为它保障：

```text
required Device checkpoint prefix
+ remaining prompt growth
+ maximum effective output growth
+ target-defined provisional/speculative growth
+ State and partial-tail COW destinations
+ selected backend requirements
```

这些资源绑定在返回的 `SequenceHandle` 中。物化进度只在 allocation 与 reserved-but-unmapped 之间转换，
不会把容量交给另一个 request。

Active truncate 或 speculative rollback 可以解除 mappings，但对应容量仍属于该 active reservation。
只有 terminal release 或明确缩减 active entitlement 的资源 transition 才能把容量归还全局。

Active entitlement 只包含 active owner 的 destination、私有增长 reservation 和已归属于该 lineage 的
exclusive optional resources。Fork 期间借用的 immutable StateImage/KV source 不能通过 primary binding
再次计费：它若由其他 surviving owner 保留则只存在于全局 physical occupancy，若由 active lineage 的
optional checkpoint 独占则只通过该 checkpoint 计一次。否则同一 allocation 会被重复收费，并把合法的
Fork 错判为超出 active guarantee。

单并发 Native KVMem 使用其独立 select/gen budgets 保障完整 history/generation envelope；
NInfer writer address 只预留当前 execution extent。Program 在 prefill/query 边界执行原生
pressure/选块，在实际 writer 增长前显式扩展 entitlement；生成沿用已固定的 native selection，
不逐 token 重选历史。精确 native endpoint 的 admission 同样只预留初始 compact
writer extent（包括需要的 partial-tail COW 和 backend），不先向同一 physical pool 再申请完整
envelope。逻辑输出上限、原生 history/gen budgets 和 physical pool capacity 均不因此缩减。
这个单 owner 的 native 路径不改变普通 dense candidate 的 completion reservation 合同。

### 6.2 Terminal 与 capture

Native KVMem 的用户取消可以保留已经提交的物理 endpoint：Program 必须先撤销未接受的
MTP verify rows，并证明 native Store、row metadata、KV frontier 和已发布 tail 一致；Runtime
再通过与普通 terminal 相同的 catalogue publication 释放 active lane。下一请求可按原有 prefix
identity 和 recurrent checkpoint rewind 复用它。取消期间未完成的 prefill、失败 cleanup 或其他
无法证明完整的状态仍走 discard，不能把 provisional columns 当成可复用缓存。

TerminalPending request 继续持有 `SequenceHandle` 和完整 reservation，直到 Program 完成：

- **Finish**：发布一个完整 immutable checkpoint；或
- **Discard**：释放整个 active continuation。

若 Finish 无法形成合法保留终态，必须采用 Discard。Optional capture 可以通过同一 pressure graph 改变
inactive owners，但只有严格优于 private-only baseline 的完整终态才会提交；否则跳过 shared publication，
不阻塞 active request，也不改变同一 frontier 原本可执行的 private capture。

### 6.3 Persistent backfill proof

Scheduler 是否允许 backfill 由 [Engine 架构](engine-architecture.md#52-admission-顺序)决定。Program
提供的物理证明使用同一 feasibility oracle：

```text
hypothetical state =
    current stable state
    - protected donor active reservations after their terminal release
    + borrower full active reservation
    + head root materialization
    with all unprotected inactive cache releasable
```

只有该完整状态可行，borrower 才具有 persistent-safe backfill 资格。证明与 `resource_revision` 绑定，
不使用 borrower 或 donor 的预计完成时间。

---

## 7. Materialization planning problem

### 7.1 Candidate

ResourceManager 为已选 request 建立有界 candidate 集合：

- root；
- matching private endpoint；
- typed rewrite checkpoint；
- retained long anchor；
- shared stable prefix。

相同 capability 经不同 index 命中时先去重。Program 对每个 shortlist entry 执行 exact verification，
并产生一个 `AdmissionCandidate`。Candidate 固定 source、destination、prompt 和 request work，但不提前
决定 Move/Fork、victims 或最终 placements。

Root 始终存在。它不复用 continuation state，代表从 prompt 开始正常 prefill。

### 7.2 Shared publication candidate

Shared prefix 的三个状态不能混为一谈：

- **boundary** 是协议或 Engine 指出的逻辑内容边界；
- **candidate** 是 Frontend 已解析到 exact token frontier 的可选写入机会；
- **owner** 是 Program 已发布、具有完整 State/KV identity 与 placement 的 immutable checkpoint。

外部协议或 C++ `PromptInput` 每个请求最多提交四个显式 markers。Frontend 还可以生成最多三个 Engine
candidates：全部 tools 之后、连续 leading System/Developer 之后，以及 full prompt。相同 frontier 合并，
因此每个请求最多七个 prepared candidates。这个固定上限不是启动配置。

Shared catalog 是 Engine-wide 公共容量，不是每条 lineage 的配额。启用 context cache 时，默认 logical
capacity 同时覆盖 active concurrency 下限和单请求最多四个显式 markers，即
`max(max_concurrency, kMaximumExplicitPromptCacheMarkers)`；显式配置仍完整覆盖默认值。这个下限允许较早的
稳定层与较晚的滚动 marker 同时成为 owner，但是否 capture、保留或替换仍只由通用 portfolio/pressure
planning 决定，不提供 Claude、compact 或 token-position 特例。

Candidate 保存 evidence flags。策略含义为：

| Evidence | 首次出现时的准入能力 |
|---|---|
| `ExplicitBoundary` | 可以参与 pressure，但仍须有严格正净收益 |
| `RequestedAutomatic` | 可以参与 pressure，但仍须有严格正净收益 |
| `DefaultAutomatic` | 只能使用不降低现有 owner 的空余终态 |
| `EngineStructural` | 只能使用不降低现有 owner 的空余终态 |
| `EngineObserved` | 至少两个独立 reuse domains 观测到相同 key 后才可创建 |

Marker、evidence 和 shortlist key 都不证明命中；Program 对 read、dedup 和 publication 重新验证完整
identity。候选创建 source 的顺序为：exact shared owner 直接 dedup；selected exact private reuse base 在
第一次模型 mutation 前做零-prefill promotion；更晚 frontier 由 active prefill capture。早于 selected
reuse base 且没有现成 exact source 的候选只保留为需求观察，不回滚状态或重新 prefill。

Shared candidate 必须在 prefill 前决定是否增加 split，而物理状态只能在 frontier 到达时确定。因此实现
分为两步：

1. admission 已选定 materialization source 后，ResourceManager 用完整逻辑 portfolio 的乐观收益上界和
   Program 返回的精确 split cost 选择 candidate subset；这一步不预留资源，也不承诺 publication；
2. capture offer 到达后，`SharedCapturePlanner` 从当前 `resource_revision` 搜索完整物理 targets，可以联合
   demote/evict 多个合法 inactive private/shared owners。shared catalog 已满时，logical replacement 与其他
   物理 victims 属于同一个 target 和同一个 transaction。

实际 planner 的 baseline 是同一 frontier 的 private-only policy。Shared publication 是可选投资：没有可行
且严格正收益的 target 时执行 private baseline 或 Skip。

### 7.3 Target

Planner 的搜索节点是完整 target，而不是一条孤立 eviction action。一个 target 同时确定：

```text
selected candidate
selected source retained or consumed-to-active
every eligible owner retained or evicted
every surviving checkpoint and required coverage
every surviving State/KV Device/Host placement
logical publication destination
```

Eligible victims 只包括未被 active reference、selected-source protection 或 open transaction pin 保护的
inactive owners。Target 应用后产生的零引用 objects 自动释放。

Program 从该完整终态重新推导：

- Move 或 Fork；
- State/KV replacement 与 partial-tail COW；
- last-reference releases；
- active completion reservation；
- Host allocator geometry；
- ordered stage peaks；
- immediate work 与未来 recovery work。

一个 candidate 的 `identity target` 只应用 incoming activation 与必需的 source disposition，保持其他
eligible inactive owners 的 checkpoint contents 和 placements 不变。它是该 candidate 压力降级图的根。

### 7.4 单调降级图

Pressure target 从 candidate 的 identity target 沿单调降级方向扩展：

- 移除冗余 Device 或 Host replica；
- 将 Device State/KV 降为 Host-only；
- 缩短不再保留的 checkpoint coverage；
- 删除 checkpoint；
- evict 完整 inactive owner。

Program 根据当前 residual deficit、checkpoint frontiers、page/extent boundaries 和共享引用生成语义
successors。搜索不枚举物理操作的排列；每个 target 由 Program 映射到唯一规范 stage order。

单个 owner action 暂时不产生 reclaim，也不能在联合 post-state 之前被删除，因为它可能与另一 action
共同形成 last-reference release。

---

## 8. 规划目标与算法

本节中的 `incumbent` 指当前已经找到的最佳可行完整 target。

### 8.1 可行性与价值分离

Program 先判断 target 是否结构合法、物理可行以及是否仍可继续降级。ResourceManager 只在物理可行且
logical publication 可采用的 targets 之间比较价值。

成本模型不参与容量判定。任何预测误差都只能改变“选择哪个可行方案”，不能让不可行方案通过。

### 8.2 机器成本

Program 将物理工作折叠为：

```text
Immediate =
    ordered transfer phases
  + remaining Text/Vision prefill
  + required State/KV copy work
```

一次同 phase、同 direction 的 transfer batch 使用：

\[
Transfer =
\max(batch\_ns+operations\cdot operation\_ns,\ bytes\cdot ns\_per\_byte)
\]

Text suffix 的 prefill work 使用：

\[
AttentionPairs = B\,S+\frac{S(S+1)}{2}
\]

其中 \(B\) 是已复用 prefix tokens，\(S\) 是剩余 suffix tokens。Vision item/patch work 使用同一
startup-resolved machine model 的独立分量。

Transfer 系数按硬件选择，prefill 系数按硬件与实际 Text/Vision config、绑定结构和 Use 生成的
`prefill_signature` 选择。签名不使用 checkpoint/release 名称，也不包含权重数值。两组系数独立
解析；没有匹配的标定时使用对应的通用系数。成本只影响可行方案之间的排序，不是加载或执行门槛。

### 8.3 Portfolio value 与 future loss

ResourceManager 保存最近 32 个成功 materialize 为 Active 的请求。每条 demand record 保存 reuse domain
以及该请求 exact-matched、selected 或可创建的 prefix keys；不保存 prompt、媒体内容、session 原文或 API
cache key。有 Engine session key 的请求使用其稳定 digest 作为 domain；无 session key 的每个请求形成独立
domain。

对 checkpoint \(p\) 和完整 portfolio state \(S\)：

\[
Saving(p,S)=\max(0,\ Rebuild(p)-Recovery(p,S))
\]

`Rebuild` 是从 root 到该 frontier 的 canonical prefill cost。Program 根据实际 State/KV placement 枚举所有
受支持的 restore/copy/interval-prefill recovery recipes；common runner 用本次 planning problem 的同一个
immutable machine cost model 定价并取最小值作为 `Recovery`。Program 不接收 cost model，也不替策略层选择
recipe。每条 demand 只取所有 matching checkpoints 中的最大 saving：

\[
EmpiricalValue(S)=\sum_q\max_{p\ matches\ q}Saving(p,S)
\]

因此 tools、instructions 和 full-prompt 等嵌套 prefixes 不会对同一个未来请求重复计价。再加上尚未到期
的显式 shared credit，得到公共价值：

\[
PublicValue(S)=EmpiricalValue(S)+SharedCredit(S)
\]

Private retention 表示每个 owner 还有一次未观测的后续复用。比较 baseline \(S_b\) 与 target \(S_t\) 时，
保持 checkpoint identity 不变，先计算每个 checkpoint 的 saving 损失，再在 owner 内取最大值：

\[
PrivateLoss_o(S_b,S_t)=w_o\max_{p\in o}
\max(0,Saving(p,S_b)-Saving(p,S_t))
\]

不同 owners 的 `PrivateLoss` 相加。这样不会把同一 continuation 的嵌套 checkpoints 全部当作未来请求，
也不会让一个仍然可用的末端 checkpoint 掩盖较早 TurnClosure 或 long anchor 的损失。权重为：

| Private retention | prior weight |
|---|---:|
| Disposable | 1 |
| RecentPrivate | 4 |
| LiveSession | 16 |

Shared owner 没有固定 retention multiplier。`ExplicitBoundary` 或 `RequestedAutomatic` 在 publication 时带来
一个 owner-scoped credit；它在第一次后续 exact match 时消费，或在 32 次成功 materialization 后到期。
同一 frontier 的多个 evidence 不叠加 credit。

对 mandatory materialization 的 candidate identity state \(I_c\) 和 pressure target \(T\)：

\[
FutureLoss_c(T)=\max(0,PublicValue(I_c)-PublicValue(T))
+\sum_o PrivateLoss_o(I_c,T),\qquad
J(c,T)=Now(c,T)+FutureLoss_c(T)
\]

对 optional shared capture，比较 private-only state \(S_b\) 与 complete shared target \(S_t\)：

\[
NetGain=PublicValue(S_t)-PublicValue(S_b)
-\sum_o PrivateLoss_o(S_b,S_t)-ImmediateDelta
\]

执行前 candidate subset 另减精确 `SplitCost`；capture offer 到达后 split 已经发生，不再重复计费。
`ImmediateDelta` 包括 shared target 相对 private baseline 的 transfer/copy cost，并乘以当前 capture owner
及被该 global transition 阻塞的其他请求数。只有 `NetGain>0` 才发布；相等、溢出或饱和无法证明严格
正收益时保持 baseline。

Selected source 的合法 `ConsumedToActive` 是 ownership transfer，不计作 eviction。其他随 pressure
删除或降级的 checkpoints 通过 public value 与 private transition loss 进入 future loss。

### 8.4 排序提示不是证明

Program 为未 assessment 的 target 返回 physical residual、预计剩余步数、transfer/recovery work 和
稳定 ordinal。ResourceManager 将这些事实与 portfolio policy、logical publication 条件合并成 priority。
构造目标同时包含物理容量和逻辑可采用性；物理缺口为零不能代替 publication slot 检查。

这些值只决定探索顺序及 optional 额度边界是否值得继续搜索：不能标记 target feasible，不能证明
incumbent 最优，不能参与 physical readiness。组合动作可能取消拷贝，预测成本不是可用于剪枝的
数学下界。只有完整 exact assessment 与 logical-adoption check 可以产生可采用方案。

### 8.5 无压力路径

Planner 必须先读取全部 exact candidate identities。只有 Program 明确表示所有 candidate 均不需要也不能
通过 pressure 改善当前 materialization work 时，才直接 seal 最佳可采用 identity。只要任一 candidate
仍 expandable，就建立同一 bounded pressure domain；不能因为估计成本高于 incumbent 而跳过它。

最终 shared-capture split 由 ResourceManager 在 selected candidate 已确定后选择。Program 在 seal 内验证并
消费 `FinalScheduleIntent`；返回的 `ResourcePlan` 不再具有 post-seal mutation API，Scheduler 看到的
summary 已是最终值。

### 8.6 Correctness incumbent

若没有 identity target 同时满足物理与 logical publication 条件，Planner 在 optional budget 之外 assessment：

```text
root candidate
+ release all unprotected inactive cache
```

root maximal target 由 candidate-specific eligible domain 构造；selected source 没有 victim cell。它不保留
可牺牲 cache value，但保证 heuristic、target budget 或 wall budget 失败不会把本可运行请求误判为 blocked。
active requirements、source required coverage、writer 和 transaction pins 始终留在 Program 的 requirement
union 中。

若 isolated root 超过静态合同，结果为 permanently infeasible；若 isolated root 可行但 active guarantee、
lane 或 open transaction 阻塞，结果为 temporarily blocked。

### 8.7 有界 heuristic search

Materialization 与 shared capture 使用两个 typed entrypoint。Materialization 的 incumbent 是已验证
identity 或 root maximal；shared capture 的 incumbent 是 Skip，只有 exact `NetGain>0` 才替换。

一次 planning problem 中：

1. ResourceManager mint candidate/owner IDs，保留到 catalog capability 的唯一映射；Program 为每个
   candidate 建立 selected source 结构性缺席的 eligible victim domain。
2. Program 持有 opaque targets 与分片构造状态；Runtime 按预计完整 J 和缺口改善排列合法选项，
   兼顾价值与尽快形成可行方案，不构造 State/KV action。
3. 优先评估完整候选，失败后根据精确物理与逻辑反馈继续修复。Host geometry 等不能由总字节量
   证明的条件需要更早的 exact feedback。局部构造以外保留普通 alternatives。
4. 完整联合 post-state 结算 unique objects、alias、Move/Fork、COW、Host geometry 与 stage peak。
   只有物理可行且 logical adoption 成功的结果参与最终 J 与稳定 tie-break 比较。
5. 任意 optional 时间、工作或容量预算耗尽，返回最佳已验证 incumbent。

构造、修复、普通 expansion、maximal target 与 seal 共用 candidate-specific domain 和 exact evaluator。
游标、target arena 与借用摘要只在同一 planning session/revision 内有效；批次停止或丢弃不能产生
真实资源 mutation。结束搜索后不跨 decode/prefill 恢复旧状态。

Engine 提供 admission boundary 共享的 optional 时间额度，head/backfill inspections 不能各自重置。
Quiescent native owner exchange 是该 policy boundary 之前的物理阶段；只有实际改变了 native
资源状态，Engine 才在其完成后建立新 boundary。Hot/no-change 与普通 dense path 不重置额度。
交换期间仍消耗请求的 queue deadline，完成后必须重新检查 cancellation/deadline；不能通过
新的 optional 时间额度延长请求期限。
预算考虑其他 runnable 请求及本 boundary 已花费的时间。Planner 先用短窗口搜索，再根据尚可获得
的预计改善和完成成本决定是否续额；不完整预测只有受限探索机会，已实现收益不能反复用于续额。
Target、工作量和 session storage 仍独立有界。

Identity 与 root maximal correctness assessment 不因 optional 额度耗尽而取消。时间在 Program
operation 之间检查，估计误差可造成单步越界；最终 seal 仍必须完成。因此预算只影响 cache quality，
不改变 mandatory readiness，也不承诺整个 planning 调用可在任意时刻中断。
Shared capture 维持独立的固定 target budget 与 Skip incumbent。

### 8.8 目标函数与确定性

对 exact feasible assessment：

```text
J = price(Program machine work)
  + ResourceManager portfolio loss
```

Program 只形成 canonical transfer/prefill work，并为 checkpoint recovery 枚举受支持的物理 recipes；
ResourceManager 提供 demand、retention 和 shared credit；runner 使用同一次 planning problem 的 immutable
machine cost model 统一定价并比较。成本模型不会进入 Program API，只能改变已验证 targets 的探索和选择
顺序，不能改变 physical status、readiness、source protection 或 target generation。

相同 `J` 下依次偏好：

1. 少影响已观测命中的 checkpoints，保留最近命中；
2. 少 owner eviction、checkpoint deletion、copy operation 和 transferred bytes；
3. 少剩余 Text/Vision prefill；
4. 多复用 prompt tokens；
5. 当前 session binding；
6. candidate 与 target 的稳定 ordinal。

停止原因只描述实际边界：`no_pressure`、`queue_exhausted`、`target_budget`、
`expansion_capacity`、`time_budget`、`work_budget` 或 `insufficient_expected_gain`。
`time_budget` 也包括预计下一不可分操作无法放入余量的情况。它们不声明当前 target graph 或真实
TTFT 的全局最优性。

### 8.9 Readiness

最终结果只有四类：

| 结果 | 含义 |
|---|---|
| `PermanentlyInfeasible` | isolated root completion requirement 超过当前 Engine 合同 |
| `TemporarilyBlocked` | 单请求可行，但当前 active/lane/transaction 状态阻塞 |
| `NeedsTransfer` | target 可行，需要异步 transfer 或 pressure stages |
| `Ready` | target 已 Device-ready，可在当前 boundary 同步发布 |

`TemporarilyBlocked` 只在 lane、FIFO protection、open transaction 或 resource revision 变化后重新检查。
普通 decode 不重复运行 planner。

---

## 9. Resource transition

### 9.1 三个对象

需要 allocation、pressure 或 transfer 的终态通过：

```text
ResourcePlan
  -> RunningTransaction
  -> ResourceResult
```

- `ResourcePlan`：Program seal 的 immutable、move-only、revision-bound transition；
- `RunningTransaction`：Program 当前执行中的唯一 global resource transition；
- `ResourceResult`：Committed 或 Aborted 的完整稳定结果。

Active reservation 已经覆盖且不需要新 allocation/transfer 的 finish、discard 或 inactive release 可以作为
零阶段原子 transition 完成，但仍遵守同一串行化、revision 和完整结果规则。

### 9.2 Start

Program 在第一次 mutation 前重新验证：

1. plan 的 `resource_revision`；
2. source、victim 和 destination capability generation；
3. ResourceManager 已保留的 logical publication capacity；
4. 当前 allocator 对每个 ordered stage 的容量和几何；
5. source/victim dependencies 与 active protections。

Stale 或不再可行的 plan 在 start 前无物理副作用。Start 成功后，source、victims 和 destinations 被
claim/pin，plan 被线性消费，不再更换 candidate 或 target。

ResourceManager 在调用 Program start 前先建立唯一 logical transaction record，并把所有 source/victim 与
publication destinations 置为 claimed/reserved。Program 在第一次物理 mutation 前完成自己的 preflight。
同步 start 返回 Aborted 时，ResourceManager 回滚完整 logical claim；start 成功后 logical record 与 Program
transaction 一直同时存在，直到 stable result adoption 或 Engine-wide cleanup。

### 9.3 Progress

Transaction 可以跨同步 copy 或 CUDA event 推进。每个 replacement 遵循：

```text
destination reserved
  -> copy complete
  -> epoch/coverage verified
  -> replacement published
  -> old replica released when unreferenced
```

Materialization 与 active capture 共用一条单调 pressure phase：

```text
HostReleases -> CopyPreparation -> CopiesInFlight? -> CopyPublication -> Committed
```

phase 是全局 pressure 顺序的唯一 authority。每个 owner work 可以保存 destination/copy 是否已实际提交以及
mutation 是否已发布的执行事实，用于形成 absolute result；这些事实不能改变或绕过全局 phase。无 copy 时从
`CopyPreparation` 直接进入 `CopyPublication`。Cancellation 只在稳定 phase boundary 采用，已发布的 Host
release 或 victim eviction 通过绝对 `ResourceResult` 报告。

同一时间至多一个 global resource transition。既有 active execution 只有在使用自身既有 reservation、
且不触碰 transaction mappings 时才能与 transfer 交错。

### 9.4 Commit

Commit 发布：

- new active sequence 或 checkpoint；
- selected source disposition；
- 已提交的 owner/checkpoint degradation；
- stable State/KV placements；
- transaction pin/reservation cleanup；
- 必要的 `resource_revision` 变化。

`ResourceResult` 包含 ResourceManager 采用逻辑终态所需的绝对结果，不包含供上层重建物理 occupancy 的
delta。每个 owner claim 绑定确切的 `CheckpointRef` 删除集合，而不是只绑定删除数量；ResourceManager
逐项核对最终 summary 恰好等于原 checkpoint 集合减去该集合。因此同数量但不同 checkpoint 的替换会在任何
catalog mutation 前失败。ResourceManager 在 start 前已预留 adoption storage，因此 commit 后的 adoption
不能进行新的容量判断。

### 9.5 Abort

Publication 前的 cancellation 或执行失败可以得到 request-local abort，只要 Program 仍能形成稳定物理状态。
Abort 保证：

- selected source 仍有效；
- target 没有半 Active 或半 published checkpoint；
- unused destinations、reservations 和 pins 已释放；
- 已安全完成的 victim demotion/deletion 被明确记录在 `ResourceResult` 中。

已经发布 replacement 后完成的合法 pressure degradation 不需要逆向复制回原 placement。ResourceManager
采用 abort result 中的实际终态，而不是回放中间 receipts。

若 Program 已无法形成可解释的稳定状态，则进入 Engine-wide failure。

---

## 10. Retention、session 与 publication

### 10.1 Retention policy

Private retention class 通过 owner prior 影响 portfolio value，不提供固定 eviction 顺序。Shared owner 的价值
来自真实 demand 与尚未到期的 explicit credit。Planner 可以组合：

- 删除冗余 replica；
- 将 Device replica 降为 Host-only；
- 删除不再保留的 checkpoint 或 suffix coverage；
- evict 完整 inactive owner。

如果一个 placement change 会删除 checkpoint 的最后一份完整 State 或 required KV coverage，同一个
target 必须先建立 replacement，或同时删除该 checkpoint。

Placement 只在 admission、capture、finish 或显式 inactive release 的 resource boundary 改变。普通 decode
不运行周期性 promotion/demotion。

### 10.2 Session ordering

SessionKey 属于 ResourceManager，只提供 candidate lookup 与 binding。Program 不读取 SessionKey。

每个可更新 SessionIndex 的请求取得单调 `publication_order`：

- 新结果只有 order 更大时才能替换当前 binding；
- 较旧请求晚完成时成为 anonymous cache 或按 policy 释放；
- matching private source 可以在合法时 consume-to-active；
- shared source 始终保持 immutable；
- abort 只能恢复自己仍持有 exact claim 的 former binding。

Capability generation 判断 handle 是否仍有效，publication order 判断哪个完成结果更新 session；两者职责不同。

### 10.3 Logical publication capacity

ResourceManager 必须在 Program mutation 前预留 active/private/shared destination slot。Program commit 后的
logical adoption 不再扩容或搜索 slot。

Private Move 可以复用 source descriptor；root 或 Fork 需要 destination。Optional capture 没有 slot 时跳过；
terminal Finish 没有合法 publication capacity 时采用 Discard。

### 10.4 原生 KVMem 的 same-run 冷会话

显式 KVMem 模式目前要求单并发。原生会话交换在无 active request、无 open context transaction 的
quiescent boundary 进行：请求前选择同一 owner 的精确 endpoint 或已保存的较早循环边界，
terminal Finish 完成后可以维护其他 idle 会话。
这不创建第二套 catalog、SessionIndex 或请求调度器。

精确 endpoint 是缓存 producer 与 archive consumer 的共同合同。KVMem 模式的 Engine
normalization 将 generic shared-prefix/long-anchor 容量置零，因此 server 自动 long-anchor
数为零；Program request planning 不发布 template rewrite/shared/long-anchor 可选 capture。
否则普通多消息请求可按 dense 默认策略留下 long anchor，而后续 A→B owner exchange 在
停车前被 exact-endpoint guard 拒绝。此规则不删改 prompt/template/control tokens 或其执行
frontiers，不禁用 native 有界循环边界/replay checkpoint，也不改变 endpoint 发布与
target/follower 停车次序。Dense 模式的可选缓存功能保持原样。

Program 按 pinned `multimodal_remember` 保存最多四个 query、完整媒体项消费前、evaluation
结束及 generation 结束的 CPU 循环检查点；新 row 删除该 row 及之后的旧记录，超过四项
时沿用媒体偏置淘汰。原生在 media decode 前保存；本地 causal 路径取整个 VisionItem 的
首个 consumer begin，MTP 因使用 x[t+1] 则提前一行。媒体 encoder/shadow forward 前才
保存，前一段的 tail hidden 已提交；不把视频后续帧变成独立恢复点。与 query 同 row 时
共享已有 payload。Payload 的不可变 backing 自有 pageable StateImage、layout 和 tail mean，
逻辑内容不可变不等于始终常驻 RAM：idle 迁移将 image/mean 的实际 owned vectors
按 shared storage 去重，追加到 Raw/follower 的同一 Native `SnapshotBuffer` manifest。
Descriptor 的 layout/frontier/MTP carry 与预期 mean 长度仍可用于只读匹配；image 与 mean
可以各自 mixed/cold，不得用空 vector 伪装成有效 Host image 或非空 tail mean。
实际 Native chunk 释放/恢复量进入既有 transfer units 和 Host headroom 规划，manifest
pin 住共享 storage，全部分块恢复并清理 Native files 后才可安装为 inference owner。
Host state slot 报告只计算真实 resident images；固定 endpoint 的 Core StateStore 不改。
小 descriptor 保存 MTP carry；live query replay 持共享引用，不占新的固定 Host pool 或
Device arena。请求已完成 evaluation 且只 Begin 确认采样、没有新 target 输入执行时，
terminal 可共享该 backing，并独立采用清理后的 draft carry；实际生成后的状态照常捕获。
Retained vector capacity/backing 与被淘汰但仍供 live replay 使用的 backing 均计入 native
archive RAM，按 storage identity 只计一次；Host slot 报告同样不重复计算 descriptor aliases。

Program 在只读 matching 中从 endpoint 开始按 frontier 降序选择最大精确匹配；先用
RequestBasePlan 已有的 prefix shortlist 排除摘要不等的候选，摘要相等仍须验证实际
token、位置、结构化媒体和 runtime mode。ResourceManager 对该 row 的 Program-minted
shortlist key 做 base-plan 校验；SessionIndex 仍只绑定同一 existing owner。
未命中当前 SessionIndex 时，还可检查显式 restore 等留下的未绑定、无 active edge 的
private catalog owner，仍调用同一 Program 精确 matching，选择最大已保存 frontier。
已经匹配的当前 session 优先；不能因内容相同而接管其他 session-bound owner，也不
在 matching 中为恢复的 owner 伪造 HTTP session key。正常 consume/publication 才建立
请求的新 binding。不能从一个
任意未保存 LCP 虚构 GDN/target/follower 状态。较早恢复排空并释放 execution views，
必要时通过既有冷 transfer thaw 完整 archive，再在 host-only/quiescent 状态截断 native
Runtime、target/follower Raw 与 row metadata，恢复部分尾块 mean。Q 范围越过新 frontier
时失效；保留 frontier 内的 prior resident IDs 并补上 checkpoint 尾块。

Frontend 的 exact user span 保留完整用户起点和媒体之后的未裁剪 Q 范围。Program 在
Native prefill、mandatory/replay planning 与 cached-Q matching 中统一使用其尾部副本：
`begin = max(source.begin, source.end - min(query_max_tokens, source.end))`，默认最多
512 tokens，与 pinned server 的 `clamp_query_span` 相同；它不裁剪 canonical 输入，
也不把 32,768-token 历史选块预算缩成 512。短 Q 坐标不变，完整 `user_begin` 不变。
Saved Q 的 begin/end/count 必须与本次有效 capped 范围一致；旧的未裁剪长 Q 或不同
有效 cap 不得被误判为可 freeze 的同一 Q，不需要改 snapshot 格式或伪造来源。

Cached user Q 的来源单独拥有 exact canonical user begin、capped Q begin/end 和完整 prompt 的
`VisionItem` identity（content digest、grid/patch、全部 frame spans/timestamps），不从
已经安装的 incoming `prefix_identity` 反推。原生 `run_prefill_multimodal` 的 same-query
判定比较整份 `media_identity`，包含用户之后的工具媒体；本地采用既有 exact media
比较而不只比较 Q 范围内或 reusable prefix 内的项。不保留 pixel body，也不引入第二套
选块/缓存政策。只有完整 Q count 与范围长度一致、prefix 已精确许可且全媒体 identity
相同时才复用旧 Q。新鲜 suffix capture 清掉 exact 来源；same-query 保留后续已观察
`[user_end, base)`，包含工具媒体，及原生部分尾块；mandatory band 放不下则使用新鲜
suffix Q。Q 本身被回退掉时清掉全部来源；Q 仍保留时不可截短媒体 key，原 prompt 中
尚未消费的工具媒体可以合法位于当前 checkpoint 之后。它独立随 park/swap/freeze/
冷恢复和完整 snapshot 搬运，其 vector 与嵌套 capacities 计入真实 archive RAM。

同一 exclusive endpoint StateImage 的全部 Device/Host replicas 被替换，内容 epoch 更新；
ledger/identity/digests、draft carry、rebuild work 与 compact frontier 一起采用。随后沿用
native restage 和 target/follower execution reconstruction。PrivateEndpoint 追加前仍按既有
bridge 规则将 follower 裁为 compact target frontier 减一，此时同步按 resident native blocks
重建执行 map，保留 original positions 与 compact offsets。只少最后 logical row；仅一行
尾块不产生 follower record，不能由旧同步 map 声明已裁掉的行有效。ResourceManager 从 absolute summary
刷新同一 catalog capability 的 endpoint/revision、SessionIndex 和 prefix index。截断前的
安全 preflight 失败保留原 archive；开始截断后的部分失败仍是 physical/fail-stop。NInfer
保存 continuation hidden 是本地适配，可从完整已执行 prompt 的 hidden 恢复既有采样；
不声称与原生未保存 logits 的最后一行处理或 recurrent wire format 相同。

取消仍遵循 Engine/Program 的既有 release/discard 合同：先消费或 abort pending batch，
再释放 continuation 与 native owner。原生 tool server 的 request-base rollback 是不同的
控制器/缓存 publication 策略，不因复制其 bounded checkpoint policy 而隐式采用。

显式完整 native snapshot 为本地 v6，保存该最多四项目录及全部 recurrent bytes/carry/mean
与重建 metadata，并在 restore 时验证 checksum、config、frontier 顺序、mean 几何和
完整 VisionItem 边界及独立 cached-Q 媒体来源；Dense v3 不变。旧 native v4/v5 不被默默
当作当前格式。本地 parked archive 为 v5，same-run Runtime record 为 v6，旧 metadata
layout 直接拒绝而不补造来源；Native Runtime/Raw codecs 保持原样。此 portable API
与下述 same-run 冷文件不同，后者仍将 identity/checkpoint metadata 保留在当前进程。
Native restore 的重建成本使用当前 Program prefill chunk 和序列化的完整 VisionItems、
rewrite frontiers、各自 rebuild_tail_begin 调用同一 canonical producer，不直接采用旧
chunks，也不改变真实执行分界。Dense v3 未保存全部 planned capture 分界，仍保留原
成本，未声称跨 prefill-chunk 配置的成本完全归一化。

ResourceManager 从现有 private catalog 产生稳定的 idle LRU，排除 selected owner、active edges 和
claims，并保持最近使用信息。Program 只接收 authorized capabilities 与顺序，不读取 SessionKey 或
retention 价值。Program 测量 native archive/query/recurrent-checkpoint metadata 的 allocation capacities，先证明完整
temporary RAM/disk transfer schedule，再通过 ResourceManager 的 callback 采用 final-capacity LRU
eviction。成功或后续失败后，ResourceManager 均从 Program 的 absolute continuation summaries
采用已完成的安全 demotion。普通 dense path 不构造这份 LRU。

`KVMemOptions::session_ram_bytes` 是 soft archive budget，零表示无限；不把未来 generation 的
worst-case reservation 当作当前 retention 占用。该预算不包含既有 fixed Engine/Program arenas、
prefix bookkeeping、weights、workspace 或 Program 的可重算 image-feature LRU；这些仍影响
原生 OS headroom 检查。Image-feature body 的独立 64 MiB 上界及 transfer lifetime 见
[Engine 物理执行约束](engine-architecture.md#8-物理执行的顶层约束)，不计入 native archive charge。
Selected/attached
owner 与冷 metadata 可使 soft limit 继续超出，hot/fresh 请求不依赖 optional migration 成功。

未配置 same-run disk cache 时，opt-in RAM compaction 仍保留完整 serialized archive，
不能把即将释放的旧 arena 提前算作新输出的可用空间。Program 在旧 owner 停放后刷新
unchanged native `session_memory_available()`，将该 measured headroom 明确交给
`Parked::compact`。既有 no-sink writer 先校验/计数，只有完整输出加 writer 的 packed-block/
metadata scratch 能容纳、且输出严格小于本次会释放的 Runtime/Raw/follower allocation，
才预留输出。预留后再按实际 vector capacity 复核相同证明；流写不允许超出计数大小。
非获益或峰值不足走既有 optional preflight 失败，热 archive、精确身份和 retained
checkpoint 不变，不请求额外 LRU。Native headroom 是带余量的 OS physical/commit 估算，
不是进程 reservation 或绝对 OOM 保证。成功输出后重新确认完整 host backing，直接释放
无 GPU/pending/NVMe 的私有 Runtime arena 与 bookkeeping，不为即将销毁的 owner 再分配
native dropped-block vector；真实 rewind 和 attached owner 的清空规则不变。

这不免除 fresh owner 的实际 allocation 准入。Conversation 从启动时真实创建的空
Runtime/Raw/follower bundle 保存 measured allocation size；transfer planner 和空 owner
重建共用该事实。每次 detached fresh 创建都独立刷新 unchanged native
`session_memory_available()`，即使 optional migration 已失败。Headroom 不足时不构建或
发布部分 owner，不额外请求 LRU，不把 RAM soft limit 变成硬 quota；原 parked archive
仍由既有 catalog 拥有。完整构建后才重新绑定 execution consumers，绑定失败仍标记
physical state poisoned。健康交换的 storage/allocation 失败使用既有 `Unavailable` 请求错误，
不把 temporary resource failure 解释为 corruption/cache miss；这不是进程级 OOM 保证。

Engine 将 read-only base-plan 准备与 native exchange 的异常边界分开。Matching、LRU
vectors 和 eviction callbacks 的 CPU allocation 在进入 physical transaction 前完成，
其失败可明确拒绝当前请求；进入 Program 后只有已分类的 `RequestError` 走该路径。
ResourceManager 仍须在成功或安全失败后采用完整 absolute summaries 并刷新 SessionIndex
revision。若 reconciliation 不变量失败，它覆盖原有的 request-local 错误；未分类的
physical failure 交给既有 Engine fail-all，而不是继续运行下一请求。

Publication 开始后若 consumed private source 已转为 active destination，request-local
逻辑失败的 lane cleanup 会释放该 source。Program 的 aborted source acknowledgement
必须明确报告 `released`，不能再宣称其仍被 retained。ResourceManager 只在有原始 error、
原计划为 ConsumeToActive、无 active owner edge 且无 final summary 时接受此结果，删除
该来源的 catalog/session-index 绑定，保留其他 owners，并让下一请求从完整 prompt 重建。
Publication 前的取消和安全失败仍按原规则保留 source；未知物理失败仍走 fail-all。

冷文件复用 unchanged native session-file manager，采用 private same-run directory 与 charged
temporary/final files。Final placement 可以 credit 即将恢复并删除的 target file；只有 **final** disk
capacity 不足且整个 schedule 已证明可执行，才按 authorized LRU 淘汰。Temporary-space、I/O 或
deletion 失败不产生额外淘汰请求。每个 allocation chunk 都保持 publish-before-release 与完整
read/checksum-before-adoption；deletion 失败保留已经验证的 RAM、原 file 与 disk charge，重试
只删除重复 file，不重新载入或覆盖有效 RAM。
Runtime 已在 RAM 而只缺失 Raw chunks 的 mixed archive，只计这些 native vectors 的
restore allocation，不再次计入 Runtime parser/packed-block scratch。已发布完整 Runtime
file 的 resident owner 再次换出不重新写文件；确认无 pending/in-flight/GPU blocks 后，
完整释放其私有 CPU arena 与 tier bookkeeping，不先分配逐块截断列表。还未发布 Runtime
record 的普通换出仍必须证明原 writer scratch，且始终 publish-before-release。
原生 Raw 写入及 cleanup 同时失败时，unfinished temp 的全部 quota charge 不代表相同
大小的实际物理载荷。新 transfer 的显式 preparation 只对仍有完整 RAM allocations 的
unfinished chunks 调用原生 delete-only restore 分支，不读取、发布或释放它们；然后再
获取 owner footprint、quota 与 filesystem headroom。删除失败保留剩余 charge/RAM，
已完成的部分 cleanup 也必须刷新 resource revision 与 absolute summary。Footprint
accessor 和纯 planner 不把 unfinished record 当成 ready file，不以其整份 quota charge
制造 physical credit，不因此扩大 LRU authority。
Configured disk quota 与 filesystem physical headroom 使用独立 ledger。必须恢复缺失载荷的
selected cold owner 时，最终 placement 同时满足 quota 与 `charged bytes + physical free`，
复用 pinned `session_balance` 的 final-capacity LRU；这是最终 footprint，不是 spill-first
临时写入需求。先 credit 即将恢复删除的 target files，再只从 authorized idle LRU 回收
必要 owner，并证明完整 exchange 可执行。Configured quota 本身不变；每次写入仍同时
满足 quota 与即时 physical ledger，实际 tracked-file 删除才 credit physical headroom。
Hot/fresh 的 `OptionalRetention` 不因 physical-space pressure 额外淘汰缓存；空间不足保留
原 RAM archive。只有 frozen bindings、没有缺失载荷或 charged files 的全 RAM target 只需
thaw，不进入 mandatory transfer，不能因另一 owner 的 optional spill 失败而拒绝该 warm hit。
LRU 删除采用 pinned `conversation_evict` 的独立规则：在可能部分成功的多文件删除前先
invalidate 该 frozen manifest。删除失败时保留 charged files 和可清理 owner，但 matcher 不再
把缺少 sole KV copies 的会话选为 cache hit；这不等同于 restore 后删除重复副本的情况。
已绑定的公开 slot snapshot 在删冷文件前通过 eviction observer 同步捕获为未发布文件，
返回只拥有该文件和摘要的 move-only prepared save，不保存借用的 Program producer。
文件关闭后重新读取 actual RAM、native file charge 和 filesystem headroom，用同一个
Native-derived planner 证明完整剩余 schedule。新计划的 victims 必须是首次计划授权的
子集；optional public snapshot 不能要求多删除一个缓存 owner。若不再需要某 victim，
先删除其私有 stage 再核算；若空间不足或需要新 victim，丢弃全部 optional stages 后
只重新规划一次。仍不可行时，保留 cached owners，沿用 required/optional transfer 的
既有失败边界。只有证明成功才提交这些 ready files、invalidate/delete 原生冷文件并
释放 catalog owner；文件的 rename/跳过发布不增加已计入的 body 占用。Public stages
不伪装成 native quota charge，但其 actual filesystem footprint 不能遗漏。Binding 只在
catalog 实际 release 时清除，不能因一个后来失败的 planned eviction 提前丢失。

请求前的 cold-target preflight 区分真正的 missing/truncated/checksum/identity/byte-parser
corruption 与临时 I/O、allocation、permission/locking 失败。只有前者进入 pinned
`session_begin_request` 的 cache-miss 规则：Program 先 invalidate，再删除该 target 的 tracked
files；全部清理成功后返回 `NativeSessionSwitchResult::cache_miss`，ResourceManager 通过既有
`take_catalogued` / Program release 清除该 exact capability、SessionIndex 与 slot-file binding。
然后同一请求、prompt、base plan 和 session key 进入普通 fresh-context admission，不创建新请求。
已损坏的 payload 不调用保存用 eviction observer。若删除只成功一部分，request 仍报错，剩余
charge 和不可命中的 owner 继续保留；不能把这次 cleanup refusal 当作成功 cache miss。

Parked endpoint 不持有 live KV address bundle，但仍保留 immutable StateImage 与完整 archive。
Checkpoint recovery profile 和 pressure projection 必须按 archive 的 prior resident blocks
计入未来 Main KV 整块恢复（每块两个物理页）、accepted follower rows 恢复与必要的 Host State
上传，不能访问不存在的 live pages。普通 State-only pressure 可以迁移其 StateImage 或删除
重复 replica，同时保留 exact endpoint、archive 与 SessionIndex；完整 owner eviction 才释放
该归档，不能将 State demotion 伪装成 cache miss。

Native transfer schedule 执行期间拒绝 reentrant GPU owner exchange。冷 Runtime/Raw 文件的
portable export 不需要重新占用 GPU，允许 bound-slot observer 读取而不停车 selected owner。
仍在 RAM 的 Runtime 需要 sole backend；若 observer 的 best-effort save 会改变已证明的 plan，
它被拒绝，不影响选中 owner 或引入额外 CPU arena。普通显式 save 在 transfer 之外仍可停车。

Host-only Runtime 的导出／导入继续通过 unchanged Native `prepare_selection`、
`spill_outgoing`、`admit_incoming` 访问其私有 CPU arena，不直接窥读或复制 Native 内部布局。
本地页后端在独占同步的 archive scope 内最多保留一个逻辑 slot，以既有固定 Host bounce
buffer 实现公开的字节 copy hooks，不为这段 CPU-to-CPU 搬运分配物理 GPU 页或提交 CUDA
拷贝。它不新增 block scratch、归档格式或第二套持久化存储；推理／prefill 的真实 slot 仍
使用原有物理页通路。开始时须无驻留 slot／prefill admission；逐块恢复完整 Native CPU
ownership 后才交付输出，成功退出时不得残留 slot。异常仍由原调用者的 cleanup／fail-stop
边界处理，不将中途失败包装成可复用缓存。Checksum、冷目标预检、计费和发布顺序不变。

Raw/follower store 直接通过 unchanged `snapshot_buffers` 冻结真实 vectors；最多四份循环
checkpoint 的 image/mean 直接绑定各自原始 vectors，按 shared storage 去重而不是复制
整份 StateImage。两类分配由同一 unchanged native
`kvmem_session_payload` 持有可信 shape/count 与 `KVCHUNK2` 文件并执行分配级搬运。部分迁移
失败保留同一份 mixed manifest，只有全部恢复并删除重复 files 后才解除 bindings、安装为
inference owner。绑定的 Raw objects 和 checkpoint storage 不得 resize/relocate 或参与推理。
Runtime 已恢复但重复文件擦除失败时，其 RAM 仍占账，未删除文件及 Raw/checkpoint manifest
仍归原 owner；后续 restore bytes 只包括尚未驻留的 vectors。剩余 restore peak 另计逐块
文件流与 Native SnapshotReader 的同时存活开销，不重复收取 Runtime 解析 scratch。
每个未驻留 Raw transfer unit 都携带这两个对象的开销，不依赖 Runtime 的恢复顺序；
Raw spill unit 同样携带输出流与 SnapshotWriter 的开销。此处使用实际 C++ 对象的
`sizeof`，不包括动态 filebuf 和 OS cache，也不宣称完整进程 RSS 峰值；既有 Native
headroom 余量不变。整个 owner 的 restore scratch 取顺序执行的 Runtime 解析与
Raw IO 最大值，而不把所有 reader 同时相加。
Portable export 从 mixed manifest 有界流式组合，不先恢复 Raw 或 recurrent allocations。
显式 save 只为导出排空并停车当前 native owner，不构造没有下一请求的 fresh empty
Runtime；后续真实 fresh request 仍独立证明和创建所需空 owner。源 owner 和原生
headroom/transfer 权限保持原样，save 失败仍按实际 physical placement 对账。
完整 native v6 的 Program save 先用 unchanged `SnapshotWriter` 的无 sink 计数模式获得
archive 长度，包含 cold Runtime/Raw 时不读取其 payload；本地 envelope 使用同一字段遍历
计数与输出，检查完整长度。Recurrent prefix 的 sizing 只使用保留的预期形状，不读取
cold payload。输出时最多四份已保存 recurrent StateImage/mean 从 resident backing 或
Native cold chunk 按原 v6 顺序分块输出，不先恢复或复制进另一个 prefix vector。
Cold body 读取仍验证原生 id/generation/count/整文件 checksum，失败保留 source/charge。
Archive 仍由独立 fresh Native writer/checksum
直接输出，endpoint 为 Host-only 时借用其 view，否则只暂存一份 D2H image。外层保留
原 v5 checksum seed，它不同于 Native 内层 archive；不重复计算未消费的第三份 hash。
Parked/Runtime archive codec 对 fresh Native 流直接借用同一 seed/body 的原生 hash，
不再另走一遍 payload 计算同域校验；在八字节 trailer 前固定 archive body hash，Native
仍把 trailer 纳入其 transport hash。Vector config/span 解码保留原本地校验与 little-endian
编码。冷文件先有 28-byte `KVFILE01`/id/generation/length 身份头，故其 factory 提供
fresh payload Native 子流而不是把已消费 header 的 containing stream 交给 archive codec；
完整文件仍独立校验 header 加 payload（含 archive trailer），并验证 payload 完整长度。
这两个文件/归档作用域及 Raw、packed-block 和不同 seed 的外层校验都必须保留；不能把
减少 direct fresh-stream 重复扫描宣称为冷文件只校验一次或另一个格式。
`Program::write_continuation` 同步交付 borrowed chunks，只返回 bytes/tokens/digest 摘要，
不会返回完整 native snapshot vector。Dense v3 仍用既有完整 vector 生成原编码后交给 sink；
不能把 Native 的额外输出内存改写宣称为 Dense 也不再持有完整 body。
Engine 显式 save 与 eviction save 均以独立 capture thread 通过固定 2 MiB ring 写临时文件，
每次 write 至多 1 MiB；有界 backpressure 不保留 Program 输入指针。文件先打开，producer
仍在持有 continuation 的原调用线程运行，EOF、关闭检查与 join 完成后才返回 ready file。
异步 spill queue 只拥有已提交的完成文件和摘要，不持有大 body、CUDA 调用或借用的 producer。
Native transfer 中的 provisional file 在重新证明前不进入该队列，放弃 prepared save
只清理其未发布私有文件；普通非 Native-transfer 的 eviction 捕获后直接提交。
Capture writer 不使用 publication gate，也不排在等待该 gate 的 publisher 后面：mapped
restore 触发两次以上 eviction 时，不能因第一项等待输入 lease、第二项 ring 写满而死锁。
Publisher 取得 lease 后按最新高水位决定覆盖，并更新 guard；explicit save 仍先 drain。
未发布临时文件由其唯一 owner 清理，stream/checksum/close/publish 失败不替换原好文件。
原 archive 与 file charge 保留；只有实际 native tier transition 被标记失败时才沿用既有
fail-stop，显式 save 成功/失败后的 physical placement 复用既有 absolute-summary 对账。
已有 in-RAM compact parking、仍驻 RAM 的 recurrent backing、恢复 arena 和 OS file pages 仍占资源，
ready files 也占真实磁盘空间。2 MiB 是单次输出通道的 ring，不是全部 Host/disk 峰值，
也不是 durable restart、整机容量或 TPS 证明。Auto-save seconds 包含 capture/stream 和
publication（含 lease wait），不含中间 queue wait，不能当作 disk-only throughput。

显式 v6 import 同样借用原始 snapshot span，先完成 Native Reader 的只读 config、block
records 与全 archive checksum 检查，再用借用的 row/query/resident metadata 对账 ledger。
Raw 的原生 framing 已有逐块 section length：本地适配借用 Native writer 的空 header，
把每个原 section 交给 unchanged `RawKvStore::snapshot_read`，只保留一个 block 的探针。
向量、格式、计数、partial frontier 与 saved resident coverage 均在准备目的 owner 前检查；
不是另写一套 Raw 向量解码器。探针的实际 `allocated_bytes` 差额累计为完整 Raw 分配量。
Native parser 的字节错误归为 corruption，source I/O 与 allocation 错误保持原类型。
最多四份 recurrent image/mean 此时仅保留有界的借用描述，验证尺寸但不复制大 body。
内部 exchange 的导入模式不创建 fresh empty Runtime，transfer planner 也不登记其
synthetic incoming allocation；停车旧 owner 后释放已有空占位。随后把启动时实测空
Runtime/Raw footprint、已测 Raw 增量、metadata/shape/单块读取 scratch 和 recurrent bodies
一起与原生当前 Host headroom 比较。仅准入后才复制循环状态；实际 capacity 分配后再查
剩余 owner headroom，最后准备固定池 StateImage 并构造完整 Runtime/Raw。显式导入不
获得额外 LRU 淘汰权限，OS headroom 也不是内存预留或全进程 RSS 峰值保证。
普通 fresh request 和 cache-hit 模式不改变。早期字节拒绝保持原 owner；停车后的不足或
失败保留原 parked archive，只有未清理的 physical slots 沿用 fail-stop。输入 snapshot、
恢复 arena、最终 recurrent bodies 与 one-block scratch 仍占资源；不据此证明完整重启。
公开 `Engine::restore_slot` 在排空既有 spill writer 后，使用 Core 拥有的普通只读文件映射
向上述 span 消费者供给输入，不先分配、读取另一份整文件 vector。映射 lease 覆盖只读
校验、全部 import 与已提交 H2D 完成；Native v6 的 Runtime/Raw/metadata、recurrent
checkpoints 和 StateImage，以及 Dense v3 的 state/KV，均由原 codec 复制到各自 owner，
不能将输入指针保留到调用返回后。缺失、空或不能映射的文件在进入 Program 前拒绝；
完整只读校验通过后，Program 在两次 Host 准入测量前调用 Engine 提供的 advisory
callback，Core 只回收该 clean 输入 mapping 的 resident pages，不关闭映射、解除
publication lease 或修改借用字节。Windows 对从未 lock 的 view 使用
[VirtualUnlock](https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-virtualunlock)，
POSIX 使用可用的 `MADV_DONTNEED`；后续访问从同一文件重新 fault。此操作不处理
模型权重、CUDA/pinned arena 或其他进程，也不把整文件长度加回可用量：仍以原生
OS physical/commit headroom 的新测量决定是否准入。无法回收或实际不足仍安全拒绝。
映射失败没有整文件 RAM fallback。Engine 的 `SlotSnapshotFiles` 将读取 lease 与显式/
后台 write-then-rename publication 分开于 spill queue mutex 管理：读取期间仍能 enqueue，
临时 capture 可独立完成，但发布必须等映射关闭后再检查高水位并 rename，不能用等待前的
stale guard 决定覆盖文件。
Windows 的 mapped destination 即使允许 read/delete sharing 也可能拒绝 rename replacement，
不能仅凭共享 flag 假定发布成功。读取 lease 始终消费已打开的同一份文件；不放宽 codec
校验或复制整文件来规避冲突。POSIX 使用只读 private mapping；两端均不 pin、mlock 或
主动预取整份输入。显式 save 的高水位更新也在同一 publication lease 内完成。
该机制借鉴 pinned llama 的 `llama_mmap`，是本地文件传输适配，不是改写 Native codec
或 mapped-Host 权重驻留。这里去掉整份输入的私有 RAM 副本，但 OS file pages、恢复
arena 和 scratch 仍占资源；不声称实际 Host peak、零 I/O、吞吐改善或 durable restart。
Engine 两个显式 restore 入口在 Program 成功或失败后均调用与 request exchange 相同的
absolute-summary reconciler，对账先前 owner 的 parked/Host placement、catalog capability
revision 与 SessionIndex。不能只登记新导入 handle 而延后旧 placement；不更换逻辑 owner
或另建目录。若 summary 不变量对账失败，它覆盖 import 的 request-local 错误；未能公布
的新导入 handle 通过既有 release 释放。

NInfer 的 Runtime CPU payload 采用本地扩展的 `KvMemCpuStorage` byte/slot 接口，每个
Runtime 独占其 storage，不能因共享 GPU backend 而共享 CPU slot 内容。逻辑 CPU 槽容量
保持 128K 输入规格，空槽只持有 bookkeeping；真正 stage-out 时才以 Core 的
`PinnedHostBuffer` 分配单块锁页内存。先准备 allocation，再改变 tier/source metadata；
同步 stage-in 或 truncate 后释放对应块，普通 CPU payload 不能退回 pageable fallback。
Native selection、packed bytes 与 snapshot wire 不变，非 NInfer backend 保留原固定 arena。
Runtime 仍使用完整 Runtime record，不伪装为 native SnapshotBuffer；RAM/restore footprint
计实际 populated buffers，公开 import preflight 另计该历史真正需要的 CPU blocks。
冷 Runtime import 的 `register_append` 只建立逻辑形状，尚未生成 GPU payload。导入器先把
所有未读 descriptors 标成无 payload 的 CPU placeholders，再逐块建立 counter-neutral
stage-in、复制已验证的 packed bytes、stage-out 到真实 CPU backing；不能让 native append
的默认 GPU tier 将尚未导入的后续块送入 stage-out。这些 placeholders 只存在于私有
construction；全部 block backing 与整文件 checksum 完成后才能发布可恢复 owner。
本地纯 planner 对 Raw chunks 与 Runtime 分别计量 transport、释放容量和恢复 scratch，并可在
同一会话内 write/read 交错；要求拆开这个 arena 的交换仍不可行。Endpoint StateImage、
prefix identity 和循环历史的逻辑 descriptor 留在现有 Program stores；循环 payload 可由
上述同一 Native chunks 持有。冷文件不是独立的 durable restart artifact。Source adaptation
与仍未验证的边界见 [KVMem provenance](../../integration/PROVENANCE.md)。

---

### 10.5 KVMem query 重选的 MTP 驻留前缀

Program 负责同一会话 query/cached-query 重选时的 follower 物理视图。所选且覆盖所需前缀的
GPU block 先取得独立只读页引用，再释放旧地址；这些块不为重选新建 Raw 副本。保留合同
使用实际 committed rows，不限于完整 128-token block；至多 64 行只保留第一页，第二个
handle 为空。最后一个 target row 尚待 bridge 时不计入 follower 的有效行。只有淘汰块和
真正的冷迁入块经过 packed Raw；所选且位于 replay begin 之后的 suffix 不做先写 Raw 再
立刻失效的临时复制，它由正常 replay 重新生成。

新视图按原始 block 顺序组合驻留页与冷块，execution frontier 是 compact，RoPE 与原始位置
不变。query 边界落在一个保留 block 内部时，完整前缀页共享，待写尾页使用既有 prefix-fork
COW；部分驻留块同样沿用有效行校验与 COW，冷的部分尾块只读取已提交的 packed rows，
不读取未提交后缀。最后一个 follower row
仍延后到既有 sampling/bridge，replay 的适用条件、recurrent checkpoint 与 MTP 接受状态机不变。

临时引用属于一次 Program transition，不是另一份会话存储或调度器。失败清理同步传输后才
释放页面；选块/物理转移的部分失败仍沿用 native fail-stop。此实现是对 pinned follower
`follow_retrieval` 保留驻留字节规则的 NInfer 页式适配，不声称两者的设备移动实现相同或已有
整模型 TTFT/TPS 证据。

目标 Raw 的正常生产写入只有 native mean-K 累计，不保存完整 pre-RoPE K/V rows；packed
目标 K/V 的存储权威是 Runtime tier。不能把 storage fixture 中显式填充的原始 K/V 当作生产
重复分配。follower Raw 保存原始位置对应的 packed GPU K/V，保留量按实际 allocations 计费。

### 10.6 KVMem owner 的正常清空与 arena 复用

正常 release/abort 在执行已排空、执行地址已释放后，原地调用 native Runtime
`truncate_to(0)` 和 target/follower Raw 的 `clear()`，清掉媒体、query、原始行位置和驻留 ID。
这沿用 pinned adapter `reset_policy` 的空 owner 语义，保留 Runtime 与 CPU slot bookkeeping，
释放已退役的锁页 CPU payload，不为每次正常终止分配或清零完整最大 Host 容量。
逻辑容量不变；权重、CUDA workspace 与固定 Host State 是独立的常驻占用，不算空会话 payload。
Windows 可以自行分页其他 pageable 工作集；本实现不终止、清空或修改其他进程，也不保证
超过实际 RAM 的锁页需求仍能成功。物理分配失败仍安全拒绝，不把页面文件伪装成锁页 RAM。

直接丢弃 pending batch/engine fail-all 可能绕过正常 cancelled commit。owner 清空前须显式
同步并丢弃尚在 capture 的 MTP verify，不能提交未接受的列，也不能带着 `Capturing` 状态重绑
Raw。已有 physical failure 或 unapplied plan 不使用健康 arena 复用路径；仍按既有截断、退役和
重新构建路径处理，任何部分清空失败继续 fail-stop，不发布可复用端点。

### 10.7 KVMem retrieval 的 query-only 计算

`score_kvmem_retrieval` 沿用 pinned `score_retrieval` 的逐 KV-head cosine、epsilon 与
head/layer 平均，不另建选块政策。一次评分中的 Q 对全部历史 block 相同，因此只计算一次
GQA 分组、FP32 均值和 Q 范数；每块仍通过 unchanged RawKvStore 读取 mean-K，独立计算
dot 和 K 范数。Q 分组累加、reciprocal multiply、坐标归约的 FP32 顺序不变，head/layer
仍按原顺序以 FP64 归约；有 Q 而缺 K 的 layer 仍计入平均分母。

Prepared Q 仅属于当前调用，不跨 query、会话或 snapshot 保留；count 为零的层不读取 stale
sum。这样移除 block 循环内的 Q-head 分配和重复计算，不修改 capture、原生 Store/Raw、
32K/16K 预算或检索 ranking。这是本地 source-guided 算法分解，不是整模型 TTFT/TPS 结论。

同一 canonical user/full-media 来源命中后，Program 对短续轮与稀疏长续轮都执行原生
cached-Q keep/reselect 的实际观察带与完整 future-append 容量证明。只有证明成功才
冻结 Q：继续使用 SessionMetadata 的完整已捕获 Q，并将 prefill capture workspace
的 query interval 置零，后续 segment 只采集 K。现有 Op 与 copy guards 因而不再执行
该续轮的 Q 特征 seed H2D、累加或 readback；attention 本身所需的 Q projection/RoPE
和全部模型 forward 照常执行。失败的 preview 不冻结，仍捕获完整 fresh suffix Q；
新的 canonical user 或变动媒体也不复用旧 Q。此规则直接适配 pinned
`run_prefill_multimodal` 的 `freeze_query(true)` / `query_contains`，不改变精度、RNG、
generation reserve、K 的 accepted-only 递推或 query checkpoint 保存。None/MTP 为
该本地 keep/reselect 路径支持的 backend，其他已有路径不被它隐式扩展。

### 10.8 KVMem 多块 prefill 与启动固定 capture

原生 128-token block 是存储/选块粒度，不是一次 forward 的 token 上限。Pinned
`prepare_working_set(n_new_tokens)` 登记整批 incoming rows，再运行一次原生 pressure
选择，不要求 pressure forward 只能有一个 block。Program 按已配置 prefill chunk、实际
媒体/逻辑边界与物理容量预览本批；对齐后的 no-pressure 和 pressure 批次均可跨多块。
部分尾块仍先完成当前 block，以保留旧页几何的交接；已证明的 query replay 走下述合同。

`preview_kvmem_prefill_append_tokens` 仅复制 unchanged Store 的 CPU metadata；没有复制
Raw、Runtime arena 或 GPU 页。实际高水位 predicate 为 true 时，先登记候选整批，再调用
原生 `pick_prefill_pressure_blocks`，要求全部 incoming IDs 被保留且总选块数不超过完整
物理 slots。原生 sink 或整组媒体造成候选超额/mandatory trim 时，减少一个新块后再预览；
候选缩短后不再触发 pressure 则沿用原生 no-pressure 路径，无一可行则在 live mutation
前返回零。不自行实现 sink/recency/media selector，也不把单张多余 64-token 页算成一个
native slot。先决定实际批长，再在 live Runtime 登记并预留全部 incoming 身份；既有
spill → detach → admit 顺序不变，未执行/harvest 的未来块不参与 spill。

原生 pressure 可以只保留 incoming batch，没有历史 prefix。实际 Text writer 此时从零
committed frontier 建立 active address，只取得精确 append entitlement，不伪造历史页或
对零长前缀调用共享 fork。MTP 同样安装零历史 writer；pressure harvest 只在其 committed
frontier 为零、resident coverage 与 outgoing 集合验证通过时允许空 map。正行数的缺失
记录仍报错。已有非空 prefix 的 sharing/COW、冷块 Raw 导入与同步提交规则不变。

`KVMemFeatureWorkspace` 借用启动计划中的 FP32 `[D,Hkv,S,L]` K block sums 与
`[D,Hq,1,L]` 一份 canonical Q sum，按原始逻辑 128-token 边界调用现有归约 Op。
每个 K block 分别写入 unchanged RawKvStore 的 mean sum；canonical Q 从已接受的一份
FP32 sum 接续逐 token 累加，部分 K 块也从 Native count+sum checkpoint 接续，不把
各 segment 的零起点小计相加。保留 head/坐标与 count，不合成一段大 Q reduction。
内部 Text/Vision tile 可以跨 native block，但不改变 accepted-only 的统计与发布边界。

一批接受后，`commit_kvmem_prefill_blocks` 接纳全部完整 target blocks；通常在 prompt 末尾
接纳未满块，部分尾块 pressure 前也须先发布其当前已接受的实际内容。调用方只
deactivate/reactivate 一次 target writer；follower 的每块 execution
begin 从本批 compact end 与原始位置差推导，不把所有块映射到末块坐标。最后一个 follower
row 的既有 deferred sampling 语义不变。已有物理 tail 可能经过媒体/query 子切分后才完成；
replace 使用实际已接纳的旧 tail 行数，而非误认最新逻辑尾长已全部接纳。

decode/prefill K/Q 与 MTP staged/reduction Tensor 都由 `PersistentLayout` 的同一 builder
分配并计入 Program device reservation；capture bridge 不另建 `DeviceBuffer`，图绑定地址
在 Program 生命周期内稳定。原生较小物理池的 effective prefill shape 在 minimum candidate
固定，新增 page group 不改变 capture/workspace shape 或打破 capacity curve 的 affine 合同。
native history 和 generation reserve 都按 128-token slot 取整；奇数张 64-token 页的余量不能
提供半个 native slot。正式 32K/16K 预算不变，dense 路径未改。

这是对 pinned batch/harvest 合同的本地页式适配，移除本地单块 capture/末块接纳造成的
forward 限制；它不修改 native 源码或数学 Op，也不表示不同 forward chunk 的整模型结果
逐位相同。尤其可能重新使用已获准的较宽 prefill execution route；精度许可、权重与采样
合同不变。检查范围和模型级未验证项见 [provenance](../../integration/PROVENANCE.md)。

### 10.9 KVMem 部分尾块 pressure 与 MTP 有效页前缀

原生 `prepare_working_set` 在 append 后统计 resident tokens 并调用 unchanged pressure
predicate；一个已有 GPU tail 的新行也计入该 resident 数量。NInfer 不再把这种 pressure
一律延后到整块边界：`prepare_partial_tail_pressure` 用同一 projected count 作决定，但
保持 Store 的旧逻辑 frontier 和尾长，当前尾块为 mandatory，媒体分组仍由原生 selector
决定。已证明的 cached-query pinned view 继续保持，不在生成/续轮中改用 recency 选块。

Program 在压力转移前先接纳当前 writer 已完成、尚未发布的尾行；不会先把 Store 尾长
改成将来 forward 的行数。沿用 native spill → detach → admit，再从所选完整块和当前
部分尾块建立 compact writable prefix，最后才登记/执行新行。原始 RoPE/media 坐标不变，
target 的共享可写尾页沿用既有 prefix-fork COW；物理转移部分失败仍 fail-stop。

Pinned MTP `follow_retrieval` 保留匹配的 resident block，部分块也适用。本地
`preserve_kvmem_prefill_follower` 在 Raw 写入前证明完整 source map 和 outgoing set，只将
淘汰的完整 follower blocks 写入 packed Raw；所选完整页与最后的部分页保留独立只读
引用和真实 committed row count。最多 64 行仅保留一页，第二 handle 无效；65..128 行
使用两页，不补造完整 follower 行，也不为这一重选往返复制 partial Raw。

混合前缀 assembler 可在 `store.total_tokens()` 的 accepted end 恢复全部已提交前缀，
或沿用 query boundary 前缀；retained logical rows 与物理 page coverage 均须满足所需
范围。共享部分页写入前 COW；没有 retained 页的 cold tail 仍只读取实际 packed Raw
前缀。NInfer prompt-final 的一行 deferred sampling/bridge 语义不变，不能把它归为原生
MTP Raw mirror 的规则。此压力路径处理的是已经同步提交的 target/follower 前缀。

这是 unchanged native pressure/resident 规则的本地所有权适配，不修改预算、权重、数学
Op 或增加第二套策略。source/build 与有限 GPU 检查的范围见
[provenance](../../integration/PROVENANCE.md)，不据此宣称整模型质量或 TPS。

### 10.10 KVMem known/control 多块提交与 decode frontier 交接

Pinned `prepare_working_set` 注册完整 incoming span；在 `retrieval_pinned/keep_selected`
期间不再运行 prefill recency pressure，新增输入使用生成 reserve。128-token 仍是存储
粒度，不是一次 known-token forward 的上限。原生 decode-mean 持有单个 pending ubatch
并只提交 accepted prefix；不能把跨多个 pending ubatches 的行数当成一个隐式提交。

NInfer `append_forced_tokens` 在固定 `prefill_chunk` 内执行全部已知输入。旧 sampled
token 和除最后一个外的 forced tokens 是 target 输入；最后 forced token 留在 ledger
尾部，作为 shifted MTP 的 next-token embedding，但尚未成为 target KV/mean-K 行。
此路径不调用 sampler 或推进 sampling RNG，query/检索选块仍保持当前 user 的 pinned view。

本地先 flush 已接受的 ordinary decode K tail，再把既有多块 prefill capture workspace
的 K frontier 同步到当前输入位置；本轮只捕获 K，不重算 canonical Q。旧部分 native
tail 仍先补到块边界，以保留现有 COW/页接纳顺序。对齐后的批次只按剩余完整 native
slot 和固定 capture/forward shape 截断，不拿 first-pass 高水位重新选择历史。
不足一个 native slot 的单张 64-token 页不能提供额外生成容量。

每个完全执行并同步的 known-input segment 沿用 `commit_kvmem_prefill_blocks`：接纳全部
完成的 target blocks、更新实际 compact follower records，结束时才发布短末块；不再只
接纳一批的最后块。原始 RoPE 坐标与紧凑执行位置分开，既有 prefix-fork COW 和失败
fail-stop 合同不变。提交后同步 ordinary decode 的 K frontier，MTP accepted-key frontier
在 control transaction 完成时交接；这些输入不会在下一轮再次捕获。

反向交接同样成立：MTP verify 只由 accepted-key owner 写入已接受 K rows；截断到
accepted end 并提交该 prefix 后，ordinary decode workspace 只更新其 frontier 标量，
以便下一次 known/control consumer 验证相同的 committed end。不能再次写入 accepted
K/mean-K，或把被拒绝的 provisional rows 当成已提交输入。

借用已有启动时规划的 prefill sums，不增加 device allocation，也不改变 ordinary CUDA
Graph 的单列捕获地址。数学 Op、权重精度、采样和正式 32K/16K 预算不变；构建与有界
检查范围见 [provenance](../../integration/PROVENANCE.md)，不据此宣称整模型质量或 TPS。

### 10.11 KVMem query replay 页所有权与多块批次

Pinned multimodal replay 在 native selection 后恢复 query boundary 的 recurrent/MTP
checkpoint，移除 query 起点后的 target/follower 逻辑行，并让 `set_replay(true)`
失效同一 original-coordinate 后缀的 packed K/V；block table、slot 和 mean-K 保留。
不能恢复 query 前状态后还读第一次执行的 query 页，也不能在 replay 时重算 canonical Q。

本地 `install_selected_for_replay` 先验证所选 query/observation 后缀完整且原始位置连续。
历史选择允许空隙，但它们必须位于 replay 起点之前；省略中间或最终 suffix block 的输入
在任何页变更前拒绝。先完成 selected prefix 与部分页 COW，再释放旧 query/suffix 的
native page refs，仅保留原有 native slot 身份与行数。其他 inactive view 仍拥有自己的
旧页引用；正在读取或 pinned 的旧 query 页阻止这一交接。

显式 replay reservation 没有可读的 GPU 页，不能 stage-out 或重新建立 selected view。
同步接受后，`commit_kvmem_prefill_blocks(replay=true)` 把本批全部完成块重新接入原有
slot；沿用正常 inactive writer 的 coverage、tail padding 与所有权检查，不分配重复的
旧 query backing。未完成整块的行仍只在 replay writer 中，末尾短块在实际结束时发布。
已发布的 slot 方可重新读取；失败沿用 Program 的 physical-transition fail-stop cleanup。

Query replay 不追加 Store 行，也不再次捕获 Q/K 统计。批长沿用固定 prefill shape、真实
媒体边界与 state/capture 分界，不再以 128-token 存储粒度截断；recurrent checkpoint、
原始 MRoPE、compact execution 和最后一行 MTP deferred bridge 合同不变。已证明的
cached-query suffix 也把 pinned 状态传给 read-only append bound，以实际剩余完整 slot
限长，不重新执行 first-pass pressure 策略。普通 first pass 沿用 10.8 的整批 pressure
admission，部分尾块沿用 10.9 的旧几何交接。

这是 upstream query-row invalidation 的本地页所有权适配，不改 native Store/Raw/selector，
不增加 device allocation 或改变正式 32K/16K 预算、权重、数学 Op 与采样。构建和有限检查
范围见 [provenance](../../integration/PROVENANCE.md)，不据此宣称模型 replay 质量或 TPS。

### 10.12 KVMem MTP 跨块 verify 与 accepted-prefix 发布

128-token native block 是存储/统计粒度，不是一个 MTP verify 的输入上限。一次 verify
只登记实际 anchor 与可用 draft 输入；Graph 的固定宽度和重复的无效列不增加 native
Store 行数。可用 draft 仍受请求输出预算、逻辑/物理容量和已有 verify window 约束。

`pinned_append_limit` 在任何 COW、登记或 forward 之前计算已固定工作集的真实增长范围：
剩余完整 native slots，加上已有 GPU 部分尾槽尚未占用的行。每个 resident block 占一个
完整 slot，奇数张 64-token 页不能提供半个新 slot；不足时缩短实际 verify 输入，不执行
first-pass pressure 或替代的 recent selection。普通 prefill/known-control 的部分尾批次
仍经 `prefill_append_limit` 先完成旧块；跨块 MTP 使用同一固定选择的完整 span 准入。

接受时先按实际 accepted input end 截去 target/follower Raw 与 native Store 的拒绝后缀，
原有 `KVMemMtpAcceptedKeys` 只归约接受列，并在 original-coordinate native 块边界拆分。
最后 sampled token 仍只在 ledger 中，尚未成为 target 输入或 mean-K。NInfer 既有
accepted-prefix 事务继续负责 GDN state、MTP carry、RNG 与 prefix identity。

提交/裁掉两个实际 writer 的拒绝行后，只 deactivate/reactivate 一次 target writer，
沿用 `commit_kvmem_prefill_blocks` 发布接受前缀内的全部完成块。旧的物理部分头块通过
实际 materialized row count 做 COW replacement；完成头块允许 writer 继续覆盖后续
已接受块，短尾块仍必须是 writer 的精确 committed end，且仅在 terminal 时发布。
非 terminal 的新短尾继续保持私有可写行，不冒充可读的 native slot。Follower map
继续按真实原始块位置与 compact prefix 重建，包括新短尾的实际 accepted row count。

完全拒绝的新块释放未绑定 slot；接受了一部分的新块保留其身份与实际尾长。页表 trim
先于 native 页发布，partial normalizer 不会把拒绝字节补成有效输入。可写共享尾页沿用
原来的 prefix-fork COW；异常仍按已有 Program physical-transition fail-stop 处理。

此变化移除本地 seam draft 截断与尾块专用提交限制，复用已有 Graph/capture/页提交，
不增加 device allocation，不改 native 源码、数学 Op、正式 32K/16K 预算、精度与采样。
构建和有界检查范围见 [provenance](../../integration/PROVENANCE.md)，不是整模型 MTP
质量、128K 或 TPS 验收。

## 11. 配置语义与有界性

`ContextCacheOptions` 在 Engine 构造时解析为固定容量：

| 配置轴 | 架构含义 |
|---|---|
| `device_state_slots` | active guarantee 之外可保留的 Device checkpoint StateImages |
| `host_state_slots` | 完整 Host StateImages |
| `host_kv_capacity_bytes` | typed packed Host KV arena 总容量 |
| `max_private_continuations` | private owner/catalog 容量 |
| `max_shared_prefixes` | shared immutable owner/catalog 容量 |
| `max_long_anchors_per_continuation` | 每条 private history 的 retained long checkpoints 上限 |

所有 stores、catalogs、Program unique-object scratch 和 reusable planner frontiers 都按解析后的上限建立。
每个 pressure planning session 的 target arena、hash 和 assessment storage 在 session 开始时按固定上限取得
容量；target expansion 不得突破该容量。Logical claim manifests 与 adoption 所需容量必须在 Program mutation
前取得。每请求 external markers 固定最多四个、Frontend candidates 固定最多三个、demand window 固定为
32；这些是产品语义与算法有界性，不是可调容量轴。
配置必须满足：

- private continuation capacity 至少覆盖全部 active requests；
- Device State 总容量为 `max_concurrency + device_state_slots`；
- Host State 与 Host KV 独立计费；
- logical counts、address-space counts 和 storage sizes 可表示；
- Program 可以兑现最小 active capacity 与 selected backend requirements。

Context cache disabled 时采用 root-only 语义：不读取或发布 inactive continuation，Device/Host checkpoint
容量为零，但 active execution 所需的 State/KV reservation 保持不变。

公开默认值和启动命令由 `EngineOptions`、[CLI](../cli.md)与 [Serving](../serving.md)维护，不在本架构
文档中复制。

---

## 12. 核心不变量

1. Scheduler 先选择 request；资源层不能以 cache value 改变请求顺序。
2. ResourceManager 是 logical cache policy 的唯一 authority，Program 是 physical state 的唯一 authority。
3. Physical occupancy 按 unique allocations 与 concrete reservations 计数，不按 logical references 重复计数。
4. Reclaim、Move/Fork 和 COW 必须从完整联合 post-state 推导。
5. 每个有序 transition stage 都必须满足容量与 allocator geometry。
6. Prefix hit 必须具有 exact identity、完整 StateImage 和全部 required typed KV coverage。
7. Published checkpoint immutable；每条 active continuation 至多一个 mutable writer。
8. Active completion reservation 在 terminal resource result 采用前不可被借用或回收。
9. 同一时刻至多一个 global resource transition，且 sealed plan 与 `resource_revision` 绑定。
10. Start 前 stale rejection 无物理副作用；start 后不能更换 candidate 或 target。
11. Program commit/abort 都返回完整稳定终态；ResourceManager adoption 已预分配且不能失败。
12. Root 加释放全部 unprotected inactive cache 是 bounded search 之外的 correctness fallback。
13. Planner 成本模型只排序可行 targets，不参与物理正确性。
14. Session binding 只接受更大的 publication order。
15. Retention 或 capture 失败必须退化为 skip/release，使 active lane 有有限终态。
16. Shared publication 必须严格优于 private-only baseline；单个 demand 对嵌套 prefixes 只能贡献一次最大
    saving。
17. Candidate selection 不是资源预留；实际 capture target 必须在 frontier 到达后按当前 revision 重新
    证明完整物理终态。

---

## 13. 实现位置

| 职责 | 主要位置 |
|---|---|
| logical catalog、claims、session policy | `src/runtime/engine/context_cache/resource_manager.h` |
| bounded target ledger 与 common search primitives | `src/runtime/engine/context_cache/resource_search.h` |
| cross-candidate bounded planner | `src/runtime/engine/context_cache/materialization_planner.h` |
| typed shared-capture bounded entrypoint | `src/runtime/engine/context_cache/shared_capture_planner.h` |
| shared/private portfolio value | `src/runtime/engine/context_cache/context_portfolio_value.h` |
| machine cost model | `src/runtime/engine/context_cache/context_cost.cpp` |
| prefill measurement signature | `src/models/qwen3_5/measurement.cpp` |
| common resource summaries | `src/runtime/contract/resources.h` |
| unique-object projection contract | `src/models/qwen3_5/program/planning/resource_projection.h` |
| target domain、projection 与 transaction | `src/models/qwen3_5/program/planning/`、`src/models/qwen3_5/program/transactions/` |
| State stores | `src/models/qwen3_5/program/storage/state_store.h` |
| logical KV/address spaces | `src/models/qwen3_5/program/storage/kv_store.h` |
| Host KV extents | `src/models/qwen3_5/program/storage/host_kv_store.h` |
| public capacity options | `include/ninfer/types.h` |

路径用于定位当前实现，不改变本文定义的所有权边界。
