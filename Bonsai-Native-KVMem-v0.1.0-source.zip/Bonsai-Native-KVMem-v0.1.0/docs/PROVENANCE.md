# Source provenance

This first distribution is a fresh source-only snapshot. It does not copy the
original repository's Git history, local identities, operational journals,
request traces or saved conversations.

## Native source

- Direct upstream: <https://github.com/JGamboa/ninfer-4090-windows>.
- Retained upstream reference: `feat/bonsai-ternary`.
- Local source HEAD before export: `318306c39461c5f14a88b89d404ee0fba7a06f28`.
- Uncommitted native/runtime/architecture changes and required new source files
  are included. The local HEAD above is a provenance identifier, not a promise
  that it can be checked out from the public upstream.
- Exact retained public base, changed-file inventory and dependency changes are
  recorded in [source-snapshot.json](../source-snapshot.json).
- A prominent downstream marker is added to changed code/document formats that
  permit comments; original attribution and license notices remain intact.

## Dependency pin

The engine-independent `kvmem/` directory comes from
<https://github.com/kvmem/kvmem-llama.cpp> at
`95a2155b75f41eada1398c86b19dcf9703581b30`.

It is vendored rather than represented by a Git submodule so the local demand
storage changes are not silently lost. Only that core is included; llama.cpp,
its adapters and large generated artifacts are not copied.

The pinned tree's original README, including its Apache-2.0 licensing statement,
is retained as [README.upstream.md](../third_party/kvmem/README.upstream.md).
Three dependency files contain local changes: `kvmem_backend.hpp`,
`kvmem_runtime.hpp` and `kvmem_runtime.cpp`. They are explicitly identified in the
snapshot inventory, not described as unchanged upstream code.

## Publication exclusions

No model weights, checkpoints, service/toolchain executables, dependency Git
metadata, API credentials, DSH profiles/application, raw run logs, journals,
memory notes or conversation/session caches are part of this distribution.
Small upstream example/benchmark media and source frequency fixtures retain
their original provenance; they are not user screenshots or runtime captures.

Other implementations of NInfer/KVMem fusion exist. The differing native page
mapping in this snapshot is an implementation choice, not evidence of exclusive
invention or a benchmark advantage.
