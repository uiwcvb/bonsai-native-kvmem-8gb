# Attribution and downstream modification notice

This is an experimental downstream integration snapshot, not an original implementation of NInfer or KVMem.

## NInfer lineage

- [Neroued/ninfer](https://github.com/Neroued/ninfer): the original C++/CUDA inference engine.
- [Don-Chad/ninfer-3090](https://github.com/Don-Chad/ninfer-3090): SM86 compatibility, ReplaySSM and runtime contributions credited by the Windows upstream.
- [sergiuszm/ninfer-4090](https://github.com/sergiuszm/ninfer-4090): Ada / SM89 downstream work.
- [UDPSendToFailed/ninfer-4090](https://github.com/UDPSendToFailed/ninfer-4090): E8-lattice KV contributions credited by the Windows upstream.
- [JGamboa/ninfer-4090-windows](https://github.com/JGamboa/ninfer-4090-windows): the direct Windows source base.

Original copyright, attribution and license notices are retained. The Apache-2.0 license text is supplied in `LICENSE`.

## KVMem

The engine-independent KVMem core is vendored from
`https://github.com/kvmem/kvmem-llama.cpp`, commit
`95a2155b75f41eada1398c86b19dcf9703581b30`.
The original README is retained as `third_party/kvmem/README.upstream.md`.
Its License section states that KVMem-qw3 source is Apache-2.0 and that this port
should be treated the same unless a LICENSE file is added upstream.
`third_party/kvmem/LICENSE.Apache-2.0` is a copy of the license text supplied for
convenience; it is not a claim to relicense any separately licensed component.

The three locally changed KVMem files are listed in `source-snapshot.json`.
They add private, demand-allocated CPU KV storage while retaining the dependency's
source identity. This distribution does not claim those files are byte-identical
to the upstream commit. llama.cpp and its adapters are not vendored here.

## Downstream changes

The native page-pair backend, ownership/adoption paths, demand CPU storage,
session/snapshot fixes and architecture-specific changes form this integration.
Changed source files carry a downstream notice where the file format permits;
the full changed-file inventory is in `source-snapshot.json`. Structured data
keeps its valid syntax, with modification provenance recorded in that inventory.

Other bundled header/source libraries retain their own license files, including
cpp-httplib, llama-jinja, nlohmann/json, spdlog and utf8proc. No endorsement by
their authors, model providers, NVIDIA, or DSH is implied.

Model weights, checkpoints, NVIDIA/toolchain binaries, chat histories and DSH
application code are not included and are not relicensed by this repository.
