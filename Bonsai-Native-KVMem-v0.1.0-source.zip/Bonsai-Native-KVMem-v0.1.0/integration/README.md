# Public integration entry point

This source distribution includes the native integration in `src/` and the
locally modified, pinned KVMem core in `third_party/kvmem/kvmem/`.

- [Overview and capacity contract](../README.md)
- [Technical route and native page integration](../docs/TECHNICAL-ROUTE.md)
- [Windows build and manual serving](../docs/BUILD-WINDOWS.md)
- [Validation boundaries](../docs/VALIDATION.md)
- [Source/dependency provenance](../docs/PROVENANCE.md)

Machine-local builders, absolute private paths, historical run directories,
journals and cached requests are intentionally not redistributed. Source
mechanism tests remain under `tests/`; this publication does not rerun GPU tests.
