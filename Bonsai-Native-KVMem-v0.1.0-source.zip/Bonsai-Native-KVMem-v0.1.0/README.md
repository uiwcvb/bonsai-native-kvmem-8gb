# Bonsai Native + KVMem · Windows / 8GB targets

面向 Windows 8GB 显卡的 **Bonsai 27B 三值模型 + NInfer 原生推理 + KVMem 长上下文**集成与部署项目。工作重点是衔接原生分页 KV、混合注意力/GDN 状态、历史检索、推测解码，以及网页 Agent 的工具调用与会话生命周期。

这是基于上游的工程适配，不是新模型，也不声称首次将 NInfer、Bonsai 与 KVMem 组合起来。**当前 Git 源码不包含模型权重、推理缓存、聊天记录、服务二进制或完整 DSH 离线环境。** 大型离线文件应放在 Releases；未实际上传的文件不列为可下载。

## 已有成绩

**128K 上下文配置，约 55 TPS。** 这是项目方提供的历史实测反馈。

128K 在这里指上下文配置，不自动代表该次请求实际填满 128K。完整复现记录仍需补充显卡/功耗、实际输入长度、MTP/Graph、采样参数和计时口径；此历史成绩不作为三个发布包已经完成同条件验收的证明。

## 三种发布目标

| 目标包 | GPU 架构 | 权重与配置关系 |
|---|---|---|
| RTX 4060 正常包 | Ada / SM89 | 原版 Bonsai 2 27B PTQ1_0，保留 Vision/MTP |
| RTX 4060 消融包 | Ada / SM89 | 消融 PTQ1_0；与正常包同引擎、同容量和运行参数，只更换权重及缓存身份 |
| RTX 5060 包 | Blackwell / SM120 | 独立架构引擎；完整档与手动小型回退档明确区分 |

这是发布目标表，**不是三个完整离线包都已上传或通过目标显卡验收的声明**。4060 是部署目标；当前维护机器实际为 RTX 4070 Laptop / SM8.9。不能把小型 5060 包改名为完整包，也不能混用两种架构的二进制。

## 技术路线

```text
原版 / 消融 Bonsai PTQ1_0 权重
              │ 保留张量格式和组件，转换为 v3 .ninfer
              ▼
     SM89 / SM120 架构专用 Native 引擎
              │ 原生 64-token 分页 KV + GDN 状态
              ▼
     128-token KVMem 块 ↔ 2 个 Native 页
              │ 按需 Host 存储 / 检索 / 页面直接接管 / 冷热会话
              ▼
    MTP 推测解码 + CUDA Graph（必须实际启用和验证）
              │
              ▼
       OpenAI 兼容本机 API → 网页 DSH / 工具调用
```

详细机制、代码入口和故障处理见 [技术路线说明](docs/TECHNICAL-ROUTE.md)。MTP 权重存在不代表进程已经启用 MTP；正常/消融包必须核对同一套显式运行配置。MTP、DFlash、DFlash2 是互斥后端，不能把所有开关同时打开。

## 这份实现有什么不同

- **原生页面桥接**：一个 KVMem 128-token 块映射为两个 NInfer 64-token 页，复用原生页面布局和引用计数。
- **直接接管预填充页面**：先预留槽身份，再接管模型真正写出的页面，避免这条路径重复分配 GPU 占位页；支持受检查的尾块增长与页面交接。
- **按需 CPU KV 存储**：为每个 Runtime 提供私有的 demand-allocated page-locked 存储，空槽不预先分配最大 KV 负载，消费、截断后释放相应负载。
- **混合状态与会话生命周期**：原生 KV、GDN 状态、检索、快照、冷热会话和失败清理在同一运行时路径中衔接。
- 保留 Windows 服务端、OpenAI 兼容接口和 SM89 / SM120 的架构特定适配代码；不同架构需要分别构建，不能混用二进制。

核心入口：[页面桥接](src/models/qwen3_5/program/storage/kvmem_page_backend.h)、[实现](src/models/qwen3_5/program/storage/kvmem_page_backend.cpp)、[按需存储接口](third_party/kvmem/kvmem/include/kvmem/kvmem_backend.hpp)。

## 默认容量的含义

| 项目 | 标准配置 |
|---|---:|
| 输入上限 | 131,072 token（128K） |
| GPU 检索历史预算 | 32,768 token（32K） |
| 单轮生成预留，含 thinking | 16,384 token（16K） |
| GPU KV 池 | 49,152 token（48K） |
| 逻辑总容量，输入＋生成 | 147,456 token |
| 并发 | 1 |

128K 是输入容量配置，不表示全部历史 KV 同时驻留显存，也不表示已证明任何任务的 128K 召回率或全量注意力等价性。单轮生成不能超过 generation reserve。

客户端必须把 `max_tokens` / `max_completion_tokens` 限制在 **16384 或以下**。服务端 `--default-max-tokens` 只对省略该字段的请求生效，不覆盖客户端明确发来的 32768。

## 消融权重

来源：[BoldingBuilds/Ternary-Bonsai-2-27B-Abliterated-PTQ1_0-GGUF](https://huggingface.co/BoldingBuilds/Ternary-Bonsai-2-27B-Abliterated-PTQ1_0-GGUF)，固定版本 `b5f8b912289f873f421e7cc6389d1bdda22b3721`。

本地转换仅移入第 15–63 层的 **98 个 writer 矩阵**，不重新量化；其余 **965 个原生对象逐字节不变**，保留 tokenizer、Vision 和 MTP，并为新权重隔离缓存身份。

作者模型卡明确提示该 PTQ1_0 消融版的 **thinking 不收尾风险**，建议先关闭 thinking；作者在其他运行时报告的 MTP 增益不是本 Native 实现的性能证明。这里不保证消融后能力、拒绝行为、视觉、工具可靠性或 TPS 与原版相同。

8GB 是目标显存档位，不是“任意 8GB 机器必能运行”的保证。模型、显示占用、CUDA workspace、CPU KV、系统提交额度都影响结果。标准档部署曾采用 **7400 MiB 空闲显存、温度低于 80°C** 的启动门槛；这些数值不是显存峰值测量。不要为了绕过报错直接去掉资源检查。

## 使用

1. 阅读 [Windows 构建步骤](docs/BUILD-WINDOWS.md)，准备 MSVC、CUDA、CMake、Ninja 与 vcpkg 依赖。
2. 自行获取具有使用权限、与该引擎兼容的 v3 `.ninfer` 模型。权重许可与引擎许可不同；本仓库不分发权重。
3. 按构建文档的示例手动启动服务。DSH 等客户端可使用 `http://127.0.0.1:18097/v1`，模型 ID 为 `bonsai-native`。

不会自动关闭其他应用、清理它们的工作集、修改页面文件、超频、改显示设置，或保证把模型强制锁在物理 RAM 中。

## 验证边界

2026-10-17，原工作树的 SM89 `ninfer-serve` 目标完成 720/720 构建，`--help` 正常退出，静态 CUDA ELF 检查为 `sm_89`。发布快照添加了来源/修改标识，没有重新运行 GPU 推理或极限测试。

2026-10-18 实际消融服务有过多轮生成；一次实时观察约 **35 token/s**，当时 GPU 为 **87°C 且温度降速激活，MTP 未开启**。这不是完整加速档成绩，不能与项目方历史约 55 TPS 直接对比，更不能据此承诺任意 4060 的速度。

**尚未在本次发布中验证**：发布目录重新构建、完整 DSH 任务链、持续 TPS、全进程内存峰值、完整 16K 输出、128K 召回质量，以及 RTX 5060 实机推理。SM120 适配代码和既往构建记录不等于完成 5060 硬件验收。

现有机制测试保留在 [tests](tests/README.md)，不将“测试文件存在”视作本次已执行。更多见 [验证记录](docs/VALIDATION.md)。不使用未经同条件比较的“4060 最快”或“更省内存百分比”宣传。

## 来源与许可

基于 [JGamboa/ninfer-4090-windows](https://github.com/JGamboa/ninfer-4090-windows)，保留 NInfer 及其 Windows / Ada / ReplaySSM 上游贡献；KVMem core 固定到 `95a2155b75f41eada1398c86b19dcf9703581b30`，附带本地按需存储修改。

源码许可和归属见 [LICENSE](LICENSE)、[NOTICE](NOTICE.md)、[来源清单](docs/PROVENANCE.md)。独立第三方目录保留各自许可，不能把模型或 DSH 的许可解释成 Apache-2.0。

已有公开同类：[ninfer-fusion-kvmem](https://github.com/1314521gjy/ninfer-fusion-kvmem)、[KVMem NInfer 迁移说明](https://github.com/kvmem/kvmem/blob/master/docs/ninfer-all-migration-plan.md)。本仓库强调具体实现与部署约束，不主张整条融合路线的排他性原创。

原项目使用说明保存在 [README.upstream.md](README.upstream.md)，其中 RTX 4090 等上游性能数据不属于本项目的 8GB 实测结果；遇到冲突以本页与本版验证边界为准。
