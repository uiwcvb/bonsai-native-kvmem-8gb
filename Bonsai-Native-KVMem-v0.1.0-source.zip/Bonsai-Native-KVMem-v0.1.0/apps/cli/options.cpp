// Modified in this downstream integration snapshot; see NOTICE.md and docs/PROVENANCE.md.
#include "options.h"
#include "product/speculative_options.h"

#include <cerrno>
#include <cmath>
#include <cstddef>
#include <cstdlib>
#include <limits>
#include <stdexcept>
#include <string_view>

namespace ninfer::cli {
namespace {

std::uint64_t parse_u64(const char* text, std::string_view label) {
    if (text == nullptr || *text == '\0' || *text == '-') {
        throw std::invalid_argument("invalid " + std::string(label) + ": " +
                                    (text == nullptr ? "" : text));
    }
    errno                          = 0;
    char* end                      = nullptr;
    const unsigned long long value = std::strtoull(text, &end, 10);
    if (errno == ERANGE || end == text || *end != '\0') {
        throw std::invalid_argument("invalid " + std::string(label) + ": " + text);
    }
    return static_cast<std::uint64_t>(value);
}

std::uint32_t parse_u32(const char* text, std::string_view label, bool allow_zero = false) {
    const std::uint64_t value = parse_u64(text, label);
    if ((!allow_zero && value == 0) || value > std::numeric_limits<std::uint32_t>::max()) {
        throw std::invalid_argument("invalid " + std::string(label) + ": " + text);
    }
    return static_cast<std::uint32_t>(value);
}

std::size_t parse_mib_bytes(const char* text, std::string_view label) {
    constexpr std::uint64_t bytes_per_mib = 1024ULL * 1024ULL;
    const std::uint64_t mib             = parse_u64(text, label);
    if (mib > std::numeric_limits<std::size_t>::max() / bytes_per_mib) {
        throw std::invalid_argument("invalid " + std::string(label) + ": " + text);
    }
    return static_cast<std::size_t>(mib * bytes_per_mib);
}

int parse_device(const char* text) {
    const std::uint64_t value = parse_u64(text, "device");
    if (value > static_cast<std::uint64_t>(std::numeric_limits<int>::max())) {
        throw std::invalid_argument(std::string("invalid device: ") + text);
    }
    return static_cast<int>(value);
}

float parse_float(const char* text, std::string_view label, float minimum, float maximum) {
    errno              = 0;
    char* end          = nullptr;
    const double value = std::strtod(text, &end);
    if (errno == ERANGE || end == text || *end != '\0' || !std::isfinite(value) ||
        value < static_cast<double>(minimum) || value > static_cast<double>(maximum)) {
        throw std::invalid_argument("invalid " + std::string(label) + ": " + text);
    }
    return static_cast<float>(value);
}

std::size_t parse_gib_bytes(const char* text, std::string_view label, bool allow_zero = false) {
    constexpr double bytes_per_gib = 1024.0 * 1024.0 * 1024.0;
    const double max_size_bytes  =
        std::ldexp(1.0, std::numeric_limits<std::size_t>::digits);
    const double max_gib         = max_size_bytes / bytes_per_gib;
    const float gib              = parse_float(text, label, 0.0F, static_cast<float>(max_gib));
    if (allow_zero && gib == 0.0F) { return 0; }
    const double bytes = static_cast<double>(gib) * bytes_per_gib;
    if (gib <= 0.0F || static_cast<double>(gib) >= max_gib || bytes < 1.0 ||
        bytes >= max_size_bytes) {
        throw std::invalid_argument("invalid " + std::string(label) + ": " + text);
    }
    return static_cast<std::size_t>(bytes);
}

KvCacheStorage parse_kv_cache(std::string_view text) {
    if (text == "bf16") { return KvCacheStorage::BFloat16; }
    if (text == "int8") { return KvCacheStorage::Int8Group64; }
    if (text == "fp8") { return KvCacheStorage::Fp8E4M3Row256; }
    if (text == "rk8v4") { return KvCacheStorage::RotatedInt8KeyInt4ValueGroup64; }
    if (text == "rk4v4") { return KvCacheStorage::RotatedInt4KeyInt4ValueGroup64; }
    if (text == "rk4v4-e8") { return KvCacheStorage::RK4V4E8; }
    if (text == "rk2v4-e8") { return KvCacheStorage::RK2V4E8; }
    if (text == "nvfp4") { return KvCacheStorage::Nvfp4Group16; }
    if (text == "k8v4") { return KvCacheStorage::Fp8KeyNvfp4Value; }
    throw std::invalid_argument("invalid kv-dtype: " + std::string(text));
}

KvCapacityPolicy parse_kv_capacity(const char* text) {
    if (std::string_view(text) == "auto") { return KvCapacityPolicy::automatic(); }
    return KvCapacityPolicy::explicit_capacity(parse_u32(text, "kv-capacity"));
}

ReasoningEffort parse_reasoning_effort(std::string_view text) {
    if (text == "none") { return ReasoningEffort::None; }
    if (text == "minimal") { return ReasoningEffort::Minimal; }
    if (text == "high") { return ReasoningEffort::High; }
    if (text == "max") { return ReasoningEffort::Max; }
    if (text == "low") { return ReasoningEffort::Low; }
    if (text == "medium") { return ReasoningEffort::Medium; }
    if (text == "xhigh") { return ReasoningEffort::XHigh; }
    throw std::invalid_argument("invalid reasoning-effort: " + std::string(text));
}

} // namespace

std::string usage_text(const char* argv0) {
    return std::string("usage: ") + argv0 +
           " <model.ninfer> (--prompt <text>|--messages <messages.json>)\n"
           "       [--max-context N] [--kv-capacity N|auto] [--prefill-chunk N] [--max-new N]\n"
           "       [--kvmem [--kvmem-history-budget N] [--kvmem-generation-reserve N]\n"
           "        [--kvmem-cpu-mib M] [--kvmem-compact-parked]\n"
           "        [--kvmem-session-cache-dir PATH --kvmem-session-disk-gb N\n"
           "         [--kvmem-session-ram-gb N]]]\n"
           "       [--device N]\n"
           "       [--kv-dtype bf16|int8|fp8|nvfp4|k8v4|rk8v4|rk4v4|rk4v4-e8|rk2v4-e8]\n"
           "       [--spec mtp|dflash|dflash2 --draft-tokens N]\n"
           "       [--lm-head-draft]\n"
           "       [--mapped-embedding] [--mapped-vision]\n"
           "       [--ngram chain [--ngram-max V] [--ngram-n N] [--ngram-min N]\n"
           "        [--ngram-pool-mib M]]\n"
           "       [--temperature F] [--top-p F] [--top-k N] [--min-p F]\n"
           "       [--presence-penalty F] [--frequency-penalty F] [--seed N] [--greedy]\n"
           "       [--stop-token-id N]... [--stop <text>]... [--reasoning-stop <text>]...\n"
           "       [--chat-template FILE]\n"
           "       [--raw-output] [--print-token-ids] [--no-thinking] [--thinking-budget N]\n"
           "       [--reasoning-effort none|minimal|low|medium|high|xhigh|max] [--vision]\n"
           "       [--vision-max-tokens N]\n"
           "       [--no-cuda-graph]\n"
           "       [--log-level trace|debug|info|warning|error|critical|off]\n"
           "\n"
           "Streams answer content to stdout and reasoning plus diagnostics to stderr.\n"
           "Structured message content accepts text, image/image_url, and video/video_url parts;\n"
           "media sources may be local paths, HTTP(S) URLs, or base64 data URIs.\n"
           "--vision enables image/video input and loads Vision weights on GPU unless "
           "--mapped-vision is set.\n"
           "--vision-max-tokens sets per-media-item Vision scratchpad capacity (default 8192).\n"
           "--mapped-embedding stores encoded input rows in mapped Host memory; GPU reads them "
           "on demand (experimental low-VRAM option).\n"
           "--mapped-vision stores Vision weights in mapped Host memory when --vision is set "
           "(experimental; image encoding may slow down).\n"
           "--thinking-budget caps model-origin thinking tokens; inserted control tokens count "
           "toward --max-new.\n"
           "--kv-capacity auto leaves " +
           std::to_string(kDefaultKvCapacityHeadroomBytes / (1024ULL * 1024ULL)) +
           " MiB of sizing headroom without KVMem; with KVMem it uses the aligned "
           "history plus generation budgets.\n"
           "--kvmem enables native KVMem (128K input plus the configured generation reserve, "
           "147456 total logical tokens by default; 32768 history and 16384 generation "
           "physical budgets). An explicit --max-context overrides the logical total.\n"
           "KVMem retains exact session endpoints only; optional rewrite, shared-prefix and "
           "long-anchor checkpoints are not published.\n"
           "--kvmem-cpu-mib overrides its CPU archive budget; zero uses the Engine Host KV default.\n"
           "--kvmem-compact-parked compacts parked archives in RAM when no session disk cache is set.\n"
           "--kvmem-session-cache-dir sets a cache root for native kvmem_session_files; pair it "
           "with positive --kvmem-session-disk-gb. Upstream creates a same-run private run-* "
           "directory and removes it on graceful exit; after a crash, stop the server before "
           "manually deleting orphans. No durable restart recovery.\n"
           "--kvmem-session-ram-gb sets a soft limit on measured native-session host RAM; zero or "
           "omitted is unlimited. Positive values require the session cache directory and disk "
           "budget. ResourceManager uses deterministic LRU selection among idle sessions, "
           "protecting the selected/active session. Disk snapshots are optional at the soft limit "
           "or on actual restore headroom pressure, not written on every park; I/O/quota failures "
           "retain the hot archive without generic eviction to work around the failed write. When "
           "a session cache is configured, native disk parking takes precedence over "
           "--kvmem-compact-parked.\n"
           "KVMem tuning flags require --kvmem.\n"
           "Sampling defaults come from the loaded model and thinking mode; flags override "
           "individual fields.\n";
}

Options parse_options(int argc, char** argv) {
    Options options;
    if (argc >= 2 && (std::string_view(argv[1]) == "--help" || std::string_view(argv[1]) == "-h")) {
        options.help_requested = true;
        return options;
    }
    if (argc < 2) { throw std::invalid_argument(".ninfer model path is required"); }
    options.artifact_path     = argv[1];
    bool kv_capacity_explicit = false;
    bool max_context_explicit = false;
    bool kvmem_tuning_explicit = false;

    for (int i = 2; i < argc; ++i) {
        const std::string_view arg(argv[i]);
        const auto value = [&](std::string_view flag) -> const char* {
            if (++i >= argc) { throw std::invalid_argument(std::string(flag) + " needs a value"); }
            return argv[i];
        };

        if (arg == "--prompt") {
            options.prompt = value(arg);
        } else if (arg == "--chat-template") {
            options.chat_template_path = value(arg);
        } else if (arg == "--messages") {
            options.messages_path = value(arg);
        } else if (arg == "--max-new") {
            options.max_new = parse_u32(value(arg), "max-new");
        } else if (arg == "--max-context") {
            options.max_context = parse_u32(value(arg), "max-context");
            max_context_explicit = true;
        } else if (arg == "--kv-capacity") {
            options.kv_capacity  = parse_kv_capacity(value(arg));
            kv_capacity_explicit = true;
        } else if (arg == "--kvmem") {
            options.kvmem.enabled = true;
        } else if (arg == "--kvmem-history-budget") {
            options.kvmem.history_budget_tokens = parse_u32(value(arg), "kvmem-history-budget");
            kvmem_tuning_explicit = true;
        } else if (arg == "--kvmem-generation-reserve") {
            options.kvmem.generation_reserve_tokens =
                parse_u32(value(arg), "kvmem-generation-reserve");
            kvmem_tuning_explicit = true;
        } else if (arg == "--kvmem-cpu-mib") {
            options.kvmem.cpu_bytes = parse_mib_bytes(value(arg), "kvmem-cpu-mib");
            kvmem_tuning_explicit = true;
        } else if (arg == "--kvmem-compact-parked") {
            options.kvmem.compact_parked_sessions = true;
            kvmem_tuning_explicit = true;
        } else if (arg == "--kvmem-session-cache-dir") {
            options.kvmem.session_cache_directory = value(arg);
            kvmem_tuning_explicit = true;
        } else if (arg == "--kvmem-session-disk-gb") {
            options.kvmem.session_disk_bytes =
                parse_gib_bytes(value(arg), "kvmem-session-disk-gb");
            kvmem_tuning_explicit = true;
        } else if (arg == "--kvmem-session-ram-gb") {
            options.kvmem.session_ram_bytes =
                parse_gib_bytes(value(arg), "kvmem-session-ram-gb", true);
            kvmem_tuning_explicit = true;
        } else if (arg == "--prefill-chunk") {
            options.prefill_chunk = parse_u32(value(arg), "prefill-chunk");
        } else if (arg == "--device") {
            options.device = parse_device(value(arg));
        } else if (arg == "--kv-dtype") {
            options.kv_cache = parse_kv_cache(value(arg));
        } else if (arg == "--spec") {
            options.speculative.backend = product::parse_speculative_backend(value(arg));
        } else if (arg == "--draft-tokens") {
            options.speculative.draft_tokens = parse_u32(value(arg), "draft-tokens");
        } else if (arg == "--lm-head-draft") {
            options.speculative.proposal_head = ProposalHead::Optimized;
        } else if (arg == "--mapped-embedding") {
            options.mapped_embedding = true;
        } else if (arg == "--mapped-vision") {
            options.mapped_vision = true;
        } else if (product::is_ngram_cli_flag(arg)) {
            const char* flag_value = value(arg);
            product::apply_ngram_cli_option(arg, flag_value, options.speculative.ngram);
        } else if (arg == "--raw-output") {
            options.raw_output = true;
        } else if (arg == "--print-token-ids") {
            options.print_token_ids = true;
        } else if (arg == "--no-thinking") {
            options.enable_thinking = false;
        } else if (arg == "--thinking-budget") {
            options.thinking_budget = parse_u32(value(arg), "thinking-budget");
        } else if (arg == "--reasoning-effort") {
            options.reasoning_effort = parse_reasoning_effort(value(arg));
        } else if (arg == "--vision") {
            options.enable_vision = true;
        } else if (arg == "--vision-max-tokens" || arg == "--vision-limit") {
            options.vision_max_tokens = parse_u32(value(arg), "vision-max-tokens", false);
            options.enable_vision     = true;
        } else if (arg == "--no-cuda-graph") {
            options.use_cuda_graph = false;
        } else if (arg == "--stop-token-id") {
            const std::uint32_t token = parse_u32(value(arg), "stop-token-id", true);
            if (token > static_cast<std::uint32_t>(std::numeric_limits<TokenId>::max())) {
                throw std::invalid_argument("--stop-token-id exceeds the token domain");
            }
            options.stop_token_ids.push_back(static_cast<TokenId>(token));
        } else if (arg == "--stop" || arg == "--reasoning-stop") {
            std::string text = value(arg);
            if (text.empty()) {
                throw std::invalid_argument(std::string(arg) + " must not be empty");
            }
            options.stop_strings.push_back(StopString{
                .text    = std::move(text),
                .channel = arg == "--stop" ? OutputChannel::Content : OutputChannel::Reasoning,
            });
        } else if (arg == "--temperature") {
            options.sampling.temperature = parse_float(value(arg), "temperature", 0.0F, 2.0F);
        } else if (arg == "--top-p") {
            options.sampling.top_p = parse_float(value(arg), "top-p", 0.0F, 1.0F);
        } else if (arg == "--top-k") {
            const std::uint32_t top_k = parse_u32(value(arg), "top-k", true);
            if (top_k > 20) { throw std::invalid_argument("--top-k must be in [0,20]"); }
            options.sampling.top_k = static_cast<std::int32_t>(top_k);
        } else if (arg == "--min-p") {
            options.sampling.min_p = parse_float(value(arg), "min-p", 0.0F, 1.0F);
        } else if (arg == "--presence-penalty") {
            options.sampling.presence_penalty =
                parse_float(value(arg), "presence-penalty", -2.0F, 2.0F);
        } else if (arg == "--frequency-penalty") {
            options.sampling.frequency_penalty =
                parse_float(value(arg), "frequency-penalty", -2.0F, 2.0F);
        } else if (arg == "--seed") {
            options.sampling.seed = parse_u64(value(arg), "seed");
        } else if (arg == "--greedy") {
            options.greedy = true;
        } else if (arg == "--log-level") {
            options.log_level = product::parse_log_level(value(arg));
        } else {
            throw std::invalid_argument("unknown argument: " + std::string(arg));
        }
    }

    if (!kv_capacity_explicit && !options.kvmem.enabled) {
        options.kv_capacity = KvCapacityPolicy::explicit_capacity(options.max_context);
    }

    const bool has_prompt   = !options.prompt.empty();
    const bool has_messages = !options.messages_path.empty();
    if (has_prompt == has_messages) {
        throw std::invalid_argument("pass exactly one of --prompt or --messages");
    }
    if (kvmem_tuning_explicit && !options.kvmem.enabled) {
        throw std::invalid_argument("KVMem tuning flags require --kvmem");
    }
    if ((options.kvmem.session_disk_bytes != 0) !=
        !options.kvmem.session_cache_directory.empty()) {
        throw std::invalid_argument(
            "KVMem session disk parking requires both --kvmem-session-cache-dir and "
            "positive --kvmem-session-disk-gb");
    }
    if (options.kvmem.session_ram_bytes != 0 &&
        (options.kvmem.session_cache_directory.empty() ||
         options.kvmem.session_disk_bytes == 0)) {
        throw std::invalid_argument(
            "a positive --kvmem-session-ram-gb requires --kvmem-session-cache-dir and "
            "positive --kvmem-session-disk-gb");
    }
    if (options.mapped_vision && !options.enable_vision) {
        throw std::invalid_argument("--mapped-vision requires --vision");
    }
    if (options.kvmem.enabled) {
        if (options.kvmem.history_budget_tokens == 0 ||
            options.kvmem.generation_reserve_tokens == 0) {
            throw std::invalid_argument("KVMem history and generation budgets must be positive");
        }
        if (!max_context_explicit) {
            const std::uint64_t logical =
                131'072ULL + options.kvmem.generation_reserve_tokens;
            if (logical > std::numeric_limits<std::uint32_t>::max()) {
                throw std::invalid_argument(
                    "KVMem 128K input plus generation reserve exceeds uint32 context capacity");
            }
            options.max_context = static_cast<std::uint32_t>(logical);
        }
        const auto aligned = [](std::uint32_t value, std::uint32_t granularity) -> std::uint64_t {
            return (static_cast<std::uint64_t>(value) + granularity - 1) /
                   granularity * granularity;
        };
        // Both budgets reserve whole native blocks, each spanning two 64-token KV pages.
        const std::uint64_t physical =
            aligned(options.kvmem.history_budget_tokens, kKVMemBlockTokens) +
            aligned(options.kvmem.generation_reserve_tokens, kKVMemBlockTokens);
        if (physical > std::numeric_limits<std::uint32_t>::max() ||
            physical > options.max_context) {
            throw std::invalid_argument(
                "KVMem physical budgets exceed the logical context or uint32 capacity");
        }
        if (!kv_capacity_explicit || options.kv_capacity.mode == KvCapacityMode::Automatic) {
            options.kv_capacity = KvCapacityPolicy::explicit_capacity(
                static_cast<std::uint32_t>(physical));
        } else if (options.kv_capacity.explicit_tokens < physical) {
            throw std::invalid_argument(
                "--kv-capacity cannot be smaller than KVMem history plus generation budgets");
        }
    }
    if (options.kvmem.enabled && options.kvmem.cpu_bytes == 0) {
        // The CLI disables ContextCache, so materialize the same Host KV default that
        // EngineOptions would otherwise transfer into the KVMem CPU archive.
        options.kvmem.cpu_bytes = ContextCacheOptions{}.host_kv_capacity_bytes;
    }
    if (options.prefill_chunk % 128 != 0) {
        throw std::invalid_argument("--prefill-chunk must be a multiple of 128");
    }
    if (!options.kvmem.enabled && options.kv_capacity.mode == KvCapacityMode::Explicit &&
        options.kv_capacity.explicit_tokens < options.max_context) {
        throw std::invalid_argument("--kv-capacity must be at least --max-context");
    }
    product::validate_speculative_cli_options(options.speculative);
    if (options.enable_thinking == false && options.reasoning_effort &&
        *options.reasoning_effort != ReasoningEffort::None) {
        throw std::invalid_argument("--reasoning-effort cannot be combined with --no-thinking");
    }
    if (options.reasoning_effort == ReasoningEffort::None) options.enable_thinking = false;
    if (options.enable_thinking == false && options.thinking_budget) {
        throw std::invalid_argument("--thinking-budget cannot be combined with --no-thinking");
    }
    if (options.greedy) { options.sampling.temperature = 0.0F; }
    return options;
}

} // namespace ninfer::cli
