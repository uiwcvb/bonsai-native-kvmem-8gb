param([Parameter(Mandatory)][string]$FirstPart)
$ErrorActionPreference='Stop'
$first=[IO.Path]::GetFullPath($FirstPart)
if(-not $first.EndsWith('.zip.001')){throw 'Select the .zip.001 part.'}
$prefix=$first.Substring(0,$first.Length-4)
$records=Get-Content -LiteralPath ($prefix+'.parts.json') -Raw|ConvertFrom-Json
if(Test-Path -LiteralPath $prefix){throw 'Joined ZIP already exists. It was not overwritten.'}
$drive=[IO.DriveInfo]::new([IO.Path]::GetPathRoot($prefix))
if($drive.AvailableFreeSpace -lt ($records.totalBytes+2GB)){throw 'Not enough disk for the joined ZIP plus 2 GiB reserve.'}
$target=[IO.File]::Open($prefix,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write)
try {
    foreach($part in $records.parts){
        $path=Join-Path (Split-Path $prefix -Parent) $part.name
        if([IO.Path]::GetFileName($part.name) -ne $part.name){throw 'Unsafe part name.'}
        if((Get-Item -LiteralPath $path).Length -ne $part.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $part.sha256){throw "Part failed verification: $($part.name)"}
        $input=[IO.File]::OpenRead($path);try{$input.CopyTo($target,1MB)}finally{$input.Dispose()}
    }
} finally {$target.Dispose()}
Write-Host "Joined and verified: $prefix"
Write-Host 'Extract this ZIP to a new folder, then read README.txt. Parts were not deleted.'
