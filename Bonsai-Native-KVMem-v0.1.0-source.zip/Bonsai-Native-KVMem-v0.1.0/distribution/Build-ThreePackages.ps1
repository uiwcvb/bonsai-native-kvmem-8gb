param(
    [Parameter(Mandatory)][string]$TemplateRoot,
    [Parameter(Mandatory)][string]$Sm89Exe,
    [Parameter(Mandatory)][string]$Sm120Exe,
    [Parameter(Mandatory)][string]$OriginalModel,
    [Parameter(Mandatory)][string]$AblatedModel,
    [Parameter(Mandatory)][string]$OutputDirectory,
    [switch]$CheckOnly
)
$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -lt 7){throw 'Build with PowerShell 7; target packages include their own runtime.'}
$template=(Resolve-Path -LiteralPath $TemplateRoot).Path.TrimEnd('\')
$output=[IO.Path]::GetFullPath($OutputDirectory)
$profiles=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'profiles.json') -Raw|ConvertFrom-Json -AsHashtable
$prior=Get-Content -LiteralPath (Join-Path $template 'manifest.json') -Raw|ConvertFrom-Json -AsHashtable
if($prior.gpuComputeCapability -ne '12.0' -or $prior.gpuHistoryTokens -ne 16384 -or $prior.maxInputTokens -ne 131072){throw 'Unexpected source template; no source files were changed.'}
foreach($file in @($Sm89Exe,$Sm120Exe,$OriginalModel,$AblatedModel)){if(-not(Test-Path -LiteralPath $file -PathType Leaf)){throw "Missing input: $file"}}
if($profiles.runtime.historyTokens -ne 32768 -or $profiles.runtime.gpuPoolTokens -ne 49152 -or $profiles.runtime.speculativeBackend -ne 'mtp' -or $profiles.runtime.draftTokens -ne 1 -or -not $profiles.runtime.cudaGraph){throw 'Incomplete shared runtime contract.'}
New-Item -ItemType Directory -Path $output -Force|Out-Null
Add-Type -Path (Join-Path $PSScriptRoot 'ReleaseStreams.cs')
$utf8=[Text.UTF8Encoding]::new($true)
$overlayRoot=Join-Path $output 'package-overlays'
New-Item -ItemType Directory -Path $overlayRoot -Force|Out-Null
$overrides=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::OrdinalIgnoreCase)
function Put-Overlay([string]$Relative,[string]$Text){
    $path=Join-Path $overlayRoot $Relative
    New-Item -ItemType Directory -Path (Split-Path $path -Parent) -Force|Out-Null
    [IO.File]::WriteAllText($path,$Text,$utf8)
    $overrides[$Relative]=$path
}
function Read-Template([string]$Relative){return [IO.File]::ReadAllText((Join-Path $template $Relative))}
function Replace-Required([string]$Text,[string]$Old,[string]$New){
    if(-not $Text.Contains($Old)){throw "Template no longer matches required edit: $Old"}
    return $Text.Replace($Old,$New)
}
$text=Read-Template 'launcher/Bonsai-Recovery.ps1'
$text=Replace-Required $text 'MaxContext=147456; History=16384; Output=16384; PhysicalKv=32768;' 'MaxContext=147456; History=32768; Output=16384; PhysicalKv=49152;'
$text=$text.Replace('小型：128K 输入 / GPU 16K 历史 + 16K 输出','完整：128K 输入 / GPU 32K 历史 + 16K 输出').Replace('StartupFreeMiB=7100','StartupFreeMiB=7400')
Put-Overlay 'launcher/Bonsai-Recovery.ps1' $text
$text=Read-Template 'launcher/Start-Bonsai-DSH.ps1'
$text=Replace-Required $text "'--kv-dtype', 'rk4v4-e8', '--no-cuda-graph'," "'--kv-dtype', 'rk4v4-e8', '--spec', 'mtp', '--draft-tokens', '1',"
$text=Replace-Required $text "'--prefill-chunk', '256'" "'--prefill-chunk', '512'"
Put-Overlay 'launcher/Start-Bonsai-DSH.ps1' $text
$text=Read-Template 'launcher/Bonsai-Gpu-Safety.ps1'
$old="if (`$owner.CommandLine -notmatch '--no-cuda-graph\b' -or `$owner.CommandLine -notmatch '--prefill-chunk\s+256\b' -or `$owner.CommandLine -match '--spec\s') {"
$new="if (`$owner.CommandLine -match '--no-cuda-graph\b' -or `$owner.CommandLine -notmatch '--prefill-chunk\s+512\b' -or `$owner.CommandLine -notmatch '--spec\s+mtp\b' -or `$owner.CommandLine -notmatch '--draft-tokens\s+1\b') {"
$text=Replace-Required $text $old $new
$text=$text.Replace('This model is still using the old high-load profile. Stop it first, then start again with the updated launcher.','The running model does not match the explicit full MTP1 / CUDA Graph profile. Stop it explicitly before switching.')
$text=Replace-Required $text "if (`$owner.CommandLine -match '--no-cuda-graph\b' -and `$owner.CommandLine -match '--prefill-chunk\s+256\b') {" "if (`$owner.CommandLine -match '--spec\s+mtp\b' -and `$owner.CommandLine -match '--prefill-chunk\s+512\b') {"
Put-Overlay 'launcher/Bonsai-Gpu-Safety.ps1' $text
$text=Read-Template 'launcher/Bonsai-Ayame-Control.ps1'
$text=$text.Replace('百鬼 · 5060 小型版（128K 输入）','百鬼 · 完整版（128K / 32K 历史 / 16K 输出 / MTP1）').Replace('切回小型版','切回完整档').Replace('档位：小型版 /','档位：完整档 /')
Put-Overlay 'launcher/Bonsai-Ayame-Control.ps1' $text
$text=Read-Template 'config/dsh.yml'
$text=$text.Replace('GPU 16K+16K','GPU 32K+16K').Replace('GPU 16K+16K, MTP off','GPU 32K+16K, MTP1').Replace('MTP off','MTP1 + CUDA Graph')
Put-Overlay 'config/dsh.yml' $text
$text=Read-Template 'config/dsh-safe.yml'
Put-Overlay 'config/dsh-safe.yml' ($text.Replace('MTP off','MTP1 + CUDA Graph'))
$text=Read-Template 'launcher/Verify-5060-128K.mjs'
$text=$text.Replace('16K GPU history + 16K generation reserve','32K GPU history + 16K generation reserve').Replace('initial.kv.capacity_tokens, 32768','initial.kv.capacity_tokens, 49152')
Put-Overlay 'launcher/Verify-5060-128K.mjs' $text
$text=Read-Template 'launcher/Teacher-Preflight.ps1'
Put-Overlay 'launcher/Teacher-Preflight.ps1' ($text.Replace('27B compact / 128K-input','27B full / 128K-input').Replace('27B / 32K GPU-cache','27B / 48K GPU-cache'))
$readme=@'
Bonsai Native + KVMem: full runtime release candidate
===================================================
Three variants: RTX 4060 stock (SM89), RTX 4060 ablated (SM89), RTX 5060 stock (SM120).
The manifest identifies this package. Never replace an architecture check with a bypass.

Default: 128K input, 32K selected GPU history, 16K output, 48K GPU KV pool;
147456 total logical tokens; one active request; RK4V4-E8; MTP1; CUDA Graph;
mapped embedding and Vision; demand-allocated CPU history; session parking.
Both SM89 variants use the same binary and runtime settings, differing only in
weights, model provenance and native artifact/cache identity.

1. Extract into a NEW folder. Do not overlay a different weight or architecture package.
2. Run Setup-Environment.cmd, then Check.cmd. Follow real resource errors.
3. Start.cmd starts model + web DSH. Control.cmd opens the Ayame start/stop panel.
4. Use Stop.cmd / the control panel to release services. Closing a browser is not stopping services.
5. DSH: http://127.0.0.1:3080/ ; API: http://127.0.0.1:18097/v1 ; model: bonsai-native.
6. Limit client max_tokens/max_completion_tokens to 16384. Thinking shares this budget.

Safe.cmd is an EXPLICIT smaller capacity, not an automatic fallback. MTP1/Graph
remain enabled; if resources are insufficient, the package reports failure.
The retained GPU guard can stop THIS package's model at its documented safety
threshold. It never kills other apps or changes global clocks/power/display/paging.

Historical project-owner report: 128K context configuration, about 55 TPS.
This does not establish a 128K-filled request, same-condition reproduction,
all-variant sustained speed, or RTX 4060/5060 hardware qualification.
These full MTP1/Graph packages are configuration-checked release candidates.
No GPU stress test or target-hardware qualification is performed by packaging.

ABLATION NOTE: the pinned upstream PTQ1_0 ablation reports runaway thinking;
use DSH's thinking Off setting when evaluating that behavior. Native preserves
Vision/MTP objects, but performance/quality need an actual same-condition comparison.

Chat data, personal tool credentials, user files and prior run logs are excluded.
New installations create data/workspace/cache locally; do not publish those folders.
Reusing an existing installation requires preserving its data and tool configuration.

Source: https://github.com/uiwcvb/bonsai-native-kvmem-8gb
Read TECHNICAL-ROUTE.md and the included licenses; record the actual runtime
command line, MTP counters, temperature and workload when reporting throughput.
'@
Put-Overlay 'README.txt' $readme
Put-Overlay 'DEPLOY-FIRST.txt' $readme
Put-Overlay 'SM120-DEPLOYMENT.txt' $readme
Put-Overlay 'CHECK-START.txt' $readme
Put-Overlay 'TECHNICAL-ROUTE.md' ([IO.File]::ReadAllText((Join-Path $PSScriptRoot '..\docs\TECHNICAL-ROUTE.md')))
Put-Overlay 'Check-Small-And-Start.cmd' "@echo off`r`necho This is the full 32K-history package. Use Check.cmd, Start.cmd or Control.cmd.`r`npause`r`n"
$parseFailures=@()
foreach($path in $overrides.Values|Where-Object {$_ -like '*.ps1'}){
    $tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
    if($errors.Count){$parseFailures+=$errors}
}
if($parseFailures.Count){throw($parseFailures|Out-String)}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Join-Package.ps1') -Destination (Join-Path $output 'Join-Package.ps1') -Force
$runtimeJson=$profiles.runtime|ConvertTo-Json -Compress
$contractHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($runtimeJson))).ToLowerInvariant()
if($CheckOnly){[pscustomobject]@{Check='PASS';Variants=@($profiles.variants.id);ContractHash=$contractHash;Mtp=1;CudaGraph=$true;GpuHistory=32768;WeightsUnchanged=$true;StartedServices=$false}|ConvertTo-Json;exit 0}
$estimated=3*($prior.uncompressedBytesExcludingManifest+150MB)+2GB
if(([IO.DriveInfo]::new([IO.Path]::GetPathRoot($output))).AvailableFreeSpace -lt $estimated){throw 'Not enough disk for three full packages plus reserve; no existing packages were deleted.'}
$buffer=[byte[]]::new(1MB)
$allResults=[Collections.Generic.List[object]]::new()
foreach($variant in $profiles.variants){
    $prefix=Join-Path $output ('Bonsai-'+$variant.id+'-full-v0.1.0.zip')
    if(Test-Path -LiteralPath ($prefix+'.001')){throw 'Package parts already exist; not overwriting.'}
    $inputs=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach($record in $prior.files){
        if($record.path -in @('COMPACT-UPDATE.txt','Check-Small-And-Start.cmd','manifest.json')){continue}
        if($record.path -match '^(?:data|workspace|cache)/|^launcher/(?:launcher-logs|previous)/'){throw "Operational data in template manifest: $($record.path)"}
        $inputs[$record.path]=Join-Path $template $record.path
    }
    foreach($key in $overrides.Keys){$inputs[$key]=$overrides[$key]}
    $exe=if($variant.computeCapability -eq '8.9'){$Sm89Exe}else{$Sm120Exe}
    $inputs['bin/native/ninfer-serve.exe']=$exe
    foreach($dll in Get-ChildItem -LiteralPath (Split-Path $exe -Parent) -Filter '*.dll' -File){$inputs['bin/native/'+$dll.Name]=$dll.FullName}
    $inputs['models/bonsai.ninfer']=if($variant.weight -eq 'ablated'){$AblatedModel}else{$OriginalModel}
    $records=[Collections.Generic.List[object]]::new()
    $stream=[ReleasePartWriter]::new($prefix,1500MB)
    $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
    $bytes=0L;$progress=[Diagnostics.Stopwatch]::StartNew()
    try{
        foreach($key in $inputs.Keys|Sort-Object){
            if($key.Contains('..') -or $key.Contains('\') -or $key.StartsWith('/')){throw "Unsafe archive path: $key"}
            $entry=$zip.CreateEntry('Bonsai/'+$key,[IO.Compression.CompressionLevel]::NoCompression)
            $target=$entry.Open();$source=[IO.File]::OpenRead($inputs[$key]);$hash=[Security.Cryptography.IncrementalHash]::CreateHash([Security.Cryptography.HashAlgorithmName]::SHA256);$size=0L
            try{while(($n=$source.Read($buffer,0,$buffer.Length)) -gt 0){$target.Write($buffer,0,$n);$hash.AppendData($buffer,0,$n);$size+=$n};$digest=[Convert]::ToHexString($hash.GetHashAndReset()).ToLowerInvariant()}finally{$target.Dispose();$source.Dispose();$hash.Dispose()}
            if($key -eq 'models/bonsai.ninfer' -and $digest -ne $variant.weightSha256){throw 'Model hash mismatch; artifact was not repackaged as another model.'}
            $records.Add(@{path=$key;bytes=$size;sha256=$digest});$bytes+=$size
            if($progress.Elapsed.TotalSeconds -gt 15){Write-Host ($variant.id+': packed '+[math]::Round($bytes/1GB,2)+' GiB');$progress.Restart()}
        }
        $manifest=@{package='Bonsai-'+$variant.id;variant=$variant.id;gpuComputeCapability=$variant.computeCapability;maxInputTokens=131072;maxOutputTokens=16384;logicalContextTokens=147456;gpuHistoryTokens=32768;gpuGenerationReserveTokens=16384;gpuPoolTokens=49152;runtime=$profiles.runtime;runtimeContractSha256=$contractHash;modelIncluded=$true;runtimeDataIncluded=$false;targetHardwareQualified=$false;fullRuntimeQualified=$false;configurationParityChecked=$true;historicalPerformance=$profiles.historicalPerformance;files=$records;fileCountExcludingManifest=$records.Count;uncompressedBytesExcludingManifest=$bytes;createdAt=(Get-Date).ToUniversalTime().ToString('o')}
        $manifestText=$manifest|ConvertTo-Json -Depth 15
        $entry=$zip.CreateEntry('Bonsai/manifest.json',[IO.Compression.CompressionLevel]::NoCompression);$writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false));try{$writer.Write($manifestText)}finally{$writer.Dispose()}
    }finally{$zip.Dispose();$stream.Dispose()}
    $parts=@(Get-ChildItem -LiteralPath $output -File|Where-Object {$_.Name -match ('^'+[regex]::Escape([IO.Path]::GetFileName($prefix))+'\.\d{3}$')}|Sort-Object Name)
    $joined=[ReleasePartReader]::new([string[]]$parts.FullName)
    $archive=[IO.Compression.ZipArchive]::new($joined,[IO.Compression.ZipArchiveMode]::Read,$true)
    try{
        if($archive.Entries.Count -ne $records.Count+1){throw 'Archive entry count mismatch.'}
        foreach($record in $records){$entry=$archive.GetEntry('Bonsai/'+$record.path);if(-not $entry -or $entry.Length -ne $record.bytes){throw 'Archive entry size mismatch.'};$input=$entry.Open();try{$digest=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($input)).ToLowerInvariant()}finally{$input.Dispose()};if($digest -ne $record.sha256){throw "Archive verification failed: $($record.path)"}}
    }finally{$archive.Dispose();$joined.Dispose()}
    $partRecords=@(foreach($part in $parts){@{name=$part.Name;bytes=$part.Length;sha256=(Get-FileHash -LiteralPath $part.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}})
    $result=@{variant=$variant.id;parts=$partRecords;totalBytes=($parts|Measure-Object Length -Sum).Sum;runtimeContractSha256=$contractHash;engineSha256=($records|Where-Object path -eq 'bin/native/ninfer-serve.exe').sha256;modelSha256=$variant.weightSha256;filesVerified=$records.Count;archiveVerified=$true;fullRuntimeQualified=$false;targetHardwareQualified=$false}
    [IO.File]::WriteAllText($prefix+'.parts.json',($result|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
    $allResults.Add($result)
    Write-Host ($variant.id+': archive verified; '+$parts.Count+' parts; no inference test was run.')
}
if($allResults[0].engineSha256 -ne $allResults[1].engineSha256 -or @($allResults.runtimeContractSha256|Select-Object -Unique).Count -ne 1){throw 'Normal/ablated binary or shared runtime contract diverged.'}
[IO.File]::WriteAllText((Join-Path $output 'release-index.json'),(@{variants=$allResults;sourceRepository='https://github.com/uiwcvb/bonsai-native-kvmem-8gb';verifiedAt=(Get-Date).ToUniversalTime().ToString('o');published=$false}|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))
$allResults|Select-Object variant,totalBytes,filesVerified,archiveVerified,fullRuntimeQualified,targetHardwareQualified|ConvertTo-Json
