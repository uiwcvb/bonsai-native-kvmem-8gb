// Split a regular ZIP byte stream into assets below GitHub's 2 GiB limit.
// This is byte concatenation, not the legacy multi-disk ZIP format.
using System;
using System.IO;
using System.Linq;

public sealed class ReleasePartWriter : Stream {
    readonly string prefix; readonly long limit; FileStream current;
    long position; int index;
    public ReleasePartWriter(string prefix, long limit) { this.prefix=prefix; this.limit=limit; }
    void Next() { current?.Dispose(); current=new FileStream(prefix+"."+(++index).ToString("D3"),FileMode.CreateNew,FileAccess.Write,FileShare.Read); }
    public override void Write(byte[] buffer,int offset,int count) {
        while(count>0) { if(current==null || current.Length==limit) Next(); int n=(int)Math.Min(count,limit-current.Length); current.Write(buffer,offset,n); offset+=n; count-=n; position+=n; }
    }
    public override bool CanRead=>false; public override bool CanSeek=>false; public override bool CanWrite=>true;
    public override long Length=>position; public override long Position {get=>position;set=>throw new NotSupportedException();}
    public override void Flush()=>current?.Flush();
    protected override void Dispose(bool disposing) {if(disposing) current?.Dispose();base.Dispose(disposing);}
    public override int Read(byte[] b,int o,int c)=>throw new NotSupportedException();
    public override long Seek(long o,SeekOrigin s)=>throw new NotSupportedException();
    public override void SetLength(long n)=>throw new NotSupportedException();
}

public sealed class ReleasePartReader : Stream {
    readonly string[] paths; readonly long[] starts; readonly long length;
    FileStream current; int index=-1; long position;
    public ReleasePartReader(string[] paths) {
        this.paths=paths; starts=new long[paths.Length]; long total=0;
        for(int i=0;i<paths.Length;i++){starts[i]=total;total+=new FileInfo(paths[i]).Length;}
        length=total;
    }
    public override int Read(byte[] b,int o,int count) {
        if(position>=length || count==0)return 0; int wanted=count;
        while(count>0 && position<length){
            int i=Array.BinarySearch(starts,position);if(i<0)i=~i-1;
            if(index!=i){current?.Dispose();current=File.OpenRead(paths[i]);index=i;}
            current.Position=position-starts[i];int n=current.Read(b,o,(int)Math.Min(count,current.Length-current.Position));
            if(n==0)throw new EndOfStreamException();position+=n;o+=n;count-=n;
        }return wanted-count;
    }
    public override long Seek(long offset,SeekOrigin origin) {long p=origin==SeekOrigin.Begin?offset:origin==SeekOrigin.Current?position+offset:length+offset;if(p<0 || p>length)throw new IOException("Seek outside archive");return position=p;}
    public override bool CanRead=>true;public override bool CanSeek=>true;public override bool CanWrite=>false;
    public override long Length=>length;public override long Position {get=>position;set=>Seek(value,SeekOrigin.Begin);}
    public override void Flush(){}
    protected override void Dispose(bool disposing){if(disposing)current?.Dispose();base.Dispose(disposing);}
    public override void Write(byte[] b,int o,int c)=>throw new NotSupportedException();
    public override void SetLength(long n)=>throw new NotSupportedException();
}
